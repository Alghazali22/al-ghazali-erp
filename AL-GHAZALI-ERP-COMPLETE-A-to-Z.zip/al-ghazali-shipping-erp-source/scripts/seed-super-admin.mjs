/**
 * Seed temporary super_admin:
 *   username: admin
 *   password: 123456
 *
 * Usage (from project root, with DATABASE_URL set):
 *   node scripts/seed-super-admin.mjs
 */
import { randomBytes, scryptSync } from "node:crypto";
import pg from "pg";

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("DATABASE_URL is required");
  process.exit(1);
}

const USERNAME = process.env.SEED_ADMIN_USERNAME || "admin";
const PASSWORD = process.env.SEED_ADMIN_PASSWORD || "123456";
const FULL_NAME = process.env.SEED_ADMIN_NAME || "المدير الأعلى";

function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

const client = new pg.Client({ connectionString: DATABASE_URL });

async function main() {
  await client.connect();
  const passwordHash = hashPassword(PASSWORD);

  const existing = await client.query(
    `SELECT id, username, role, is_active FROM users WHERE username = $1 LIMIT 1`,
    [USERNAME],
  );

  if (existing.rows.length) {
    const row = existing.rows[0];
    await client.query(
      `UPDATE users
       SET password_hash = $1,
           role = 'super_admin',
           full_name = $2,
           is_active = true
       WHERE id = $3`,
      [passwordHash, FULL_NAME, row.id],
    );
    console.log(`Updated existing user #${row.id}:`);
  } else {
    const inserted = await client.query(
      `INSERT INTO users (username, password_hash, full_name, role, is_active)
       VALUES ($1, $2, $3, 'super_admin', true)
       RETURNING id, username, role`,
      [USERNAME, passwordHash, FULL_NAME],
    );
    console.log(`Created user #${inserted.rows[0].id}:`);
  }

  console.log(`  username : ${USERNAME}`);
  console.log(`  password : ${PASSWORD}`);
  console.log(`  role     : super_admin`);
  console.log(`  name     : ${FULL_NAME}`);
  console.log("");
  console.log("⚠️  كلمة المرور مؤقتة — غيّرها من داخل النظام بعد أول دخول.");
}

main()
  .catch((err) => {
    console.error("Seed failed:", err.message || err);
    process.exit(1);
  })
  .finally(() => client.end());
