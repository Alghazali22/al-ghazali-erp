# نظام الغزالي للشحن — نسخة كاملة جاهزة (من الألف إلى الياء)

هذه الحزمة مبنية على **v6** الكاملة + تحسينات:
- اللوجو الرسمي + خلفية 3D لشاشة الدخول
- إثبات التسليم (صورة + توقيع المستلم)
- إشعارات SMS / WhatsApp جاهزة للتفعيل بمفاتيح المزود
- OTP محسّن (قفل محاولات + إرسال للعميل عند الإنشاء)

---

## 1) رفع المشروع على Replit

1. أنشئ مشروع **Node.js** جديد (أو استبدل مشروعك الحالي).
2. ارفع **كل محتويات** مجلد `al-ghazali-shipping-erp-source` إلى جذر المشروع.
3. تأكد أن `package.json` و`pnpm-workspace.yaml` في الجذر.

## 2) Secrets (مهم جداً)

في Replit → Secrets أضف:

| المفتاح | مطلوب؟ | مثال / ملاحظة |
|---------|--------|----------------|
| `DATABASE_URL` | نعم | رابط PostgreSQL (Replit DB أو Neon/Supabase) |
| `SESSION_SECRET` | نعم | نص عشوائي 32+ حرف |
| `PORT` | عادة تلقائي | Replit يضبطه |
| `BASE_PATH` | حسب الواجهة | غالباً `/` |
| `PUBLIC_APP_URL` | مستحسن | رابط المشروع العلني (لروابط التتبع) |
| `SMS_PROVIDER` | اختياري | `twilio` أو `console` |
| `TWILIO_ACCOUNT_SID` | مع Twilio | |
| `TWILIO_AUTH_TOKEN` | مع Twilio | |
| `TWILIO_FROM_NUMBER` | مع Twilio SMS | مثل `+1...` |
| `WHATSAPP_PROVIDER` | اختياري | `twilio` أو `meta` أو `console` |
| `WHATSAPP_FROM_NUMBER` | Twilio WA | مثل `whatsapp:+1...` |
| `META_WHATSAPP_TOKEN` | Meta Cloud API | |
| `META_WHATSAPP_PHONE_ID` | Meta Cloud API | |

بدون مفاتيح SMS/WhatsApp النظام يعمل، والإرسال يذهب إلى الـ console فقط (آمن للتجربة).

## 3) التثبيت والتشغيل

```bash
pnpm install
pnpm --filter @workspace/db push
```

ثم Run من Replit (أو أوامر الـ artifacts المعتادة عندك).

أمر `push` يضيف الأعمدة الجديدة دون حذف بيانات:
- `orders.pod_photo_url`
- `orders.pod_signature`
- `orders.pod_captured_at`

## 4) ماذا يوجد في النظام (ملخص)

### تشغيل يومي
- إنشاء شحنات (فردي / جماعي / Excel / Sheets / واتساب)
- مخزن + تحويلات بين الفروع
- غرفة عمليات (تحميل QR، استلام مندوب، مرتجعات)
- شيفتات ودور المناديب
- رحلات + توزيع ذكي + ترتيب خط السير
- تسليم بـ OTP + إثبات تسليم (صورة/توقيع)
- مرتجعات + إعادة جدولة

### مالية
- محافظ التجار (متاح / معلّق / مسحوب)
- تسوية كاش المندوب
- طلبات سحب + رفض

### تتبع
- تتبع مندوبين GPS
- تتبع عميل + دبوس موقع + ETA

### أمان وصلاحيات
- 7 أدوار + 36 صلاحية قابلة للتخصيص
- سجل مراجعة (Audit)
- Rate limit على OTP وتسجيل الدخول

### تكاملات
- API Keys للتجار (Shopify/Woo...)
- SMS/WhatsApp عند ضبط المفاتيح

## 5) إثبات التسليم (POD)

من تطبيق المندوب عند الضغط على **تسليم**:
1. إدخال OTP (إجباري)
2. اختياري: التقاط صورة
3. اختياري: توقيع المستلم على الشاشة
4. تأكيد → يُحفظ مع الطلب

## 6) أول مستخدم

أنشئ مدير نظام من أدواتك المعتادة / سكربت الإنشاء في المشروع.
كلمة المرور لا تُخزَّن نصاً صريحاً — تُجزَّأ في قاعدة البيانات.

## 7) ملاحظات إنتاج

- اربط `PUBLIC_APP_URL` برابطك الحقيقي قبل الاعتماد على رسائل التتبع.
- للصور الكبيرة لاحقاً يُفضّل تخزين S3/Supabase Storage بدل data-URL.
- جرّب دورة كاملة: شيفت → إسناد → تحميل → انطلاق → تسليم+POD → تسوية.

## 8) الملفات الأساسية لهذه الحزمة

- `artifacts/al-ghazali/src/pages/login.tsx` — دخول + 3D + اللوجو
- `attached_assets/al-ghazali-logo.png` — اللوجو الرسمي
- `lib/db/src/schema/orders.ts` — حقول POD
- `artifacts/api-server/src/routes/orders.ts` — تسليم + إشعارات
- `artifacts/api-server/src/lib/notifications.ts` — SMS/WhatsApp
- `artifacts/al-ghazali/src/pages/driver-dashboard.tsx` — واجهة POD للمندوب

---

تم تجهيز المصدر بالكامل يدوياً — لا يعتمد على توليد Replit لأي من هذه الميزات.

## تحديث المرحلة 4
- تنبيه المندوب عند اكتمال التحميل + polling أسرع + صوت/اهتزاز
- إشعار WhatsApp/SMS للمندوب عند جاهزية الرحلة

## إنشاء المدير الأعلى (مؤقت)

```bash
# بعد pnpm install و db push
pnpm seed:admin
# أو:
node scripts/seed-super-admin.mjs
```

بيانات الدخول المؤقتة:
- Username: `admin`
- Password: `123456`
- Role: `super_admin`

⚠️ غيّر كلمة المرور فورًا بعد الدخول (أيقونة المفتاح في الواجهة).
ملاحظة: بعض شاشات تغيير كلمة المرور تطلب 8 أحرف على الأقل — استخدم كلمة أقوى بعد الدخول.
