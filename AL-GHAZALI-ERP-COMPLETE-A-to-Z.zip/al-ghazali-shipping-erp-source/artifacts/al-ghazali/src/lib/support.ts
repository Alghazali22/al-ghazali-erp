import { trackingLink, whatsappUrl } from './share';

export const TICKET_TYPES: Record<string, string> = {
  complaint: 'شكوى', delay: 'تأخير', address_change: 'تغيير عنوان', reschedule: 'إعادة جدولة', damaged: 'تلف', cod_dispute: 'خلاف تحصيل', other: 'أخرى',
};
export const PRIORITIES: Record<string, { label: string; cls: string }> = {
  low: { label: 'منخفضة', cls: 'bg-slate-500/10 text-slate-400 border-slate-500/30' },
  normal: { label: 'عادية', cls: 'bg-blue-500/10 text-blue-400 border-blue-500/30' },
  high: { label: 'عالية', cls: 'bg-amber-500/10 text-amber-500 border-amber-500/30' },
  urgent: { label: 'عاجلة', cls: 'bg-destructive/10 text-destructive border-destructive/30' },
};
export const TICKET_STATUSES: Record<string, string> = {
  open: 'مفتوحة', in_progress: 'قيد المعالجة', waiting: 'بانتظار رد', resolved: 'تم الحل', closed: 'مغلقة',
};
export const NOTE_KIND_LABELS: Record<string, string> = {
  note: 'ملاحظة داخلية', call: 'مكالمة', call_answered: 'مكالمة — رد', call_no_answer: 'مكالمة — لم يرد',
  whatsapp: 'واتساب', reschedule: 'إعادة جدولة', status: 'تغيير', reply: 'رد',
};

export interface CareOrder { orderNumber: string; customerName: string; customerPhone: string; customerAddress?: string }

/** Ready-made Arabic messages for the most common care situations. */
export const WHATSAPP_TEMPLATES: { key: string; label: string; text: (o: CareOrder) => string }[] = [
  { key: 'delay', label: 'اعتذار عن تأخير',
    text: (o) => `مرحباً ${o.customerName} 👋\nمعك خدمة عملاء الغزالي للشحن. نعتذر عن تأخر شحنتك رقم ${o.orderNumber}، وجاري متابعتها الآن وستصلك في أقرب وقت.\nتابعها من هنا: ${trackingLink(o.orderNumber)}` },
  { key: 'failed', label: 'تعذّر التسليم — إعادة المحاولة',
    text: (o) => `مرحباً ${o.customerName}،\nحاول مندوبنا توصيل شحنتك رقم ${o.orderNumber} ولم نتمكن من الوصول إليك.\nهل تفضّل إعادة التسليم؟ من فضلك أخبرنا بالموعد المناسب 🙏` },
  { key: 'address', label: 'تأكيد العنوان',
    text: (o) => `مرحباً ${o.customerName}،\nلتأكيد توصيل شحنتك رقم ${o.orderNumber}: هل العنوان التالي صحيح؟\n${o.customerAddress ?? ''}\nلو في تعديل ابعتلنا العنوان الجديد، أو حدّد موقعك بدقة من هنا: ${trackingLink(o.orderNumber)}` },
  { key: 'tracking', label: 'إرسال رابط التتبع',
    text: (o) => `مرحباً ${o.customerName}،\nتابع شحنتك رقم ${o.orderNumber} لحظة بلحظة من هنا:\n${trackingLink(o.orderNumber)}` },
];

export const whatsappFor = (phone: string, text: string) => whatsappUrl(phone, text);

export const AUDIT_LABELS: Record<string, string> = {
  'order.delete': 'حذف طلب', 'order.emergency_otp': 'استخدام كود الطوارئ', 'trip.delete': 'حذف رحلة',
  'trip.override_departure': 'تجاوز شروط انطلاق رحلة', 'finance.settle_driver': 'تسوية كاش مندوب',
  'finance.approve_withdrawal': 'صرف سحب تاجر', 'finance.reject_withdrawal': 'رفض سحب تاجر',
  'user.create': 'إضافة مستخدم', 'user.reset_password': 'إعادة تعيين كلمة مرور', 'user.disable': 'تعطيل حساب',
  'user.enable': 'تفعيل حساب', 'user.delete': 'حذف مستخدم', 'permissions.update': 'تعديل صلاحيات',
  'branch.lock': 'قفل فرع', 'branch.unlock': 'فتح فرع', 'branch.delete': 'حذف فرع',
  'system.shutdown': 'إيقاف النظام', 'system.restore': 'إعادة تشغيل النظام', 'support.reschedule': 'إعادة جدولة تسليم',
};
