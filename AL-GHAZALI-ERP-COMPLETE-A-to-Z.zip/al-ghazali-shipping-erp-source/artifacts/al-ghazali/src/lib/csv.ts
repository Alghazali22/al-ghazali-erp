/** Minimal RFC-4180 CSV parser: quoted fields, escaped quotes, newlines inside quotes, BOM, auto-detected delimiter. */
export function parseCsv(input: string): string[][] {
  const text = input.replace(/^\uFEFF/, '');
  const firstLine = text.split(/\r?\n/, 1)[0] ?? '';
  const delimiter = [',', ';', '\t'].reduce((best, d) => (firstLine.split(d).length > firstLine.split(best).length ? d : best), ',');

  const rows: string[][] = [];
  let row: string[] = [];
  let field = '';
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"' && text[i + 1] === '"') { field += '"'; i++; }
      else if (c === '"') inQuotes = false;
      else field += c;
    } else if (c === '"') inQuotes = true;
    else if (c === delimiter) { row.push(field); field = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && text[i + 1] === '\n') i++;
      row.push(field); field = '';
      if (row.some((v) => v.trim() !== '')) rows.push(row);
      row = [];
    } else field += c;
  }
  row.push(field);
  if (row.some((v) => v.trim() !== '')) rows.push(row);
  return rows;
}

export const ORDER_COLUMNS: { key: string; label: string; aliases: string[]; required: boolean }[] = [
  { key: 'reference', label: 'رقم الطلب عندك', aliases: ['reference', 'ref', 'order id', 'orderid', 'رقم الطلب عندك', 'مرجع'], required: false },
  { key: 'customerName', label: 'اسم العميل', aliases: ['customername', 'name', 'اسم العميل', 'الاسم'], required: true },
  { key: 'customerPhone', label: 'هاتف العميل', aliases: ['customerphone', 'phone', 'mobile', 'هاتف العميل', 'الهاتف', 'موبايل'], required: true },
  { key: 'customerPhone2', label: 'هاتف بديل', aliases: ['customerphone2', 'phone2', 'هاتف بديل', 'رقم بديل'], required: false },
  { key: 'governorate', label: 'المحافظة', aliases: ['governorate', 'city', 'المحافظة'], required: true },
  { key: 'area', label: 'المنطقة', aliases: ['area', 'district', 'المنطقة'], required: true },
  { key: 'customerAddress', label: 'العنوان', aliases: ['customeraddress', 'address', 'العنوان'], required: true },
  { key: 'packageValue', label: 'قيمة الشحنة', aliases: ['packagevalue', 'cod', 'amount', 'total', 'قيمة الشحنة', 'المبلغ', 'قيمة'], required: true },
  { key: 'notes', label: 'ملاحظات', aliases: ['notes', 'note', 'ملاحظات'], required: false },
];

const norm = (s: string) => s.trim().toLowerCase().replace(/\s+/g, ' ');

/** Turns parsed CSV rows into order objects, matching headers by Arabic or English name. */
export function mapOrderRows(rows: string[][]): { orders: Record<string, string>[]; missingColumns: string[] } {
  if (rows.length === 0) return { orders: [], missingColumns: ORDER_COLUMNS.filter((c) => c.required).map((c) => c.label) };
  const header = rows[0].map(norm);
  const indexOf: Record<string, number> = {};
  for (const col of ORDER_COLUMNS) {
    const idx = header.findIndex((h) => col.aliases.map(norm).includes(h));
    if (idx !== -1) indexOf[col.key] = idx;
  }
  const missingColumns = ORDER_COLUMNS.filter((c) => c.required && !(c.key in indexOf)).map((c) => c.label);
  const orders = rows.slice(1).map((r) => {
    const o: Record<string, string> = {};
    for (const [key, idx] of Object.entries(indexOf)) o[key] = (r[idx] ?? '').trim();
    return o;
  });
  return { orders, missingColumns };
}

export function templateCsv(): string {
  const header = ORDER_COLUMNS.map((c) => c.label).join(',');
  const example = ['A-1001', 'أحمد محمد', '01012345678', '', 'القاهرة', 'مدينة نصر', '15 شارع عباس العقاد - الدور 3', '350', 'اتصل قبل الوصول'].join(',');
  return `\uFEFF${header}\r\n${example}\r\n`;
}
