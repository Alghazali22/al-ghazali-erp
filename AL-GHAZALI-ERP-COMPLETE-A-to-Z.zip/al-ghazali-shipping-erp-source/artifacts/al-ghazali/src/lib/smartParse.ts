import { normalizeArabic, toWesternDigits, normalizeEgyptPhone, GOVERNORATES } from './egypt';
import type { ZoneLite } from './zoneMatch';

export interface ParsedCustomer {
  customerName: string;
  customerPhone: string;
  customerPhone2: string;
  governorate: string;
  area: string;
  customerAddress: string;
  packageValue: string;
  notes: string;
}

/** "1,200" → 1200 (thousands separator), "350,5" → 350.5 (decimal comma). */
function cleanAmount(raw: string): string {
  return /^\d{1,3}(,\d{3})+$/.test(raw) ? raw.replace(/,/g, '') : raw.replace(',', '.');
}

const PHONE_LABEL_RE = /(?:تليفون|تلفون|موبايل|محمول|هاتف|واتساب|واتس|tel|phone|mobile)\s*[:：-]?|رقم\s*[:：]/gi;
const PHONE_RE = /(?:\+?\s*20|0020)?[\s-]*0?1[0125](?:[\s-]?\d){8}/g;
const AMOUNT_UNIT_RE = /(\d+(?:[.,]\d+)?)\s*(?:جنيه|جنية|ج\.?\s?م|جم|ج|egp|le|l\.e)(?![\u0621-\u064A])/i;
const AMOUNT_LABEL_RE = /(?:المبلغ|الاجمالي|الإجمالي|المطلوب|السعر|سعر|قيمة|تحصيل|كاش|cod)\s*[:：=-]?\s*(\d+(?:[.,]\d+)?)/i;
const NOTES_RE = /^\s*(?:ملاحظات|ملاحظة|notes?)\s*[:：-]\s*(.*)$/i;
const NAME_LABEL_RE = /^\s*(?:الاسم|اسم العميل|العميل|name)\s*[:：-]\s*(.+)$/i;
const ADDRESS_LABEL_RE = /^\s*(?:العنوان|address)\s*[:：-]\s*/i;

/** Removes a phrase (matched word-by-word, spelling-insensitively) from text. */
function removePhrase(text: string, phrase: string): string {
  const target = normalizeArabic(phrase).split(' ').filter(Boolean);
  if (!target.length) return text;
  const tokens = text.split(/(\s+)/); // keeps separators
  const words = tokens.map((t, i) => ({ t, i })).filter((x) => x.t.trim() !== '');
  for (let w = 0; w + target.length <= words.length; w++) {
    const slice = words.slice(w, w + target.length);
    if (slice.every((x, k) => normalizeArabic(x.t.replace(/[,،:;.\-]+$/g, '')) === target[k])) {
      slice.forEach((x) => { tokens[x.i] = ''; });
      return tokens.join('').replace(/\s{2,}/g, ' ');
    }
  }
  return text;
}

function containsPhrase(text: string, phrase: string): boolean {
  const hay = ` ${normalizeArabic(text).replace(/[,،:;.\-]+/g, ' ')} `;
  return hay.includes(` ${normalizeArabic(phrase)} `);
}

function parseBlock(blockRaw: string, zones: ZoneLite[]): ParsedCustomer | null {
  let text = toWesternDigits(blockRaw).replace(/[\u200e\u200f]/g, '').trim();
  if (!text) return null;

  // 1) phones
  const phones: string[] = [];
  text = text.replace(PHONE_RE, (m) => {
    const p = normalizeEgyptPhone(m);
    if (p && !phones.includes(p)) phones.push(p);
    return ' ';
  });

  text = text.replace(PHONE_LABEL_RE, ' ').replace(/(^|\s)[/|\\+]+(?=\s|$)/g, ' ');

  // 2) amount
  let packageValue = '';
  const labeled = AMOUNT_LABEL_RE.exec(text);
  if (labeled) {
    packageValue = cleanAmount(labeled[1]);
    text = text.replace(labeled[0], ' ');
  } else {
    const unit = AMOUNT_UNIT_RE.exec(text);
    if (unit) { packageValue = cleanAmount(unit[1]); text = text.replace(unit[0], ' '); }
  }

  // 3) line-level labels (notes / name / address)
  let notes = '';
  let name = '';
  const lines: string[] = [];
  for (const line of text.split(/\r?\n/)) {
    const note = NOTES_RE.exec(line);
    if (note) { notes = note[1].trim(); continue; }
    const nm = NAME_LABEL_RE.exec(line);
    if (nm && !name) { name = nm[1].trim(); continue; }
    const cleaned = line.replace(ADDRESS_LABEL_RE, '').replace(/\s{2,}/g, ' ').trim();
    if (cleaned && !/^[-–—_=*\s]+$/.test(cleaned)) lines.push(cleaned);
  }
  let rest = lines.join('\n');

  // 4) governorate + area (longest spelling-insensitive match wins)
  const govNames = [...new Set([...zones.map((z) => z.governorate), ...GOVERNORATES])];
  const govHits = govNames.filter((g) => containsPhrase(rest, g)).sort((a, b) => normalizeArabic(b).length - normalizeArabic(a).length);
  let governorate = govHits[0] ?? '';
  const areaPool = zones.filter((z) => !governorate || normalizeArabic(z.governorate) === normalizeArabic(governorate));
  const areaHits = areaPool.filter((z) => containsPhrase(rest, z.area)).sort((a, b) => normalizeArabic(b.area).length - normalizeArabic(a.area).length);
  let area = '';
  if (areaHits[0]) {
    area = areaHits[0].area;
    if (!governorate) governorate = areaHits[0].governorate;
    rest = removePhrase(rest, area);
  }
  if (governorate) rest = removePhrase(rest, governorate);

  // 5) name (when not labelled): leading words before the first digit, or a short first line without digits
  if (!name) {
    const restLines = rest.split('\n').map((l) => l.trim()).filter(Boolean);
    const first = restLines[0] ?? '';
    const wordsOf = (s: string) => s.split(/\s+/).filter(Boolean);
    if (first && !/\d/.test(first) && wordsOf(first).length <= 5 && (restLines.length > 1 || phones.length > 0)) {
      name = first;
      restLines.shift();
      rest = restLines.join('\n');
    } else if (first && /\d/.test(first)) {
      const prefix = first.slice(0, first.search(/\d/)).replace(/[\s,،:;-]+$/g, '').trim();
      if (prefix && wordsOf(prefix).length >= 1 && wordsOf(prefix).length <= 5 && !/(شارع|ش\.|عمارة|برج|حارة|ميدان|كمبوند)/.test(prefix)) {
        name = prefix;
        restLines[0] = first.slice(first.search(/\d/));
        rest = restLines.join('\n');
      }
    }
  }

  const customerAddress = rest.split('\n').map((l) => l.trim()).filter(Boolean).join(' - ')
    .replace(/^[\s,،:;-]+|[\s,،:;-]+$/g, '').replace(/\s{2,}/g, ' ');

  if (!phones.length && !name && !customerAddress) return null;
  return {
    customerName: name.replace(/[\s,،:;-]+$/g, '').trim(),
    customerPhone: phones[0] ?? '',
    customerPhone2: phones[1] ?? '',
    governorate, area, customerAddress,
    packageValue, notes,
  };
}

/**
 * Turns pasted WhatsApp/Facebook messages into order rows. Customers are separated by a blank line
 * (or a line of dashes). Works on free text or "label: value" lines, Arabic or Western digits.
 */
export function parseCustomerBlocks(text: string, zones: ZoneLite[]): ParsedCustomer[] {
  return text
    .split(/\r?\n\s*(?:[-_=*]{3,}\s*)?\r?\n+/)
    .map((block) => parseBlock(block, zones))
    .filter((c): c is ParsedCustomer => c !== null);
}
