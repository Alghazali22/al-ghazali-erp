export const GOVERNORATES = [
  'القاهرة', 'الجيزة', 'الإسكندرية', 'القليوبية', 'الشرقية', 'الدقهلية', 'الغربية', 'المنوفية', 'البحيرة',
  'كفر الشيخ', 'دمياط', 'بورسعيد', 'الإسماعيلية', 'السويس', 'شمال سيناء', 'جنوب سيناء', 'الفيوم', 'بني سويف',
  'المنيا', 'أسيوط', 'سوهاج', 'قنا', 'الأقصر', 'أسوان', 'البحر الأحمر', 'الوادي الجديد', 'مطروح',
];

const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
const FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹';

/** Eastern-Arabic / Persian digits → 0-9. */
export function toWesternDigits(s: string): string {
  return s.replace(/[٠-٩۰-۹]/g, (d) => {
    const i = AR_DIGITS.indexOf(d);
    return String(i !== -1 ? i : FA_DIGITS.indexOf(d));
  });
}

/** Spelling-insensitive Arabic key: أ/إ/آ→ا، ة→ه، ى→ي، without diacritics/tatweel, lower-case, single spaces. */
export function normalizeArabic(s: string): string {
  return s
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/محافظة/g, '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Cleans a phone cell into an Egyptian number. Handles Arabic digits, +20/0020 prefixes, spaces/dashes and the
 * classic Excel damage: leading zero dropped (1012345678) or scientific notation (1.012345678E9).
 * Returns null when it can't be a phone.
 */
export function normalizeEgyptPhone(raw: string): string | null {
  let text = toWesternDigits(String(raw ?? '')).trim();
  if (/^\d+(\.\d+)?e\+?\d+$/i.test(text)) {
    const n = Number(text);
    if (Number.isFinite(n)) text = BigInt(Math.round(n)).toString();
  }
  let digits = text.replace(/\D/g, '');
  if (digits.startsWith('0020')) digits = digits.slice(4);
  if (digits.startsWith('20') && digits.length === 12) digits = `0${digits.slice(2)}`;
  if (digits.length === 10 && digits.startsWith('1')) digits = `0${digits}`;
  if (/^01[0125]\d{8}$/.test(digits)) return digits;
  if (/^0\d{8,10}$/.test(digits)) return digits; // landline
  return null;
}

/** "350", "350.5", "٣٥٠", "350 ج.م", "1,200 جنيه" → "350" … ; null when there is no amount. */
export function parseAmountCell(raw: string): string | null {
  const text = toWesternDigits(String(raw ?? '')).replace(/[٬,]/g, '').trim();
  const m = /^(?:egp|le)?\s*(\d+(?:\.\d+)?)\s*(?:جنيه|جنية|ج\.?\s?م|جم|ج|egp|le|l\.e)?\.?$/i.exec(text);
  return m ? m[1] : null;
}
