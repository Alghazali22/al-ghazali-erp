import { GOVERNORATES, normalizeArabic } from './egypt';

export interface ZoneLite { governorate: string; area: string; isActive?: boolean; basePrice?: number; id?: number }

export interface ZoneMatch {
  governorate: string;
  area: string;
  /** ok = exact (spelling-insensitive); fixed = corrected a typo; unknown = nothing close enough */
  status: 'ok' | 'fixed' | 'unknown';
  zone?: ZoneLite;
}

function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  const prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let diag = prev[0];
    prev[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = prev[j];
      prev[j] = Math.min(prev[j] + 1, prev[j - 1] + 1, diag + (a[i - 1] === b[j - 1] ? 0 : 1));
      diag = tmp;
    }
  }
  return prev[b.length];
}

function closest<T>(needle: string, items: T[], key: (t: T) => string): { item: T; exact: boolean } | null {
  const n = normalizeArabic(needle);
  if (!n) return null;
  const stripAl = (v: string) => v.replace(/^ال/, '');
  let best: { item: T; dist: number } | null = null;
  for (const item of items) {
    const k = normalizeArabic(key(item));
    if (k === n) return { item, exact: true };
    // "هرم" vs "الهرم": same word, only the article differs.
    if (stripAl(k) === stripAl(n) && !best) { best = { item, dist: 0.5 }; continue; }
    const dist = levenshtein(n, k);
    const allowed = Math.max(1, Math.floor(Math.max(n.length, k.length) * 0.25));
    if (dist <= allowed && (!best || dist < best.dist)) best = { item, dist };
  }
  return best ? { item: best.item, exact: false } : null;
}

/**
 * Resolves what the merchant typed ("القاهره" / "مدينه نصر") to a real governorate + zone from the price list,
 * fixing small spelling differences, so import rows don't fail over ة/ه or a missing letter.
 */
export function matchZone(governorateInput: string, areaInput: string, zones: ZoneLite[]): ZoneMatch {
  const knownGovernorates = [...new Set([...zones.map((z) => z.governorate), ...GOVERNORATES])];
  const govHit = closest(governorateInput, knownGovernorates, (g) => g);
  const governorate = govHit ? govHit.item : governorateInput.trim();
  let fixed = !!govHit && !govHit.exact;

  const inGov = zones.filter((z) => normalizeArabic(z.governorate) === normalizeArabic(governorate));
  const areaHit = closest(areaInput, inGov, (z) => z.area);
  if (areaHit) {
    fixed = fixed || !areaHit.exact;
    return { governorate: areaHit.item.governorate, area: areaHit.item.area, status: fixed ? 'fixed' : 'ok', zone: areaHit.item };
  }
  return { governorate, area: areaInput.trim(), status: 'unknown' };
}
