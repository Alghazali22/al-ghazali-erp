// Thin helpers for endpoints added after the generated client (api-client-react) was built.
// When the OpenAPI spec is next regenerated these can be replaced by generated hooks.

export async function apiFetch<T = any>(path: string, init: RequestInit = {}): Promise<T> {
  const token = localStorage.getItem('al-ghazali-token');
  const res = await fetch(`/api${path}`, {
    ...init,
    headers: {
      ...(init.body ? { 'Content-Type': 'application/json' } : {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(init.headers ?? {}),
    },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `تعذر تنفيذ الطلب (${res.status})`);
  }
  return res.status === 204 ? (undefined as T) : res.json();
}

/** Downloads an authenticated file (the browser can't attach the Bearer header to a plain link). */
export async function downloadFile(path: string, fallbackName: string): Promise<void> {
  const token = localStorage.getItem('al-ghazali-token');
  const res = await fetch(`/api${path}`, { headers: token ? { Authorization: `Bearer ${token}` } : {} });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || 'تعذر تنزيل الملف');
  }
  const disposition = res.headers.get('Content-Disposition') ?? '';
  const name = /filename="([^"]+)"/.exec(disposition)?.[1] ?? fallbackName;
  const url = URL.createObjectURL(await res.blob());
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
