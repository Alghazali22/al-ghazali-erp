/**
 * Minimal, dependency-free .xlsx reader (first worksheet → rows of text).
 * An .xlsx is a ZIP of XML files; we read the ZIP directory, inflate the entries we need with the browser's
 * built-in DecompressionStream, and parse shared strings + sheet cells. Formulas keep their cached value.
 */

const decoder = new TextDecoder('utf-8');

function readU16(v: DataView, o: number) { return v.getUint16(o, true); }
function readU32(v: DataView, o: number) { return v.getUint32(o, true); }

interface ZipEntry { name: string; method: number; compressedSize: number; localOffset: number }

function readZipDirectory(view: DataView): ZipEntry[] {
  // End-of-central-directory record: signature 0x06054b50, searched from the end (comment may follow it).
  let eocd = -1;
  for (let i = view.byteLength - 22; i >= Math.max(0, view.byteLength - 65_557); i--) {
    if (readU32(view, i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd === -1) throw new Error('الملف ليس Excel (xlsx) صحيحاً');
  const count = readU16(view, eocd + 10);
  let offset = readU32(view, eocd + 16);
  const entries: ZipEntry[] = [];
  for (let i = 0; i < count; i++) {
    if (readU32(view, offset) !== 0x02014b50) break;
    const method = readU16(view, offset + 10);
    const compressedSize = readU32(view, offset + 20);
    const nameLen = readU16(view, offset + 28);
    const extraLen = readU16(view, offset + 30);
    const commentLen = readU16(view, offset + 32);
    const localOffset = readU32(view, offset + 42);
    const name = decoder.decode(new Uint8Array(view.buffer, view.byteOffset + offset + 46, nameLen));
    entries.push({ name, method, compressedSize, localOffset });
    offset += 46 + nameLen + extraLen + commentLen;
  }
  return entries;
}

async function inflateRaw(data: Uint8Array): Promise<Uint8Array> {
  const stream = new Blob([data as BlobPart]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

async function readEntry(buffer: ArrayBuffer, view: DataView, entry: ZipEntry): Promise<string> {
  const o = entry.localOffset;
  if (readU32(view, o) !== 0x04034b50) throw new Error('ملف Excel تالف');
  const nameLen = readU16(view, o + 26);
  const extraLen = readU16(view, o + 28);
  const start = o + 30 + nameLen + extraLen;
  const raw = new Uint8Array(buffer, start, entry.compressedSize);
  if (entry.method === 0) return decoder.decode(raw);
  if (entry.method === 8) return decoder.decode(await inflateRaw(raw));
  throw new Error('صيغة ضغط غير مدعومة في ملف Excel');
}

const decodeXml = (s: string) =>
  s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'")
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(Number(d)))
    .replace(/&amp;/g, '&');

function textOf(xml: string): string {
  let out = '';
  for (const m of xml.matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)) out += m[1];
  return decodeXml(out);
}

function columnIndex(ref: string): number {
  let n = 0;
  for (const ch of ref.replace(/[^A-Z]/gi, '').toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64);
  return n - 1;
}

export async function readXlsx(buffer: ArrayBuffer): Promise<string[][]> {
  const view = new DataView(buffer);
  const entries = readZipDirectory(view);

  const sheetEntry = entries
    .filter((e) => /^xl\/worksheets\/sheet\d+\.xml$/.test(e.name))
    .sort((a, b) => Number(a.name.match(/\d+/)![0]) - Number(b.name.match(/\d+/)![0]))[0];
  if (!sheetEntry) throw new Error('لا توجد ورقة بيانات داخل الملف');

  const sharedEntry = entries.find((e) => e.name === 'xl/sharedStrings.xml');
  const shared: string[] = [];
  if (sharedEntry) {
    const xml = await readEntry(buffer, view, sharedEntry);
    for (const m of xml.matchAll(/<si(?:\s[^>]*)?>([\s\S]*?)<\/si>/g)) shared.push(textOf(m[1]));
  }

  const sheetXml = await readEntry(buffer, view, sheetEntry);
  const rows: string[][] = [];
  for (const rowMatch of sheetXml.matchAll(/<row(?:\s[^>]*)?>([\s\S]*?)<\/row>/g)) {
    const row: string[] = [];
    for (const cell of rowMatch[1].matchAll(/<c\s([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
      const attrs = cell[1];
      const body = cell[2] ?? '';
      const ref = /\br="([A-Z]+\d+)"/i.exec(attrs)?.[1];
      const type = /\bt="([^"]+)"/.exec(attrs)?.[1];
      const idx = ref ? columnIndex(ref) : row.length;
      let value = '';
      if (type === 'inlineStr') value = textOf(body);
      else {
        const v = /<v>([\s\S]*?)<\/v>/.exec(body)?.[1] ?? '';
        value = type === 's' ? shared[Number(v)] ?? '' : decodeXml(v);
        if (type === 'b') value = v === '1' ? 'TRUE' : 'FALSE';
      }
      while (row.length < idx) row.push('');
      row[idx] = value;
    }
    if (row.some((c) => c.trim() !== '')) rows.push(row);
  }
  return rows;
}
