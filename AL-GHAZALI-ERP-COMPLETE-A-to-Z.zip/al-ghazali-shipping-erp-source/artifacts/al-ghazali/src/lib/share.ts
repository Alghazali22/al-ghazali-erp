/** Public link the customer can open to follow (and pin) their order. */
export function trackingLink(orderNumber: string): string {
  const base = (import.meta.env.BASE_URL || '/').replace(/\/$/, '');
  return `${window.location.origin}${base}/track?order=${encodeURIComponent(orderNumber)}`;
}

/** wa.me link with a pre-filled message. Handles 010…, +2010…, 2010… and 10… Egyptian formats. */
export function whatsappUrl(phone: string, text: string): string {
  let digits = phone.replace(/\D/g, '');
  if (digits.startsWith('0020')) digits = digits.slice(2);
  else if (digits.startsWith('0')) digits = `20${digits.slice(1)}`;
  else if (!digits.startsWith('20')) digits = `20${digits}`;
  return `https://wa.me/${digits}?text=${encodeURIComponent(text)}`;
}

/** Turn-by-turn navigation: the customer's exact pin when they shared one, otherwise the written address. */
export function mapsUrl(o: { customerLat?: number | null; customerLng?: number | null; customerAddress?: string; area?: string; governorate?: string }): string {
  const destination = o.customerLat != null && o.customerLng != null
    ? `${o.customerLat},${o.customerLng}`
    : encodeURIComponent([o.customerAddress, o.area, o.governorate, 'مصر'].filter(Boolean).join('، '));
  return `https://www.google.com/maps/dir/?api=1&destination=${destination}&travelmode=driving`;
}
