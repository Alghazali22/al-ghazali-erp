import QRCode from 'qrcode';
import { trackingLink } from './share';

export interface LabelOrder {
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  governorate: string;
  area: string;
  totalToCollect: number;
  notes?: string | null;
}

const esc = (value: unknown) =>
  String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] as string));

/**
 * Prints shipping labels (airway bills): 4 per A4 page, each with the order number, a QR code that opens the
 * customer's tracking page, the consignee, address and the cash to collect.
 * Must be called straight from a click handler — the window is opened first so pop-up blockers allow it.
 */
export async function printLabels(orders: LabelOrder[], merchantName: string): Promise<void> {
  const win = window.open('', '_blank');
  if (!win) throw new Error('المتصفح منع النافذة المنبثقة — اسمح بالنوافذ المنبثقة لهذا الموقع ثم أعد المحاولة');
  win.document.write('<p style="font-family:sans-serif;direction:rtl;padding:24px">جاري تجهيز البوالص...</p>');

  const qr = await Promise.all(orders.map((o) => QRCode.toDataURL(trackingLink(o.orderNumber), { margin: 0, width: 220 })));
  const date = new Date().toLocaleDateString('ar-EG');

  const labels = orders.map((o, i) => `
    <section class="label">
      <header><b>الغزالي للشحن</b><span>${esc(date)}</span></header>
      <div class="no">${esc(o.orderNumber)}</div>
      <div class="mid">
        <img src="${qr[i]}" alt="QR" />
        <div class="cod"><small>المطلوب تحصيله</small><strong>${esc(o.totalToCollect)} ج.م</strong></div>
      </div>
      <dl>
        <dt>العميل</dt><dd>${esc(o.customerName)}</dd>
        <dt>الهاتف</dt><dd dir="ltr" style="text-align:right">${esc(o.customerPhone)}</dd>
        <dt>العنوان</dt><dd>${esc(o.governorate)} — ${esc(o.area)}<br>${esc(o.customerAddress)}</dd>
        ${o.notes ? `<dt>ملاحظات</dt><dd>${esc(o.notes)}</dd>` : ''}
        <dt>التاجر</dt><dd>${esc(merchantName)}</dd>
      </dl>
    </section>`).join('');

  win.document.open();
  win.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>بوالص الشحن (${orders.length})</title>
    <style>
      @page { size: A4; margin: 8mm; }
      * { box-sizing: border-box; }
      body { margin: 0; font-family: Tahoma, Arial, sans-serif; color: #111; }
      .sheet { display: grid; grid-template-columns: repeat(2, 99mm); grid-auto-rows: 138mm; justify-content: center; }
      .label { border: 1px dashed #666; padding: 5mm; display: flex; flex-direction: column; gap: 2.5mm; break-inside: avoid; overflow: hidden; }
      header { display: flex; justify-content: space-between; font-size: 11px; border-bottom: 2px solid #111; padding-bottom: 2mm; }
      .no { font: 700 22px/1 monospace; text-align: center; letter-spacing: 1px; direction: ltr; }
      .mid { display: flex; align-items: center; justify-content: space-between; gap: 4mm; }
      .mid img { width: 30mm; height: 30mm; }
      .cod { flex: 1; border: 2px solid #111; border-radius: 6px; text-align: center; padding: 3mm 1mm; }
      .cod small { display: block; font-size: 10px; } .cod strong { font-size: 20px; }
      dl { margin: 0; display: grid; grid-template-columns: 17mm 1fr; gap: 1.2mm 2mm; font-size: 11.5px; line-height: 1.4; }
      dt { color: #555; } dd { margin: 0; font-weight: 600; word-break: break-word; }
      @media screen { body { background: #eee; padding: 12px; } .label { background: #fff; } }
    </style></head><body><main class="sheet">${labels}</main>
    <script>window.onload = function () { setTimeout(function () { window.print(); }, 300); };</script></body></html>`);
  win.document.close();
}
