import { ORDER_COLUMNS, mapOrderRows } from './csv';
import { normalizeArabic, normalizeEgyptPhone, parseAmountCell, toWesternDigits } from './egypt';
import { matchZone, type ZoneLite } from './zoneMatch';

export interface GridRow {
  id: string;
  reference: string;
  customerName: string;
  customerPhone: string;
  customerPhone2: string;
  governorate: string;
  area: string;
  customerAddress: string;
  packageValue: string;
  notes: string;
}

export type EditableKey = Exclude<keyof GridRow, 'id'>;

/** Visible columns, in the order a merchant normally keeps them in a sheet (used for header-less pastes). */
export const GRID_COLUMNS: { key: EditableKey; label: string; width: number; ltr?: boolean; list?: 'gov' | 'area' }[] = [
  { key: 'customerName', label: 'اسم العميل', width: 150 },
  { key: 'customerPhone', label: 'الهاتف', width: 125, ltr: true },
  { key: 'governorate', label: 'المحافظة', width: 115, list: 'gov' },
  { key: 'area', label: 'المنطقة', width: 125, list: 'area' },
  { key: 'customerAddress', label: 'العنوان بالتفصيل', width: 230 },
  { key: 'packageValue', label: 'قيمة الشحنة', width: 95, ltr: true },
  { key: 'notes', label: 'ملاحظات', width: 130 },
  { key: 'customerPhone2', label: 'هاتف بديل', width: 120, ltr: true },
  { key: 'reference', label: 'رقم عندك', width: 100, ltr: true },
];

let counter = 0;
export const newRowId = () => `r${Date.now().toString(36)}${(counter++).toString(36)}`;

export const emptyRow = (): GridRow => ({
  id: newRowId(), reference: '', customerName: '', customerPhone: '', customerPhone2: '',
  governorate: '', area: '', customerAddress: '', packageValue: '', notes: '',
});

export const isBlankRow = (r: GridRow) =>
  GRID_COLUMNS.every((c) => !r[c.key].trim());

export interface RowIssue { level: 'error' | 'warning'; message: string; field?: EditableKey }

/** Cleans a row in place-style: phones, amount, spelling of governorate/area. Returns what it fixed. */
export function normalizeRow(row: GridRow, zones: ZoneLite[]): { row: GridRow; fixes: string[] } {
  const fixes: string[] = [];
  const next = { ...row };
  for (const key of Object.keys(next) as (keyof GridRow)[]) {
    if (key !== 'id') next[key] = toWesternDigits(next[key]).replace(/\s+/g, ' ').trim() as never;
  }
  for (const key of ['customerPhone', 'customerPhone2'] as const) {
    if (!next[key]) continue;
    const phone = normalizeEgyptPhone(next[key]);
    if (phone && phone !== next[key]) { next[key] = phone; fixes.push('تم تصحيح صيغة رقم الهاتف'); }
  }
  if (next.packageValue) {
    const amount = parseAmountCell(next.packageValue);
    if (amount !== null && amount !== next.packageValue) { next.packageValue = amount; fixes.push('تم تنظيف قيمة الشحنة'); }
  }
  if (next.governorate || next.area) {
    const m = matchZone(next.governorate, next.area, zones);
    if (m.status !== 'unknown') {
      if (m.governorate !== next.governorate || m.area !== next.area) fixes.push(`تم تصحيح المنطقة إلى «${m.governorate} — ${m.area}»`);
      next.governorate = m.governorate;
      next.area = m.area;
    } else {
      // Governorate and area typed in swapped columns is a common sheet mistake.
      const swapped = matchZone(next.area, next.governorate, zones);
      if (swapped.status !== 'unknown') { next.governorate = swapped.governorate; next.area = swapped.area; fixes.push('تم تبديل المحافظة والمنطقة'); }
    }
  }
  return { row: next, fixes };
}

export function validateRow(row: GridRow, zones: ZoneLite[]): RowIssue[] {
  const issues: RowIssue[] = [];
  const err = (message: string, field?: EditableKey) => issues.push({ level: 'error', message, field });
  const warn = (message: string, field?: EditableKey) => issues.push({ level: 'warning', message, field });

  if (row.customerName.trim().length < 2) err('اسم العميل مطلوب', 'customerName');
  if (!row.customerPhone) err('رقم الهاتف مطلوب', 'customerPhone');
  else if (!normalizeEgyptPhone(row.customerPhone)) err('رقم الهاتف غير صحيح', 'customerPhone');
  if (row.customerPhone2 && !normalizeEgyptPhone(row.customerPhone2)) err('الهاتف البديل غير صحيح', 'customerPhone2');
  if (!row.governorate) err('المحافظة مطلوبة', 'governorate');
  if (!row.area) err('المنطقة مطلوبة', 'area');
  if (row.customerAddress.trim().length < 5) err('العنوان مطلوب بالتفصيل', 'customerAddress');
  const amount = parseAmountCell(row.packageValue);
  if (row.packageValue === '') err('قيمة الشحنة مطلوبة (اكتب 0 للشحن المدفوع مسبقاً)', 'packageValue');
  else if (amount === null || Number(amount) < 0) err('قيمة الشحنة غير صحيحة', 'packageValue');

  if (row.governorate && row.area) {
    const m = matchZone(row.governorate, row.area, zones);
    if (m.status === 'unknown') warn('المنطقة غير موجودة في قائمة الأسعار — سيُطبّق السعر الافتراضي', 'area');
    else if (m.zone && m.zone.isActive === false) err('التوصيل لهذه المنطقة غير متاح حالياً', 'area');
  }
  return issues;
}

export const signature = (r: GridRow) =>
  [r.reference, r.customerName, r.customerPhone, r.customerPhone2, r.governorate, r.area, r.customerAddress, r.packageValue, r.notes].join('\u0001');

/** True when the first row of pasted/uploaded data is a header row (≥ 2 known column names). */
export function looksLikeHeader(row: string[]): boolean {
  const known = new Set(ORDER_COLUMNS.flatMap((c) => c.aliases.map((a) => normalizeArabic(a))));
  return row.filter((cell) => known.has(normalizeArabic(cell))).length >= 2;
}

/** Table (from paste / CSV / XLSX) → grid rows. Uses the header when present, otherwise the default column order. */
export function rowsFromTable(table: string[][], zones: ZoneLite[]): { rows: GridRow[]; fixes: number } {
  if (table.length === 0) return { rows: [], fixes: 0 };
  let objects: Partial<Record<EditableKey, string>>[];
  if (looksLikeHeader(table[0])) {
    objects = mapOrderRows(table).orders as Partial<Record<EditableKey, string>>[];
  } else {
    objects = table.map((cells) => {
      const o: Partial<Record<EditableKey, string>> = {};
      GRID_COLUMNS.forEach((col, i) => { if (cells[i] !== undefined) o[col.key] = cells[i]; });
      return o;
    });
  }
  let fixes = 0;
  const rows = objects
    .map((o) => ({ ...emptyRow(), ...Object.fromEntries(Object.entries(o).map(([k, v]) => [k, String(v ?? '')])) }) as GridRow)
    .filter((r) => !isBlankRow(r))
    .map((r) => {
      const n = normalizeRow(r, zones);
      fixes += n.fixes.length;
      return n.row;
    });
  return { rows, fixes };
}
