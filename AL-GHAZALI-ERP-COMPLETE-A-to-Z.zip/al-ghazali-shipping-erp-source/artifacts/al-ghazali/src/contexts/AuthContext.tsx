import React, { createContext, useContext, useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { User, LoginInput } from '@workspace/api-client-react';
import { useLogin, useLogout } from '@workspace/api-client-react';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  login: (data: LoginInput) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
  /** Does the signed-in user hold this permission (role default + personal grants − revokes)? */
  can: (permission: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [, setLocation] = useLocation();

  const loginMutation = useLogin();
  const logoutMutation = useLogout();

  const clearSession = React.useCallback(() => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('al-ghazali-user');
    localStorage.removeItem('al-ghazali-token');
  }, []);

  // Session expired / account disabled (any API call returned 401).
  useEffect(() => {
    const onExpired = () => { clearSession(); setLocation('/login'); };
    window.addEventListener('auth:expired', onExpired);
    return () => window.removeEventListener('auth:expired', onExpired);
  }, [clearSession, setLocation]);

  useEffect(() => {
    // Load from local storage
    const storedUser = localStorage.getItem('al-ghazali-user');
    const storedToken = localStorage.getItem('al-ghazali-token');

    if (storedUser && storedToken) {
      try {
        setUser(JSON.parse(storedUser));
        setToken(storedToken);
      } catch (e) {
        console.error('Failed to parse stored user', e);
        localStorage.removeItem('al-ghazali-user');
        localStorage.removeItem('al-ghazali-token');
      }
    }
    setIsLoading(false);

    // Refresh the cached profile so role / branch / disabled-state changes apply without a re-login.
    if (storedUser && storedToken) {
      fetch('/api/auth/me', { headers: { Authorization: `Bearer ${storedToken}` } })
        .then(async (res) => {
          if (!res.ok) return; // 401 is handled globally; 503 (shutdown) keeps the session
          const fresh = await res.json();
          setUser(fresh);
          localStorage.setItem('al-ghazali-user', JSON.stringify(fresh));
        })
        .catch(() => { /* offline: keep cached session */ });
    }
  }, []);

  const login = async (data: LoginInput) => {
    try {
      const response = await loginMutation.mutateAsync({ data });
      setUser(response.user);
      setToken(response.token);
      localStorage.setItem('al-ghazali-user', JSON.stringify(response.user));
      localStorage.setItem('al-ghazali-token', response.token);
      
      // Redirect based on role
      if (response.user.role === 'cs') {
        setLocation('/cs');
      } else if (response.user.role === 'driver') {
        setLocation('/driver-dashboard');
      } else {
        setLocation('/');
      }
    } catch (error) {
      throw error;
    }
  };

  const logout = () => {
    logoutMutation.mutate(undefined, {
      onSettled: () => {
        setUser(null);
        setToken(null);
        localStorage.removeItem('al-ghazali-user');
        localStorage.removeItem('al-ghazali-token');
        setLocation('/login');
      }
    });
  };

  return (
    <AuthContext.Provider value={{ user, token, isAuthenticated: !!user, login, logout, isLoading, can: (permission: string) => ((user as any)?.permissions as string[] | undefined)?.includes(permission) ?? false }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const ProtectedRoute: React.FC<{ component: React.ComponentType<any>, requiredRoles?: string[], permission?: string, path?: string }> = ({ component: Component, requiredRoles, permission, ...rest }) => {
  const { isAuthenticated, isLoading, user, can } = useAuth();
  const [, setLocation] = useLocation();

  // Allowed by role, OR because the employee was personally granted the permission for this area.
  const allowed = !requiredRoles || !user || requiredRoles.includes(user.role) || (!!permission && can(permission));

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      setLocation('/login');
    } else if (!isLoading && isAuthenticated && !allowed) {
      setLocation('/');
    }
  }, [isLoading, isAuthenticated, setLocation, allowed]);

  if (isLoading || !isAuthenticated) {
    return <div className="min-h-screen flex items-center justify-center bg-background"><div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div></div>;
  }

  if (!allowed) {
    return null;
  }

  return <Component {...rest} />;
};
