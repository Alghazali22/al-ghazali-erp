import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'wouter';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Users, PackageCheck, Undo2, Play, Square, ChevronsUp, ChevronsDown, Coffee, Truck, ScanLine, Loader2, CheckCircle2,
  Circle, XCircle, Sparkles, Hourglass, ShieldAlert, Phone, Rocket, Trash2,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { apiFetch } from '@/lib/extra-api';
import { SmartDispatchDialog } from '@/components/SmartDispatchDialog';

type Tab = 'board' | 'loading' | 'returns';
type Status = 'off' | 'available' | 'break' | 'on_trip';

interface BoardDriver {
  driverId: number; driverName: string; phone: string | null; status: Status; queuePosition: number | null;
  shiftStartedAt: string | null; waitingSince: string | null; breakMinutes: number; deliveredToday: number; parcelsOut: number;
  trip: { id: number; status: string } | null; cashBalance: number;
}
interface Board { drivers: BoardDriver[]; summary: { available: number; onTrip: number; onBreak: number; off: number } }
interface TripOrder { id: number; orderNumber: string; customerName: string; area: string; status: string; stopSequence: number | null; loadedAt: string | null }
interface Trip {
  id: number; driverId: number; driverName: string; status: string; orderCount: number; loadedCount: number; activeCount: number;
  acceptedAt: string | null; orders: TripOrder[]; totalToCollect: number;
}
interface ScanResult { orderNumber: string; ok: boolean; message: string }

const STATUS_META: Record<Status, { label: string; dot: string; badge: string }> = {
  available: { label: 'متاح في الدور', dot: 'bg-emerald-500', badge: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/30' },
  on_trip: { label: 'في رحلة', dot: 'bg-orange-500', badge: 'bg-orange-500/10 text-orange-500 border-orange-500/30' },
  break: { label: 'استراحة', dot: 'bg-amber-500', badge: 'bg-amber-500/10 text-amber-500 border-amber-500/30' },
  off: { label: 'خارج الشيفت', dot: 'bg-slate-500', badge: 'bg-slate-500/10 text-slate-400 border-slate-500/30' },
};

const minutesSince = (iso: string | null) => (iso ? Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60_000)) : 0);
const fmtDuration = (m: number) => (m < 60 ? `${m} د` : `${Math.floor(m / 60)}س ${m % 60}د`);

/** Short audible feedback so a station operator scanning with a handheld scanner doesn't have to watch the screen. */
function beep(ok: boolean) {
  try {
    const Ctx = window.AudioContext || (window as any).webkitAudioContext;
    const ctx = new Ctx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.frequency.value = ok ? 880 : 220;
    gain.gain.value = 0.08;
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(); osc.stop(ctx.currentTime + (ok ? 0.08 : 0.25));
    setTimeout(() => ctx.close(), 400);
  } catch { /* audio blocked: silent */ }
}

function ScanBox({ placeholder, onScan, busy }: { placeholder: string; onScan: (numbers: string[]) => Promise<void>; busy: boolean }) {
  const [value, setValue] = useState('');
  const ref = useRef<HTMLInputElement>(null);
  useEffect(() => { ref.current?.focus(); }, [busy]);
  return (
    <form className="flex gap-2" onSubmit={async (e) => {
      e.preventDefault();
      const numbers = value.split(/[\s,;]+/).map((v) => v.trim()).filter(Boolean);
      if (!numbers.length) return;
      setValue('');
      await onScan(numbers);
    }}>
      <div className="relative flex-1">
        <ScanLine className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input ref={ref} autoFocus dir="ltr" value={value} onChange={(e) => setValue(e.target.value)} placeholder={placeholder} className="pr-9 font-mono h-11" disabled={busy} />
      </div>
      <Button type="submit" className="h-11" disabled={busy || !value.trim()}>{busy ? <Loader2 className="w-4 h-4 animate-spin" /> : 'تسجيل'}</Button>
    </form>
  );
}

// ===========================================================================
// 1) Rotation board
// ===========================================================================
function BoardTab({ onSmartCreated }: { onSmartCreated: () => void }) {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [smartOpen, setSmartOpen] = useState(false);
  const [busyId, setBusyId] = useState<number | null>(null);
  const { data, isLoading } = useQuery({ queryKey: ['shift-board'], queryFn: () => apiFetch<Board>('/shifts/board'), refetchInterval: 10_000 });

  const act = async (driverId: number, path: string, body: object, okTitle: string) => {
    setBusyId(driverId);
    try {
      await apiFetch(path, { method: 'POST', body: JSON.stringify({ driverId, ...body }) });
      toast({ title: okTitle });
      qc.invalidateQueries({ queryKey: ['shift-board'] });
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر تنفيذ الإجراء', description: e.message });
    } finally { setBusyId(null); }
  };

  const drivers = data?.drivers ?? [];
  const next = drivers.find((d) => d.queuePosition === 1);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {([['available', data?.summary.available], ['on_trip', data?.summary.onTrip], ['break', data?.summary.onBreak], ['off', data?.summary.off]] as const).map(([k, v]) => (
          <Card key={k} className="border-border/40 bg-card/60"><CardContent className="p-3 flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${STATUS_META[k].dot}`} />
            <div><div className="text-[11px] text-muted-foreground">{STATUS_META[k].label}</div><div className="text-2xl font-bold font-mono leading-none">{v ?? '—'}</div></div>
          </CardContent></Card>
        ))}
      </div>

      <Card className="border-primary/30 bg-primary/5">
        <CardContent className="p-4 flex flex-wrap items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-primary/15 text-primary flex items-center justify-center"><Users className="w-6 h-6" /></div>
          <div className="flex-1 min-w-[12rem]">
            <p className="text-xs text-muted-foreground">الدور الآن على</p>
            <p className="text-xl font-bold">{next ? next.driverName : 'لا يوجد مندوب في الانتظار'}</p>
            {next && <p className="text-xs text-muted-foreground flex items-center gap-1"><Hourglass className="w-3 h-3" /> منتظر من {fmtDuration(minutesSince(next.waitingSince))}</p>}
          </div>
          <Button onClick={() => setSmartOpen(true)} disabled={!drivers.some((d) => d.status === 'available')}><Sparkles className="w-4 h-4 ml-1.5" /> وزّع على الدور</Button>
          <Link href="/trips"><Button variant="outline">رحلة يدوية</Button></Link>
        </CardContent>
      </Card>

      {isLoading ? <div className="h-32 rounded-xl bg-muted/20 animate-pulse" /> : drivers.length === 0 ? (
        <p className="text-center text-muted-foreground py-10">لا يوجد مناديب مفعّلون في فرعك</p>
      ) : (
        <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
          {drivers.map((d) => (
            <Card key={d.driverId} className={`border-border/40 ${d.status === 'available' && d.queuePosition === 1 ? 'border-primary/60 bg-primary/5' : 'bg-card/70'}`}>
              <CardContent className="p-4 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3 min-w-0">
                    {d.queuePosition ? (
                      <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground font-extrabold flex items-center justify-center shrink-0">{d.queuePosition}</div>
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center shrink-0"><span className={`w-3 h-3 rounded-full ${STATUS_META[d.status].dot}`} /></div>
                    )}
                    <div className="min-w-0">
                      <p className="font-bold truncate">{d.driverName}</p>
                      {d.phone && <a href={`tel:${d.phone}`} className="text-[11px] text-muted-foreground inline-flex items-center gap-1"><Phone className="w-3 h-3" />{d.phone}</a>}
                    </div>
                  </div>
                  <Badge variant="outline" className={`${STATUS_META[d.status].badge} text-[11px] shrink-0`}>{STATUS_META[d.status].label}</Badge>
                </div>

                <div className="grid grid-cols-3 gap-1.5 text-center text-[11px]">
                  <div className="rounded-lg bg-background/50 py-1.5"><div className="font-bold text-sm">{d.deliveredToday}</div>سلّم اليوم</div>
                  <div className="rounded-lg bg-background/50 py-1.5"><div className="font-bold text-sm">{d.parcelsOut}</div>في الطريق</div>
                  <div className="rounded-lg bg-background/50 py-1.5"><div className="font-bold text-sm font-mono">{Math.round(d.cashBalance)}</div>كاش معه</div>
                </div>
                {d.shiftStartedAt && <p className="text-[11px] text-muted-foreground flex items-center gap-1"><Coffee className="w-3 h-3" /> شيفت من {fmtDuration(minutesSince(d.shiftStartedAt))}{d.breakMinutes ? ` · استراحة ${d.breakMinutes} د` : ''}</p>}

                <div className="flex flex-wrap gap-1.5">
                  {d.status === 'off' && (
                    <Button size="sm" variant="outline" disabled={busyId === d.driverId} onClick={() => act(d.driverId, '/shifts/start', {}, `تم بدء شيفت ${d.driverName}`)}>
                      <Play className="w-3.5 h-3.5 ml-1" /> ابدأ شيفته
                    </Button>
                  )}
                  {d.status === 'available' && (
                    <>
                      <Button size="sm" variant="outline" disabled={busyId === d.driverId} title="قدّمه لأول الدور" onClick={() => act(d.driverId, `/shifts/queue/${d.driverId}`, { position: 'front' }, 'تم تقديمه لأول الدور')}><ChevronsUp className="w-3.5 h-3.5" /></Button>
                      <Button size="sm" variant="outline" disabled={busyId === d.driverId} title="أخّره لآخر الدور" onClick={() => act(d.driverId, `/shifts/queue/${d.driverId}`, { position: 'back' }, 'تم تأخيره لآخر الدور')}><ChevronsDown className="w-3.5 h-3.5" /></Button>
                    </>
                  )}
                  {(d.status === 'available' || d.status === 'break') && (
                    <Button size="sm" variant="ghost" className="text-destructive hover:bg-destructive/10" disabled={busyId === d.driverId}
                      onClick={() => { if (window.confirm(`إنهاء شيفت ${d.driverName}؟`)) void act(d.driverId, '/shifts/end', {}, `تم إنهاء شيفت ${d.driverName}`); }}>
                      <Square className="w-3.5 h-3.5 ml-1" /> إنهاء
                    </Button>
                  )}
                  {d.trip && d.trip.status === 'draft' && <Link href={`/dispatch?tab=loading&trip=${d.trip.id}`}><Button size="sm"><PackageCheck className="w-3.5 h-3.5 ml-1" /> محطة التحميل</Button></Link>}
                  {d.status === 'on_trip' && <span className="text-xs text-orange-500 flex items-center gap-1"><Truck className="w-3.5 h-3.5" /> رحلة #{d.trip?.id}</span>}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <SmartDispatchDialog open={smartOpen} onOpenChange={setSmartOpen} onCreated={() => { qc.invalidateQueries({ queryKey: ['shift-board'] }); onSmartCreated(); }} />
    </div>
  );
}

// ===========================================================================
// 2) Loading station → departure
// ===========================================================================
function LoadingTab({ initialTripId }: { initialTripId: number | null }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const canOverride = user?.role === 'super_admin' || user?.role === 'branch_manager';
  const [tripId, setTripId] = useState<number | null>(initialTripId);
  const [results, setResults] = useState<ScanResult[]>([]);
  const [busy, setBusy] = useState(false);
  const [override, setOverride] = useState(false);
  const [reason, setReason] = useState('');

  const { data: trips = [], isLoading } = useQuery({ queryKey: ['draft-trips'], queryFn: () => apiFetch<Trip[]>('/trips?status=draft'), refetchInterval: 6_000 });
  const { data: board } = useQuery({ queryKey: ['shift-board'], queryFn: () => apiFetch<Board>('/shifts/board'), refetchInterval: 10_000 });

  useEffect(() => { if (tripId === null && trips.length) setTripId(trips[0].id); }, [trips, tripId]);
  const trip = trips.find((t) => t.id === tripId) ?? null;
  const driver = board?.drivers.find((d) => d.driverId === trip?.driverId);

  const refresh = () => { qc.invalidateQueries({ queryKey: ['draft-trips'] }); qc.invalidateQueries({ queryKey: ['shift-board'] }); };

  const scan = async (numbers: string[]) => {
    if (!trip) return;
    setBusy(true);
    try {
      const res = await apiFetch<{ results: ScanResult[] }>(`/trips/${trip.id}/load-scan`, { method: 'POST', body: JSON.stringify({ orderNumbers: numbers }) });
      setResults((prev) => [...res.results, ...prev].slice(0, 8));
      beep(res.results.every((r) => r.ok));
      refresh();
    } catch (e: any) {
      beep(false);
      toast({ variant: 'destructive', title: 'تعذر المسح', description: e.message });
    } finally { setBusy(false); }
  };

  const removeOrder = async (orderNumber: string) => {
    if (!trip || !window.confirm(`إخراج ${orderNumber} من الرحلة؟`)) return;
    try {
      await apiFetch(`/trips/${trip.id}/remove-order`, { method: 'POST', body: JSON.stringify({ orderNumber }) });
      refresh();
    } catch (e: any) { toast({ variant: 'destructive', title: 'تعذر الإخراج', description: e.message }); }
  };

  const depart = async () => {
    if (!trip) return;
    setBusy(true);
    try {
      await apiFetch(`/trips/${trip.id}/confirm`, { method: 'POST', body: JSON.stringify(override ? { override: true, reason } : {}) });
      toast({ title: `انطلقت الرحلة #${trip.id}`, description: `${trip.driverName} في الطريق ومعه ${trip.activeCount} شحنة` });
      setTripId(null); setOverride(false); setReason('');
      refresh();
      qc.invalidateQueries({ queryKey: ['trips'] });
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'لا يمكن الانطلاق', description: e.message });
    } finally { setBusy(false); }
  };

  const allLoaded = !!trip && trip.activeCount > 0 && trip.loadedCount === trip.activeCount;
  const onDuty = driver ? driver.status === 'available' : false;
  const checks = trip ? [
    { ok: allLoaded, text: `كل الشحنات اتمسحت (${trip.loadedCount} من ${trip.activeCount})` },
    { ok: !!trip.acceptedAt, text: trip.acceptedAt ? 'المندوب أكد استلام الشحنات' : 'بانتظار تأكيد المندوب من تطبيقه' },
    { ok: onDuty, text: onDuty ? 'المندوب على الشيفت' : 'المندوب ليس متاحاً (لم يبدأ الشيفت أو في استراحة)' },
  ] : [];
  const ready = checks.length > 0 && checks.every((c) => c.ok);

  if (isLoading) return <div className="h-40 rounded-xl bg-muted/20 animate-pulse" />;
  if (trips.length === 0) {
    return (
      <div className="text-center py-14 space-y-3">
        <PackageCheck className="w-10 h-10 mx-auto text-muted-foreground" />
        <p className="text-muted-foreground">لا توجد رحلات بانتظار التحميل. أنشئ رحلة أو وزّع على الدور من تبويب «الدور».</p>
      </div>
    );
  }

  return (
    <div className="grid lg:grid-cols-3 gap-4">
      <div className="space-y-2">
        <p className="text-sm font-semibold text-muted-foreground">رحلات بانتظار التحميل</p>
        {trips.map((t) => (
          <button key={t.id} type="button" onClick={() => { setTripId(t.id); setResults([]); }}
            className={`w-full text-right rounded-xl border p-3 transition-colors ${t.id === tripId ? 'border-primary bg-primary/10' : 'border-border/50 bg-card/60 hover:bg-card'}`}>
            <div className="flex justify-between items-center"><b>{t.driverName}</b><span className="text-xs text-muted-foreground">#{t.id}</span></div>
            <div className="mt-2 h-1.5 rounded-full bg-muted overflow-hidden"><div className="h-full bg-primary" style={{ width: `${t.activeCount ? (t.loadedCount / t.activeCount) * 100 : 0}%` }} /></div>
            <div className="mt-1 flex justify-between text-[11px] text-muted-foreground"><span>{t.loadedCount}/{t.activeCount} محمّلة</span>{t.acceptedAt && <span className="text-emerald-500">✓ أكد المندوب</span>}</div>
          </button>
        ))}
      </div>

      {trip && (
        <div className="lg:col-span-2 space-y-4">
          <Card className="border-border/40 bg-card/60"><CardContent className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold flex items-center gap-2"><Truck className="w-5 h-5 text-primary" /> تحميل رحلة {trip.driverName}</h3>
              <span className="text-sm font-mono">{trip.loadedCount}/{trip.activeCount}</span>
            </div>
            <ScanBox placeholder="امسح QR الشحنة أو اكتب رقمها (ALG-...) ثم Enter" onScan={scan} busy={busy} />
            {results.length > 0 && (
              <ul className="text-xs space-y-1">
                {results.map((r, i) => (
                  <li key={`${r.orderNumber}-${i}`} className={`flex items-center gap-2 ${r.ok ? 'text-emerald-500' : 'text-destructive'}`}>
                    {r.ok ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}
                    <span className="font-mono font-bold">{r.orderNumber}</span><span>{r.message}</span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent></Card>

          <Card className="border-border/40 bg-card/60"><CardContent className="p-0 divide-y divide-border/30">
            {[...trip.orders].filter((o) => !['delivered', 'partial_delivery', 'final_return'].includes(o.status))
              .sort((a, b) => (a.stopSequence ?? 1e9) - (b.stopSequence ?? 1e9) || a.id - b.id).map((o) => (
              <div key={o.id} className="flex items-center gap-3 px-4 py-2.5 text-sm">
                {o.loadedAt ? <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" /> : <Circle className="w-5 h-5 text-muted-foreground shrink-0" />}
                <span className="font-mono font-bold text-primary w-28 shrink-0">{o.orderNumber}</span>
                <span className="flex-1 truncate">{o.customerName} — {o.area}</span>
                {o.stopSequence && <span className="text-xs text-muted-foreground">محطة {o.stopSequence}</span>}
                <button type="button" onClick={() => removeOrder(o.orderNumber)} className="p-1 text-muted-foreground hover:text-destructive" aria-label="إخراج من الرحلة"><Trash2 className="w-4 h-4" /></button>
              </div>
            ))}
          </CardContent></Card>

          <Card className={`border-border/40 ${ready ? 'border-emerald-500/40 bg-emerald-500/5' : 'bg-card/60'}`}><CardContent className="p-4 space-y-3">
            <ul className="space-y-1.5 text-sm">
              {checks.map((c) => (
                <li key={c.text} className={`flex items-center gap-2 ${c.ok ? 'text-emerald-500' : 'text-muted-foreground'}`}>
                  {c.ok ? <CheckCircle2 className="w-4 h-4" /> : <Circle className="w-4 h-4" />} {c.text}
                </li>
              ))}
            </ul>
            {!ready && canOverride && (
              <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 space-y-2">
                <label className="flex items-center gap-2 text-sm text-amber-500 cursor-pointer"><input type="checkbox" checked={override} onChange={(e) => setOverride(e.target.checked)} /><ShieldAlert className="w-4 h-4" /> تجاوز الشروط بصلاحية المدير (يُسجَّل السبب)</label>
                {override && <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="سبب التجاوز (مطلوب)" maxLength={300} />}
              </div>
            )}
            <Button size="lg" className="w-full h-12 text-base" disabled={busy || (!ready && !(override && reason.trim().length >= 3))} onClick={depart}>
              {busy ? <Loader2 className="w-5 h-5 animate-spin ml-2" /> : <Rocket className="w-5 h-5 ml-2" />} {ready ? 'انطلاق الرحلة' : override ? 'انطلاق بالتجاوز' : 'انطلاق الرحلة'}
            </Button>
          </CardContent></Card>
        </div>
      )}
    </div>
  );
}

// ===========================================================================
// 3) Returned parcels check-in
// ===========================================================================
function ReturnsTab() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);
  const [results, setResults] = useState<ScanResult[]>([]);
  const { data: pending = [], isLoading } = useQuery({
    queryKey: ['returns-pending'],
    queryFn: () => apiFetch<{ id: number; orderNumber: string; customerName: string; area: string; status: string; driverName: string | null; tripId: number | null }[]>('/returns/pending'),
    refetchInterval: 10_000,
  });

  const scan = async (numbers: string[]) => {
    setBusy(true);
    try {
      const res = await apiFetch<{ results: ScanResult[] }>('/returns/check-in', { method: 'POST', body: JSON.stringify({ orderNumbers: numbers }) });
      setResults((prev) => [...res.results, ...prev].slice(0, 8));
      beep(res.results.every((r) => r.ok));
      qc.invalidateQueries({ queryKey: ['returns-pending'] });
    } catch (e: any) {
      beep(false);
      toast({ variant: 'destructive', title: 'تعذر الاستلام', description: e.message });
    } finally { setBusy(false); }
  };

  const byDriver = useMemo(() => {
    const m = new Map<string, typeof pending>();
    pending.forEach((p) => m.set(p.driverName ?? 'بدون مندوب', [...(m.get(p.driverName ?? 'بدون مندوب') ?? []), p]));
    return [...m.entries()];
  }, [pending]);

  return (
    <div className="space-y-4 max-w-3xl">
      <Card className="border-border/40 bg-card/60"><CardContent className="p-4 space-y-3">
        <h3 className="font-bold flex items-center gap-2"><Undo2 className="w-5 h-5 text-primary" /> استلام المرتجعات من المناديب</h3>
        <p className="text-sm text-muted-foreground">امسح كل شحنة مرتجعة يسلّمها المندوب. الرحلة لا تُغلق قبل استلام مرتجعاتها، والشحنة لا تخرج مرة ثانية قبل أن تدخل المخزن.</p>
        <ScanBox placeholder="امسح الشحنة المرتجعة" onScan={scan} busy={busy} />
        {results.length > 0 && (
          <ul className="text-xs space-y-1">
            {results.map((r, i) => (
              <li key={`${r.orderNumber}-${i}`} className={`flex items-center gap-2 ${r.ok ? 'text-emerald-500' : 'text-destructive'}`}>
                {r.ok ? <CheckCircle2 className="w-3.5 h-3.5" /> : <XCircle className="w-3.5 h-3.5" />}<span className="font-mono font-bold">{r.orderNumber}</span><span>{r.message}</span>
              </li>
            ))}
          </ul>
        )}
      </CardContent></Card>

      <div>
        <p className="text-sm font-semibold text-muted-foreground mb-2">بانتظار الاستلام في المخزن ({pending.length})</p>
        {isLoading ? <div className="h-20 rounded-xl bg-muted/20 animate-pulse" /> : pending.length === 0 ? (
          <p className="text-center text-sm text-emerald-500 py-8">كل المرتجعات مستلمة ✓</p>
        ) : byDriver.map(([name, list]) => (
          <Card key={name} className="border-border/40 bg-card/60 mb-2"><CardContent className="p-3">
            <p className="font-bold text-sm mb-1.5">{name} <span className="text-muted-foreground font-normal">({list.length})</span></p>
            <div className="flex flex-wrap gap-1.5">
              {list.map((p) => <Badge key={p.id} variant="outline" className="font-mono text-[11px]" title={`${p.customerName} — ${p.area}`}>{p.orderNumber}</Badge>)}
            </div>
          </CardContent></Card>
        ))}
      </div>
    </div>
  );
}

export default function Dispatch() {
  const params = new URLSearchParams(window.location.search);
  const initialTab = (['board', 'loading', 'returns'] as const).find((t) => t === params.get('tab')) ?? 'board';
  const [tab, setTab] = useState<Tab>(initialTab);
  const tripParam = Number(params.get('trip'));

  const tabs: { key: Tab; label: string; Icon: typeof Users }[] = [
    { key: 'board', label: 'الدور والمناديب', Icon: Users },
    { key: 'loading', label: 'التحميل والانطلاق', Icon: PackageCheck },
    { key: 'returns', label: 'استلام المرتجعات', Icon: Undo2 },
  ];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">غرفة العمليات</h1>
        <p className="text-muted-foreground">الشيفتات والدور، تحميل الشحنات قبل الخروج، واستلام المرتجعات</p>
      </div>
      <div className="inline-flex rounded-xl border border-border/50 bg-card/50 p-1 gap-1 flex-wrap">
        {tabs.map(({ key, label, Icon }) => (
          <button key={key} type="button" onClick={() => setTab(key)}
            className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-colors ${tab === key ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
            <Icon className="w-4 h-4" /> {label}
          </button>
        ))}
      </div>
      {tab === 'board' && <BoardTab onSmartCreated={() => setTab('loading')} />}
      {tab === 'loading' && <LoadingTab initialTripId={Number.isInteger(tripParam) && tripParam > 0 ? tripParam : null} />}
      {tab === 'returns' && <ReturnsTab />}
    </div>
  );
}
