import React, { useState, useMemo } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { motion, useMotionValue, useTransform, useSpring } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';
import logoPath from '@assets/al-ghazali-logo.png';
import { useToast } from '@/hooks/use-toast';

const loginSchema = z.object({
  username: z.string().min(3, { message: 'اسم المستخدم يجب أن يكون 3 أحرف على الأقل' }),
  password: z.string().min(6, { message: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' }),
});

/** Floating dust / star particles for depth */
function Particles({ count = 36 }: { count?: number }) {
  const items = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        id: i,
        left: `${(i * 37) % 100}%`,
        top: `${(i * 53) % 100}%`,
        size: 1.5 + (i % 4),
        delay: (i % 10) * 0.4,
        duration: 6 + (i % 7),
        opacity: 0.15 + (i % 5) * 0.08,
      })),
    [count],
  );

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden>
      {items.map((p) => (
        <motion.span
          key={p.id}
          className="absolute rounded-full bg-amber-400"
          style={{
            left: p.left,
            top: p.top,
            width: p.size,
            height: p.size,
            opacity: p.opacity,
          }}
          animate={{
            y: [0, -28, 0],
            opacity: [p.opacity, p.opacity * 1.6, p.opacity],
            scale: [1, 1.35, 1],
          }}
          transition={{
            repeat: Infinity,
            duration: p.duration,
            delay: p.delay,
            ease: 'easeInOut',
          }}
        />
      ))}
    </div>
  );
}

/** Orbiting rings giving a 3D platform feel */
function OrbitRings() {
  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none" aria-hidden>
      <div
        className="absolute w-[min(90vw,420px)] h-[min(90vw,420px)] border border-amber-500/15 rounded-full"
        style={{ transform: 'rotateX(68deg) scaleY(0.55)', boxShadow: '0 0 40px rgba(245,158,11,0.08)' }}
      />
      <div
        className="absolute w-[min(70vw,300px)] h-[min(70vw,300px)] border border-amber-400/25 rounded-full"
        style={{ transform: 'rotateX(68deg) scaleY(0.55)' }}
      />
      <div
        className="absolute w-[min(50vw,200px)] h-[min(50vw,200px)] border border-amber-300/20 rounded-full"
        style={{ transform: 'rotateX(68deg) scaleY(0.55)' }}
      />
      <div
        className="absolute w-[min(55vw,260px)] h-8 rounded-[100%] bg-amber-500/20 blur-2xl"
        style={{ bottom: '18%', transform: 'scaleX(1.4)' }}
      />
    </div>
  );
}

export default function Login() {
  const { login } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: { username: '', password: '' },
  });

  const onSubmit = async (values: z.infer<typeof loginSchema>) => {
    setIsLoading(true);
    try {
      await login(values);
    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: 'خطأ في تسجيل الدخول',
        description: error.message || 'تأكد من اسم المستخدم وكلمة المرور',
      });
      setIsLoading(false);
    }
  };

  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const springX = useSpring(mouseX, { stiffness: 80, damping: 18 });
  const springY = useSpring(mouseY, { stiffness: 80, damping: 18 });
  const rotateX = useTransform(springY, [-400, 400], [14, -14]);
  const rotateY = useTransform(springX, [-400, 400], [-16, 16]);

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    mouseX.set(e.clientX - rect.left - rect.width / 2);
    mouseY.set(e.clientY - rect.top - rect.height / 2);
  };

  const handleMouseLeave = () => {
    mouseX.set(0);
    mouseY.set(0);
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#07080c] text-foreground overflow-hidden">
      {/* 3D Visual Panel */}
      <div
        className="relative overflow-hidden flex items-center justify-center
          h-52 sm:h-64 md:flex-1 md:h-auto md:min-h-screen
          bg-[radial-gradient(ellipse_at_30%_20%,#1a1520_0%,#0a0b10_45%,#050508_100%)]"
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        style={{ perspective: 1200 }}
      >
        <div className="absolute inset-0 opacity-40 pointer-events-none">
          <div className="absolute -top-1/4 -left-1/4 w-[70%] h-[70%] rounded-full bg-amber-600/20 blur-[100px]" />
          <div className="absolute -bottom-1/4 -right-1/4 w-[60%] h-[60%] rounded-full bg-orange-700/15 blur-[90px]" />
          <div className="absolute top-1/3 right-1/4 w-[40%] h-[40%] rounded-full bg-amber-400/10 blur-[80px]" />
        </div>

        <div
          className="absolute inset-x-0 bottom-0 h-[55%] opacity-[0.12] pointer-events-none
            bg-[linear-gradient(rgba(245,158,11,0.35)_1px,transparent_1px),linear-gradient(90deg,rgba(245,158,11,0.35)_1px,transparent_1px)]
            bg-[size:48px_48px]"
          style={{
            transform: 'perspective(600px) rotateX(58deg)',
            transformOrigin: 'center top',
            maskImage: 'linear-gradient(to bottom, transparent, black 30%, black 70%, transparent)',
            WebkitMaskImage: 'linear-gradient(to bottom, transparent, black 30%, black 70%, transparent)',
          }}
        />

        <Particles count={40} />
        <OrbitRings />

        <motion.div
          style={{ rotateX, rotateY, transformStyle: 'preserve-3d' }}
          className="relative z-10 flex flex-col items-center justify-center px-4"
        >
          <motion.div
            animate={{
              y: [0, -14, 0],
              filter: [
                'drop-shadow(0 12px 28px rgba(245,158,11,0.25)) drop-shadow(0 0 20px rgba(245,158,11,0.2))',
                'drop-shadow(0 22px 48px rgba(245,158,11,0.45)) drop-shadow(0 0 40px rgba(245,158,11,0.35))',
                'drop-shadow(0 12px 28px rgba(245,158,11,0.25)) drop-shadow(0 0 20px rgba(245,158,11,0.2))',
              ],
            }}
            transition={{ repeat: Infinity, duration: 4.2, ease: 'easeInOut' }}
            style={{ transform: 'translateZ(60px)' }}
          >
            <img
              src={logoPath}
              alt="Al-Ghazali"
              className="w-28 h-28 sm:w-40 sm:h-40 md:w-56 md:h-56 lg:w-64 lg:h-64 object-contain select-none"
              draggable={false}
            />
          </motion.div>

          <motion.div
            className="mt-4 md:mt-6 text-center hidden sm:block"
            style={{ transform: 'translateZ(30px)' }}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25, duration: 0.6 }}
          >
            <h1 className="text-2xl md:text-3xl lg:text-4xl font-extrabold tracking-[0.18em] text-white">
              AL-GHAZALI
            </h1>
            <p className="mt-2 text-amber-400/90 text-xs md:text-sm tracking-[0.35em] uppercase font-medium">
              Fast. Reliable. Al-Ghazali.
            </p>
            <p className="mt-1 text-white/50 text-sm md:text-base font-medium tracking-wide">
              سريع. موثوق. الغزالي.
            </p>
          </motion.div>
        </motion.div>

        <div className="absolute bottom-3 left-0 right-0 text-center sm:hidden z-10">
          <p className="text-amber-400/90 text-[11px] font-bold tracking-[0.25em] uppercase">
            Al-Ghazali Shipping ERP
          </p>
        </div>

        <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_center,transparent_40%,rgba(0,0,0,0.55)_100%)]" />
      </div>

      {/* Login Form Panel */}
      <div className="flex-1 flex items-center justify-center p-5 sm:p-8 relative min-h-0
        bg-gradient-to-br from-[#0c0e14] via-[#10131a] to-[#0a0b10]">
        <div
          className="absolute inset-0 opacity-[0.04] pointer-events-none"
          style={{
            backgroundImage:
              "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23f59e0b' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")",
          }}
        />

        <Card className="w-full max-w-sm sm:max-w-md border-amber-500/15 shadow-[0_0_60px_rgba(245,158,11,0.08)] bg-card/70 backdrop-blur-xl relative z-10">
          <CardHeader className="text-center space-y-3 pb-2">
            <div className="mx-auto sm:hidden">
              <img src={logoPath} alt="" className="w-16 h-16 object-contain mx-auto opacity-90" />
            </div>
            <CardTitle className="text-2xl sm:text-3xl font-bold tracking-tight">تسجيل الدخول</CardTitle>
            <CardDescription className="text-muted-foreground text-sm">
              أدخل بيانات الاعتماد للوصول إلى نظام الغزالي للشحن
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>اسم المستخدم</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="admin"
                          {...field}
                          className="bg-background/50 border-border/50 focus:border-amber-500/50 transition-colors h-11"
                          autoComplete="username"
                          dir="ltr"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>كلمة المرور</FormLabel>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder="••••••••"
                          {...field}
                          className="bg-background/50 border-border/50 focus:border-amber-500/50 transition-colors h-11"
                          autoComplete="current-password"
                          dir="ltr"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button
                  type="submit"
                  className="w-full h-11 text-base font-bold bg-amber-500 hover:bg-amber-400 text-black
                    shadow-[0_0_24px_rgba(245,158,11,0.35)] transition-all"
                  disabled={isLoading}
                >
                  {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'دخول'}
                </Button>
              </form>
            </Form>
            <p className="mt-6 text-center text-[11px] text-muted-foreground/70 tracking-wide">
              Fast. Reliable. Al-Ghazali.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
