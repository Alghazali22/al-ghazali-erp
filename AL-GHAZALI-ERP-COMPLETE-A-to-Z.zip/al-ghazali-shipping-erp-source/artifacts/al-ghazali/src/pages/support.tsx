import React from 'react';
import { TicketsPanel } from '@/components/TicketsPanel';

/** Merchant-facing help desk: open a ticket about a shipment and follow the reply. */
export default function MerchantSupport() {
  return (
    <div className="space-y-5 max-w-3xl">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">الدعم الفني</h1>
        <p className="text-muted-foreground">تواصل مع فريق الغزالي بخصوص أي شحنة وتابع الرد من هنا</p>
      </div>
      <TicketsPanel merchant />
    </div>
  );
}
