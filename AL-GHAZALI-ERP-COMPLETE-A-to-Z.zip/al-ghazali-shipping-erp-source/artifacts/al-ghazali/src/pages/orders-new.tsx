import React, { useMemo, useState } from 'react';
import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { ArrowRight, FilePlus2, Table2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { apiFetch } from '@/lib/extra-api';
import { SingleOrderForm } from '@/components/SingleOrderForm';
import { OrderGrid } from '@/components/OrderGrid';
import type { ZoneLite } from '@/lib/zoneMatch';

type Zone = ZoneLite & { id: number };
type Mode = 'single' | 'grid';

export default function NewOrder() {
  const { user } = useAuth();
  const isMerchant = user?.role === 'merchant';
  const initialMode: Mode = new URLSearchParams(window.location.search).get('mode') === 'grid' ? 'grid' : 'single';
  const [mode, setMode] = useState<Mode>(initialMode);
  const [pickedMerchant, setPickedMerchant] = useState<number | null>(null);

  const { data: zones = [] } = useQuery({ queryKey: ['zones-all'], queryFn: () => apiFetch<Zone[]>('/zones'), staleTime: 5 * 60_000 });
  const { data: merchants = [] } = useQuery({
    queryKey: ['merchants-for-orders'],
    queryFn: () => apiFetch<{ id: number; fullName: string }[]>('/users?role=merchant'),
    enabled: !isMerchant,
  });

  const merchantId = isMerchant ? user?.id ?? null : pickedMerchant;
  const merchantName = useMemo(
    () => (isMerchant ? user?.fullName ?? '' : merchants.find((m) => m.id === pickedMerchant)?.fullName ?? ''),
    [isMerchant, user, merchants, pickedMerchant],
  );

  const tabs: { key: Mode; title: string; hint: string; Icon: typeof FilePlus2 }[] = [
    { key: 'single', title: 'شحنة واحدة', hint: 'فورم ذكي بالتعبئة التلقائية', Icon: FilePlus2 },
    { key: 'grid', title: 'شحنات كثيرة (جدول / Excel)', hint: 'الصق من Excel أو Google Sheets', Icon: Table2 },
  ];

  return (
    <div className={`${mode === 'grid' ? 'max-w-7xl' : 'max-w-2xl'} mx-auto space-y-5`}>
      <div className="flex items-center gap-3">
        <Link href="/orders">
          <Button variant="ghost" size="sm" className="h-9 px-2.5"><ArrowRight className="w-4 h-4 ml-1" /> الطلبات</Button>
        </Link>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">إنشاء شحنات</h1>
          <p className="text-muted-foreground text-sm">طلب واحد أو مئات الطلبات دفعة واحدة، مع حساب السعر ومؤشر ثقة التسليم قبل الشحن</p>
        </div>
      </div>

      {!isMerchant && (
        <label className="block text-sm space-y-1">
          <span className="font-semibold">التاجر صاحب الشحنات *</span>
          <select value={pickedMerchant ?? ''} onChange={(e) => setPickedMerchant(e.target.value ? Number(e.target.value) : null)}
            className="w-full h-10 px-3 rounded-md border border-border bg-background/50 outline-none focus:border-primary">
            <option value="">اختر التاجر</option>
            {merchants.map((m) => <option key={m.id} value={m.id}>{m.fullName}</option>)}
          </select>
        </label>
      )}

      <div className="grid grid-cols-2 gap-2">
        {tabs.map(({ key, title, hint, Icon }) => (
          <button key={key} type="button" onClick={() => setMode(key)}
            className={`flex items-center gap-3 rounded-xl border p-3 text-right transition-colors ${mode === key ? 'border-primary bg-primary/10' : 'border-border/50 bg-card/40 hover:bg-card/70'}`}>
            <Icon className={`w-6 h-6 shrink-0 ${mode === key ? 'text-primary' : 'text-muted-foreground'}`} />
            <span><span className="block font-bold text-sm">{title}</span><span className="block text-xs text-muted-foreground">{hint}</span></span>
          </button>
        ))}
      </div>

      {mode === 'single'
        ? <SingleOrderForm zones={zones} merchantId={merchantId} merchantName={merchantName} />
        : <OrderGrid zones={zones} merchantId={merchantId} merchantName={merchantName} userKey={`${user?.id ?? 0}-${merchantId ?? 0}`} />}
    </div>
  );
}
