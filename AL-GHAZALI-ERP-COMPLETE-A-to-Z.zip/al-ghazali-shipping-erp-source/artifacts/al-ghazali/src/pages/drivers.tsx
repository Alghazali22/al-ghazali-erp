import React, { useState } from 'react';
import { useGetUsers, useGetBranches, useCreateUser, useToggleUserStatus, useDeleteUser, getGetUsersQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { ResetPasswordButton } from '@/components/ResetPasswordButton';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { User, MapPin, Wallet, Plus, Search, Power, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

const driverSchema = z.object({
  username: z.string().min(3, 'اسم المستخدم 3 أحرف على الأقل'),
  password: z.string().min(8, 'كلمة المرور 8 أحرف على الأقل'),
  fullName: z.string().min(2, 'الاسم مطلوب'),
  phone: z.string().optional(),
  branchId: z.coerce.number().optional(),
});

export default function Drivers() {
  const [search, setSearch] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDriver, setDeleteDriver] = useState<any>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user: currentUser } = useAuth();
  const toggleStatus = useToggleUserStatus();
  const createUser = useCreateUser();
  const deleteUser = useDeleteUser();
  const canDelete = currentUser?.role === 'super_admin';

  const { data, isLoading } = useGetUsers({ role: 'driver', ...(search ? { search } : {}) });
  const { data: branches } = useGetBranches();
  const drivers = Array.isArray(data) ? data : [];

  const form = useForm<z.infer<typeof driverSchema>>({
    resolver: zodResolver(driverSchema),
    defaultValues: { username: '', password: '', fullName: '', phone: '' },
  });

  const onSubmit = async (values: z.infer<typeof driverSchema>) => {
    try {
      await createUser.mutateAsync({ data: { ...values, role: 'driver' } });
      queryClient.invalidateQueries({ queryKey: getGetUsersQueryKey({ role: 'driver' }) });
      toast({ title: 'تم إضافة المندوب بنجاح' });
      setDialogOpen(false);
      form.reset();
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'خطأ', description: e.message || 'حدث خطأ أثناء الإضافة' });
    }
  };

  const handleToggle = async (id: number, isActive: boolean) => {
    try {
      await toggleStatus.mutateAsync({ id });
      queryClient.invalidateQueries({ queryKey: getGetUsersQueryKey({ role: 'driver' }) });
      toast({ title: isActive ? 'تم إيقاف المندوب' : 'تم تفعيل المندوب' });
    } catch {
      toast({ variant: 'destructive', title: 'حدث خطأ' });
    }
  };

  const handleDelete = async () => {
    if (!deleteDriver) return;
    try {
      await deleteUser.mutateAsync({ id: deleteDriver.id });
      await queryClient.invalidateQueries({ queryKey: getGetUsersQueryKey({ role: 'driver' }) });
      toast({ title: 'تم حذف المندوب', description: `تم حذف حساب ${deleteDriver.fullName} نهائياً` });
      setDeleteDriver(null);
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر حذف المندوب', description: e.message || 'حدث خطأ أثناء الحذف' });
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">المندوبين</h1>
          <p className="text-muted-foreground text-sm">إدارة طاقم التوصيل والمندوبين</p>
        </div>
        <Button className="bg-primary hover:bg-primary/90 shrink-0" onClick={() => setDialogOpen(true)}>
          <Plus className="w-4 h-4 ml-2" /> إضافة مندوب
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
        <Input placeholder="بحث بالاسم..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-4 pr-9 bg-card/60" />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading ? (
          [...Array(4)].map((_, i) => <Card key={i} className="h-44 animate-pulse bg-muted/20" />)
        ) : drivers.length === 0 ? (
          <div className="col-span-full text-center py-12 text-muted-foreground">لا يوجد مندوبين</div>
        ) : drivers.map((driver) => (
          <Card key={driver.id} className={`border-border/40 bg-card/60 backdrop-blur-sm overflow-hidden transition-all hover:shadow-[0_4px_20px_rgba(245,158,11,0.08)] ${!driver.isActive ? 'opacity-60' : ''}`}>
            <CardContent className="p-5">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
                    <User className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold">{driver.fullName}</h3>
                    <p className="text-xs text-muted-foreground" dir="ltr">{driver.phone || '—'}</p>
                  </div>
                </div>
                <Badge variant={driver.isActive ? 'default' : 'destructive'} className="text-xs px-2 shrink-0">
                  {driver.isActive ? 'نشط' : 'موقوف'}
                </Badge>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5" /> الفرع</span>
                  <span className="font-medium">{driver.branchName || '—'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground flex items-center gap-1.5"><Wallet className="w-3.5 h-3.5" /> العهدة</span>
                  <span className="font-bold text-primary">{driver.cashBalance || 0} ج.م</span>
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <Button variant="ghost" size="sm" className="flex-1 text-xs text-muted-foreground hover:text-foreground border border-border/40"
                  onClick={() => handleToggle(driver.id, driver.isActive)} disabled={toggleStatus.isPending}>
                  <Power className="w-3.5 h-3.5 ml-1.5" />
                  {driver.isActive ? 'إيقاف مؤقت' : 'تفعيل'}
                </Button>
                <ResetPasswordButton user={driver} />
                {canDelete && (
                  <Button variant="ghost" size="sm" className="h-9 w-9 p-0 text-muted-foreground hover:text-destructive border border-border/40"
                    onClick={() => setDeleteDriver(driver)}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) form.reset(); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>إضافة مندوب جديد</DialogTitle>
            <DialogDescription>أدخل بيانات المندوب لإنشاء حساب جديد</DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="username" render={({ field }) => (
                  <FormItem><FormLabel>اسم المستخدم</FormLabel><FormControl><Input {...field} dir="ltr" className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="password" render={({ field }) => (
                  <FormItem><FormLabel>كلمة المرور</FormLabel><FormControl><Input type="password" {...field} dir="ltr" className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={form.control} name="fullName" render={({ field }) => (
                <FormItem><FormLabel>الاسم الكامل</FormLabel><FormControl><Input {...field} className="bg-background/50" /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="phone" render={({ field }) => (
                <FormItem><FormLabel>رقم الهاتف</FormLabel><FormControl><Input {...field} dir="ltr" className="bg-background/50" /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="branchId" render={({ field }) => (
                <FormItem><FormLabel>الفرع</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value?.toString()}>
                    <FormControl><SelectTrigger className="bg-background/50"><SelectValue placeholder="اختر الفرع (اختياري)" /></SelectTrigger></FormControl>
                    <SelectContent>{branches?.map(b => <SelectItem key={b.id} value={b.id.toString()}>{b.name}</SelectItem>)}</SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
                <Button type="submit" disabled={createUser.isPending} className="bg-primary hover:bg-primary/90">
                  {createUser.isPending ? 'جاري الحفظ...' : 'إضافة المندوب'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteDriver} onOpenChange={(open) => !open && setDeleteDriver(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>حذف حساب المندوب</DialogTitle>
            <DialogDescription className="text-destructive">
              سيتم حذف حساب {deleteDriver?.fullName} نهائياً ولا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setDeleteDriver(null)}>إلغاء</Button>
            <Button type="button" variant="destructive" onClick={handleDelete} disabled={deleteUser.isPending}>
              {deleteUser.isPending ? 'جاري الحذف...' : 'تأكيد الحذف'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
