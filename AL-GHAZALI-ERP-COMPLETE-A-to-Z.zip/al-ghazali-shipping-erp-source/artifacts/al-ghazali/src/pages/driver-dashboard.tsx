import React, { useEffect, useState } from 'react';
// useRef imported below if needed
import { useGetOrders, getGetOrdersQueryKey } from '@workspace/api-client-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { useLiveLocation } from '@/hooks/use-live-location';
import { trackingLink, whatsappUrl, mapsUrl } from '@/lib/share';
import { GpsStatusBanner } from '@/components/GpsStatusBanner';
import { ShiftPanel } from '@/components/ShiftPanel';
import { useShift } from '@/hooks/use-shift';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Truck, Package, Phone, MapPin, Wallet, CheckCircle2,
  XCircle, AlertCircle, ChevronDown, RotateCcw, LogOut
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { motion, AnimatePresence } from 'framer-motion';

const RETURN_REASONS = [
  'العميل رفض الاستلام',
  'العميل غير موجود بالعنوان',
  'العنوان غير صحيح أو غير موجود',
  'العميل طلب التأجيل',
  'مقاس غير مناسب',
  'اللون مختلف عن المطلوب',
  'عينة مرفوضة من العميل',
  'الطرد تالف أو مكسور',
  'سبب آخر',
];

const PARTIAL_REASONS = [
  'مقاس غير مناسب',
  'اللون مختلف عن المطلوب',
  'عينة مرفوضة',
  'العميل اختار قطع معينة فقط',
  'سبب آخر',
];

// Some mobile keyboards (Arabic locale) type Eastern Arabic / Persian digits
// instead of Western digits. Normalize both before stripping non-digits so
// OTP entry doesn't silently mangle what the user typed.
function normalizeDigits(value: string): string {
  return value
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0));
}

function useDeliverOrder() {
  return useMutation({
    mutationFn: async (payload: {
      orderId: number;
      otp: string;
      deliveryType: 'full' | 'partial';
      collectedAmount?: number;
      returnedItemCount?: number;
      reason?: string;
      podPhoto?: string | null;
      podSignature?: string | null;
    }) => {
      const token = localStorage.getItem('al-ghazali-token');
      const res = await fetch(`/api/orders/${payload.orderId}/deliver`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          otp: payload.otp,
          deliveryType: payload.deliveryType,
          collectedAmount: payload.collectedAmount,
          returnedItemCount: payload.returnedItemCount,
          reason: payload.reason,
          podPhoto: payload.podPhoto || undefined,
          podSignature: payload.podSignature || undefined,
        }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'خطأ في الاتصال' }));
        throw new Error(err.error || 'حدث خطأ');
      }
      return res.json();
    },
  });
}

function useReturnOrder() {
  return useMutation({
    mutationFn: async (payload: { orderId: number; shippingFeeCollected: boolean; reason: string }) => {
      const token = localStorage.getItem('al-ghazali-token');
      const res = await fetch(`/api/orders/${payload.orderId}/return`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ shippingFeeCollected: payload.shippingFeeCollected, reason: payload.reason }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'خطأ في الاتصال' }));
        throw new Error(err.error || 'حدث خطأ');
      }
      return res.json();
    },
  });
}

type OrderItem = {
  id: number;
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  customerPhone2?: string | null;
  customerAddress?: string;
  governorate: string;
  area: string;
  totalToCollect: number;
  shippingFee: number;
  status: string;
  notes?: string | null;
  customerLat?: number | null;
  customerLng?: number | null;
  stopSequence?: number | null;
};

export default function DriverDashboard() {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const deliverOrder = useDeliverOrder();
  const returnOrder = useReturnOrder();

  const [deliverTarget, setDeliverTarget] = useState<OrderItem | null>(null);
  const [returnTarget, setReturnTarget] = useState<OrderItem | null>(null);

  // Deliver form state
  const [otp, setOtp] = useState('');
  const [deliveryType, setDeliveryType] = useState<'full' | 'partial'>('full');
  const [collectedAmount, setCollectedAmount] = useState('');
  const [returnedItemCount, setReturnedItemCount] = useState('');
  const [partialReason, setPartialReason] = useState('');
  const [podPhoto, setPodPhoto] = useState<string | null>(null);
  const [podSignature, setPodSignature] = useState<string | null>(null);
  const sigCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const sigDrawing = useRef(false);

  // Return form state
  const [returnReason, setReturnReason] = useState('');
  const [shippingFeeCollected, setShippingFeeCollected] = useState(false);

  const ordersQKey = getGetOrdersQueryKey({ status: 'in_transit' });
  const { data, isLoading, refetch } = useGetOrders({ status: 'in_transit' }, {
    query: { queryKey: ordersQKey, refetchInterval: 30000 },
  });

  // Dispatch's optimised route first, then creation order.
  const orders = ([...(data?.orders || [])] as OrderItem[]).sort(
    (a, b) => (a.stopSequence ?? 1e9) - (b.stopSequence ?? 1e9) || a.id - b.id,
  );
  // Location is shared while the courier is on duty (so dispatch sees who is free), or while parcels are out.
  const shift = useShift();
  const onDuty = !!shift.data && shift.data.status !== 'off' && shift.data.status !== 'break';
  const gps = useLiveLocation(onDuty || orders.length > 0);

  const resetDeliverForm = () => {
    setOtp('');
    setDeliveryType('full');
    setCollectedAmount('');
    setReturnedItemCount('');
    setPartialReason('');
    setPodPhoto(null);
    setPodSignature(null);
    const c = sigCanvasRef.current;
    if (c) {
      const ctx = c.getContext('2d');
      if (ctx) ctx.clearRect(0, 0, c.width, c.height);
    }
  };

  const clearSignature = () => {
    const c = sigCanvasRef.current;
    if (!c) return;
    const ctx = c.getContext('2d');
    if (ctx) ctx.clearRect(0, 0, c.width, c.height);
    setPodSignature(null);
  };

  const captureSignature = () => {
    const c = sigCanvasRef.current;
    if (!c) return null;
    // empty check
    const ctx = c.getContext('2d');
    if (!ctx) return null;
    const blank = document.createElement('canvas');
    blank.width = c.width; blank.height = c.height;
    if (c.toDataURL() === blank.toDataURL()) return null;
    const data = c.toDataURL('image/png');
    setPodSignature(data);
    return data;
  };

  const onSigPointer = (e: React.PointerEvent<HTMLCanvasElement>, type: 'down' | 'move' | 'up') => {
    const c = sigCanvasRef.current;
    if (!c) return;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    const rect = c.getBoundingClientRect();
    const x = (e.clientX - rect.left) * (c.width / rect.width);
    const y = (e.clientY - rect.top) * (c.height / rect.height);
    if (type === 'down') {
      sigDrawing.current = true;
      ctx.strokeStyle = '#111';
      ctx.lineWidth = 2.2;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(x, y);
    } else if (type === 'move' && sigDrawing.current) {
      ctx.lineTo(x, y);
      ctx.stroke();
    } else if (type === 'up') {
      sigDrawing.current = false;
      captureSignature();
    }
  };

  const onPodPhotoSelected = (file: File | null) => {
    if (!file) { setPodPhoto(null); return; }
    if (!file.type.startsWith('image/')) return;
    if (file.size > 2_000_000) {
      // compress roughly via canvas later; for now reject huge files
      alert('حجم الصورة كبير — اختر صورة أقل من 2 ميجا');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setPodPhoto(String(reader.result || ''));
    reader.readAsDataURL(file);
  };


  const resetReturnForm = () => {
    setReturnReason('');
    setShippingFeeCollected(false);
  };

  const openDeliverDialog = (order: OrderItem) => {
    resetDeliverForm();
    setDeliverTarget(order);
    // Pre-fill collected amount with total
    setCollectedAmount(String(order.totalToCollect));
  };

  const openReturnDialog = (order: OrderItem) => {
    resetReturnForm();
    setReturnTarget(order);
  };

  const handleDeliver = async () => {
    if (!deliverTarget) return;
    if (!otp.trim() || otp.trim().length !== 4) {
      toast({ variant: 'destructive', title: 'كود OTP مطلوب', description: 'أدخل كود OTP المكون من 4 أرقام' });
      return;
    }
    if (deliveryType === 'partial') {
      if (!collectedAmount || isNaN(Number(collectedAmount)) || Number(collectedAmount) < 0) {
        toast({ variant: 'destructive', title: 'المبلغ المحصل مطلوب', description: 'أدخل المبلغ الفعلي المحصل' });
        return;
      }
      if (!returnedItemCount || isNaN(Number(returnedItemCount)) || Number(returnedItemCount) < 1) {
        toast({ variant: 'destructive', title: 'عدد القطع المرتجعة مطلوب', description: 'أدخل عدد القطع التي ترجع مع المندوب' });
        return;
      }
    }
    try {
      const sig = captureSignature() || podSignature;
      await deliverOrder.mutateAsync({
        orderId: deliverTarget.id,
        otp: otp.trim(),
        deliveryType,
        collectedAmount: deliveryType === 'partial' ? Number(collectedAmount) : undefined,
        returnedItemCount: deliveryType === 'partial' ? Number(returnedItemCount) : undefined,
        reason: deliveryType === 'partial' ? partialReason : undefined,
        podPhoto,
        podSignature: sig,
      });
      queryClient.invalidateQueries({ queryKey: ordersQKey });
      toast({
        title: deliveryType === 'full' ? '✅ تم التسليم بنجاح' : '✅ تم التسليم الجزئي',
        description: deliveryType === 'partial'
          ? `تم تحصيل ${collectedAmount} ج.م — مرتجع ${returnedItemCount} قطعة`
          : `تم إقفال الطلب وتحديث ذمتك المالية`,
      });
      setDeliverTarget(null);
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'خطأ في OTP', description: e.message });
    }
  };

  const handleReturn = async () => {
    if (!returnTarget) return;
    if (!returnReason) {
      toast({ variant: 'destructive', title: 'سبب الإرجاع مطلوب' });
      return;
    }
    try {
      await returnOrder.mutateAsync({
        orderId: returnTarget.id,
        shippingFeeCollected,
        reason: returnReason,
      });
      queryClient.invalidateQueries({ queryKey: ordersQKey });
      toast({ title: '↩ تم تسجيل المرتجع', description: returnReason });
      setReturnTarget(null);
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'خطأ', description: e.message });
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground pb-6">
      {/* Driver Header */}
      <div className="sticky top-0 z-40 bg-card/90 backdrop-blur-xl border-b border-border/50 shadow-sm">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-sm leading-tight">{user?.fullName}</p>
              <p className="text-[10px] text-primary/80 uppercase tracking-wide">مندوب توصيل</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="text-left">
              <p className="text-[10px] text-muted-foreground">ذمتك المالية</p>
              <p className="font-bold text-primary text-sm flex items-center gap-1">
                <Wallet className="w-3.5 h-3.5" /> {(user as any)?.cashBalance || 0} ج.م
              </p>
            </div>
            <button onClick={logout} className="w-8 h-8 rounded-lg bg-destructive/10 text-destructive flex items-center justify-center">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="px-4 pt-4 space-y-3">
        {shift.data && <ShiftPanel me={shift.data} onChange={() => { shift.refresh(); refetch(); }} />}
        <GpsStatusBanner info={gps} />
        {/* Summary bar */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold">طلعتك اليوم</h2>
            <p className="text-xs text-muted-foreground">الطلبات المسندة إليك حالياً</p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="bg-orange-500/10 text-orange-500 border-orange-500/20 font-bold">
              {orders.length} طلب نشط
            </Badge>
            <button onClick={() => refetch()} className="w-8 h-8 rounded-lg bg-muted/50 text-muted-foreground flex items-center justify-center">
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Orders list */}
        {isLoading ? (
          [...Array(3)].map((_, i) => (
            <div key={i} className="h-36 rounded-xl bg-muted/20 animate-pulse" />
          ))
        ) : orders.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <Package className="w-16 h-16 text-muted-foreground/30 mb-4" />
            <p className="text-muted-foreground font-medium">لا توجد طلبات نشطة</p>
            <p className="text-xs text-muted-foreground mt-1">ستظهر هنا طلبات الطلعة فور إسنادها إليك</p>
          </div>
        ) : (
          <AnimatePresence>
            {orders.map((order, idx) => (
              <motion.div
                key={order.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ delay: idx * 0.05 }}
              >
                <Card className="border-border/40 bg-card/80 backdrop-blur-sm overflow-hidden">
                  <CardContent className="p-0">
                    {/* Order header */}
                    <div className="flex items-center justify-between px-4 py-2.5 bg-muted/20 border-b border-border/30">
                      <span className="font-mono font-bold text-primary text-sm">{order.orderNumber}</span>
                      <span className="text-lg font-bold text-amber-500">{order.totalToCollect} ج.م</span>
                    </div>

                    <div className="px-4 py-3 space-y-2">
                      {/* Customer info */}
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold shrink-0">
                          {order.customerName.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-sm truncate">{order.customerName}</p>
                          <div className="flex items-center gap-1.5 text-xs text-muted-foreground" dir="ltr">
                            <Phone className="w-3 h-3 shrink-0" />
                            <span>{order.customerPhone}</span>
                            {order.customerPhone2 && <span>• {order.customerPhone2}</span>}
                          </div>
                        </div>
                        <a href={`tel:${order.customerPhone}`} className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center shrink-0">
                          <Phone className="w-4 h-4" />
                        </a>
                      </div>

                      <div className="flex items-start gap-1.5 text-xs text-muted-foreground">
                        <MapPin className="w-3.5 h-3.5 mt-0.5 shrink-0 text-primary/60" />
                        <span>{order.governorate}، {order.area} — {order.customerAddress}</span>
                      </div>

                      {order.customerLat != null && (
                        <div className="text-[11px] text-emerald-500 flex items-center gap-1">
                          <MapPin className="w-3 h-3" /> العميل حدّد موقعه بدقة على الخريطة
                        </div>
                      )}
                      <div className="grid grid-cols-2 gap-2">
                        <a href={mapsUrl(order)} target="_blank" rel="noreferrer"
                          className="h-9 rounded-lg bg-blue-500/10 text-blue-500 text-xs font-semibold flex items-center justify-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5" /> ابدأ الملاحة
                        </a>
                        <a href={whatsappUrl(order.customerPhone, `مرحباً ${order.customerName}، أنا مندوب الغزالي للشحن وفي الطريق إليك بطلبك رقم ${order.orderNumber}.\nتابع الطلب وحدّد موقعك بدقة من هنا:\n${trackingLink(order.orderNumber)}`)}
                          target="_blank" rel="noreferrer"
                          className="h-9 rounded-lg bg-emerald-500/10 text-emerald-500 text-xs font-semibold flex items-center justify-center gap-1.5">
                          <Phone className="w-3.5 h-3.5" /> واتساب للعميل
                        </a>
                      </div>

                      {order.notes && (
                        <div className="text-xs bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded-lg px-2.5 py-1.5">
                          ملاحظة: {order.notes}
                        </div>
                      )}

                      {/* Action buttons */}
                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <Button
                          size="sm"
                          className="h-10 bg-emerald-500 hover:bg-emerald-600 text-white font-bold shadow-[0_4px_12px_rgba(16,185,129,0.25)]"
                          onClick={() => openDeliverDialog(order)}
                        >
                          <CheckCircle2 className="w-4 h-4 ml-1.5" /> تسليم
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-10 border-destructive/40 text-destructive hover:bg-destructive/10 font-bold"
                          onClick={() => openReturnDialog(order)}
                        >
                          <XCircle className="w-4 h-4 ml-1.5" /> مرتجع
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>

      {/* === DELIVERY DIALOG === */}
      <Dialog open={!!deliverTarget} onOpenChange={(open) => { if (!open) setDeliverTarget(null); }}>
        <DialogContent className="sm:max-w-sm p-0 overflow-hidden">
          <DialogHeader className="px-5 pt-5 pb-3 bg-emerald-500/5 border-b border-border/50">
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-500" /> تأكيد التسليم
            </DialogTitle>
            <DialogDescription className="font-mono text-primary font-bold">
              {deliverTarget?.orderNumber} — {deliverTarget?.customerName}
            </DialogDescription>
          </DialogHeader>

          <ScrollArea className="max-h-[70vh]">
            <div className="px-5 py-4 space-y-4">
              {/* OTP Input */}
              <div className="space-y-2">
                <Label className="text-sm font-bold flex items-center gap-1.5">
                  <span className="text-destructive">*</span> كود التأكيد (OTP)
                </Label>
                <Input
                  value={otp}
                  onChange={(e) => setOtp(normalizeDigits(e.target.value).replace(/\D/g, '').slice(0, 4))}
                  placeholder="• • • •"
                  className="text-center text-2xl font-mono font-bold h-14 tracking-widest bg-background/50 border-primary/30 focus:border-primary"
                  maxLength={4}
                  inputMode="numeric"
                  dir="ltr"
                />
                <p className="text-xs text-muted-foreground text-center">أدخل الكود المرسل على هاتف العميل</p>
              </div>

              {/* Delivery type toggle */}
              <div className="space-y-2">
                <Label className="text-sm font-bold">نوع التسليم</Label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => { setDeliveryType('full'); setCollectedAmount(String(deliverTarget?.totalToCollect || 0)); }}
                    className={`p-3 rounded-xl border text-sm font-medium transition-all ${deliveryType === 'full' ? 'bg-emerald-500/10 border-emerald-500/50 text-emerald-500' : 'border-border/50 text-muted-foreground hover:border-border'}`}
                  >
                    <CheckCircle2 className="w-5 h-5 mx-auto mb-1" />
                    تسليم كامل
                    <div className="text-xs opacity-70 mt-0.5">{deliverTarget?.totalToCollect} ج.م</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => { setDeliveryType('partial'); setCollectedAmount(''); }}
                    className={`p-3 rounded-xl border text-sm font-medium transition-all ${deliveryType === 'partial' ? 'bg-amber-500/10 border-amber-500/50 text-amber-500' : 'border-border/50 text-muted-foreground hover:border-border'}`}
                  >
                    <Package className="w-5 h-5 mx-auto mb-1" />
                    تسليم جزئي
                    <div className="text-xs opacity-70 mt-0.5">مرتجع جزئي</div>
                  </button>
                </div>
              </div>

              {/* Partial delivery extra fields */}
              <AnimatePresence>
                {deliveryType === 'partial' && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="space-y-3 overflow-hidden"
                  >
                    <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg text-xs text-amber-600">
                      <AlertCircle className="w-3.5 h-3.5 inline ml-1" />
                      رسوم الشحن ({deliverTarget?.shippingFee} ج.م) تُخصم كاملة لصالح الشركة
                    </div>

                    <div className="space-y-1.5">
                      <Label className="text-sm font-bold flex items-center gap-1">
                        <span className="text-destructive">*</span> المبلغ الفعلي المحصل (ج.م)
                      </Label>
                      <Input
                        type="number"
                        value={collectedAmount}
                        onChange={(e) => setCollectedAmount(e.target.value)}
                        placeholder="0"
                        className="font-mono font-bold text-lg h-12 bg-background/50"
                        inputMode="numeric"
                      />
                      {collectedAmount && deliverTarget && (
                        <p className="text-xs text-emerald-500">
                          صافي التاجر: {Math.max(0, Number(collectedAmount) - (deliverTarget.shippingFee || 0)).toFixed(0)} ج.م
                        </p>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      <Label className="text-sm font-bold flex items-center gap-1">
                        <span className="text-destructive">*</span> عدد القطع المرتجعة
                      </Label>
                      <Input
                        type="number"
                        value={returnedItemCount}
                        onChange={(e) => setReturnedItemCount(e.target.value)}
                        placeholder="مثال: 2"
                        className="font-mono h-12 bg-background/50"
                        inputMode="numeric"
                        min="1"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <Label className="text-sm font-bold">سبب الإرجاع الجزئي</Label>
                      <Select value={partialReason} onValueChange={setPartialReason}>
                        <SelectTrigger className="bg-background/50 h-12">
                          <SelectValue placeholder="اختر السبب" />
                        </SelectTrigger>
                        <SelectContent>
                          {PARTIAL_REASONS.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </ScrollArea>

          
              {/* Proof of Delivery */}
              <div className="space-y-3 pt-2 border-t border-border/40">
                <p className="text-xs font-bold text-muted-foreground">إثبات التسليم (اختياري لكن مستحسن)</p>
                <div className="space-y-1">
                  <label className="text-xs">صورة من موقع التسليم / الشحنة</label>
                  <input
                    type="file"
                    accept="image/*"
                    capture="environment"
                    className="block w-full text-xs file:mr-2 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:bg-primary/15 file:text-primary"
                    onChange={(e) => onPodPhotoSelected(e.target.files?.[0] || null)}
                  />
                  {podPhoto && (
                    <img src={podPhoto} alt="POD" className="mt-1 h-20 rounded-md object-cover border border-border/50" />
                  )}
                </div>
                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="text-xs">توقيع المستلم</label>
                    <button type="button" className="text-[11px] text-primary" onClick={clearSignature}>مسح</button>
                  </div>
                  <canvas
                    ref={sigCanvasRef}
                    width={320}
                    height={120}
                    className="w-full h-28 rounded-md bg-white border border-border/60 touch-none"
                    onPointerDown={(e) => onSigPointer(e, 'down')}
                    onPointerMove={(e) => onSigPointer(e, 'move')}
                    onPointerUp={(e) => onSigPointer(e, 'up')}
                    onPointerLeave={(e) => onSigPointer(e, 'up')}
                  />
                </div>
              </div>

<DialogFooter className="px-5 py-4 border-t border-border/50 bg-muted/10">
            <Button variant="outline" className="flex-1" onClick={() => setDeliverTarget(null)}>إلغاء</Button>
            <Button
              className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white font-bold"
              onClick={handleDeliver}
              disabled={deliverOrder.isPending}
            >
              {deliverOrder.isPending ? 'جاري التأكيد...' : '✅ تأكيد التسليم'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* === RETURN DIALOG === */}
      <Dialog open={!!returnTarget} onOpenChange={(open) => { if (!open) setReturnTarget(null); }}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <XCircle className="w-5 h-5 text-destructive" /> تسجيل مرتجع
            </DialogTitle>
            <DialogDescription className="font-mono text-primary font-bold">
              {returnTarget?.orderNumber} — {returnTarget?.customerName}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-1">
            <div className="space-y-1.5">
              <Label className="text-sm font-bold flex items-center gap-1">
                <span className="text-destructive">*</span> سبب الإرجاع
              </Label>
              <Select value={returnReason} onValueChange={setReturnReason}>
                <SelectTrigger className="bg-background/50 h-12">
                  <SelectValue placeholder="اختر سبب الإرجاع" />
                </SelectTrigger>
                <SelectContent>
                  {RETURN_REASONS.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between p-3 border border-border/50 rounded-lg bg-muted/10">
              <div>
                <p className="text-sm font-medium">رسوم الشحن في إيدك؟</p>
                <p className="text-xs text-muted-foreground">هل دفع العميل رسوم الشحن ({returnTarget?.shippingFee} ج.م)؟</p>
              </div>
              <Switch checked={shippingFeeCollected} onCheckedChange={setShippingFeeCollected} />
            </div>

            <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg text-xs text-destructive">
              <AlertCircle className="w-3.5 h-3.5 inline ml-1" />
              بعد 3 محاولات إرجاع يصبح الطلب مرتجعاً نهائياً
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" className="flex-1" onClick={() => setReturnTarget(null)}>إلغاء</Button>
            <Button
              variant="destructive"
              className="flex-1 font-bold"
              onClick={handleReturn}
              disabled={returnOrder.isPending || !returnReason}
            >
              {returnOrder.isPending ? 'جاري التسجيل...' : '↩ تأكيد الإرجاع'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
