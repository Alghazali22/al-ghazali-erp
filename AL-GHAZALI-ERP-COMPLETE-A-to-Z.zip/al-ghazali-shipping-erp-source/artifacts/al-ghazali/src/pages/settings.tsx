import React, { useState } from 'react';
import { useGetAnnouncement, useSetAnnouncement, useGetSystemStatus, useToggleSystemShutdown, getGetAnnouncementQueryKey, getGetSystemStatusQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { Settings as SettingsIcon, AlertCircle, ShieldAlert, Save } from 'lucide-react';

export default function Settings() {
  const { data: announcement, isLoading: announcementLoading } = useGetAnnouncement();
  const { data: systemStatus, isLoading: statusLoading } = useGetSystemStatus();
  
  const setAnnouncement = useSetAnnouncement();
  const toggleShutdown = useToggleSystemShutdown();
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [annMessage, setAnnMessage] = useState('');
  const [annActive, setAnnActive] = useState(false);
  const [shutdownMessage, setShutdownMessage] = useState('');

  // Sync state when data loads
  React.useEffect(() => {
    if (announcement) {
      setAnnMessage(announcement.message || '');
      setAnnActive(announcement.isActive);
    }
  }, [announcement]);

  React.useEffect(() => {
    if (systemStatus) {
      setShutdownMessage(systemStatus.shutdownMessage || '');
    }
  }, [systemStatus]);

  const handleSaveAnnouncement = async () => {
    try {
      await setAnnouncement.mutateAsync({ data: { message: annMessage, isActive: annActive }});
      queryClient.invalidateQueries({ queryKey: getGetAnnouncementQueryKey() });
      toast({ title: 'تم حفظ الإعلان بنجاح' });
    } catch (e) {
      toast({ variant: 'destructive', title: 'خطأ في الحفظ' });
    }
  };

  const handleToggleShutdown = async (newStatus: boolean) => {
    try {
      await toggleShutdown.mutateAsync({ data: { isShutdown: newStatus, message: shutdownMessage }});
      queryClient.invalidateQueries({ queryKey: getGetSystemStatusQueryKey() });
      toast({ title: newStatus ? 'تم إيقاف النظام' : 'تم تشغيل النظام' });
    } catch (e) {
      toast({ variant: 'destructive', title: 'خطأ في تغيير حالة النظام' });
    }
  };

  if (announcementLoading || statusLoading) return <div>جاري التحميل...</div>;

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
          <SettingsIcon className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">إعدادات النظام</h1>
          <p className="text-muted-foreground">صلاحيات المدير وإعدادات المنصة</p>
        </div>
      </div>

      <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-primary" />
            شريط الإعلانات العام
          </CardTitle>
          <CardDescription>هذا الإعلان سيظهر لجميع المستخدمين في أعلى الشاشة</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between border border-border/50 p-4 rounded-lg bg-muted/20">
            <span className="font-medium">تفعيل شريط الإعلانات</span>
            <Switch checked={annActive} onCheckedChange={setAnnActive} />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">نص الإعلان</label>
            <Textarea 
              value={annMessage} 
              onChange={(e) => setAnnMessage(e.target.value)}
              placeholder="اكتب رسالة الإعلان هنا..."
              className="bg-background/50 min-h-[100px]"
            />
          </div>
          <Button onClick={handleSaveAnnouncement} disabled={setAnnouncement.isPending} className="bg-primary hover:bg-primary/90">
            <Save className="w-4 h-4 ml-2" /> حفظ الإعلان
          </Button>
        </CardContent>
      </Card>

      <Card className="border-destructive/30 bg-destructive/5 backdrop-blur-sm mt-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-destructive">
            <ShieldAlert className="w-5 h-5" />
            إيقاف النظام (وضع الصيانة)
          </CardTitle>
          <CardDescription>إيقاف دخول جميع المستخدمين باستثناء مدراء النظام</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between border border-destructive/20 p-4 rounded-lg bg-destructive/10">
            <span className="font-bold text-destructive">تفعيل وضع الصيانة وإيقاف النظام</span>
            <Switch 
              checked={systemStatus?.isShutdown} 
              onCheckedChange={handleToggleShutdown}
              className="data-[state=checked]:bg-destructive"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-destructive">رسالة الصيانة (تظهر للمستخدمين عند الإيقاف)</label>
            <Input 
              value={shutdownMessage} 
              onChange={(e) => setShutdownMessage(e.target.value)}
              placeholder="النظام تحت الصيانة حالياً..."
              className="bg-background/50 border-destructive/30 focus:border-destructive"
            />
            {systemStatus?.isShutdown && (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => handleToggleShutdown(true)} 
                className="mt-2 border-destructive/50 text-destructive hover:bg-destructive hover:text-white"
              >
                تحديث رسالة الصيانة
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}