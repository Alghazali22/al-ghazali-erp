import React, { useState } from 'react';
import { useGetBranches, useCreateBranch, useUpdateBranch, useDeleteBranch, useToggleBranchLockdown, useGetUsers, getGetBranchesQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { Branch } from '@workspace/api-client-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Building2, MapPin, Phone, Users, Plus, Edit, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

const branchSchema = z.object({
  name: z.string().min(2, 'اسم الفرع مطلوب'),
  governorate: z.string().min(2, 'المحافظة مطلوبة'),
  address: z.string().optional(),
  phone: z.string().optional(),
  managerId: z.coerce.number().optional(),
});

type BranchForm = z.infer<typeof branchSchema>;

export default function Branches() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editBranch, setEditBranch] = useState<Branch | null>(null);
  const [deleteBranch, setDeleteBranch] = useState<Branch | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user: currentUser } = useAuth();
  const toggleLockdown = useToggleBranchLockdown();
  const createBranch = useCreateBranch();
  const updateBranch = useUpdateBranch();
  const deleteBranchMutation = useDeleteBranch();
  const canDelete = currentUser?.role === 'super_admin';

  const { data: branches, isLoading } = useGetBranches();
  const { data: managersData } = useGetUsers({ role: 'branch_manager' });
  const managers = Array.isArray(managersData) ? managersData : [];

  const form = useForm<BranchForm>({
    resolver: zodResolver(branchSchema),
    defaultValues: { name: '', governorate: '', address: '', phone: '' },
  });

  const isEditing = !!editBranch;

  const openCreate = () => {
    setEditBranch(null);
    form.reset({ name: '', governorate: '', address: '', phone: '' });
    setDialogOpen(true);
  };

  const openEdit = (branch: Branch) => {
    setEditBranch(branch);
    form.reset({
      name: branch.name,
      governorate: branch.governorate || '',
      address: branch.address || '',
      phone: branch.phone || '',
      managerId: branch.managerId || undefined,
    });
    setDialogOpen(true);
  };

  const onSubmit = async (values: BranchForm) => {
    try {
      if (isEditing && editBranch) {
        await updateBranch.mutateAsync({ id: editBranch.id, data: { ...values, managerId: values.managerId || undefined } });
        toast({ title: 'تم تحديث بيانات الفرع' });
      } else {
        await createBranch.mutateAsync({ data: { ...values, managerId: values.managerId || undefined } });
        toast({ title: 'تم إضافة الفرع بنجاح' });
      }
      queryClient.invalidateQueries({ queryKey: getGetBranchesQueryKey() });
      setDialogOpen(false);
      form.reset();
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'خطأ', description: e.message || 'حدث خطأ' });
    }
  };

  const handleToggleLockdown = async (id: number, currentLocked: boolean) => {
    try {
      await toggleLockdown.mutateAsync({ id, data: { locked: !currentLocked } });
      queryClient.invalidateQueries({ queryKey: getGetBranchesQueryKey() });
      toast({ title: currentLocked ? 'تم فتح الفرع' : 'تم إغلاق الفرع مؤقتاً' });
    } catch {
      toast({ variant: 'destructive', title: 'خطأ', description: 'تعذر تغيير حالة الفرع' });
    }
  };

  const handleDelete = async () => {
    if (!deleteBranch) return;
    try {
      await deleteBranchMutation.mutateAsync({ id: deleteBranch.id });
      await queryClient.invalidateQueries({ queryKey: getGetBranchesQueryKey() });
      toast({ title: 'تم حذف الفرع', description: `تم حذف فرع ${deleteBranch.name} نهائياً` });
      setDeleteBranch(null);
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر حذف الفرع', description: e.message || 'حدث خطأ أثناء الحذف' });
    }
  };

  const isPending = createBranch.isPending || updateBranch.isPending;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">الفروع</h1>
          <p className="text-muted-foreground text-sm">إدارة فروع الشركة وحالاتها</p>
        </div>
        <Button className="bg-primary hover:bg-primary/90" onClick={openCreate}>
          <Plus className="w-4 h-4 ml-2" /> إضافة فرع
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading ? (
          [...Array(3)].map((_, i) => <Card key={i} className="h-48 animate-pulse bg-muted/20" />)
        ) : branches?.map((branch) => (
          <Card key={branch.id} className={`border-border/40 bg-card/60 backdrop-blur-sm overflow-hidden relative ${branch.isLocked ? 'border-destructive/30' : ''}`}>
            {branch.isLocked && <div className="absolute top-0 right-0 w-full h-1 bg-destructive/80" />}
            <CardContent className="p-5">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${branch.isLocked ? 'bg-destructive/10 text-destructive' : 'bg-primary/10 text-primary'}`}>
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold">{branch.name}</h3>
                    <p className="text-xs text-muted-foreground">{branch.governorate}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={branch.isLocked ? 'destructive' : 'default'} className="text-xs">
                    {branch.isLocked ? 'مغلق' : 'يعمل'}
                  </Badge>
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => openEdit(branch)}>
                      <Edit className="w-3.5 h-3.5" />
                    </Button>
                    {canDelete && (
                      <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive"
                        onClick={() => setDeleteBranch(branch)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-2 text-sm text-muted-foreground mb-4">
                {branch.address && <div className="flex items-center gap-2"><MapPin className="w-3.5 h-3.5 shrink-0" />{branch.address}</div>}
                {branch.phone && <div className="flex items-center gap-2"><Phone className="w-3.5 h-3.5 shrink-0" /><span dir="ltr">{branch.phone}</span></div>}
                <div className="flex items-center gap-2"><Users className="w-3.5 h-3.5 shrink-0" />مدير: {branch.managerName || '—'}</div>
              </div>

              <div className="flex items-center justify-between border-t border-border/50 pt-3">
                <span className="text-xs font-medium text-muted-foreground">استقبال الطلبات</span>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">{branch.isLocked ? 'موقوف' : 'مفعّل'}</span>
                  <Switch checked={!branch.isLocked} onCheckedChange={() => handleToggleLockdown(branch.id, branch.isLocked)} disabled={toggleLockdown.isPending} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) { setEditBranch(null); form.reset(); } }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{isEditing ? 'تعديل بيانات الفرع' : 'إضافة فرع جديد'}</DialogTitle>
            <DialogDescription>{isEditing ? `تعديل فرع: ${editBranch?.name}` : 'أدخل بيانات الفرع الجديد'}</DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="name" render={({ field }) => (
                  <FormItem><FormLabel>اسم الفرع</FormLabel><FormControl><Input {...field} className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="governorate" render={({ field }) => (
                  <FormItem><FormLabel>المحافظة</FormLabel><FormControl><Input {...field} className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={form.control} name="address" render={({ field }) => (
                <FormItem><FormLabel>العنوان التفصيلي</FormLabel><FormControl><Input {...field} className="bg-background/50" /></FormControl><FormMessage /></FormItem>
              )} />
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="phone" render={({ field }) => (
                  <FormItem><FormLabel>هاتف الفرع</FormLabel><FormControl><Input {...field} dir="ltr" className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="managerId" render={({ field }) => (
                  <FormItem><FormLabel>مدير الفرع</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value?.toString()}>
                      <FormControl><SelectTrigger className="bg-background/50"><SelectValue placeholder="اختر المدير" /></SelectTrigger></FormControl>
                      <SelectContent>{managers.map(m => <SelectItem key={m.id} value={m.id.toString()}>{m.fullName}</SelectItem>)}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
                <Button type="submit" disabled={isPending} className="bg-primary hover:bg-primary/90">
                  {isPending ? 'جاري الحفظ...' : isEditing ? 'حفظ التعديلات' : 'إضافة الفرع'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteBranch} onOpenChange={(open) => !open && setDeleteBranch(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>حذف الفرع</DialogTitle>
            <DialogDescription className="text-destructive">
              سيتم حذف فرع {deleteBranch?.name} نهائياً. سيتم نقل الطلبات المرتبطة إلى الفرع الرئيسي ولا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setDeleteBranch(null)}>إلغاء</Button>
            <Button type="button" variant="destructive" onClick={handleDelete} disabled={deleteBranchMutation.isPending}>
              {deleteBranchMutation.isPending ? 'جاري الحذف...' : 'تأكيد الحذف'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
