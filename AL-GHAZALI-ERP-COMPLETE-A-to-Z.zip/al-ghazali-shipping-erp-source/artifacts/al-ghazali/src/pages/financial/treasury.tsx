import React from 'react';
import { useGetTreasury, useGetTransactions } from '@workspace/api-client-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Wallet, ArrowDownRight, ArrowUpRight, Activity } from 'lucide-react';
import { format } from 'date-fns';
import { arEG } from 'date-fns/locale';

export default function Treasury() {
  const { data: treasury, isLoading: treasuryLoading } = useGetTreasury({});
  const { data: transactions, isLoading: txLoading } = useGetTransactions({});

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'driver_settlement': return 'توريد مندوب';
      case 'merchant_withdrawal': return 'صرف لتاجر';
      case 'shipping_fee': return 'رسوم شحن';
      case 'return_fee': return 'رسوم مرتجع';
      case 'adjustment': return 'تسوية رصيد';
      default: return type;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">الخزينة</h1>
          <p className="text-muted-foreground">مراقبة حركات النقدية والرصيد الفعلي بالخزينة</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-primary/20 bg-primary/5 backdrop-blur-sm shadow-[0_0_20px_rgba(245,158,11,0.1)]">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-bold text-primary uppercase mb-1">الرصيد الحالي</p>
                <h3 className="text-4xl font-bold tracking-tight text-foreground">
                  {treasuryLoading ? '...' : `${treasury?.balance || 0} ج.م`}
                </h3>
              </div>
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-primary">
                <Wallet className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">إجمالي الوارد (اليوم)</p>
                <h3 className="text-2xl font-bold tracking-tight text-emerald-500">
                  {treasuryLoading ? '...' : `${treasury?.totalIn || 0} ج.م`}
                </h3>
              </div>
              <div className="w-12 h-12 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-500">
                <ArrowDownRight className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">إجمالي المنصرف (اليوم)</p>
                <h3 className="text-2xl font-bold tracking-tight text-destructive">
                  {treasuryLoading ? '...' : `${treasury?.totalOut || 0} ج.م`}
                </h3>
              </div>
              <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center text-destructive">
                <ArrowUpRight className="w-6 h-6" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-primary" /> سجل الحركات النقدية
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border border-border/50 overflow-hidden">
            <Table>
              <TableHeader className="bg-muted/30">
                <TableRow>
                  <TableHead className="text-right">رقم الحركة</TableHead>
                  <TableHead className="text-right">النوع</TableHead>
                  <TableHead className="text-right">البيان</TableHead>
                  <TableHead className="text-right">المرجع</TableHead>
                  <TableHead className="text-right">المبلغ</TableHead>
                  <TableHead className="text-right">التاريخ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {txLoading ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8">جاري التحميل...</TableCell></TableRow>
                ) : transactions?.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">لا توجد حركات نقدية مسجلة</TableCell></TableRow>
                ) : (
                  transactions?.map((tx) => {
                    const isIn = tx.type === 'driver_settlement' || tx.type === 'shipping_fee' || tx.type === 'return_fee';
                    return (
                      <TableRow key={tx.id} className="hover:bg-muted/30">
                        <TableCell className="font-mono text-muted-foreground">TX-{tx.id}</TableCell>
                        <TableCell><Badge variant="outline">{getTypeLabel(tx.type)}</Badge></TableCell>
                        <TableCell>{tx.description}</TableCell>
                        <TableCell className="font-mono text-xs">{tx.reference || '-'}</TableCell>
                        <TableCell>
                          <span className={`font-bold font-mono flex items-center gap-1 ${isIn ? 'text-emerald-500' : 'text-destructive'}`}>
                            {isIn ? '+' : '-'}{tx.amount}
                            {isIn ? <ArrowDownRight className="w-3 h-3" /> : <ArrowUpRight className="w-3 h-3" />}
                          </span>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground dir-ltr text-right">
                          {format(new Date(tx.createdAt), 'dd MMM HH:mm', { locale: arEG })}
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}