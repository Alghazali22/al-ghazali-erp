import React from 'react';
import { useGetWithdrawalRequests, useApproveWithdrawal, getGetWithdrawalRequestsQueryKey } from '@workspace/api-client-react';
import { useQueryClient, useQuery } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Wallet, Check, Printer, X, Clock, Banknote, ArrowUpFromLine } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiFetch } from '@/lib/extra-api';
import { format } from 'date-fns';
import { arEG } from 'date-fns/locale';

const fmtMoney = (n: number) => `${Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 })} ج.م`;

function StatCard({ icon: Icon, label, value, hint, tone }: { icon: any; label: string; value: string; hint?: string; tone: string }) {
  return (
    <Card className="border-border/40 bg-card/60">
      <CardContent className="p-4 flex items-start gap-3">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${tone}`}><Icon className="w-5 h-5" /></div>
        <div className="min-w-0">
          <div className="text-xs text-muted-foreground">{label}</div>
          <div className="text-xl font-bold font-mono">{value}</div>
          {hint && <div className="text-[11px] text-muted-foreground mt-0.5">{hint}</div>}
        </div>
      </CardContent>
    </Card>
  );
}

export default function Wallets() {
  const { user } = useAuth();
  const isMerchant = user?.role === 'merchant';
  const canProcess = user?.role === 'super_admin' || user?.role === 'accountant';

  const { data: requests, isLoading } = useGetWithdrawalRequests({});
  const approveReq = useApproveWithdrawal();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [receipt, setReceipt] = React.useState<any>(null);

  // Merchant-only data: balances + statement
  const wallet = useQuery({
    queryKey: ['merchant-wallet', user?.id],
    queryFn: () => apiFetch<any>(`/financial/merchant-wallet/${user!.id}`),
    enabled: isMerchant && !!user?.id,
  });
  const statement = useQuery({
    queryKey: ['merchant-statement', user?.id],
    queryFn: () => apiFetch<any>(`/financial/merchant-statement/${user!.id}`),
    enabled: isMerchant && !!user?.id,
  });

  const [withdrawOpen, setWithdrawOpen] = React.useState(false);
  const [withdrawAmount, setWithdrawAmount] = React.useState('');
  const [withdrawNotes, setWithdrawNotes] = React.useState('');
  const [submitting, setSubmitting] = React.useState(false);

  const [rejectTarget, setRejectTarget] = React.useState<any>(null);
  const [rejectReason, setRejectReason] = React.useState('');

  const refreshAll = () => {
    queryClient.invalidateQueries({ queryKey: getGetWithdrawalRequestsQueryKey() });
    queryClient.invalidateQueries({ queryKey: ['merchant-wallet'] });
    queryClient.invalidateQueries({ queryKey: ['merchant-statement'] });
  };

  const handleApprove = async (id: number) => {
    try {
      const result = await approveReq.mutateAsync({ id });
      refreshAll();
      setReceipt(result);
      toast({ title: 'تم صرف المبلغ بنجاح' });
    } catch (error: any) {
      toast({ variant: 'destructive', title: 'تعذر الصرف', description: error?.message || 'تعذر الموافقة على الطلب' });
    }
  };

  const submitWithdrawal = async () => {
    setSubmitting(true);
    try {
      await apiFetch('/financial/withdrawal-requests', {
        method: 'POST',
        body: JSON.stringify({ amount: Number(withdrawAmount), notes: withdrawNotes || undefined }),
      });
      toast({ title: 'تم إرسال طلب السحب', description: 'سيتم مراجعته من المحاسب' });
      setWithdrawOpen(false); setWithdrawAmount(''); setWithdrawNotes('');
      refreshAll();
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر إرسال الطلب', description: e.message });
    } finally {
      setSubmitting(false);
    }
  };

  const submitReject = async () => {
    if (!rejectTarget) return;
    try {
      await apiFetch(`/financial/withdrawal-requests/${rejectTarget.id}/reject`, {
        method: 'POST',
        body: JSON.stringify({ reason: rejectReason || undefined }),
      });
      toast({ title: 'تم رفض الطلب' });
      setRejectTarget(null); setRejectReason('');
      refreshAll();
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر رفض الطلب', description: e.message });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending': return <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20">قيد الانتظار</Badge>;
      case 'approved': return <Badge variant="outline" className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">تم الصرف</Badge>;
      case 'rejected': return <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">مرفوض</Badge>;
      default: return null;
    }
  };

  const available = wallet.data ? wallet.data.readyBalance : 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">{isMerchant ? 'محفظتي' : 'محافظ التجار'}</h1>
          <p className="text-muted-foreground">{isMerchant ? 'أرصدتك وطلبات السحب وكشف حساب الشحنات' : 'إدارة طلبات سحب الأرصدة للتجار'}</p>
        </div>
        {isMerchant && (
          <Button onClick={() => setWithdrawOpen(true)} disabled={available <= 0} className="bg-primary hover:bg-primary/90">
            <ArrowUpFromLine className="w-4 h-4 ml-1" /> طلب سحب
          </Button>
        )}
      </div>

      {isMerchant && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <StatCard icon={Wallet} label="متاح للسحب" value={fmtMoney(wallet.data?.readyBalance ?? 0)} hint="بعد توريد المندوب للكاش" tone="bg-emerald-500/10 text-emerald-500" />
            <StatCard icon={Clock} label="رصيد معلّق" value={fmtMoney(wallet.data?.pendingBalance ?? 0)} hint="شحنات سُلّمت وبانتظار توريد الكاش" tone="bg-amber-500/10 text-amber-500" />
            <StatCard icon={Banknote} label="إجمالي ما تم سحبه" value={fmtMoney(wallet.data?.totalWithdrawn ?? 0)} tone="bg-primary/10 text-primary" />
          </div>

          <Card className="border-border/40 bg-card/60">
            <CardContent className="p-4 sm:p-6 space-y-3">
              <h2 className="font-bold">كشف حساب الشحنات المسلّمة</h2>
              <div className="rounded-md border border-border/50 overflow-x-auto">
                <Table>
                  <TableHeader className="bg-muted/30">
                    <TableRow>
                      <TableHead className="text-right">الطلب</TableHead>
                      <TableHead className="text-right">المحصّل</TableHead>
                      <TableHead className="text-right">الشحن</TableHead>
                      <TableHead className="text-right">صافي لك</TableHead>
                      <TableHead className="text-right">الحالة</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {statement.isLoading ? (
                      <TableRow><TableCell colSpan={5} className="text-center py-6">جاري التحميل...</TableCell></TableRow>
                    ) : !statement.data?.rows?.length ? (
                      <TableRow><TableCell colSpan={5} className="text-center py-6 text-muted-foreground">لا توجد شحنات مسلّمة بعد</TableCell></TableRow>
                    ) : statement.data.rows.map((r: any) => (
                      <TableRow key={r.orderId}>
                        <TableCell className="font-mono text-primary font-bold">{r.orderNumber}</TableCell>
                        <TableCell className="font-mono">{fmtMoney(r.collected)}</TableCell>
                        <TableCell className="font-mono text-muted-foreground">{fmtMoney(r.shippingFee)}</TableCell>
                        <TableCell className="font-mono font-bold">{fmtMoney(r.net)}</TableCell>
                        <TableCell>
                          {r.released
                            ? <Badge variant="outline" className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">في المحفظة</Badge>
                            : <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20">بانتظار التوريد</Badge>}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              {statement.data?.totals && (
                <div className="text-xs text-muted-foreground flex flex-wrap gap-x-6 gap-y-1">
                  <span>إجمالي المحصّل: <b className="text-foreground">{fmtMoney(statement.data.totals.collected)}</b></span>
                  <span>إجمالي الشحن: <b className="text-foreground">{fmtMoney(statement.data.totals.shippingFee)}</b></span>
                  <span>صافي مستحقاتك: <b className="text-foreground">{fmtMoney(statement.data.totals.net)}</b></span>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}

      <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
        <CardContent className="p-4 sm:p-6 space-y-3">
          {isMerchant && <h2 className="font-bold">طلبات السحب</h2>}
          <div className="rounded-md border border-border/50 overflow-x-auto">
            <Table>
              <TableHeader className="bg-muted/30">
                <TableRow>
                  <TableHead className="text-right">رقم الطلب</TableHead>
                  {!isMerchant && <TableHead className="text-right">التاجر</TableHead>}
                  <TableHead className="text-right">المبلغ المطلوب</TableHead>
                  <TableHead className="text-right">تاريخ الطلب</TableHead>
                  <TableHead className="text-right">الحالة</TableHead>
                  {canProcess && <TableHead className="text-right">إجراء</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8">جاري التحميل...</TableCell></TableRow>
                ) : requests?.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">لا توجد طلبات سحب حالية</TableCell></TableRow>
                ) : (
                  requests?.map((req) => (
                    <TableRow key={req.id} className="hover:bg-muted/30">
                      <TableCell className="font-mono">REQ-{req.id}</TableCell>
                      {!isMerchant && <TableCell className="font-bold">{req.merchantName}</TableCell>}
                      <TableCell className="font-mono text-primary font-bold">{req.amount} ج.م</TableCell>
                      <TableCell className="text-sm text-muted-foreground dir-ltr text-right">
                        {format(new Date(req.createdAt), 'dd MMM yyyy HH:mm', { locale: arEG })}
                      </TableCell>
                      <TableCell>{getStatusBadge(req.status)}</TableCell>
                      {canProcess && (
                        <TableCell>
                          {req.status === 'pending' && (
                            <div className="flex gap-2">
                              <Button size="sm" className="bg-emerald-500 hover:bg-emerald-600 text-white" onClick={() => handleApprove(req.id)} disabled={approveReq.isPending}>
                                <Check className="w-4 h-4" /> موافقة وصرف
                              </Button>
                              <Button size="sm" variant="outline" className="text-destructive border-destructive/30 hover:bg-destructive/10" onClick={() => setRejectTarget(req)}>
                                <X className="w-4 h-4" /> رفض
                              </Button>
                            </div>
                          )}
                        </TableCell>
                      )}
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Merchant: new withdrawal request */}
      <Dialog open={withdrawOpen} onOpenChange={setWithdrawOpen}>
        <DialogContent className="sm:max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle>طلب سحب رصيد</DialogTitle>
            <DialogDescription>المتاح للسحب الآن: <b>{fmtMoney(available)}</b></DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Input type="number" inputMode="decimal" min={1} max={available} placeholder="المبلغ (ج.م)" value={withdrawAmount} onChange={(e) => setWithdrawAmount(e.target.value)} />
            <Input placeholder="ملاحظات (اختياري)" value={withdrawNotes} onChange={(e) => setWithdrawNotes(e.target.value)} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setWithdrawOpen(false)}>إلغاء</Button>
            <Button onClick={submitWithdrawal} disabled={submitting || !(Number(withdrawAmount) > 0) || Number(withdrawAmount) > available}>
              {submitting ? 'جاري الإرسال...' : 'إرسال الطلب'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Accountant: reject */}
      <Dialog open={!!rejectTarget} onOpenChange={(open) => { if (!open) { setRejectTarget(null); setRejectReason(''); } }}>
        <DialogContent className="sm:max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle>رفض طلب السحب</DialogTitle>
            <DialogDescription>{rejectTarget ? `${rejectTarget.merchantName} — ${rejectTarget.amount} ج.م` : ''}</DialogDescription>
          </DialogHeader>
          <Input placeholder="سبب الرفض (اختياري)" value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} />
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectTarget(null)}>تراجع</Button>
            <Button variant="destructive" onClick={submitReject}>تأكيد الرفض</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!receipt} onOpenChange={(open) => { if (!open) setReceipt(null); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Wallet className="w-5 h-5 text-emerald-500" /> سند صرف مستحقات تاجر
            </DialogTitle>
            <DialogDescription>تم تسجيل العملية داخل معاملة مالية ذرية وتحديث الخزينة والمحفظة.</DialogDescription>
          </DialogHeader>
          {receipt && (
            <div id="merchant-payout-receipt" className="rounded-lg border border-border/50 bg-muted/10 p-4 space-y-3 text-sm">
              <div className="flex items-center justify-between border-b border-border/40 pb-3">
                <span className="text-muted-foreground">رقم السند</span>
                <span className="font-mono font-bold text-primary">{receipt.receiptNumber || `PAY-${receipt.id}`}</span>
              </div>
              <div className="flex justify-between"><span className="text-muted-foreground">التاجر</span><span className="font-bold">{receipt.merchantName}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">المبلغ المصروف</span><span className="font-mono font-bold">{receipt.amount} ج.م</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">المحاسب</span><span>{receipt.processedBy || receipt.processedByName || '—'}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">تاريخ الصرف</span><span>{receipt.processedAt ? format(new Date(receipt.processedAt), 'dd MMM yyyy HH:mm', { locale: arEG }) : '—'}</span></div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => window.print()}>
              <Printer className="w-4 h-4 ml-1" /> طباعة السند
            </Button>
            <Button onClick={() => setReceipt(null)}>إغلاق</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
