import React, { useState } from 'react';
import { useGetDriverBalances, useSettleDriver, getGetDriverBalancesQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Wallet, CheckCircle2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function Settlements() {
  const { data: balances, isLoading } = useGetDriverBalances({});
  const settleDriver = useSettleDriver();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [selectedDriver, setSelectedDriver] = useState<any>(null);
  const [settleAmount, setSettleAmount] = useState('');

  const handleSettle = async () => {
    if (!selectedDriver || !settleAmount || isNaN(Number(settleAmount)) || Number(settleAmount) <= 0) return;
    
    try {
      await settleDriver.mutateAsync({
        driverId: selectedDriver.driverId,
        data: { amount: Number(settleAmount) }
      });
      
      queryClient.invalidateQueries({ queryKey: getGetDriverBalancesQueryKey() });
      setSelectedDriver(null);
      setSettleAmount('');
      
      toast({
        title: "تم التسوية بنجاح",
        description: "تم تحديث رصيد عهدة المندوب",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "خطأ",
        description: "حدث خطأ أثناء التسوية",
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">تسويات المندوبين</h1>
          <p className="text-muted-foreground">استلام النقدية وتسوية عهد المندوبين</p>
        </div>
      </div>

      <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
        <CardContent className="p-6">
          <div className="rounded-md border border-border/50 overflow-hidden">
            <Table>
              <TableHeader className="bg-muted/30">
                <TableRow>
                  <TableHead className="text-right">المندوب</TableHead>
                  <TableHead className="text-right">الفرع</TableHead>
                  <TableHead className="text-right">الطلبات المسلمة</TableHead>
                  <TableHead className="text-right">إجمالي العهدة (المطلوب توريده)</TableHead>
                  <TableHead className="text-right"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-8">جاري التحميل...</TableCell></TableRow>
                ) : balances?.length === 0 ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">لا يوجد عهد معلقة للمندوبين</TableCell></TableRow>
                ) : (
                  balances?.map((balance) => (
                    <TableRow key={balance.driverId} className="hover:bg-muted/30">
                      <TableCell className="font-bold">{balance.driverName}</TableCell>
                      <TableCell>{balance.branchName || '-'}</TableCell>
                      <TableCell>{balance.orderCount} طلب</TableCell>
                      <TableCell className="font-mono text-primary font-bold text-lg">{balance.cashBalance} ج.م</TableCell>
                      <TableCell>
                        <Button 
                          onClick={() => {
                            setSelectedDriver(balance);
                            setSettleAmount(balance.cashBalance.toString());
                          }}
                          disabled={balance.cashBalance <= 0}
                          className="bg-emerald-500 hover:bg-emerald-600 text-white"
                        >
                          <Wallet className="w-4 h-4 ml-2" /> تسوية العهدة
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={!!selectedDriver} onOpenChange={(open) => !open && setSelectedDriver(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>تسوية عهدة المندوب</DialogTitle>
            <DialogDescription>
              توريد النقدية من المندوب: <span className="font-bold text-foreground">{selectedDriver?.driverName}</span>
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="bg-muted/20 p-4 rounded-lg flex items-center justify-between border border-border/50">
              <span className="text-sm text-muted-foreground">إجمالي العهدة الحالية</span>
              <span className="text-xl font-bold text-primary">{selectedDriver?.cashBalance} ج.م</span>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">المبلغ المورد (ج.م)</label>
              <Input 
                type="number" 
                value={settleAmount} 
                onChange={(e) => setSettleAmount(e.target.value)}
                className="text-lg font-mono"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedDriver(null)}>إلغاء</Button>
            <Button 
              onClick={handleSettle} 
              disabled={settleDriver.isPending || !settleAmount || Number(settleAmount) <= 0}
              className="bg-emerald-500 hover:bg-emerald-600 text-white"
            >
              {settleDriver.isPending ? 'جاري التسوية...' : <><CheckCircle2 className="w-4 h-4 ml-2" /> تأكيد الاستلام</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}