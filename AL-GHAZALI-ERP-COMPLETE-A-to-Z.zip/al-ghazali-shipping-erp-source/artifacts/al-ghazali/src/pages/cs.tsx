import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiFetch } from '@/lib/extra-api';
import { TicketsPanel } from '@/components/TicketsPanel';
import { OrderCareDialog } from '@/components/OrderCareDialog';
import { WHATSAPP_TEMPLATES, whatsappFor } from '@/lib/support';
import { useGetOrders, getGetOrdersQueryKey } from '@workspace/api-client-react';
import { keepPreviousData } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ListChecks, Ticket, ScanSearch } from 'lucide-react';
import { Search, Headset, Package, MapPin, Phone, User, Clock, Truck, CheckCircle2, XCircle } from 'lucide-react';

const STATUS_COLORS: Record<string, string> = {
  delivered: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
  pending: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
  in_transit: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
  returned: 'bg-destructive/10 text-destructive border-destructive/20',
  final_return: 'bg-red-900/20 text-red-500 border-red-900/30',
  ready: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
};

const STATUS_LABELS: Record<string, string> = {
  delivered: 'مكتمل',
  pending: 'قيد الانتظار',
  in_transit: 'في الطريق',
  returned: 'مرتجع',
  final_return: 'مرتجع نهائي',
  ready: 'جاهز',
};

const STATUS_ICONS: Record<string, React.ReactNode> = {
  delivered: <CheckCircle2 className="w-4 h-4" />,
  in_transit: <Truck className="w-4 h-4" />,
  returned: <XCircle className="w-4 h-4" />,
  final_return: <XCircle className="w-4 h-4" />,
  pending: <Clock className="w-4 h-4" />,
  ready: <Package className="w-4 h-4" />,
};

function OrderSearch() {
  const [careId, setCareId] = useState<number | null>(null);
  const [searchInput, setSearchInput] = useState('');
  const [activeSearch, setActiveSearch] = useState('');

  const { data, isLoading, isFetching } = useGetOrders(
    { search: activeSearch, limit: 20 },
    {
      query: {
        queryKey: getGetOrdersQueryKey({ search: activeSearch, limit: 20 }),
        enabled: activeSearch.length >= 2,
        placeholderData: keepPreviousData,
      },
    }
  );

  const orders = data?.orders || [];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim().length >= 2) setActiveSearch(searchInput.trim());
  };

  const handleClear = () => {
    setSearchInput('');
    setActiveSearch('');
  };

  return (
    <div className="space-y-5 max-w-4xl mx-auto">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
          <Headset className="w-5 h-5" />
        </div>
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">خدمة العملاء</h1>
          <p className="text-muted-foreground text-sm">البحث السريع عن الشحنات</p>
        </div>
      </div>

      <Card className="border-primary/20 bg-card/80 backdrop-blur-md shadow-[0_0_30px_rgba(245,158,11,0.05)]">
        <CardContent className="p-5">
          <form onSubmit={handleSearch} className="flex gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                placeholder="رقم التتبع، رقم الهاتف، أو اسم العميل..."
                className="pr-9 h-12 bg-background/50 border-primary/30 focus:border-primary text-sm"
              />
            </div>
            <Button type="submit" className="h-12 px-6 font-bold bg-primary hover:bg-primary/90" disabled={searchInput.trim().length < 2}>
              {isFetching ? 'جاري البحث...' : 'بحث'}
            </Button>
            {activeSearch && (
              <Button type="button" variant="outline" className="h-12 px-4" onClick={handleClear}>مسح</Button>
            )}
          </form>
          {activeSearch && (
            <p className="text-xs text-muted-foreground mt-2">
              نتائج البحث عن: <span className="text-primary font-medium">"{activeSearch}"</span>
              {data && <span> — {data.total} نتيجة</span>}
            </p>
          )}
        </CardContent>
      </Card>

      {/* Results */}
      {isLoading && activeSearch && (
        <div className="flex justify-center py-8">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      )}

      {activeSearch && !isLoading && orders.length === 0 && (
        <Card className="border-border/40 bg-card/60">
          <CardContent className="p-8 text-center">
            <Package className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-40" />
            <p className="text-muted-foreground">لا توجد شحنات تطابق بحثك</p>
            <p className="text-xs text-muted-foreground mt-1">تأكد من رقم التتبع أو رقم الهاتف</p>
          </CardContent>
        </Card>
      )}

      {orders.length > 0 && (
        <div className="space-y-3">
          {orders.map((order) => (
            <Card key={order.id} className="border-border/40 bg-card/60 backdrop-blur-sm hover:border-primary/20 transition-colors">
              <CardContent className="p-4">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="space-y-2 flex-1">
                    {/* Header row */}
                    <div className="flex items-center gap-3 flex-wrap">
                      <span className="font-mono font-bold text-primary text-sm">{order.orderNumber}</span>
                      <Badge variant="outline" className={`${STATUS_COLORS[order.status] || ''} text-xs px-2 py-0.5 flex items-center gap-1`}>
                        {STATUS_ICONS[order.status]}
                        {STATUS_LABELS[order.status] || order.status}
                      </Badge>
                      {order.merchantName && (
                        <span className="text-xs text-muted-foreground bg-muted/30 px-2 py-0.5 rounded">{order.merchantName}</span>
                      )}
                      <Button size="sm" variant="outline" className="mr-auto h-7 text-xs" onClick={() => setCareId(order.id)}>ملف المتابعة</Button>
                    </div>

                    {/* Customer info */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1 text-sm">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <User className="w-3.5 h-3.5 shrink-0" />
                        <span className="font-medium text-foreground">{order.customerName}</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground" dir="ltr">
                        <Phone className="w-3.5 h-3.5 shrink-0" />
                        <span>{order.customerPhone}</span>
                        {order.customerPhone2 && <span className="text-xs">/ {order.customerPhone2}</span>}
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground sm:col-span-2">
                        <MapPin className="w-3.5 h-3.5 shrink-0" />
                        <span>{order.governorate}، {order.area} — {order.customerAddress}</span>
                      </div>
                    </div>

                    {order.notes && (
                      <p className="text-xs bg-amber-500/10 text-amber-500/90 border border-amber-500/20 rounded px-2 py-1">
                        ملاحظة: {order.notes}
                      </p>
                    )}
                  </div>

                  {/* Financials */}
                  <div className="flex sm:flex-col items-center sm:items-end gap-4 sm:gap-1 sm:shrink-0 sm:text-left">
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">المطلوب</p>
                      <p className="font-bold text-lg text-primary">{order.totalToCollect} ج.م</p>
                    </div>
                    {order.driverName && (
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground">المندوب</p>
                        <p className="text-xs font-medium">{order.driverName}</p>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {!activeSearch && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-4">
          {[
            { icon: <Search className="w-5 h-5" />, title: 'بحث برقم التتبع', desc: 'مثل: ALG-12345' },
            { icon: <Phone className="w-5 h-5" />, title: 'بحث برقم الهاتف', desc: 'رقم هاتف العميل' },
            { icon: <User className="w-5 h-5" />, title: 'بحث بالاسم', desc: 'اسم العميل كاملاً أو جزئياً' },
          ].map((tip, i) => (
            <div key={i} className="flex items-start gap-3 p-4 rounded-lg border border-border/30 bg-muted/10">
              <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center text-primary shrink-0">{tip.icon}</div>
              <div>
                <p className="font-medium text-sm">{tip.title}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{tip.desc}</p>
              </div>
            </div>
          ))}
        </div>
      )}
      <OrderCareDialog orderId={careId} onClose={() => setCareId(null)} />
    </div>
  );
}


// ===========================================================================
// Follow-up queue
// ===========================================================================
interface QueueItem {
  kind: 'failed' | 'delayed' | 'stuck'; orderId: number; orderNumber: string; customerName: string; customerPhone: string;
  governorate: string; area: string; status: string; attemptCount: number; backInWarehouse: boolean; hoursSince: number;
  lastContact: { at: string; kind: string; by: string } | null; openTickets: number;
}

const GROUPS: { key: 'failed' | 'delayed' | 'stuck'; title: string; hint: string; tone: string }[] = [
  { key: 'failed', title: 'فشل التسليم — تحتاج اتصالاً', hint: 'المندوب رجّع الشحنة. اتصل بالعميل واعرف الموعد المناسب لإعادة المحاولة.', tone: 'text-destructive' },
  { key: 'delayed', title: 'متأخرة في الطريق', hint: 'مع المندوب بدون أي حركة لفترة طويلة.', tone: 'text-amber-500' },
  { key: 'stuck', title: 'لم تخرج للتوصيل', hint: 'وصلت الفرع منذ أكثر من يومين ولم تُسند لمندوب.', tone: 'text-blue-400' },
];

function Queue() {
  const [careId, setCareId] = useState<number | null>(null);
  const { data, isLoading } = useQuery({ queryKey: ['support-queue'], queryFn: () => apiFetch<{ failed: QueueItem[]; delayed: QueueItem[]; stuck: QueueItem[] }>('/support/queue'), refetchInterval: 30_000 });
  const total = data ? data.failed.length + data.delayed.length + data.stuck.length : 0;

  if (isLoading) return <div className="h-40 rounded-xl bg-muted/20 animate-pulse" />;
  if (!data || total === 0) return <p className="text-center text-emerald-500 py-14">لا توجد شحنات تحتاج متابعة الآن 🎉</p>;

  return (
    <div className="space-y-6">
      {GROUPS.map((g) => {
        const items = data[g.key];
        if (!items.length) return null;
        return (
          <section key={g.key} className="space-y-2">
            <div>
              <h3 className={`font-bold ${g.tone}`}>{g.title} <span className="text-muted-foreground font-normal">({items.length})</span></h3>
              <p className="text-xs text-muted-foreground">{g.hint}</p>
            </div>
            <div className="space-y-2">
              {items.map((o) => {
                const contactedRecently = !!o.lastContact && Date.now() - new Date(o.lastContact.at).getTime() < 12 * 3_600_000;
                const tpl = WHATSAPP_TEMPLATES.find((t) => t.key === (g.key === 'failed' ? 'failed' : g.key === 'delayed' ? 'delay' : 'tracking'))!;
                const care = { orderNumber: o.orderNumber, customerName: o.customerName, customerPhone: o.customerPhone };
                return (
                  <Card key={o.orderId} className="border-border/40 bg-card/60">
                    <CardContent className="p-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm">
                      <span className="font-mono font-bold text-primary">{o.orderNumber}</span>
                      <span className="font-medium">{o.customerName}</span>
                      <span className="text-muted-foreground text-xs">{o.governorate} — {o.area}</span>
                      <span className="text-xs text-muted-foreground">منذ {o.hoursSince < 24 ? `${o.hoursSince} س` : `${Math.round(o.hoursSince / 24)} يوم`}</span>
                      {g.key === 'failed' && <Badge variant="outline" className="text-[10px]">محاولة {o.attemptCount}/3</Badge>}
                      {g.key === 'failed' && !o.backInWarehouse && <Badge variant="outline" className="text-[10px] text-amber-500 border-amber-500/30">لم تصل المخزن</Badge>}
                      {o.openTickets > 0 && <Badge variant="outline" className="text-[10px]">{o.openTickets} تذكرة</Badge>}
                      <span className={`text-[11px] ${contactedRecently ? 'text-emerald-500' : 'text-muted-foreground'}`}>
                        {o.lastContact ? `آخر تواصل: ${o.lastContact.by}` : 'لم يتم التواصل بعد'}
                      </span>
                      <span className="mr-auto flex gap-1.5">
                        <a href={`tel:${o.customerPhone}`}><Button size="sm" variant="outline" className="h-8"><Phone className="w-3.5 h-3.5" /></Button></a>
                        <a href={whatsappFor(o.customerPhone, tpl.text(care))} target="_blank" rel="noreferrer" onClick={() => setCareId(null)}>
                          <Button size="sm" variant="outline" className="h-8 text-emerald-500 border-emerald-500/30">واتساب</Button></a>
                        <Button size="sm" className="h-8" onClick={() => setCareId(o.orderId)}>فتح الملف</Button>
                      </span>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </section>
        );
      })}
      <OrderCareDialog orderId={careId} onClose={() => setCareId(null)} />
    </div>
  );
}

export default function CustomerService() {
  const [tab, setTab] = useState<'queue' | 'tickets' | 'search'>('queue');
  const { data } = useQuery({ queryKey: ['support-queue'], queryFn: () => apiFetch<{ failed: unknown[]; delayed: unknown[]; stuck: unknown[] }>('/support/queue'), refetchInterval: 30_000 });
  const queueCount = data ? data.failed.length + data.delayed.length + data.stuck.length : 0;

  const tabs = [
    { key: 'queue' as const, label: 'تحتاج متابعة', Icon: ListChecks, badge: queueCount },
    { key: 'tickets' as const, label: 'التذاكر', Icon: Ticket, badge: 0 },
    { key: 'search' as const, label: 'بحث عن شحنة', Icon: ScanSearch, badge: 0 },
  ];
  return (
    <div className="space-y-5 max-w-5xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2"><Headset className="w-7 h-7 text-primary" /> مركز خدمة العملاء</h1>
        <p className="text-muted-foreground">متابعة الشحنات المتعثرة، التذاكر، وسجل التواصل مع العملاء</p>
      </div>
      <div className="inline-flex rounded-xl border border-border/50 bg-card/50 p-1 gap-1 flex-wrap">
        {tabs.map(({ key, label, Icon, badge }) => (
          <button key={key} type="button" onClick={() => setTab(key)}
            className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-colors ${tab === key ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
            <Icon className="w-4 h-4" /> {label}
            {badge > 0 && <span className={`text-[11px] rounded-full px-1.5 ${tab === key ? 'bg-primary-foreground/20' : 'bg-destructive/15 text-destructive'}`}>{badge}</span>}
          </button>
        ))}
      </div>
      {tab === 'queue' && <Queue />}
      {tab === 'tickets' && <TicketsPanel />}
      {tab === 'search' && <OrderSearch />}
    </div>
  );
}
