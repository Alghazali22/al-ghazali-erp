import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Package, CheckCircle2, RotateCcw, Timer, Banknote, Target, TrendingUp } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { apiFetch } from '@/lib/extra-api';

type Overview = {
  days: number;
  kpis: { totalOrders: number; delivered: number; returned: number; openOrders: number; successRate: number | null; firstAttemptRate: number | null; avgDeliveryHours: number | null; codCollected: number };
  areas: { governorate: string; area: string; total: number; delivered: number; returned: number; returnRate: number | null }[];
  hourly: { hour: number; deliveries: number }[];
  drivers: { driverId: number; name: string; closed: number; delivered: number; returned: number; successRate: number | null; avgHours: number | null; cod: number }[];
  merchants: { merchantId: number; name: string; total: number; delivered: number; returned: number; returnRate: number | null }[];
};

const fmtPct = (v: number | null) => (v === null ? '—' : `${v}%`);
const fmtMoney = (n: number) => `${Math.round(n).toLocaleString('en-US')} ج.م`;
const rateTone = (rate: number | null, good = true) =>
  rate === null ? 'text-muted-foreground'
  : (good ? rate >= 85 : rate <= 10) ? 'text-emerald-500'
  : (good ? rate >= 70 : rate <= 25) ? 'text-amber-500' : 'text-destructive';

function Kpi({ icon: Icon, label, value, tone }: { icon: any; label: string; value: string; tone: string }) {
  return (
    <Card className="border-border/40 bg-card/60">
      <CardContent className="p-4 flex items-center gap-3">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${tone}`}><Icon className="w-5 h-5" /></div>
        <div className="min-w-0"><div className="text-xs text-muted-foreground">{label}</div><div className="text-xl font-bold font-mono truncate">{value}</div></div>
      </CardContent>
    </Card>
  );
}

export default function Analytics() {
  const { user } = useAuth();
  const isMerchant = user?.role === 'merchant';
  const [days, setDays] = useState<7 | 30 | 90>(30);
  const { data, isLoading, isError } = useQuery({
    queryKey: ['analytics', days],
    queryFn: () => apiFetch<Overview>(`/analytics/overview?days=${days}`),
    staleTime: 60_000,
  });

  const hourly = (data?.hourly ?? []).map((h) => ({ ...h, label: `${h.hour}:00` }));
  const peak = hourly.reduce((best, h) => (h.deliveries > best.deliveries ? h : best), { hour: 0, deliveries: 0, label: '' });
  const worstAreas = [...(data?.areas ?? [])].filter((a) => a.delivered + a.returned >= 5 && (a.returnRate ?? 0) > 0)
    .sort((a, b) => (b.returnRate ?? 0) - (a.returnRate ?? 0)).slice(0, 5);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">التحليلات</h1>
          <p className="text-muted-foreground">{isMerchant ? 'أداء شحناتك: أين تنجح وأين ترجع' : 'أين ينجح التوصيل وأين يفشل، ومن الأفضل أداءً'}</p>
        </div>
        <div className="inline-flex rounded-lg border border-border/50 overflow-hidden">
          {([7, 30, 90] as const).map((d) => (
            <button key={d} type="button" onClick={() => setDays(d)}
              className={`px-4 py-1.5 text-sm ${days === d ? 'bg-primary text-primary-foreground' : 'bg-card/60 text-muted-foreground hover:text-foreground'}`}>
              {d} يوم
            </button>
          ))}
        </div>
      </div>

      {isError && <div role="alert" className="rounded-lg border border-destructive/30 bg-destructive/10 text-destructive text-sm p-3">تعذر تحميل التحليلات</div>}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Kpi icon={Package} label="إجمالي الطلبات" value={isLoading ? '…' : String(data?.kpis.totalOrders ?? 0)} tone="bg-primary/10 text-primary" />
        <Kpi icon={Target} label="نسبة نجاح التسليم" value={isLoading ? '…' : fmtPct(data?.kpis.successRate ?? null)} tone="bg-emerald-500/10 text-emerald-500" />
        <Kpi icon={TrendingUp} label="نجاح من أول محاولة" value={isLoading ? '…' : fmtPct(data?.kpis.firstAttemptRate ?? null)} tone="bg-blue-500/10 text-blue-500" />
        <Kpi icon={Timer} label="متوسط زمن التوصيل" value={isLoading ? '…' : data?.kpis.avgDeliveryHours == null ? '—' : `${data.kpis.avgDeliveryHours} ساعة`} tone="bg-amber-500/10 text-amber-500" />
        <Kpi icon={CheckCircle2} label="تم تسليمها" value={isLoading ? '…' : String(data?.kpis.delivered ?? 0)} tone="bg-emerald-500/10 text-emerald-500" />
        <Kpi icon={RotateCcw} label="مرتجعة" value={isLoading ? '…' : String(data?.kpis.returned ?? 0)} tone="bg-destructive/10 text-destructive" />
        <Kpi icon={Package} label="قيد التنفيذ" value={isLoading ? '…' : String(data?.kpis.openOrders ?? 0)} tone="bg-orange-500/10 text-orange-500" />
        <Kpi icon={Banknote} label="كاش تم تحصيله" value={isLoading ? '…' : fmtMoney(data?.kpis.codCollected ?? 0)} tone="bg-primary/10 text-primary" />
      </div>

      <Card className="border-border/40 bg-card/60">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center justify-between">
            <span>توزيع التسليمات على ساعات اليوم</span>
            {peak.deliveries > 0 && <Badge variant="outline" className="text-xs">ذروة التسليم: {peak.label}</Badge>}
          </CardTitle>
        </CardHeader>
        <CardContent style={{ height: 240 }} dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={hourly} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
              <XAxis dataKey="hour" tick={{ fontSize: 11 }} interval={1} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
              <Tooltip formatter={(v: number) => [v, 'تسليمات']} labelFormatter={(h) => `${h}:00`} />
              <Bar dataKey="deliveries" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="border-border/40 bg-card/60">
          <CardHeader className="pb-2"><CardTitle className="text-base">المناطق الأعلى طلباً</CardTitle></CardHeader>
          <CardContent className="overflow-x-auto">
            <Table>
              <TableHeader><TableRow>
                <TableHead className="text-right">المنطقة</TableHead><TableHead className="text-right">طلبات</TableHead>
                <TableHead className="text-right">مرتجع</TableHead>
              </TableRow></TableHeader>
              <TableBody>
                {(data?.areas ?? []).slice(0, 10).map((a) => (
                  <TableRow key={`${a.governorate}-${a.area}`}>
                    <TableCell>{a.governorate} — {a.area}</TableCell>
                    <TableCell className="font-mono">{a.total}</TableCell>
                    <TableCell className={`font-mono ${rateTone(a.returnRate, false)}`}>{fmtPct(a.returnRate)}</TableCell>
                  </TableRow>
                ))}
                {!isLoading && !data?.areas.length && <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground py-6">لا توجد بيانات في هذه الفترة</TableCell></TableRow>}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card className="border-border/40 bg-card/60">
          <CardHeader className="pb-2"><CardTitle className="text-base">مناطق ترتفع فيها المرتجعات</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {worstAreas.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4">لا مناطق بمرتجعات ملحوظة (يُحسب لمناطق فيها 5 طلبات منتهية على الأقل).</p>
            ) : worstAreas.map((a) => (
              <div key={`${a.governorate}-${a.area}`} className="flex items-center justify-between rounded-lg border border-border/40 px-3 py-2 text-sm">
                <span>{a.governorate} — {a.area}</span>
                <span className={`font-mono font-bold ${rateTone(a.returnRate, false)}`}>{fmtPct(a.returnRate)} <span className="text-xs text-muted-foreground font-normal">({a.returned} من {a.delivered + a.returned})</span></span>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {!isMerchant && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card className="border-border/40 bg-card/60">
            <CardHeader className="pb-2"><CardTitle className="text-base">أداء المناديب</CardTitle></CardHeader>
            <CardContent className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="text-right">المندوب</TableHead><TableHead className="text-right">سلّم</TableHead>
                  <TableHead className="text-right">النجاح</TableHead><TableHead className="text-right">متوسط الزمن</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {(data?.drivers ?? []).map((d) => (
                    <TableRow key={d.driverId}>
                      <TableCell className="font-medium">{d.name}</TableCell>
                      <TableCell className="font-mono">{d.delivered}</TableCell>
                      <TableCell className={`font-mono font-bold ${rateTone(d.successRate)}`}>{fmtPct(d.successRate)}</TableCell>
                      <TableCell className="font-mono text-muted-foreground">{d.avgHours === null ? '—' : `${d.avgHours} س`}</TableCell>
                    </TableRow>
                  ))}
                  {!isLoading && !data?.drivers.length && <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground py-6">لا توجد بيانات</TableCell></TableRow>}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card className="border-border/40 bg-card/60">
            <CardHeader className="pb-2"><CardTitle className="text-base">أكبر التجار</CardTitle></CardHeader>
            <CardContent className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead className="text-right">التاجر</TableHead><TableHead className="text-right">طلبات</TableHead>
                  <TableHead className="text-right">نسبة المرتجع</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {(data?.merchants ?? []).map((m) => (
                    <TableRow key={m.merchantId}>
                      <TableCell className="font-medium">{m.name}</TableCell>
                      <TableCell className="font-mono">{m.total}</TableCell>
                      <TableCell className={`font-mono font-bold ${rateTone(m.returnRate, false)}`}>{fmtPct(m.returnRate)}</TableCell>
                    </TableRow>
                  ))}
                  {!isLoading && !data?.merchants.length && <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground py-6">لا توجد بيانات</TableCell></TableRow>}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
