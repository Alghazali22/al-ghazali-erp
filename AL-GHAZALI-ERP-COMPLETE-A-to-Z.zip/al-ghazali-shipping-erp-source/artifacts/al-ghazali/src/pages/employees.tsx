import React, { useState } from 'react';
import { useGetUsers, useGetBranches, useCreateUser, useUpdateUser, useToggleUserStatus, useDeleteUser, getGetUsersQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { ResetPasswordButton } from '@/components/ResetPasswordButton';
import { User } from '@workspace/api-client-react';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { UserCircle, Search, Plus, Edit, Power, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { arEG } from 'date-fns/locale';

const ROLE_LABELS: Record<string, string> = {
  super_admin: 'مدير النظام',
  branch_manager: 'مدير فرع',
  accountant: 'محاسب',
  operations: 'عمليات',
  cs: 'خدمة عملاء',
};

const createSchema = z.object({
  username: z.string().min(3, 'اسم المستخدم 3 أحرف على الأقل'),
  password: z.string().min(8, 'كلمة المرور 8 أحرف على الأقل'),
  fullName: z.string().min(2, 'الاسم مطلوب'),
  role: z.string().min(1, 'الصلاحية مطلوبة'),
  phone: z.string().optional(),
  branchId: z.coerce.number().optional(),
});

const editSchema = z.object({
  fullName: z.string().min(2, 'الاسم مطلوب'),
  phone: z.string().optional(),
  branchId: z.coerce.number().optional(),
});

type CreateForm = z.infer<typeof createSchema>;
type EditForm = z.infer<typeof editSchema>;

export default function Employees() {
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [editEmployee, setEditEmployee] = useState<User | null>(null);
  const [deleteEmployee, setDeleteEmployee] = useState<User | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user: currentUser } = useAuth();
  const createUser = useCreateUser();
  const updateUser = useUpdateUser();
  const toggleStatus = useToggleUserStatus();
  const deleteUser = useDeleteUser();
  const canDelete = currentUser?.role === 'super_admin';

  const { data, isLoading } = useGetUsers({
    ...(roleFilter !== 'all' ? { role: roleFilter } : {}),
    ...(search ? { search } : {}),
  });
  const { data: branches } = useGetBranches();
  const allUsers = Array.isArray(data) ? data : [];
  const employees = allUsers.filter(u => u.role !== 'driver' && u.role !== 'merchant');

  const createForm = useForm<CreateForm>({
    resolver: zodResolver(createSchema),
    defaultValues: { username: '', password: '', fullName: '', role: '', phone: '' },
  });

  const editForm = useForm<EditForm>({
    resolver: zodResolver(editSchema),
    defaultValues: { fullName: '', phone: '' },
  });

  const onCreateSubmit = async (values: CreateForm) => {
    try {
      await createUser.mutateAsync({ data: { ...values, branchId: values.branchId || undefined } });
      queryClient.invalidateQueries({ queryKey: getGetUsersQueryKey() });
      toast({ title: 'تم إضافة الموظف بنجاح' });
      setCreateOpen(false);
      createForm.reset();
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'خطأ', description: e.message || 'حدث خطأ' });
    }
  };

  const onEditSubmit = async (values: EditForm) => {
    if (!editEmployee) return;
    try {
      await updateUser.mutateAsync({ id: editEmployee.id, data: { ...values, branchId: values.branchId || undefined } });
      queryClient.invalidateQueries({ queryKey: getGetUsersQueryKey() });
      toast({ title: 'تم تحديث بيانات الموظف' });
      setEditEmployee(null);
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'خطأ', description: e.message || 'حدث خطأ' });
    }
  };

  const handleToggle = async (id: number, isActive: boolean) => {
    try {
      await toggleStatus.mutateAsync({ id });
      queryClient.invalidateQueries({ queryKey: getGetUsersQueryKey() });
      toast({ title: isActive ? 'تم إيقاف الموظف' : 'تم تفعيل الموظف' });
    } catch {
      toast({ variant: 'destructive', title: 'حدث خطأ' });
    }
  };

  const handleDelete = async () => {
    if (!deleteEmployee) return;
    try {
      await deleteUser.mutateAsync({ id: deleteEmployee.id });
      await queryClient.invalidateQueries({ queryKey: getGetUsersQueryKey() });
      toast({ title: 'تم حذف الموظف', description: `تم حذف حساب ${deleteEmployee.fullName} نهائياً` });
      setDeleteEmployee(null);
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر حذف الموظف', description: e.message || 'حدث خطأ أثناء الحذف' });
    }
  };

  const openEdit = (user: User) => {
    setEditEmployee(user);
    editForm.reset({ fullName: user.fullName, phone: user.phone || '', branchId: user.branchId || undefined });
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">الموظفين</h1>
          <p className="text-muted-foreground text-sm">إدارة طاقم العمل ومسؤولي النظام</p>
        </div>
        <Button className="bg-primary hover:bg-primary/90 shrink-0" onClick={() => setCreateOpen(true)}>
          <Plus className="w-4 h-4 ml-2" /> إضافة موظف
        </Button>
      </div>

      <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
        <CardContent className="p-4 sm:p-6">
          <div className="flex flex-col sm:flex-row gap-3 mb-5">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input placeholder="بحث بالاسم أو الهاتف..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-4 pr-9 bg-background/50" />
            </div>
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-full sm:w-48 bg-background/50"><SelectValue placeholder="الصلاحية" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">الكل</SelectItem>
                {Object.entries(ROLE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div className="rounded-md border border-border/50 overflow-x-auto">
            <Table>
              <TableHeader className="bg-muted/30">
                <TableRow>
                  <TableHead className="text-right">الموظف</TableHead>
                  <TableHead className="text-right hidden sm:table-cell">الصلاحية</TableHead>
                  <TableHead className="text-right hidden md:table-cell">الفرع</TableHead>
                  <TableHead className="text-right">الحالة</TableHead>
                  <TableHead className="text-right hidden lg:table-cell">تاريخ الإضافة</TableHead>
                  <TableHead className="text-right"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8">جاري التحميل...</TableCell></TableRow>
                ) : employees.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">لا يوجد موظفين</TableCell></TableRow>
                ) : employees.map((user) => (
                  <TableRow key={user.id} className="hover:bg-muted/30">
                    <TableCell>
                      <div className="flex items-center gap-2.5">
                        <UserCircle className="w-7 h-7 text-primary/80 shrink-0" />
                        <div>
                          <div className="font-bold text-sm">{user.fullName}</div>
                          <div className="text-xs text-muted-foreground" dir="ltr">{user.phone}</div>
                          <div className="sm:hidden mt-0.5">
                            <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-primary/20 text-primary">{ROLE_LABELS[user.role] || user.role}</Badge>
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="hidden sm:table-cell">
                      <Badge variant="outline" className="px-2 py-0.5 border-primary/20 text-primary text-xs">{ROLE_LABELS[user.role] || user.role}</Badge>
                    </TableCell>
                    <TableCell className="hidden md:table-cell text-sm">{user.branchName || '—'}</TableCell>
                    <TableCell>
                      <Badge variant={user.isActive ? 'default' : 'destructive'} className="text-xs px-2">{user.isActive ? 'نشط' : 'موقوف'}</Badge>
                    </TableCell>
                    <TableCell className="hidden lg:table-cell text-sm text-muted-foreground" dir="ltr">
                      {user.createdAt ? format(new Date(user.createdAt), 'dd MMM yyyy', { locale: arEG }) : '—'}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => openEdit(user)}><Edit className="w-3.5 h-3.5" /></Button>
                        <ResetPasswordButton user={user} />
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
                          onClick={() => handleToggle(user.id, user.isActive)} disabled={toggleStatus.isPending}>
                          <Power className="w-3.5 h-3.5" />
                        </Button>
                        {canDelete && (
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
                            onClick={() => setDeleteEmployee(user)}>
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Create Dialog */}
      <Dialog open={createOpen} onOpenChange={(open) => { setCreateOpen(open); if (!open) createForm.reset(); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>إضافة موظف جديد</DialogTitle>
            <DialogDescription>أدخل بيانات الموظف لإنشاء حساب</DialogDescription>
          </DialogHeader>
          <Form {...createForm}>
            <form onSubmit={createForm.handleSubmit(onCreateSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField control={createForm.control} name="username" render={({ field }) => (
                  <FormItem><FormLabel>اسم المستخدم</FormLabel><FormControl><Input {...field} dir="ltr" className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={createForm.control} name="password" render={({ field }) => (
                  <FormItem><FormLabel>كلمة المرور</FormLabel><FormControl><Input type="password" {...field} dir="ltr" className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={createForm.control} name="fullName" render={({ field }) => (
                <FormItem><FormLabel>الاسم الكامل</FormLabel><FormControl><Input {...field} className="bg-background/50" /></FormControl><FormMessage /></FormItem>
              )} />
              <div className="grid grid-cols-2 gap-4">
                <FormField control={createForm.control} name="role" render={({ field }) => (
                  <FormItem><FormLabel>الصلاحية</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger className="bg-background/50"><SelectValue placeholder="اختر" /></SelectTrigger></FormControl>
                      <SelectContent>{Object.entries(ROLE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={createForm.control} name="phone" render={({ field }) => (
                  <FormItem><FormLabel>رقم الهاتف</FormLabel><FormControl><Input {...field} dir="ltr" className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={createForm.control} name="branchId" render={({ field }) => (
                <FormItem><FormLabel>الفرع (اختياري)</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value?.toString()}>
                    <FormControl><SelectTrigger className="bg-background/50"><SelectValue placeholder="اختر الفرع" /></SelectTrigger></FormControl>
                    <SelectContent>{branches?.map(b => <SelectItem key={b.id} value={b.id.toString()}>{b.name}</SelectItem>)}</SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setCreateOpen(false)}>إلغاء</Button>
                <Button type="submit" disabled={createUser.isPending} className="bg-primary hover:bg-primary/90">
                  {createUser.isPending ? 'جاري الحفظ...' : 'إضافة الموظف'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editEmployee} onOpenChange={(open) => !open && setEditEmployee(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>تعديل بيانات الموظف</DialogTitle>
            <DialogDescription>{editEmployee?.fullName}</DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              <FormField control={editForm.control} name="fullName" render={({ field }) => (
                <FormItem><FormLabel>الاسم الكامل</FormLabel><FormControl><Input {...field} className="bg-background/50" /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={editForm.control} name="phone" render={({ field }) => (
                <FormItem><FormLabel>رقم الهاتف</FormLabel><FormControl><Input {...field} dir="ltr" className="bg-background/50" /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={editForm.control} name="branchId" render={({ field }) => (
                <FormItem><FormLabel>الفرع</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value?.toString()}>
                    <FormControl><SelectTrigger className="bg-background/50"><SelectValue placeholder="اختر الفرع" /></SelectTrigger></FormControl>
                    <SelectContent>{branches?.map(b => <SelectItem key={b.id} value={b.id.toString()}>{b.name}</SelectItem>)}</SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setEditEmployee(null)}>إلغاء</Button>
                <Button type="submit" disabled={updateUser.isPending} className="bg-primary hover:bg-primary/90">
                  {updateUser.isPending ? 'جاري الحفظ...' : 'حفظ التعديلات'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteEmployee} onOpenChange={(open) => !open && setDeleteEmployee(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>حذف حساب الموظف</DialogTitle>
            <DialogDescription className="text-destructive">
              سيتم حذف حساب {deleteEmployee?.fullName} نهائياً ولا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setDeleteEmployee(null)}>إلغاء</Button>
            <Button type="button" variant="destructive" onClick={handleDelete} disabled={deleteUser.isPending}>
              {deleteUser.isPending ? 'جاري الحذف...' : 'تأكيد الحذف'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
