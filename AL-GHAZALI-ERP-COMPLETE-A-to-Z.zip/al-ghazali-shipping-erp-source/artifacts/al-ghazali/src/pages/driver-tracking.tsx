import React, { useEffect, useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { MapContainer, TileLayer, Marker, Popup, Circle, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';
import markerIcon2x from 'leaflet/dist/images/marker-icon-2x.png';
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Truck, Clock, RotateCcw, WifiOff, Phone, MessageCircle, Search, Route, Gauge, Timer, PauseCircle, AlertTriangle, LocateFixed, X } from 'lucide-react';
import { apiFetch } from '@/lib/extra-api';
import 'leaflet/dist/leaflet.css';

// Vite bundles these as hashed URLs; wire them into Leaflet's default icon
// since the default icon paths break under a bundler.
L.Marker.prototype.options.icon = L.icon({
  iconUrl: markerIcon, iconRetinaUrl: markerIcon2x, shadowUrl: markerShadow,
  iconSize: [25, 41], iconAnchor: [12, 41], popupAnchor: [1, -34],
});

type Connection = 'live' | 'stale' | 'offline' | 'no_signal';

type TrackedOrder = {
  orderId: number; orderNumber: string; customerName: string; governorate: string; area: string;
  status: string; lat: number | null; lng: number | null; queuePosition: number;
  etaMinutes: number | null; distanceKm: number | null;
};
type TrackingPoint = { lat: number; lng: number; recordedAt: string | null };
type DriverLocation = {
  driverId: number; driverName: string; phone: string | null;
  lat: number | null; lng: number | null; locationUpdatedAt: string | null;
  status: Connection; ageSeconds: number | null; accuracy: number | null; speedKmh: number | null;
  heading: number | null; path: TrackingPoint[]; activeOrderCount: number; orders: TrackedOrder[];
};
type TrackingResponse = {
  drivers: DriverLocation[]; trafficMultiplier: number; hour: number; generatedAt: string;
  summary: { total: number; live: number; stale: number; offline: number; noSignal: number; activeOrders: number; needsAttention: number };
};
type HistoryResponse = {
  driverName: string; pointCount: number; path: TrackingPoint[];
  stats: { distanceKm: number; movingMinutes: number; maxSpeedKmh: number; stops: { lat: number; lng: number; from: string; to: string; minutes: number }[] };
};

const CAIRO_CENTER: [number, number] = [30.0444, 31.2357];

const STATUS_META: Record<Connection, { label: string; color: string; badge: string }> = {
  live:      { label: 'متصل الآن',    color: '#10b981', badge: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' },
  stale:     { label: 'إشارة قديمة', color: '#f59e0b', badge: 'bg-amber-500/10 text-amber-500 border-amber-500/20' },
  offline:   { label: 'غير متصل',    color: '#94a3b8', badge: 'bg-slate-500/10 text-slate-400 border-slate-500/20' },
  no_signal: { label: 'لم يحدد موقعه', color: '#64748b', badge: 'bg-slate-500/10 text-slate-400 border-slate-500/20' },
};

function ageText(seconds: number | null): string {
  if (seconds === null) return 'لم يحدد موقعه بعد';
  if (seconds < 60) return `منذ ${seconds} ثانية`;
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `منذ ${minutes} دقيقة`;
  const hours = Math.floor(minutes / 60);
  return `منذ ${hours} ساعة${minutes % 60 ? ` و${minutes % 60} د` : ''}`;
}

const hhmm = (iso: string) => new Date(iso).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', timeZone: 'Africa/Cairo' });

function driverIcon(d: DriverLocation, selected: boolean) {
  const color = STATUS_META[d.status].color;
  const moving = d.status === 'live' && (d.speedKmh ?? 0) >= 4 && d.heading !== null;
  const size = selected ? 38 : 32;
  const arrow = moving
    ? `<div style="transform:rotate(${d.heading}deg);font-size:${selected ? 18 : 15}px;line-height:1">▲</div>`
    : '<div style="font-size:15px;line-height:1">●</div>';
  return L.divIcon({
    className: 'driver-map-icon',
    html: `<div style="width:${size}px;height:${size}px;border-radius:50%;background:#0f172a;border:3px solid ${color};color:${color};display:flex;align-items:center;justify-content:center;opacity:${d.status === 'live' ? 1 : 0.7};box-shadow:0 2px 8px rgba(0,0,0,.4)${selected ? `,0 0 0 4px ${color}33` : ''}">${arrow}</div>`,
    iconSize: [size, size], iconAnchor: [size / 2, size / 2],
  });
}

function numberedIcon(n: number, color: string) {
  return L.divIcon({
    className: 'order-map-icon',
    html: `<div style="width:26px;height:26px;border-radius:50%;background:${color};border:2px solid white;color:white;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;box-shadow:0 2px 6px rgba(0,0,0,.35)">${n}</div>`,
    iconSize: [26, 26], iconAnchor: [13, 13],
  });
}

const stopIcon = L.divIcon({
  className: 'stop-map-icon',
  html: '<div style="width:22px;height:22px;border-radius:6px;background:#7c3aed;border:2px solid white;color:white;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;box-shadow:0 2px 6px rgba(0,0,0,.35)">P</div>',
  iconSize: [22, 22], iconAnchor: [11, 11],
});

/** Fits the map to all drivers once, and flies to the selected driver when it changes. */
function MapController({ drivers, selected, recenterKey }: { drivers: DriverLocation[]; selected: DriverLocation | null; recenterKey: number }) {
  const map = useMap();
  const [fittedOnce, setFittedOnce] = useState(false);

  useEffect(() => {
    if (selected?.lat != null && selected.lng != null) {
      map.flyTo([selected.lat, selected.lng], Math.max(map.getZoom(), 14), { duration: 0.8 });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected?.driverId]);

  useEffect(() => {
    const pts = drivers.filter((d) => d.lat != null && d.lng != null).map((d) => [d.lat as number, d.lng as number] as [number, number]);
    if (pts.length === 0) return;
    if (!fittedOnce || recenterKey > 0) {
      map.fitBounds(L.latLngBounds(pts), { padding: [48, 48], maxZoom: 15 });
      setFittedOnce(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [drivers.length, recenterKey]);

  return null;
}

function useDriverTracking() {
  return useQuery({
    queryKey: ['driver-tracking'],
    queryFn: () => apiFetch<TrackingResponse>('/tracking/drivers'),
    refetchInterval: 10_000,
  });
}

function useDriverHistory(driverId: number | null) {
  return useQuery({
    queryKey: ['driver-tracking-history', driverId],
    queryFn: () => apiFetch<HistoryResponse>(`/tracking/drivers/${driverId}/history`),
    enabled: driverId !== null,
    refetchInterval: 30_000,
  });
}

type Filter = 'all' | 'live' | 'active' | 'attention';

export default function DriverTracking() {
  const { data, isLoading, isError, refetch, isFetching } = useDriverTracking();
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [filter, setFilter] = useState<Filter>('all');
  const [search, setSearch] = useState('');
  const [showTrail, setShowTrail] = useState(true);
  const [recenterKey, setRecenterKey] = useState(0);

  const drivers = data?.drivers ?? [];
  const summary = data?.summary;
  const selected = useMemo(() => drivers.find((d) => d.driverId === selectedId) ?? null, [drivers, selectedId]);
  const { data: history } = useDriverHistory(selectedId);

  const rank: Record<Connection, number> = { live: 0, stale: 1, offline: 2, no_signal: 3 };
  const visible = useMemo(() => {
    const q = search.trim().toLowerCase();
    return drivers
      .filter((d) => (q ? d.driverName.toLowerCase().includes(q) : true))
      .filter((d) => {
        if (filter === 'live') return d.status === 'live';
        if (filter === 'active') return d.activeOrderCount > 0;
        if (filter === 'attention') return d.activeOrderCount > 0 && d.status !== 'live';
        return true;
      })
      .sort((a, b) => rank[a.status] - rank[b.status] || b.activeOrderCount - a.activeOrderCount);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [drivers, filter, search]);

  const located = useMemo(() => visible.filter((d) => d.lat !== null && d.lng !== null), [visible]);

  const trafficLabel = data
    ? data.trafficMultiplier >= 1.5 ? 'ازدحام متوقع الآن' : data.trafficMultiplier <= 0.9 ? 'حركة خفيفة الآن' : 'حركة طبيعية'
    : '';

  const chips: { key: Filter; label: string; count: number | undefined }[] = [
    { key: 'all', label: 'الكل', count: summary?.total },
    { key: 'live', label: 'متصلون', count: summary?.live },
    { key: 'active', label: 'معهم طلبات', count: drivers.filter((d) => d.activeOrderCount > 0).length },
    { key: 'attention', label: 'يحتاجون متابعة', count: summary?.needsAttention },
  ];

  const trailPositions = (history?.path ?? []).map((p) => [p.lat, p.lng] as [number, number]);
  const selectedOrders = (selected?.orders ?? []).filter((o) => o.lat !== null && o.lng !== null);
  const routeChain: [number, number][] = selected && selected.lat !== null
    ? [[selected.lat, selected.lng as number], ...selectedOrders.map((o) => [o.lat as number, o.lng as number] as [number, number])]
    : [];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Truck className="w-6 h-6 text-primary" /> تتبع المندوبين المباشر
          </h1>
          <p className="text-sm text-muted-foreground mt-1">مواقع المندوبين لحظة بلحظة، مع مسار اليوم والتوقفات وتقدير وقت الوصول</p>
        </div>
        <div className="flex items-center gap-2">
          {data && <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20">{trafficLabel}</Badge>}
          <Button size="sm" variant="outline" onClick={() => refetch()} disabled={isFetching}>
            <RotateCcw className={`w-3.5 h-3.5 ml-1.5 ${isFetching ? 'animate-spin' : ''}`} /> تحديث
          </Button>
        </div>
      </div>

      {isError && (
        <div role="alert" className="flex items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/10 text-destructive text-sm px-3 py-2">
          <AlertTriangle className="w-4 h-4 shrink-0" /> تعذر تحديث بيانات التتبع — سيتم إعادة المحاولة تلقائياً
        </div>
      )}

      {summary && summary.needsAttention > 0 && (
        <button
          type="button"
          onClick={() => setFilter('attention')}
          className="w-full text-right flex items-center gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 text-amber-500 text-sm px-3 py-2"
        >
          <AlertTriangle className="w-4 h-4 shrink-0" />
          {summary.needsAttention} مندوب معهم طلبات ولا يرسلون موقعاً حياً — اضغط لعرضهم
        </button>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {[
          { label: 'متصل الآن', value: summary?.live, color: 'text-emerald-500' },
          { label: 'إشارة قديمة', value: summary?.stale, color: 'text-amber-500' },
          { label: 'غير متصل', value: (summary?.offline ?? 0) + (summary?.noSignal ?? 0), color: 'text-slate-400' },
          { label: 'طلبات في الطريق', value: summary?.activeOrders, color: 'text-primary' },
        ].map((s) => (
          <Card key={s.label} className="border-border/40 bg-card/60">
            <CardContent className="p-3">
              <div className="text-[11px] text-muted-foreground">{s.label}</div>
              <div className={`text-2xl font-bold font-mono ${s.color}`}>{s.value ?? '—'}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 relative rounded-xl overflow-hidden border border-border/40" style={{ height: 560 }}>
          {isLoading ? (
            <div className="h-full flex items-center justify-center bg-muted/10"><p className="text-sm text-muted-foreground">جاري تحميل الخريطة...</p></div>
          ) : (
            <MapContainer center={CAIRO_CENTER} zoom={11} style={{ height: '100%', width: '100%' }}>
              <TileLayer attribution="&copy; OpenStreetMap contributors" url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
              <MapController drivers={located} selected={selected} recenterKey={recenterKey} />

              {/* Other drivers: short recent trail only; the selected one gets the full route. */}
              {located.filter((d) => d.driverId !== selectedId && d.path.length > 1).map((d) => (
                <Polyline key={`trail-${d.driverId}`} positions={d.path.map((p) => [p.lat, p.lng] as [number, number])}
                  pathOptions={{ color: STATUS_META[d.status].color, weight: 3, opacity: 0.45 }} />
              ))}

              {selected && showTrail && trailPositions.length > 1 && (
                <Polyline positions={trailPositions} pathOptions={{ color: '#38bdf8', weight: 4, opacity: 0.85 }} />
              )}
              {selected && showTrail && history?.stats.stops.map((s, i) => (
                <Marker key={`stop-${i}`} position={[s.lat, s.lng]} icon={stopIcon}>
                  <Popup><div dir="rtl" className="text-right text-xs">
                    <div className="font-bold">توقف {s.minutes} دقيقة</div>
                    <div>{hhmm(s.from)} ← {hhmm(s.to)}</div>
                  </div></Popup>
                </Marker>
              ))}

              {routeChain.length > 1 && (
                <Polyline positions={routeChain} pathOptions={{ color: '#f59e0b', weight: 2, dashArray: '7 8', opacity: 0.9 }} />
              )}
              {selected && selectedOrders.map((o) => (
                <Marker key={o.orderId} position={[o.lat as number, o.lng as number]} icon={numberedIcon(o.queuePosition, '#f59e0b')}>
                  <Popup><div dir="rtl" className="text-right text-xs">
                    <div className="font-bold">{o.orderNumber}</div>
                    <div>{o.customerName}</div>
                    <div className="text-muted-foreground">{o.governorate} — {o.area}</div>
                    <div className="mt-1 font-semibold text-emerald-600">
                      {o.etaMinutes === null ? 'الوقت غير متاح' : `بعد ≈ ${o.etaMinutes} دقيقة`}{o.distanceKm !== null ? ` · ${o.distanceKm} كم` : ''}
                    </div>
                  </div></Popup>
                </Marker>
              ))}

              {located.map((d) => (
                <React.Fragment key={d.driverId}>
                  {d.accuracy !== null && d.status === 'live' && (
                    <Circle center={[d.lat as number, d.lng as number]} radius={Math.min(Math.max(d.accuracy, 15), 500)}
                      pathOptions={{ color: STATUS_META[d.status].color, weight: 1, fillOpacity: 0.08 }} />
                  )}
                  <Marker position={[d.lat as number, d.lng as number]} icon={driverIcon(d, d.driverId === selectedId)}
                    eventHandlers={{ click: () => setSelectedId(d.driverId) }}>
                    <Popup><div dir="rtl" className="text-right text-xs">
                      <div className="font-bold">{d.driverName}</div>
                      <div style={{ color: STATUS_META[d.status].color }}>{STATUS_META[d.status].label} · {ageText(d.ageSeconds)}</div>
                      <div className="mt-1">{d.activeOrderCount} طلب نشط{d.speedKmh !== null && d.status === 'live' ? ` · ${d.speedKmh} كم/س` : ''}</div>
                    </div></Popup>
                  </Marker>
                </React.Fragment>
              ))}
            </MapContainer>
          )}
          <Button size="sm" variant="secondary" className="absolute top-3 left-3 z-[500] shadow-md" onClick={() => setRecenterKey((k) => k + 1)}>
            <LocateFixed className="w-4 h-4 ml-1" /> عرض الكل
          </Button>
          {located.length === 0 && !isLoading && (
            <div className="absolute inset-x-0 bottom-4 flex justify-center z-[500]">
              <span className="bg-card/95 border border-border/50 rounded-full px-4 py-1.5 text-xs text-muted-foreground shadow">لا توجد مواقع مطابقة للفلتر الحالي</span>
            </div>
          )}
        </div>

        <div className="space-y-3 max-h-[560px] overflow-auto custom-scrollbar pl-1">
          <div className="relative">
            <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="بحث باسم المندوب..." className="pr-9" />
          </div>
          <div className="flex flex-wrap gap-1.5">
            {chips.map((c) => (
              <button key={c.key} type="button" onClick={() => setFilter(c.key)}
                className={`text-xs rounded-full px-3 py-1 border transition-colors ${filter === c.key ? 'bg-primary text-primary-foreground border-primary' : 'border-border/50 text-muted-foreground hover:text-foreground'}`}>
                {c.label}{c.count !== undefined ? ` (${c.count})` : ''}
              </button>
            ))}
          </div>

          {selected && (
            <Card className="border-primary/40 bg-primary/5">
              <CardContent className="p-3 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-bold">{selected.driverName}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {STATUS_META[selected.status].label} · {ageText(selected.ageSeconds)}
                      {selected.accuracy !== null ? ` · دقة ≈ ${Math.round(selected.accuracy)} م` : ''}
                    </p>
                  </div>
                  <button type="button" aria-label="إغلاق" onClick={() => setSelectedId(null)} className="p-1 rounded text-muted-foreground hover:text-foreground"><X className="w-4 h-4" /></button>
                </div>

                {selected.phone && (
                  <div className="flex gap-2">
                    <a href={`tel:${selected.phone}`} className="flex-1"><Button size="sm" variant="outline" className="w-full"><Phone className="w-3.5 h-3.5 ml-1" /> اتصال</Button></a>
                    <a href={`https://wa.me/${selected.phone.replace(/[^\d]/g, '').replace(/^0/, '20')}`} target="_blank" rel="noreferrer" className="flex-1">
                      <Button size="sm" variant="outline" className="w-full"><MessageCircle className="w-3.5 h-3.5 ml-1" /> واتساب</Button>
                    </a>
                  </div>
                )}

                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-lg bg-background/60 p-2"><Route className="w-4 h-4 mx-auto text-primary" /><div className="font-mono font-bold text-sm mt-1">{history ? `${history.stats.distanceKm} كم` : '—'}</div><div className="text-[10px] text-muted-foreground">مسافة اليوم</div></div>
                  <div className="rounded-lg bg-background/60 p-2"><Timer className="w-4 h-4 mx-auto text-primary" /><div className="font-mono font-bold text-sm mt-1">{history ? `${history.stats.movingMinutes} د` : '—'}</div><div className="text-[10px] text-muted-foreground">وقت الحركة</div></div>
                  <div className="rounded-lg bg-background/60 p-2"><Gauge className="w-4 h-4 mx-auto text-primary" /><div className="font-mono font-bold text-sm mt-1">{history ? `${history.stats.maxSpeedKmh}` : '—'}</div><div className="text-[10px] text-muted-foreground">أقصى سرعة كم/س</div></div>
                </div>

                <label className="flex items-center gap-2 text-xs cursor-pointer">
                  <input type="checkbox" checked={showTrail} onChange={(e) => setShowTrail(e.target.checked)} />
                  إظهار مسار اليوم والتوقفات على الخريطة
                </label>

                {history && history.stats.stops.length > 0 && (
                  <div className="space-y-1">
                    <p className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1"><PauseCircle className="w-3.5 h-3.5" /> توقفات اليوم</p>
                    {history.stats.stops.slice(-6).map((s, i) => (
                      <div key={i} className="w-full flex justify-between text-xs rounded px-2 py-1 bg-background/40">
                        <span>{hhmm(s.from)} ← {hhmm(s.to)}</span><span className="font-mono">{s.minutes} د</span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {isLoading ? (
            [...Array(3)].map((_, i) => <div key={i} className="h-24 rounded-xl bg-muted/20 animate-pulse" />)
          ) : visible.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground text-sm">لا يوجد مندوبين مطابقين</div>
          ) : (
            visible.map((d) => (
              <Card key={d.driverId}
                className={`border-border/40 cursor-pointer transition-all ${selectedId === d.driverId ? 'border-primary/60 bg-primary/5' : 'bg-card/70'}`}
                onClick={() => setSelectedId(d.driverId === selectedId ? null : d.driverId)}>
                <CardContent className="p-3 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="relative w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold shrink-0">
                        {d.driverName.charAt(0)}
                        <span className="absolute -bottom-0.5 -left-0.5 w-3 h-3 rounded-full border-2 border-card" style={{ background: STATUS_META[d.status].color }} />
                      </div>
                      <div className="min-w-0">
                        <p className="font-bold text-sm truncate">{d.driverName}</p>
                        <p className="text-[11px] text-muted-foreground flex items-center gap-1">
                          {d.lat === null ? <WifiOff className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                          {ageText(d.ageSeconds)}{d.status === 'live' && d.speedKmh ? ` · ${d.speedKmh} كم/س` : ''}
                        </p>
                      </div>
                    </div>
                    <Badge variant="outline" className={`${STATUS_META[d.status].badge} text-[10px] shrink-0`}>
                      {d.activeOrderCount > 0 ? `${d.activeOrderCount} طلب` : STATUS_META[d.status].label}
                    </Badge>
                  </div>

                  {d.orders.length > 0 && (
                    <div className="space-y-1.5 pt-1 border-t border-border/30">
                      {d.orders.slice(0, selectedId === d.driverId ? 50 : 3).map((o) => (
                        <div key={o.orderId} className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <span className="w-4 h-4 rounded-full bg-muted flex items-center justify-center text-[10px] font-bold shrink-0">{o.queuePosition}</span>
                            <span className="truncate">{o.orderNumber} — {o.area}</span>
                          </div>
                          <span className={`font-mono font-bold shrink-0 ${o.etaMinutes === null ? 'text-muted-foreground' : 'text-emerald-500'}`}>
                            {o.etaMinutes === null ? 'غير متاح' : `${o.etaMinutes} د`}
                          </span>
                        </div>
                      ))}
                      {selectedId !== d.driverId && d.orders.length > 3 && (
                        <p className="text-[11px] text-muted-foreground">+ {d.orders.length - 3} طلبات أخرى</p>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>

      <p className="text-[11px] text-muted-foreground leading-relaxed">
        وقت الوصول تقدير تقريبي: المسافة في خط مستقيم × معامل طرق، مع معامل ازدحام حسب ساعة اليوم (بتوقيت القاهرة)، ووقت تسليم ثابت لكل طلب.
        نقطة الوصول هي مركز المنطقة وليست عنوان العميل بالتحديد.
      </p>
    </div>
  );
}
