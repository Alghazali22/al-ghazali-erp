import React, { useState } from 'react';
import { useGetTrips, useCreateTrip, useConfirmTrip, useCompleteTrip, useDeleteTrip, useGetUsers, useGetOrders, getGetTripsQueryKey, getGetOrdersQueryKey } from '@workspace/api-client-react';
import { useQueryClient, useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Truck, Plus, Package, CheckSquare, Square, Send, CheckCircle2, Trash2, Sparkles, Route } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { SmartDispatchDialog } from '@/components/SmartDispatchDialog';
import { apiFetch } from '@/lib/extra-api';
import { format } from 'date-fns';
import { arEG } from 'date-fns/locale';

const STATUS_COLORS: Record<string, string> = {
  completed: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
  in_progress: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
  confirmed: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
  draft: 'bg-muted text-muted-foreground',
};
const STATUS_LABELS: Record<string, string> = {
  completed: 'مكتملة',
  in_progress: 'في الطريق',
  confirmed: 'مؤكدة',
  draft: 'مسودة',
};

export default function Trips() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [smartOpen, setSmartOpen] = useState(false);
  const { data: board } = useQuery({ queryKey: ['shift-board'], queryFn: () => apiFetch<{ drivers: { driverId: number; status: string; queuePosition: number | null }[] }>('/shifts/board'), refetchInterval: 15_000 });
  const driverTag = (id: number) => {
    const b = board?.drivers.find((x) => x.driverId === id);
    if (!b) return '';
    return b.status === 'available' ? ` — الدور ${b.queuePosition}` : b.status === 'off' ? ' — خارج الشيفت' : b.status === 'on_trip' ? ' — في رحلة' : ' — استراحة';
  };
  const [selectedDriver, setSelectedDriver] = useState('');
  const [selectedOrderIds, setSelectedOrderIds] = useState<number[]>([]);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const createTrip = useCreateTrip();
  const confirmTrip = useConfirmTrip();
  const completeTrip = useCompleteTrip();
  const deleteTrip = useDeleteTrip();
  const { user: currentUser } = useAuth();
  const canDelete = currentUser?.role === 'super_admin';

  const { data: trips, isLoading } = useGetTrips({});
  const { data: driversData } = useGetUsers({ role: 'driver' });
  const drivers = (Array.isArray(driversData) ? driversData : []).filter(d => d.isActive);

  const availableOrdersParams = { status: 'ready' as const, inventoryStatus: 'in_warehouse' as const, limit: 100 };
  const { data: ordersData } = useGetOrders(availableOrdersParams, {
    query: { queryKey: getGetOrdersQueryKey(availableOrdersParams), enabled: dialogOpen },
  });
  const availableOrders = ordersData?.orders || [];

  const toggleOrder = (id: number) => {
    setSelectedOrderIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const handleCreate = async () => {
    if (!selectedDriver || selectedOrderIds.length === 0) {
      toast({ variant: 'destructive', title: 'يرجى اختيار مندوب وطلب واحد على الأقل' });
      return;
    }
    try {
      await createTrip.mutateAsync({ data: { driverId: Number(selectedDriver), orderIds: selectedOrderIds } });
      queryClient.invalidateQueries({ queryKey: getGetTripsQueryKey({}) });
      toast({ title: 'تم إنشاء الرحلة بنجاح', description: `${selectedOrderIds.length} طلب — مندوب: ${drivers.find(d => d.id === Number(selectedDriver))?.fullName}` });
      setDialogOpen(false);
      setSelectedDriver('');
      setSelectedOrderIds([]);
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'خطأ', description: e.message || 'حدث خطأ أثناء إنشاء الرحلة' });
    }
  };

  const handleConfirm = async (id: number) => {
    try {
      await confirmTrip.mutateAsync({ id });
      queryClient.invalidateQueries({ queryKey: getGetTripsQueryKey({}) });
      queryClient.invalidateQueries({ queryKey: getGetOrdersQueryKey({}) });
      toast({ title: 'تم تأكيد الرحلة', description: 'الطلبات الآن قيد التوصيل وستظهر لدى المندوب' });
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'خطأ', description: e.message || 'تعذر تأكيد الرحلة' });
    }
  };

  const handleComplete = async (id: number) => {
    try {
      await completeTrip.mutateAsync({ id });
      queryClient.invalidateQueries({ queryKey: getGetTripsQueryKey({}) });
      toast({ title: 'تم إغلاق الرحلة بنجاح' });
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'خطأ', description: e.message || 'تعذر إغلاق الرحلة' });
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm('سيتم حذف الرحلة وفك ارتباط الطلبات بها نهائياً. هل تريد المتابعة؟')) return;
    try {
      await deleteTrip.mutateAsync({ id });
      await queryClient.invalidateQueries({ queryKey: getGetTripsQueryKey({}) });
      await queryClient.invalidateQueries({ queryKey: getGetOrdersQueryKey({}) });
      toast({ title: 'تم حذف الرحلة نهائياً' });
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر حذف الرحلة', description: e.message || 'حدث خطأ أثناء الحذف' });
    }
  };

  const handleOptimize = async (id: number) => {
    try {
      const res = await apiFetch<{ optimization: { stops: number; beforeKm: number; afterKm: number; savedPercent: number; unlocatedStops: number } }>(
        `/trips/${id}/optimize`, { method: 'POST' });
      const o = res.optimization;
      toast({
        title: 'تم ترتيب خط السير',
        description: o.beforeKm > 0
          ? `من ${o.beforeKm} كم إلى ${o.afterKm} كم (توفير ${o.savedPercent}%)${o.unlocatedStops ? ` — ${o.unlocatedStops} طلب بدون إحداثيات وُضع في النهاية` : ''}`
          : `${o.stops} نقطة`,
      });
      queryClient.invalidateQueries({ queryKey: getGetTripsQueryKey() });
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر ترتيب الرحلة', description: e.message });
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">إدارة الرحلات</h1>
          <p className="text-muted-foreground text-sm">تتبع خطوط السير وحركة المندوبين</p>
        </div>
        <div className="flex gap-2 shrink-0">
          <Button variant="outline" className="border-primary/40 text-primary" onClick={() => setSmartOpen(true)}>
            <Sparkles className="w-4 h-4 ml-2" /> توزيع ذكي
          </Button>
          <Button className="bg-primary hover:bg-primary/90" onClick={() => setDialogOpen(true)}>
            <Plus className="w-4 h-4 ml-2" /> رحلة جديدة
          </Button>
        </div>
      </div>

      <SmartDispatchDialog
        open={smartOpen}
        onOpenChange={setSmartOpen}
        onCreated={() => {
          queryClient.invalidateQueries({ queryKey: getGetTripsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetOrdersQueryKey() });
        }}
      />

      <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-muted/30">
                <TableRow>
                  <TableHead className="text-right">رقم الرحلة</TableHead>
                  <TableHead className="text-right">المندوب</TableHead>
                  <TableHead className="text-right">الحالة</TableHead>
                  <TableHead className="text-right">الطلبات</TableHead>
                  <TableHead className="text-right hidden sm:table-cell">إجمالي التحصيل</TableHead>
                  <TableHead className="text-right hidden md:table-cell">تاريخ الإنشاء</TableHead>
                  <TableHead className="text-right">إجراءات</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow><TableCell colSpan={7} className="text-center py-8">جاري التحميل...</TableCell></TableRow>
                ) : !trips?.length ? (
                  <TableRow><TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                    <Truck className="w-10 h-10 mx-auto mb-3 opacity-30" />
                    لا توجد رحلات حالياً
                  </TableCell></TableRow>
                ) : trips.map((trip) => (
                  <TableRow key={trip.id} className="hover:bg-muted/30">
                    <TableCell className="font-mono font-bold text-primary text-sm">TRP-{trip.id.toString().padStart(4, '0')}</TableCell>
                    <TableCell className="font-medium text-sm">{trip.driverName}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={`${STATUS_COLORS[trip.status] || ''} text-xs px-2`}>
                        {STATUS_LABELS[trip.status] || trip.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm">{trip.orderCount || 0} طلب</TableCell>
                    <TableCell className="hidden sm:table-cell font-mono text-primary font-bold text-sm">
                      {trip.totalToCollect || 0} ج.م
                    </TableCell>
                    <TableCell className="hidden md:table-cell text-sm text-muted-foreground" dir="ltr">
                      {format(new Date(trip.createdAt), 'dd MMM yyyy', { locale: arEG })}
                    </TableCell>
                     <TableCell>
                       <div className="flex items-center gap-2">
                         {trip.status === 'draft' ? (
                           <Link href={`/dispatch?tab=loading&trip=${trip.id}`}>
                             <Button size="sm" className="bg-primary hover:bg-primary/90 h-8 text-xs">
                               <Send className="w-3.5 h-3.5 ml-1.5" /> تحميل وانطلاق
                             </Button>
                           </Link>
                         ) : trip.status === 'in_progress' ? (
                           <Button
                             size="sm"
                             variant="outline"
                             className="h-8 text-xs border-emerald-500/30 text-emerald-500 hover:bg-emerald-500/10"
                             disabled={completeTrip.isPending}
                             onClick={() => handleComplete(trip.id)}
                           >
                             <CheckCircle2 className="w-3.5 h-3.5 ml-1.5" /> إغلاق الرحلة
                           </Button>
                         ) : (
                           <span className="text-xs text-muted-foreground">—</span>
                         )}
                         {(trip.status === 'draft' || trip.status === 'in_progress') && (
                           <Button variant="ghost" size="sm" title="ترتيب أمثل لخط السير" aria-label="ترتيب أمثل لخط السير"
                             className="h-8 w-8 p-0 text-muted-foreground hover:text-primary" onClick={() => handleOptimize(trip.id)}>
                             <Route className="w-3.5 h-3.5" />
                           </Button>
                         )}
                         {canDelete && (
                           <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
                             onClick={() => handleDelete(trip.id)} disabled={deleteTrip.isPending}>
                             <Trash2 className="w-3.5 h-3.5" />
                           </Button>
                         )}
                       </div>
                     </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Create Trip Dialog */}
      <Dialog open={dialogOpen} onOpenChange={(open) => {
        setDialogOpen(open);
        if (!open) { setSelectedDriver(''); setSelectedOrderIds([]); }
      }}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>إنشاء رحلة جديدة</DialogTitle>
            <DialogDescription>اختر المندوب والطلبات الجاهزة للتسليم</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label>المندوب</Label>
              <Select value={selectedDriver} onValueChange={setSelectedDriver}>
                <SelectTrigger className="bg-background/50">
                  <SelectValue placeholder="اختر المندوب" />
                </SelectTrigger>
                <SelectContent>
                  {drivers.map(d => (
                    <SelectItem key={d.id} value={d.id.toString()}>
                      {d.fullName}{driverTag(d.id)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>الطلبات الجاهزة</Label>
                <span className="text-xs text-muted-foreground">
                  {selectedOrderIds.length > 0 ? `${selectedOrderIds.length} طلب محدد` : 'اختر الطلبات'}
                </span>
              </div>

              {availableOrders.length === 0 ? (
                <div className="border border-border/50 rounded-lg p-6 text-center text-muted-foreground text-sm bg-muted/10">
                  <Package className="w-8 h-8 mx-auto mb-2 opacity-40" />
                  لا توجد طلبات جاهزة للتسليم حالياً
                </div>
              ) : (
                <ScrollArea className="h-56 border border-border/50 rounded-lg bg-muted/10">
                  <div className="p-2 space-y-1">
                    {availableOrders.map((order) => {
                      const selected = selectedOrderIds.includes(order.id);
                      return (
                        <button
                          key={order.id}
                          type="button"
                          onClick={() => toggleOrder(order.id)}
                          className={`w-full text-right flex items-center gap-3 p-3 rounded-md text-sm transition-colors ${selected ? 'bg-primary/10 border border-primary/30' : 'hover:bg-muted/30 border border-transparent'}`}
                        >
                          <div className={`shrink-0 ${selected ? 'text-primary' : 'text-muted-foreground'}`}>
                            {selected ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-bold text-primary text-xs">{order.orderNumber}</span>
                              <span className="font-medium truncate">{order.customerName}</span>
                            </div>
                            <div className="text-xs text-muted-foreground">{order.governorate} — {order.area} · {order.totalToCollect} ج.م</div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </ScrollArea>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
            <Button
              onClick={handleCreate}
              disabled={createTrip.isPending || !selectedDriver || selectedOrderIds.length === 0}
              className="bg-primary hover:bg-primary/90"
            >
              {createTrip.isPending ? 'جاري الإنشاء...' : `إنشاء الرحلة (${selectedOrderIds.length} طلب)`}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
