import React, { useEffect, useMemo, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Check, Minus, ShieldCheck, Table2, UserCog, ScrollText, Lock, RotateCcw, Loader2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { apiFetch } from '@/lib/extra-api';
import { AUDIT_LABELS } from '@/lib/support';

interface Catalog {
  groups: { key: string; label: string; permissions: { key: string; label: string; locked: boolean }[] }[];
  roles: { key: string; label: string; canHaveGrants: boolean; defaults: string[] }[];
}
interface Staff {
  id: number; fullName: string; role: string; roleLabel: string; isActive: boolean; branchName: string | null;
  grants: string[]; revokes: string[]; effective: string[];
}
interface AuditRow { id: number; actorName: string; actorRole: string; action: string; targetType: string | null; targetId: string | null; details: string | null; createdAt: string }

type Tab = 'matrix' | 'employees' | 'audit';

// ---------------------------------------------------------------------------
function Matrix({ catalog }: { catalog: Catalog }) {
  return (
    <div className="rounded-xl border border-border/40 overflow-x-auto bg-card/40">
      <table className="w-full text-sm border-separate border-spacing-0">
        <thead className="bg-muted/50 sticky top-0">
          <tr>
            <th className="text-right px-3 py-2 min-w-[18rem]">الصلاحية</th>
            {catalog.roles.map((r) => <th key={r.key} className="px-2 py-2 text-xs whitespace-nowrap">{r.label}</th>)}
          </tr>
        </thead>
        <tbody>
          {catalog.groups.map((g) => (
            <React.Fragment key={g.key}>
              <tr><td colSpan={catalog.roles.length + 1} className="bg-muted/20 px-3 py-1.5 text-xs font-bold text-primary">{g.label}</td></tr>
              {g.permissions.map((p) => (
                <tr key={p.key} className="border-t border-border/20 hover:bg-muted/10">
                  <td className="px-3 py-2">{p.label}{p.locked && <Lock className="w-3 h-3 inline mr-1.5 text-muted-foreground" />}</td>
                  {catalog.roles.map((r) => (
                    <td key={r.key} className="text-center">
                      {r.defaults.includes(p.key) ? <Check className="w-4 h-4 text-emerald-500 mx-auto" /> : <Minus className="w-4 h-4 text-muted-foreground/30 mx-auto" />}
                    </td>
                  ))}
                </tr>
              ))}
            </React.Fragment>
          ))}
        </tbody>
      </table>
      <p className="text-xs text-muted-foreground p-3 border-t border-border/20">دي الصلاحيات الافتراضية لكل دور. من تبويب «تخصيص الموظفين» تقدر تمنح أو تسحب صلاحية لموظف بعينه. نطاق البيانات (فرعه فقط أم كل الفروع) يتحدد بدوره ولا يتغير بالصلاحيات.</p>
    </div>
  );
}

// ---------------------------------------------------------------------------
function Employees({ catalog }: { catalog: Catalog }) {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { data: staff = [], isLoading } = useQuery({ queryKey: ['perm-staff'], queryFn: () => apiFetch<Staff[]>('/permissions/users') });
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [search, setSearch] = useState('');
  const [grants, setGrants] = useState<Set<string>>(new Set());
  const [revokes, setRevokes] = useState<Set<string>>(new Set());
  const [saving, setSaving] = useState(false);

  const selected = staff.find((s) => s.id === selectedId) ?? null;
  const defaults = useMemo(() => new Set(catalog.roles.find((r) => r.key === selected?.role)?.defaults ?? []), [catalog, selected?.role]);

  useEffect(() => { if (selected) { setGrants(new Set(selected.grants)); setRevokes(new Set(selected.revokes)); } }, [selected?.id, selected?.grants.join(','), selected?.revokes.join(',')]);

  const effective = (key: string) => (defaults.has(key) ? !revokes.has(key) : grants.has(key));
  const toggle = (key: string) => {
    const next = !effective(key);
    const g = new Set(grants); const r = new Set(revokes);
    g.delete(key); r.delete(key);
    if (next && !defaults.has(key)) g.add(key);
    if (!next && defaults.has(key)) r.add(key);
    setGrants(g); setRevokes(r);
  };
  const dirty = !!selected && (grants.size !== selected.grants.length || revokes.size !== selected.revokes.length
    || [...grants].some((g) => !selected.grants.includes(g)) || [...revokes].some((r) => !selected.revokes.includes(r)));

  const save = async () => {
    if (!selected) return;
    setSaving(true);
    try {
      await apiFetch(`/permissions/users/${selected.id}`, { method: 'PUT', body: JSON.stringify({ grants: [...grants], revokes: [...revokes] }) });
      toast({ title: 'تم حفظ الصلاحيات', description: 'تسري فوراً على الطلب القادم للموظف' });
      qc.invalidateQueries({ queryKey: ['perm-staff'] });
    } catch (e: any) { toast({ variant: 'destructive', title: 'تعذر الحفظ', description: e.message }); }
    finally { setSaving(false); }
  };

  const list = staff.filter((s) => !search.trim() || s.fullName.includes(search.trim()));

  return (
    <div className="grid lg:grid-cols-3 gap-4">
      <div className="space-y-2">
        <Input placeholder="بحث باسم الموظف" value={search} onChange={(e) => setSearch(e.target.value)} />
        {isLoading ? <div className="h-24 rounded-xl bg-muted/20 animate-pulse" /> : list.length === 0 ? <p className="text-sm text-muted-foreground py-6 text-center">لا يوجد موظفون</p> : list.map((s) => (
          <button key={s.id} type="button" onClick={() => setSelectedId(s.id)}
            className={`w-full text-right rounded-xl border p-3 transition-colors ${s.id === selectedId ? 'border-primary bg-primary/10' : 'border-border/50 bg-card/60 hover:bg-card'}`}>
            <div className="flex items-center justify-between gap-2"><b className="truncate">{s.fullName}</b>{!s.isActive && <Badge variant="outline" className="text-[10px]">معطّل</Badge>}</div>
            <div className="text-xs text-muted-foreground flex items-center gap-2 mt-0.5">
              <span>{s.roleLabel}{s.branchName ? ` — ${s.branchName}` : ''}</span>
              {(s.grants.length > 0 || s.revokes.length > 0) && <span className="text-amber-500">مخصّص ({s.grants.length}+ / {s.revokes.length}−)</span>}
            </div>
          </button>
        ))}
      </div>

      <div className="lg:col-span-2">
        {!selected ? (
          <div className="text-center text-muted-foreground py-16 border border-dashed border-border/50 rounded-xl">اختر موظفاً لتخصيص صلاحياته</div>
        ) : (
          <Card className="border-border/40 bg-card/60"><CardContent className="p-4 space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex-1 min-w-[10rem]"><p className="font-bold text-lg">{selected.fullName}</p><p className="text-xs text-muted-foreground">{selected.roleLabel} — الصلاحيات الافتراضية للدور تظهر بعلامة «افتراضي»</p></div>
              <Button size="sm" variant="ghost" disabled={grants.size === 0 && revokes.size === 0} onClick={() => { setGrants(new Set()); setRevokes(new Set()); }}><RotateCcw className="w-3.5 h-3.5 ml-1" /> رجوع للافتراضي</Button>
              <Button size="sm" disabled={!dirty || saving} onClick={save}>{saving ? <Loader2 className="w-4 h-4 animate-spin ml-1" /> : null} حفظ التغييرات</Button>
            </div>
            {catalog.groups.map((g) => (
              <div key={g.key} className="space-y-1">
                <p className="text-xs font-bold text-primary">{g.label}</p>
                {g.permissions.map((p) => {
                  const on = effective(p.key);
                  const isDefault = defaults.has(p.key);
                  const custom = on !== isDefault;
                  return (
                    <label key={p.key} className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm ${p.locked ? 'opacity-50' : 'cursor-pointer hover:bg-muted/20'} ${custom ? 'bg-amber-500/5' : ''}`}>
                      <input type="checkbox" checked={on} disabled={p.locked} onChange={() => toggle(p.key)} />
                      <span className="flex-1">{p.label}</span>
                      {isDefault && !custom && <span className="text-[10px] text-muted-foreground">افتراضي</span>}
                      {custom && <Badge variant="outline" className={`text-[10px] ${on ? 'text-emerald-500 border-emerald-500/30' : 'text-destructive border-destructive/30'}`}>{on ? 'مُنحت' : 'مسحوبة'}</Badge>}
                      {p.locked && <Lock className="w-3.5 h-3.5" />}
                    </label>
                  );
                })}
              </div>
            ))}
          </CardContent></Card>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
function Audit() {
  const [action, setAction] = useState('');
  const [limit, setLimit] = useState(50);
  const { data: rows = [], isLoading } = useQuery({
    queryKey: ['audit', action, limit],
    queryFn: () => apiFetch<AuditRow[]>(`/audit?limit=${limit}${action ? `&action=${action}` : ''}`),
    refetchInterval: 30_000,
  });
  const groups = [['', 'كل العمليات'], ['finance', 'المالية'], ['order', 'الطلبات'], ['trip', 'الرحلات'], ['user', 'المستخدمون'], ['permissions', 'الصلاحيات'], ['branch', 'الفروع'], ['system', 'النظام']];
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-1.5">
        {groups.map(([k, label]) => (
          <button key={k} type="button" onClick={() => { setAction(k); setLimit(50); }}
            className={`text-xs rounded-full px-3 py-1 border ${action === k ? 'bg-primary text-primary-foreground border-primary' : 'border-border/50 text-muted-foreground hover:text-foreground'}`}>{label}</button>
        ))}
      </div>
      <div className="rounded-xl border border-border/40 overflow-x-auto bg-card/40">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs"><tr>
            <th className="text-right px-3 py-2">الوقت</th><th className="text-right px-3 py-2">المنفِّذ</th><th className="text-right px-3 py-2">العملية</th><th className="text-right px-3 py-2">التفاصيل</th>
          </tr></thead>
          <tbody>
            {isLoading ? <tr><td colSpan={4} className="text-center py-8">جاري التحميل...</td></tr>
              : rows.length === 0 ? <tr><td colSpan={4} className="text-center py-8 text-muted-foreground">لا توجد عمليات مسجّلة</td></tr>
              : rows.map((r) => (
                <tr key={r.id} className="border-t border-border/20 align-top">
                  <td className="px-3 py-2 text-xs text-muted-foreground whitespace-nowrap">{new Date(r.createdAt).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short', timeZone: 'Africa/Cairo' })}</td>
                  <td className="px-3 py-2 whitespace-nowrap">{r.actorName} <span className="text-[10px] text-muted-foreground">({r.actorRole})</span></td>
                  <td className="px-3 py-2 font-medium whitespace-nowrap">{AUDIT_LABELS[r.action] ?? r.action}{r.targetType ? <span className="text-xs text-muted-foreground"> #{r.targetId}</span> : null}</td>
                  <td className="px-3 py-2 text-xs text-muted-foreground">{r.details}</td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
      {rows.length >= limit && <Button variant="outline" size="sm" onClick={() => setLimit((l) => l + 50)}>عرض المزيد</Button>}
    </div>
  );
}

// ---------------------------------------------------------------------------
export default function Permissions() {
  const [tab, setTab] = useState<Tab>('matrix');
  const { data: catalog, isLoading } = useQuery({ queryKey: ['perm-catalog'], queryFn: () => apiFetch<Catalog>('/permissions/catalog'), staleTime: 5 * 60_000 });
  const tabs = [
    { key: 'matrix' as const, label: 'مصفوفة الأدوار', Icon: Table2 },
    { key: 'employees' as const, label: 'تخصيص الموظفين', Icon: UserCog },
    { key: 'audit' as const, label: 'سجل العمليات الحساسة', Icon: ScrollText },
  ];
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2"><ShieldCheck className="w-7 h-7 text-primary" /> الصلاحيات والمراجعة</h1>
        <p className="text-muted-foreground">مين يقدر يعمل إيه، وإعطاء أو سحب صلاحية لموظف بعينه، وسجل كامل بالعمليات الحساسة</p>
      </div>
      <div className="inline-flex rounded-xl border border-border/50 bg-card/50 p-1 gap-1 flex-wrap">
        {tabs.map(({ key, label, Icon }) => (
          <button key={key} type="button" onClick={() => setTab(key)}
            className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-colors ${tab === key ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
            <Icon className="w-4 h-4" /> {label}
          </button>
        ))}
      </div>
      {tab === 'audit' ? <Audit /> : isLoading || !catalog ? <div className="h-40 rounded-xl bg-muted/20 animate-pulse" /> : tab === 'matrix' ? <Matrix catalog={catalog} /> : <Employees catalog={catalog} />}
    </div>
  );
}
