import React, { useState } from 'react';
import { useGetOrders, useUpdateOrder, useGetEmergencyOtp, useAdvanceOrderStatus, useDeleteOrder, useGetUsers, getGetOrdersQueryKey, getGetOrderQueryKey, getGetUsersQueryKey } from '@workspace/api-client-react';
import { useQueryClient, keepPreviousData, useMutation } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Search, Filter, ChevronLeft, ChevronRight, Package, User, Calendar, CreditCard, Plus, AlertTriangle, Edit, Printer, ArrowLeftCircle, Truck, Trash2, Download } from 'lucide-react';
import { format } from 'date-fns';
import { arEG } from 'date-fns/locale';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import QRCode from 'qrcode';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Link } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { downloadFile } from '@/lib/extra-api';

const STATUS_COLORS: Record<string, string> = {
  delivered: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
  pending: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
  in_transit: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
  returned: 'bg-destructive/10 text-destructive border-destructive/20',
  final_return: 'bg-red-900/20 text-red-500 border-red-900/30',
  partial_delivery: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
  ready: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
};

const STATUS_LABELS: Record<string, string> = {
  delivered: 'مكتمل',
  pending: 'قيد الانتظار',
  in_transit: 'في الطريق',
  returned: 'مرتجع',
  final_return: 'مرتجع نهائي',
  partial_delivery: 'تسليم جزئي',
  ready: 'جاهز',
};

const ALL_STATUSES = ['pending', 'ready', 'in_transit', 'delivered', 'partial_delivery', 'returned', 'final_return'];

// Mirrors the backend's linear happy-path flow used by the quick-advance action.
// Branch statuses (returned/final_return/partial_delivery) are only reachable via
// the dedicated delivery/return actions, not this shortcut.
const STATUS_FLOW = ['pending', 'ready', 'in_transit', 'delivered'];

function useEmergencyOtpFetch() {
  return useMutation({
    mutationFn: async (orderId: number) => {
      const token = localStorage.getItem('al-ghazali-token');
      const res = await fetch(`/api/orders/${orderId}/emergency-otp`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'غير مصرح' }));
        throw new Error(err.error || 'خطأ');
      }
      return res.json() as Promise<{ otp: string; orderId: number; generatedBy: string; generatedAt: string }>;
    },
  });
}

export default function Orders() {
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [emergencyOtp, setEmergencyOtp] = useState<{ otp: string; generatedBy: string } | null>(null);
  const [statusChangeOpen, setStatusChangeOpen] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [reassignDriverId, setReassignDriverId] = useState<string>('');
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);

  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const updateOrder = useUpdateOrder();
  const fetchEmergencyOtp = useEmergencyOtpFetch();
  const advanceStatus = useAdvanceOrderStatus();
  const deleteOrder = useDeleteOrder();

  const canUseEmergencyOtp = user?.role === 'super_admin' || user?.role === 'branch_manager';
  const canChangeStatus = user?.role === 'super_admin' || user?.role === 'branch_manager' || user?.role === 'operations';
  const canQuickAdvanceStatus = user?.role === 'super_admin';
  const canReassignDriver = user?.role === 'super_admin' || user?.role === 'branch_manager' || user?.role === 'operations';
  const canDeleteOrder = user?.role === 'super_admin';
  const showFinancials = user?.role !== 'cs';

  const driversParams = { role: 'driver' };
  const { data: driversData } = useGetUsers(
    driversParams,
    { query: { queryKey: getGetUsersQueryKey(driversParams), enabled: canReassignDriver && !!selectedOrder } },
  );
  const drivers = driversData || [];

  React.useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(searchQuery), 500);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const warehouseScoped = user?.role === 'super_admin' || user?.role === 'branch_manager' || user?.role === 'operations';
  const params = {
    page,
    limit: 10,
    ...(warehouseScoped ? { inventoryStatus: 'in_warehouse' as const } : {}),
    ...(statusFilter !== 'all' ? { status: statusFilter } : {}),
    ...(debouncedSearch ? { search: debouncedSearch } : {}),
  };

  const { data, isLoading } = useGetOrders(params, {
    query: {
      queryKey: getGetOrdersQueryKey(params),
      placeholderData: keepPreviousData,
    },
  });

  const orders = data?.orders || [];

  const handleEmergencyOtp = async () => {
    if (!selectedOrder) return;
    const requestedOrderId = selectedOrder.id;
    try {
      const result = await fetchEmergencyOtp.mutateAsync(requestedOrderId);
      // Guard against a race: if the user switched to a different order while
      // this request was in flight, do NOT show this OTP — it belongs to the
      // order that was open when the request was sent, not the current one.
      setSelectedOrder((current: any) => {
        if (current?.id === requestedOrderId) {
          setEmergencyOtp(result);
        }
        return current;
      });
      // Refresh order to see the audit log event
      queryClient.invalidateQueries({ queryKey: getGetOrdersQueryKey(params) });
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'خطأ', description: e.message });
    }
  };

  const handleStatusChange = async () => {
    if (!selectedOrder || !newStatus) return;
    try {
      await updateOrder.mutateAsync({ id: selectedOrder.id, data: { status: newStatus } });
      queryClient.invalidateQueries({ queryKey: getGetOrdersQueryKey(params) });
      toast({ title: 'تم تحديث حالة الطلب', description: `الحالة الجديدة: ${STATUS_LABELS[newStatus]}` });
      setStatusChangeOpen(false);
      setSelectedOrder(null);
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'خطأ', description: e.message });
    }
  };

  const handleAdvanceStatus = async (order: any, e?: React.MouseEvent) => {
    e?.stopPropagation();
    try {
      await advanceStatus.mutateAsync({ id: order.id });
      queryClient.invalidateQueries({ queryKey: getGetOrdersQueryKey(params) });
      const nextStatus = STATUS_FLOW[STATUS_FLOW.indexOf(order.status) + 1];
      toast({ title: 'تم تقديم حالة الطلب', description: `الحالة الجديدة: ${STATUS_LABELS[nextStatus] || nextStatus}` });
    } catch (err: any) {
      toast({ variant: 'destructive', title: 'تعذر تحديث الحالة', description: err.message });
    }
  };

  const handleReassignDriver = async () => {
    if (!selectedOrder || !reassignDriverId) return;
    try {
      await updateOrder.mutateAsync({ id: selectedOrder.id, data: { driverId: parseInt(reassignDriverId) } });
      queryClient.invalidateQueries({ queryKey: getGetOrdersQueryKey(params) });
      const driver = drivers.find((d: any) => d.id === parseInt(reassignDriverId));
      toast({ title: 'تم نقل الطلب', description: `تم إسناد الطلب إلى ${driver?.fullName || 'الطيار المحدد'}` });
      setReassignDriverId('');
      setSelectedOrder(null);
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'خطأ', description: e.message });
    }
  };

  const handleDeleteOrder = async () => {
    if (!selectedOrder) return;
    try {
      await deleteOrder.mutateAsync({ id: selectedOrder.id });
      queryClient.invalidateQueries({ queryKey: getGetOrdersQueryKey(params) });
      toast({ title: 'تم حذف الطلب', description: `تم حذف الطلب ${selectedOrder.orderNumber} نهائياً` });
      setDeleteConfirmOpen(false);
      setSelectedOrder(null);
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر حذف الطلب', description: e.message });
    }
  };

  const handlePrintWaybill = async (order: any) => {
    const trackingUrl = `${window.location.origin}${import.meta.env.BASE_URL}track?order=${order.orderNumber}`;
    const qrDataUrl = await QRCode.toDataURL(trackingUrl, {
      width: 260,
      margin: 1,
      color: { dark: '#111111', light: '#ffffff' },
    });

    const printWindow = window.open('', '_blank', 'width=440,height=680');
    if (!printWindow) return;
    printWindow.document.write(`
      <!DOCTYPE html>
      <html dir="rtl" lang="ar">
      <head>
        <meta charset="utf-8" />
        <title>بوليصة شحن — ${order.orderNumber}</title>
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body {
            font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
            padding: 0;
            font-size: 12px;
            color: #1a1a1a;
            background: #f3f4f6;
          }
          .waybill {
            max-width: 380px;
            margin: 16px auto;
            background: #fff;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 4px 16px rgba(0,0,0,0.08);
            border: 1px solid #e5e7eb;
          }
          .header {
            background: linear-gradient(135deg, #1c1c1e 0%, #2d2a24 100%);
            color: #fff;
            text-align: center;
            padding: 16px 14px 14px;
            position: relative;
          }
          .header::after {
            content: '';
            position: absolute;
            bottom: -1px; left: 0; right: 0;
            height: 4px;
            background: linear-gradient(90deg, transparent, #f59e0b, transparent);
          }
          .logo { font-size: 16px; font-weight: 800; letter-spacing: 0.5px; }
          .logo-sub { font-size: 9px; color: #d1a355; letter-spacing: 2px; margin-top: 2px; text-transform: uppercase; }
          .qr-section {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 14px;
            background: #fffbeb;
            border-bottom: 2px dashed #e5c98a;
          }
          .qr-section img { width: 78px; height: 78px; border-radius: 8px; background: #fff; padding: 4px; box-shadow: 0 1px 4px rgba(0,0,0,0.1); }
          .order-num-block { text-align: right; flex: 1; }
          .order-num-label { font-size: 9px; color: #92702a; font-weight: 600; letter-spacing: 1px; margin-bottom: 2px; }
          .order-num { font-size: 21px; font-weight: 800; color: #b45309; font-family: 'Courier New', monospace; letter-spacing: 1px; }
          .body-content { padding: 14px; }
          .row { display: flex; justify-content: space-between; align-items: flex-start; padding: 7px 0; border-bottom: 1px solid #f1f1f1; gap: 10px; }
          .row:last-child { border-bottom: none; }
          .label { color: #8a8a8e; font-weight: 600; white-space: nowrap; font-size: 10.5px; }
          .value { font-weight: 700; text-align: left; direction: ltr; unicode-bidi: plaintext; font-size: 11.5px; }
          .amount {
            font-size: 19px;
            font-weight: 800;
            text-align: center;
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: #fff;
            padding: 10px;
            border-radius: 10px;
            margin: 12px 14px 0;
            box-shadow: 0 3px 10px rgba(217,119,6,0.3);
          }
          .amount .sub { display: block; font-size: 9px; font-weight: 500; opacity: 0.85; margin-top: 2px; }
          .footer {
            text-align: center;
            color: #a0a0a5;
            font-size: 8.5px;
            padding: 12px 14px 16px;
            border-top: 1px solid #f1f1f1;
            margin-top: 10px;
          }
          .footer .brand { color: #b45309; font-weight: 700; }
          @media print {
            body { background: #fff; }
            .waybill { box-shadow: none; margin: 0 auto; border: none; }
          }
        </style>
      </head>
      <body>
        <div class="waybill">
          <div class="header">
            <div class="logo">🦌 الغزالي للشحن</div>
            <div class="logo-sub">Al-Ghazali Shipping</div>
          </div>
          <div class="qr-section">
            <div class="order-num-block">
              <div class="order-num-label">رقم التتبع</div>
              <div class="order-num">${order.orderNumber}</div>
            </div>
            <img src="${qrDataUrl}" alt="QR" />
          </div>
          <div class="body-content">
            <div class="row"><span class="label">التاجر</span><span class="value">${order.merchantName || '—'}</span></div>
            <div class="row"><span class="label">العميل</span><span class="value">${order.customerName}</span></div>
            <div class="row"><span class="label">الهاتف</span><span class="value" dir="ltr">${order.customerPhone}</span></div>
            <div class="row"><span class="label">العنوان</span><span class="value">${order.governorate}، ${order.area}</span></div>
            <div class="row"><span class="label">التفصيلي</span><span class="value">${order.customerAddress || '—'}</span></div>
            ${order.notes ? `<div class="row"><span class="label">ملاحظة</span><span class="value">${order.notes}</span></div>` : ''}
          </div>
          <div class="amount">
            💰 ${order.totalToCollect} ج.م
            <span class="sub">المطلوب تحصيله عند التسليم</span>
          </div>
          <div class="footer">
            امسح رمز الـ QR لتتبع الشحنة مباشرة<br/>
            <span class="brand">الغزالي للشحن</span> — سريع. موثوق. الغزالي. &nbsp;|&nbsp; ${new Date().toLocaleDateString('ar-EG')}
          </div>
        </div>
        <script>window.onload = () => { window.print(); }</script>
      </body>
      </html>
    `);
    printWindow.document.close();
  };

  const [exporting, setExporting] = useState(false);
  const handleExport = async () => {
    setExporting(true);
    try {
      const params = new URLSearchParams();
      if (statusFilter !== 'all') params.set('status', statusFilter);
      if (debouncedSearch) params.set('search', debouncedSearch);
      await downloadFile(`/orders/export?${params.toString()}`, 'orders.csv');
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر التصدير', description: e.message });
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">إدارة الطلبات</h1>
          <p className="text-muted-foreground text-sm">عرض وتتبع جميع الشحنات في النظام</p>
        </div>
        <div className="flex gap-2 w-full sm:w-auto">
          <Button variant="outline" onClick={handleExport} disabled={exporting} className="shrink-0 flex-1 sm:flex-none">
            <Download className="w-4 h-4 ml-2" /> {exporting ? 'جاري التصدير...' : 'تصدير Excel'}
          </Button>
        {(user?.role === 'super_admin' || user?.role === 'branch_manager' || user?.role === 'operations' || user?.role === 'merchant') && (
          <Link href="/orders/new">
            <Button className="bg-primary hover:bg-primary/90 shrink-0 w-full sm:w-auto">
              <Plus className="w-4 h-4 ml-2" /> إضافة طلب
            </Button>
          </Link>
        )}
        </div>
      </div>

      <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
        <CardHeader className="pb-3 pt-4 px-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="رقم التتبع، اسم العميل، أو رقم الهاتف..."
                value={searchQuery}
                onChange={(e) => { setSearchQuery(e.target.value); setPage(1); }}
                className="pl-4 pr-9 bg-background/50"
              />
            </div>
            <div className="flex items-center gap-2 min-w-0">
              <Filter className="w-4 h-4 text-muted-foreground shrink-0" />
              <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(1); }}>
                <SelectTrigger className="bg-background/50 w-full sm:w-44">
                  <SelectValue placeholder="الحالة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">الكل</SelectItem>
                  {Object.entries(STATUS_LABELS).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-muted/30">
                <TableRow>
                  <TableHead className="text-right">رقم التتبع</TableHead>
                  <TableHead className="text-right">العميل</TableHead>
                  <TableHead className="text-right hidden md:table-cell">المنطقة</TableHead>
                  <TableHead className="text-right hidden lg:table-cell">التاجر</TableHead>
                  {showFinancials && <TableHead className="text-right">المبلغ</TableHead>}
                  <TableHead className="text-right">الحالة</TableHead>
                  <TableHead className="text-right hidden sm:table-cell">التاريخ</TableHead>
                  {canQuickAdvanceStatus && <TableHead className="text-right">إجراء سريع</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  [...Array(5)].map((_, i) => (
                    <TableRow key={i}>
                      {[...Array((showFinancials ? 7 : 6) + (canQuickAdvanceStatus ? 1 : 0))].map((_, j) => (
                        <TableCell key={j}><div className="h-4 bg-muted animate-pulse rounded" /></TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : orders.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={(showFinancials ? 7 : 6) + (canQuickAdvanceStatus ? 1 : 0)} className="text-center py-12 text-muted-foreground">
                      لا توجد طلبات تطابق معايير البحث
                    </TableCell>
                  </TableRow>
                ) : orders.map((order) => (
                  <TableRow
                    key={order.id}
                    className="cursor-pointer hover:bg-muted/30 transition-colors"
                    onClick={() => { setSelectedOrder(order); setEmergencyOtp(null); }}
                  >
                    <TableCell className="font-mono font-bold text-primary text-sm">{order.orderNumber}</TableCell>
                    <TableCell>
                      <div className="font-medium text-sm">{order.customerName}</div>
                      <div className="text-xs text-muted-foreground" dir="ltr">{order.customerPhone}</div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell text-sm">{order.governorate} - {order.area}</TableCell>
                    <TableCell className="hidden lg:table-cell text-sm">{order.merchantName}</TableCell>
                    {showFinancials && (
                      <TableCell className="font-medium text-sm whitespace-nowrap">{order.totalToCollect} ج.م</TableCell>
                    )}
                    <TableCell>
                      <Badge variant="outline" className={`${STATUS_COLORS[order.status] || 'bg-muted text-muted-foreground'} px-2 py-0.5 text-xs whitespace-nowrap`}>
                        {STATUS_LABELS[order.status] || order.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="hidden sm:table-cell text-sm text-muted-foreground" dir="ltr">
                      {format(new Date(order.createdAt), 'dd MMM', { locale: arEG })}
                    </TableCell>
                    {canQuickAdvanceStatus && (
                      <TableCell>
                        {STATUS_FLOW.includes(order.status) && STATUS_FLOW.indexOf(order.status) < STATUS_FLOW.length - 1 ? (
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 px-2 text-xs border-blue-500/30 text-blue-400 hover:bg-blue-500/10 whitespace-nowrap"
                            onClick={(e) => handleAdvanceStatus(order, e)}
                            disabled={advanceStatus.isPending}
                          >
                            <ArrowLeftCircle className="w-3.5 h-3.5 ml-1" />
                            {STATUS_LABELS[STATUS_FLOW[STATUS_FLOW.indexOf(order.status) + 1]]}
                          </Button>
                        ) : (
                          <span className="text-xs text-muted-foreground">—</span>
                        )}
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {data && data.total > 0 && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-border/30">
              <div className="text-xs text-muted-foreground">إجمالي {data.total} طلب</div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="h-8 px-2.5 bg-background/50">
                  <ChevronRight className="w-4 h-4" />
                </Button>
                <span className="text-xs font-medium px-1">{page} / {Math.ceil(data.total / data.limit)}</span>
                <Button variant="outline" size="sm" onClick={() => setPage(p => p + 1)} disabled={page >= Math.ceil(data.total / data.limit)} className="h-8 px-2.5 bg-background/50">
                  <ChevronLeft className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Order Detail Sheet */}
      <Sheet open={!!selectedOrder} onOpenChange={(open) => { if (!open) { setSelectedOrder(null); setEmergencyOtp(null); } }}>
        <SheetContent side="left" className="w-full sm:max-w-md border-r border-border/50 bg-card/95 backdrop-blur-xl p-0 flex flex-col">
          <SheetHeader className="p-5 border-b border-border/50 bg-muted/20">
            <div className="flex items-center justify-between mb-2">
              <Badge variant="outline" className={`${selectedOrder ? STATUS_COLORS[selectedOrder.status] : ''} px-3 py-1 font-bold`}>
                {selectedOrder && (STATUS_LABELS[selectedOrder.status] || selectedOrder.status)}
              </Badge>
              <div className="font-mono text-lg font-bold text-primary">{selectedOrder?.orderNumber}</div>
            </div>
            <SheetTitle>تفاصيل الطلب</SheetTitle>
          </SheetHeader>

          <ScrollArea className="flex-1">
            {selectedOrder && (
              <div className="p-5 space-y-5">
                {/* Customer */}
                <div className="space-y-2">
                  <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                    <User className="w-3.5 h-3.5" /> بيانات العميل
                  </h3>
                  <div className="bg-muted/10 rounded-lg p-4 border border-border/40 space-y-2.5 text-sm">
                    <div className="flex justify-between"><span className="text-muted-foreground">الاسم</span><span className="font-medium">{selectedOrder.customerName}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">الهاتف</span><span dir="ltr">{selectedOrder.customerPhone}</span></div>
                    {selectedOrder.customerPhone2 && (
                      <div className="flex justify-between"><span className="text-muted-foreground">رقم بديل</span><span dir="ltr">{selectedOrder.customerPhone2}</span></div>
                    )}
                    <Separator className="opacity-50" />
                    <div className="flex justify-between gap-4">
                      <span className="text-muted-foreground whitespace-nowrap">العنوان</span>
                      <span className="text-left text-sm">{selectedOrder.governorate}، {selectedOrder.area}<br />{selectedOrder.customerAddress}</span>
                    </div>
                  </div>
                </div>

                {/* Financials — hidden for CS */}
                {showFinancials && (
                  <div className="space-y-2">
                    <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                      <CreditCard className="w-3.5 h-3.5" /> المالية
                    </h3>
                    <div className="bg-muted/10 rounded-lg p-4 border border-border/40 space-y-2.5 text-sm">
                      <div className="flex justify-between"><span className="text-muted-foreground">التاجر</span><span className="font-medium">{selectedOrder.merchantName}</span></div>
                      <div className="flex justify-between"><span className="text-muted-foreground">قيمة الشحنة</span><span>{selectedOrder.packageValue} ج.م</span></div>
                      <div className="flex justify-between"><span className="text-muted-foreground">رسوم الشحن</span><span>{selectedOrder.shippingFee} ج.م</span></div>
                      <Separator className="opacity-50" />
                      <div className="flex justify-between"><span className="font-bold text-primary">المطلوب</span><span className="font-bold text-primary text-base">{selectedOrder.totalToCollect} ج.م</span></div>
                      {selectedOrder.collectedAmount !== null && selectedOrder.collectedAmount !== undefined && (
                        <div className="flex justify-between"><span className="text-muted-foreground">المحصل فعلياً</span><span className="font-bold text-emerald-500">{selectedOrder.collectedAmount} ج.م</span></div>
                      )}
                    </div>
                  </div>
                )}

                {/* Driver */}
                {selectedOrder.driverName && !canReassignDriver && (
                  <div className="flex justify-between items-center text-sm bg-muted/10 rounded-lg p-3 border border-border/40">
                    <span className="text-muted-foreground">المندوب المسند</span>
                    <span className="font-bold">{selectedOrder.driverName}</span>
                  </div>
                )}

                {/* Driver reassignment */}
                {canReassignDriver && (
                  <div className="space-y-2">
                    <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                      <Truck className="w-3.5 h-3.5" /> المندوب المسند
                    </h3>
                    <div className="bg-muted/10 rounded-lg p-3 border border-border/40 space-y-2">
                      <div className="text-sm font-bold">{selectedOrder.driverName || 'لم يتم إسناد طيار بعد'}</div>
                      <div className="flex gap-2">
                        <Select value={reassignDriverId} onValueChange={setReassignDriverId}>
                          <SelectTrigger className="bg-background/50 flex-1">
                            <SelectValue placeholder="نقل إلى طيار آخر..." />
                          </SelectTrigger>
                          <SelectContent>
                            {drivers
                              .filter((d: any) => d.id !== selectedOrder.driverId)
                              .map((d: any) => (
                                <SelectItem key={d.id} value={String(d.id)}>{d.fullName}</SelectItem>
                              ))}
                          </SelectContent>
                        </Select>
                        <Button
                          size="sm"
                          className="bg-primary hover:bg-primary/90 shrink-0"
                          onClick={handleReassignDriver}
                          disabled={!reassignDriverId || updateOrder.isPending}
                        >
                          نقل
                        </Button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Timeline */}
                {selectedOrder.timeline?.length > 0 && (
                  <div className="space-y-2">
                    <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5" /> سجل التتبع
                    </h3>
                    <div className="space-y-2 relative before:absolute before:right-4 before:top-0 before:h-full before:w-0.5 before:bg-border/50 pr-10">
                      {selectedOrder.timeline.map((event: any, i: number) => (
                        <div key={event.id} className="relative">
                          <div className={`absolute -right-6 top-2 w-4 h-4 rounded-full border-2 border-card flex items-center justify-center ${event.isEmergencyOtp ? 'bg-destructive' : i === 0 ? 'bg-primary' : 'bg-muted'}`}>
                            <div className="w-1.5 h-1.5 rounded-full bg-current" />
                          </div>
                          <div className={`rounded-lg p-3 border ${event.isEmergencyOtp ? 'bg-destructive/10 border-destructive/30' : 'bg-muted/10 border-border/30'}`}>
                            <div className="flex justify-between items-center mb-1">
                              <span className="font-bold text-xs">{STATUS_LABELS[event.status] || event.status}</span>
                              <span className="text-[10px] text-muted-foreground" dir="ltr">{format(new Date(event.timestamp), 'dd/MM HH:mm')}</span>
                            </div>
                            <p className="text-xs text-muted-foreground">{event.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Emergency OTP result */}
                {emergencyOtp && (
                  <div className="bg-destructive/10 border border-destructive/40 rounded-lg p-4 space-y-2">
                    <div className="flex items-center gap-2 text-destructive font-bold text-sm">
                      <AlertTriangle className="w-4 h-4" /> كود الطوارئ — سري
                    </div>
                    <div className="text-center text-4xl font-mono font-black text-destructive tracking-widest py-2">
                      {emergencyOtp.otp}
                    </div>
                    <p className="text-xs text-muted-foreground text-center">
                      بواسطة: {emergencyOtp.generatedBy} — تم تسجيل هذا الإجراء في سجل المراجعة
                    </p>
                  </div>
                )}

                {selectedOrder.notes && (
                  <div className="bg-amber-500/10 text-amber-500/90 border border-amber-500/20 rounded-lg p-3 text-sm">
                    <span className="font-bold block mb-1">ملاحظات:</span>
                    {selectedOrder.notes}
                  </div>
                )}
              </div>
            )}
          </ScrollArea>

          {/* Action buttons */}
          <div className="p-4 border-t border-border/50 bg-card space-y-2">
            {/* Print waybill */}
            <Button
              variant="outline"
              className="w-full font-bold border-primary/30 hover:border-primary/60 hover:bg-primary/5"
              onClick={() => handlePrintWaybill(selectedOrder)}
            >
              <Printer className="w-4 h-4 ml-2" /> طباعة البوليصة
            </Button>

            {/* Status change — admin / branch_manager / operations */}
            {canChangeStatus && (
              <Button
                variant="outline"
                className="w-full border-blue-500/30 text-blue-400 hover:bg-blue-500/10"
                onClick={() => { setNewStatus(selectedOrder?.status || ''); setStatusChangeOpen(true); }}
              >
                <Edit className="w-4 h-4 ml-2" /> تعديل الحالة يدوياً
              </Button>
            )}

            {/* Emergency OTP — super_admin / branch_manager only */}
            {canUseEmergencyOtp && (
              <Button
                variant="outline"
                className="w-full border-destructive/40 text-destructive hover:bg-destructive/10 font-bold"
                onClick={handleEmergencyOtp}
                disabled={fetchEmergencyOtp.isPending}
              >
                <AlertTriangle className="w-4 h-4 ml-2" />
                {fetchEmergencyOtp.isPending ? 'جاري الاسترجاع...' : '🚨 إظهار كود الطوارئ (OTP Bypass)'}
              </Button>
            )}

            {/* Delete order — super_admin only, any order, any time */}
            {canDeleteOrder && (
              <Button
                variant="outline"
                className="w-full border-destructive/40 text-destructive hover:bg-destructive/10 font-bold"
                onClick={() => setDeleteConfirmOpen(true)}
              >
                <Trash2 className="w-4 h-4 ml-2" /> حذف الطلب نهائياً
              </Button>
            )}
          </div>
        </SheetContent>
      </Sheet>

      {/* Delete confirmation dialog */}
      <Dialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>حذف الطلب نهائياً</DialogTitle>
            <DialogDescription className="text-destructive text-xs">
              ⚠️ هذا الإجراء لا يمكن التراجع عنه — سيتم حذف الطلب {selectedOrder?.orderNumber} وكل سجل تتبعه نهائياً
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteConfirmOpen(false)}>إلغاء</Button>
            <Button
              variant="destructive"
              onClick={handleDeleteOrder}
              disabled={deleteOrder.isPending}
            >
              {deleteOrder.isPending ? 'جاري الحذف...' : 'تأكيد الحذف'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Manual status change dialog */}
      <Dialog open={statusChangeOpen} onOpenChange={setStatusChangeOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>تعديل حالة الطلب يدوياً</DialogTitle>
            <DialogDescription className="text-destructive text-xs">
              ⚠️ استخدم هذا الإجراء عند الضرورة القصوى فقط — سيُسجَّل في سجل التتبع
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <Select value={newStatus} onValueChange={setNewStatus}>
              <SelectTrigger className="bg-background/50">
                <SelectValue placeholder="اختر الحالة الجديدة" />
              </SelectTrigger>
              <SelectContent>
                {ALL_STATUSES.map(s => (
                  <SelectItem key={s} value={s}>{STATUS_LABELS[s]}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setStatusChangeOpen(false)}>إلغاء</Button>
            <Button
              className="bg-primary hover:bg-primary/90"
              onClick={handleStatusChange}
              disabled={updateOrder.isPending || !newStatus}
            >
              {updateOrder.isPending ? 'جاري الحفظ...' : 'تأكيد التعديل'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
