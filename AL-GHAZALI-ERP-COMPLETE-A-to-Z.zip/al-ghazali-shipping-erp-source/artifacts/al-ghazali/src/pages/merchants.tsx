import React, { useState } from 'react';
import { useGetUsers, useCreateUser, useToggleUserStatus, useDeleteUser, getGetUsersQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { ResetPasswordButton } from '@/components/ResetPasswordButton';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Store, Wallet, Plus, Package, Search, TrendingUp, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

const merchantSchema = z.object({
  username: z.string().min(3, 'اسم المستخدم 3 أحرف على الأقل'),
  password: z.string().min(8, 'كلمة المرور 8 أحرف على الأقل'),
  fullName: z.string().min(2, 'الاسم مطلوب'),
  phone: z.string().optional(),
  email: z.string().email('بريد إلكتروني غير صالح').optional().or(z.literal('')),
});

export default function Merchants() {
  const [search, setSearch] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteMerchant, setDeleteMerchant] = useState<any>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user: currentUser } = useAuth();
  const createUser = useCreateUser();
  const deleteUser = useDeleteUser();
  const canDelete = currentUser?.role === 'super_admin';

  const { data, isLoading } = useGetUsers({ role: 'merchant', ...(search ? { search } : {}) });
  const merchants = Array.isArray(data) ? data : [];

  const form = useForm<z.infer<typeof merchantSchema>>({
    resolver: zodResolver(merchantSchema),
    defaultValues: { username: '', password: '', fullName: '', phone: '', email: '' },
  });

  const onSubmit = async (values: z.infer<typeof merchantSchema>) => {
    try {
      await createUser.mutateAsync({ data: { ...values, role: 'merchant', email: values.email || undefined } });
      queryClient.invalidateQueries({ queryKey: getGetUsersQueryKey({ role: 'merchant' }) });
      toast({ title: 'تم إضافة التاجر بنجاح' });
      setDialogOpen(false);
      form.reset();
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'خطأ', description: e.message || 'حدث خطأ أثناء الإضافة' });
    }
  };

  const handleDelete = async () => {
    if (!deleteMerchant) return;
    try {
      await deleteUser.mutateAsync({ id: deleteMerchant.id });
      await queryClient.invalidateQueries({ queryKey: getGetUsersQueryKey({ role: 'merchant' }) });
      toast({ title: 'تم حذف التاجر', description: `تم حذف حساب ${deleteMerchant.fullName} نهائياً` });
      setDeleteMerchant(null);
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر حذف التاجر', description: e.message || 'حدث خطأ أثناء الحذف' });
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">التجار</h1>
          <p className="text-muted-foreground text-sm">إدارة العملاء والتجار المتعاقدين</p>
        </div>
        <Button className="bg-primary hover:bg-primary/90 shrink-0" onClick={() => setDialogOpen(true)}>
          <Plus className="w-4 h-4 ml-2" /> إضافة تاجر
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
        <Input placeholder="بحث بالاسم..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-4 pr-9 bg-card/60" />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading ? (
          [...Array(3)].map((_, i) => <Card key={i} className="h-44 animate-pulse bg-muted/20" />)
        ) : merchants.length === 0 ? (
          <div className="col-span-full text-center py-12 text-muted-foreground">لا يوجد تجار</div>
        ) : merchants.map((merchant) => (
          <Card key={merchant.id} className="border-border/40 bg-card/60 backdrop-blur-sm overflow-hidden transition-all hover:shadow-[0_4px_20px_rgba(245,158,11,0.08)]">
            <CardContent className="p-5">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-lg bg-primary/10 flex items-center justify-center text-primary shrink-0">
                    <Store className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold">{merchant.fullName}</h3>
                    <p className="text-xs text-muted-foreground" dir="ltr">{merchant.phone || '—'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <Badge variant={merchant.isActive ? 'default' : 'destructive'} className="text-xs shrink-0">
                    {merchant.isActive ? 'نشط' : 'موقوف'}
                  </Badge>
                  <ResetPasswordButton user={merchant} />
                  {canDelete && (
                    <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive"
                      onClick={() => setDeleteMerchant(merchant)}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  )}
                </div>
              </div>
              <div className="space-y-2 text-sm border-t border-border/30 pt-3">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground flex items-center gap-1.5"><Wallet className="w-3.5 h-3.5" /> المحفظة</span>
                  <span className="font-bold text-emerald-500">{merchant.walletBalance || 0} ج.م</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground flex items-center gap-1.5"><Package className="w-3.5 h-3.5" /> قيد التحصيل</span>
                  <span className="font-bold text-amber-500">{merchant.pendingBalance || 0} ج.م</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground flex items-center gap-1.5"><TrendingUp className="w-3.5 h-3.5" /> إجمالي محول</span>
                  <span className="font-medium">{merchant.totalWithdrawn || 0} ج.م</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={(open) => { setDialogOpen(open); if (!open) form.reset(); }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>إضافة تاجر جديد</DialogTitle>
            <DialogDescription>أدخل بيانات التاجر لإنشاء حساب جديد</DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="username" render={({ field }) => (
                  <FormItem><FormLabel>اسم المستخدم</FormLabel><FormControl><Input {...field} dir="ltr" className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="password" render={({ field }) => (
                  <FormItem><FormLabel>كلمة المرور</FormLabel><FormControl><Input type="password" {...field} dir="ltr" className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={form.control} name="fullName" render={({ field }) => (
                <FormItem><FormLabel>الاسم التجاري</FormLabel><FormControl><Input {...field} className="bg-background/50" /></FormControl><FormMessage /></FormItem>
              )} />
              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="phone" render={({ field }) => (
                  <FormItem><FormLabel>رقم الهاتف</FormLabel><FormControl><Input {...field} dir="ltr" className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={form.control} name="email" render={({ field }) => (
                  <FormItem><FormLabel>البريد الإلكتروني</FormLabel><FormControl><Input type="email" {...field} dir="ltr" className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
                <Button type="submit" disabled={createUser.isPending} className="bg-primary hover:bg-primary/90">
                  {createUser.isPending ? 'جاري الحفظ...' : 'إضافة التاجر'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteMerchant} onOpenChange={(open) => !open && setDeleteMerchant(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>حذف حساب التاجر</DialogTitle>
            <DialogDescription className="text-destructive">
              سيتم حذف حساب {deleteMerchant?.fullName} نهائياً ولا يمكن التراجع عن هذا الإجراء.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setDeleteMerchant(null)}>إلغاء</Button>
            <Button type="button" variant="destructive" onClick={handleDelete} disabled={deleteUser.isPending}>
              {deleteUser.isPending ? 'جاري الحذف...' : 'تأكيد الحذف'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
