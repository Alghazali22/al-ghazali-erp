import React, { useState } from 'react';
import { useGetZones, useCreateZone, useUpdateZone, useDeleteZone, getGetZonesQueryKey } from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { Zone } from '@workspace/api-client-react';
import { Card, CardContent } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Map, Search, Edit2, Plus, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

const createZoneSchema = z.object({
  governorate: z.string().min(2, 'المحافظة مطلوبة'),
  area: z.string().min(2, 'المنطقة مطلوبة'),
  basePrice: z.coerce.number().min(0, 'السعر مطلوب'),
  returnPrice: z.coerce.number().min(0).optional(),
  lat: z.string().optional(),
  lng: z.string().optional(),
});

const editZoneSchema = z.object({
  basePrice: z.coerce.number().min(0, 'السعر مطلوب'),
  returnPrice: z.coerce.number().min(0).optional(),
  lat: z.string().optional(),
  lng: z.string().optional(),
  isActive: z.boolean().optional(),
});

type CreateZoneForm = z.infer<typeof createZoneSchema>;
type EditZoneForm = z.infer<typeof editZoneSchema>;

export default function Zones() {
  const [search, setSearch] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const [editZone, setEditZone] = useState<Zone | null>(null);
  const [deleteZone, setDeleteZone] = useState<Zone | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user: currentUser } = useAuth();
  const createZone = useCreateZone();
  const updateZone = useUpdateZone();
  const deleteZoneMutation = useDeleteZone();
  const canDelete = currentUser?.role === 'super_admin';

  const { data: zones, isLoading } = useGetZones();

  const filteredZones = zones?.filter(z =>
    z.governorate.includes(search) || z.area.includes(search)
  ) || [];

  const createForm = useForm<CreateZoneForm>({
    resolver: zodResolver(createZoneSchema),
    defaultValues: { governorate: '', area: '', basePrice: 0, returnPrice: 0, lat: '', lng: '' },
  });

  const editForm = useForm<EditZoneForm>({
    resolver: zodResolver(editZoneSchema),
    defaultValues: { basePrice: 0, returnPrice: 0, lat: '', lng: '', isActive: true },
  });

  // Coordinates are optional; blank = leave unchanged. Validated again on the server.
  const coordsPayload = (v: { lat?: string; lng?: string }) => {
    const out: { lat?: number; lng?: number } = {};
    if (v.lat?.trim()) out.lat = Number(v.lat);
    if (v.lng?.trim()) out.lng = Number(v.lng);
    return out;
  };

  const onCreateSubmit = async (values: CreateZoneForm) => {
    try {
      await createZone.mutateAsync({ data: { ...values, returnPrice: values.returnPrice || undefined, lat: undefined, lng: undefined, ...coordsPayload(values) } as any });
      queryClient.invalidateQueries({ queryKey: getGetZonesQueryKey() });
      toast({ title: 'تم إضافة المنطقة بنجاح' });
      setCreateOpen(false);
      createForm.reset();
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'خطأ', description: e.message || 'حدث خطأ' });
    }
  };

  const onEditSubmit = async (values: EditZoneForm) => {
    if (!editZone) return;
    try {
      await updateZone.mutateAsync({ id: editZone.id, data: { ...values, returnPrice: values.returnPrice || undefined, lat: undefined, lng: undefined, ...coordsPayload(values) } as any });
      queryClient.invalidateQueries({ queryKey: getGetZonesQueryKey() });
      toast({ title: 'تم تحديث بيانات المنطقة' });
      setEditZone(null);
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'خطأ', description: e.message || 'حدث خطأ' });
    }
  };

  const openEdit = (zone: Zone) => {
    setEditZone(zone);
    const z = zone as any;
    editForm.reset({
      basePrice: zone.basePrice, returnPrice: zone.returnPrice || 0, isActive: zone.isActive ?? true,
      lat: z.lat != null ? String(z.lat) : '', lng: z.lng != null ? String(z.lng) : '',
    });
  };

  const handleDelete = async () => {
    if (!deleteZone) return;
    try {
      await deleteZoneMutation.mutateAsync({ id: deleteZone.id });
      await queryClient.invalidateQueries({ queryKey: getGetZonesQueryKey() });
      toast({ title: 'تم حذف المنطقة', description: `تم حذف ${deleteZone.governorate} — ${deleteZone.area} نهائياً` });
      setDeleteZone(null);
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر حذف المنطقة', description: e.message || 'حدث خطأ أثناء الحذف' });
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">المناطق والتسعير</h1>
          <p className="text-muted-foreground text-sm">إدارة أسعار الشحن للمحافظات والمناطق</p>
        </div>
        <Button className="bg-primary hover:bg-primary/90" onClick={() => setCreateOpen(true)}>
          <Plus className="w-4 h-4 ml-2" /> إضافة منطقة
        </Button>
      </div>

      <Card className="border-border/40 bg-card/60 backdrop-blur-sm">
        <CardContent className="p-4 sm:p-6">
          <div className="relative w-full sm:w-80 mb-5">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input placeholder="البحث باسم المحافظة أو المنطقة..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-4 pr-9 bg-background/50" />
          </div>

          <div className="rounded-md border border-border/50 overflow-x-auto">
            <Table>
              <TableHeader className="bg-muted/30">
                <TableRow>
                  <TableHead className="text-right">المحافظة</TableHead>
                  <TableHead className="text-right">المنطقة</TableHead>
                  <TableHead className="text-right">سعر الشحن</TableHead>
                  <TableHead className="text-right hidden sm:table-cell">سعر المرتجع</TableHead>
                  <TableHead className="text-right hidden md:table-cell">الحالة</TableHead>
                  <TableHead className="text-right"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8">جاري التحميل...</TableCell></TableRow>
                ) : filteredZones.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">لا توجد مناطق</TableCell></TableRow>
                ) : filteredZones.map((zone) => (
                  <TableRow key={zone.id} className="hover:bg-muted/30">
                    <TableCell className="font-bold text-sm">{zone.governorate}</TableCell>
                    <TableCell className="text-sm">{zone.area}{(zone as any).lat != null && <span title="لها إحداثيات" className="mr-1.5 text-xs">📍</span>}</TableCell>
                    <TableCell className="font-mono text-primary font-bold text-sm">{zone.basePrice} ج.م</TableCell>
                    <TableCell className="hidden sm:table-cell font-mono text-destructive text-sm">{zone.returnPrice || 0} ج.م</TableCell>
                    <TableCell className="hidden md:table-cell">
                      <span className={`text-xs font-medium ${zone.isActive !== false ? 'text-emerald-500' : 'text-muted-foreground'}`}>
                        {zone.isActive !== false ? 'مفعّلة' : 'معطّلة'}
                      </span>
                    </TableCell>
                     <TableCell>
                       <div className="flex items-center gap-1">
                         <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => openEdit(zone)}>
                           <Edit2 className="w-3.5 h-3.5" />
                         </Button>
                         {canDelete && (
                           <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
                             onClick={() => setDeleteZone(zone)}>
                             <Trash2 className="w-3.5 h-3.5" />
                           </Button>
                         )}
                       </div>
                     </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Create Zone Dialog */}
      <Dialog open={createOpen} onOpenChange={(open) => { setCreateOpen(open); if (!open) createForm.reset(); }}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>إضافة منطقة جديدة</DialogTitle>
            <DialogDescription>أدخل بيانات المنطقة وأسعار الشحن</DialogDescription>
          </DialogHeader>
          <Form {...createForm}>
            <form onSubmit={createForm.handleSubmit(onCreateSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField control={createForm.control} name="governorate" render={({ field }) => (
                  <FormItem><FormLabel>المحافظة</FormLabel><FormControl><Input {...field} className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={createForm.control} name="area" render={({ field }) => (
                  <FormItem><FormLabel>المنطقة</FormLabel><FormControl><Input {...field} className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField control={createForm.control} name="basePrice" render={({ field }) => (
                  <FormItem><FormLabel>سعر الشحن (ج.م)</FormLabel><FormControl><Input type="number" {...field} className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={createForm.control} name="returnPrice" render={({ field }) => (
                  <FormItem><FormLabel>سعر المرتجع (ج.م)</FormLabel><FormControl><Input type="number" {...field} className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField control={createForm.control} name="lat" render={({ field }) => (
                  <FormItem><FormLabel>خط العرض (اختياري)</FormLabel><FormControl><Input {...field} dir="ltr" inputMode="decimal" placeholder="30.0444" className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={createForm.control} name="lng" render={({ field }) => (
                  <FormItem><FormLabel>خط الطول (اختياري)</FormLabel><FormControl><Input {...field} dir="ltr" inputMode="decimal" placeholder="31.2357" className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <p className="text-xs text-muted-foreground -mt-2">إحداثيات مركز المنطقة (انسخها من خرائط جوجل: كليك يمين ← أول سطر). بتحسّن وقت الوصول وترتيب الرحلات والتوزيع الذكي. لو تركتها فارغة بيُستخدم مركز المحافظة.</p>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setCreateOpen(false)}>إلغاء</Button>
                <Button type="submit" disabled={createZone.isPending} className="bg-primary hover:bg-primary/90">
                  {createZone.isPending ? 'جاري الحفظ...' : 'إضافة المنطقة'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Edit Zone Dialog */}
      <Dialog open={!!editZone} onOpenChange={(open) => !open && setEditZone(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>تعديل تسعير المنطقة</DialogTitle>
            <DialogDescription>{editZone?.governorate} — {editZone?.area}</DialogDescription>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField control={editForm.control} name="basePrice" render={({ field }) => (
                  <FormItem><FormLabel>سعر الشحن (ج.م)</FormLabel><FormControl><Input type="number" {...field} className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={editForm.control} name="returnPrice" render={({ field }) => (
                  <FormItem><FormLabel>سعر المرتجع (ج.م)</FormLabel><FormControl><Input type="number" {...field} className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField control={editForm.control} name="lat" render={({ field }) => (
                  <FormItem><FormLabel>خط العرض (اختياري)</FormLabel><FormControl><Input {...field} dir="ltr" inputMode="decimal" placeholder="30.0444" className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={editForm.control} name="lng" render={({ field }) => (
                  <FormItem><FormLabel>خط الطول (اختياري)</FormLabel><FormControl><Input {...field} dir="ltr" inputMode="decimal" placeholder="31.2357" className="bg-background/50" /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <p className="text-xs text-muted-foreground -mt-2">إحداثيات مركز المنطقة (انسخها من خرائط جوجل: كليك يمين ← أول سطر). بتحسّن وقت الوصول وترتيب الرحلات والتوزيع الذكي. لو تركتها فارغة بيُستخدم مركز المحافظة.</p>
              <FormField control={editForm.control} name="isActive" render={({ field }) => (
                <FormItem className="flex items-center justify-between border border-border/50 rounded-lg p-3 bg-muted/20">
                  <FormLabel className="mb-0">المنطقة مفعّلة</FormLabel>
                  <FormControl><Switch checked={field.value} onCheckedChange={field.onChange} /></FormControl>
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setEditZone(null)}>إلغاء</Button>
                <Button type="submit" disabled={updateZone.isPending} className="bg-primary hover:bg-primary/90">
                  {updateZone.isPending ? 'جاري الحفظ...' : 'حفظ التعديلات'}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteZone} onOpenChange={(open) => !open && setDeleteZone(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>حذف المنطقة</DialogTitle>
            <DialogDescription className="text-destructive">
              سيتم حذف منطقة {deleteZone?.governorate} — {deleteZone?.area} وكل أسعارها الخاصة نهائياً ولا يمكن التراجع.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setDeleteZone(null)}>إلغاء</Button>
            <Button type="button" variant="destructive" onClick={handleDelete} disabled={deleteZoneMutation.isPending}>
              {deleteZoneMutation.isPending ? 'جاري الحذف...' : 'تأكيد الحذف'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
