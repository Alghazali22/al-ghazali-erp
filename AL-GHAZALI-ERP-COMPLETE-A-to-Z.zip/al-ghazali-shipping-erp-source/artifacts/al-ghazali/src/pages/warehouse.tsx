import React, { useState } from 'react';
import {
  getGetOrderTransfersQueryKey,
  getGetOrdersQueryKey,
  useGetBranches,
  useGetOrderTransfers,
  useGetOrders,
  useReceiveOrder,
  useReceiveOrderTransfer,
  useTransferOrderOut,
} from '@workspace/api-client-react';
import { useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Package, ArrowDownToLine, ArrowUpFromLine, CheckCircle2, Warehouse as WarehouseIcon } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import { ScanLine } from 'lucide-react';
import { apiFetch } from '@/lib/extra-api';

const awaitingParams = { inventoryStatus: 'awaiting_merchant_receipt' as const, limit: 100 };
const warehouseParams = { inventoryStatus: 'in_warehouse' as const, limit: 100 };
const transferParams = { status: 'in_transit' as const };
const transferHistoryParams = { status: 'received' as const };

export default function WarehousePage() {
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [toBranchId, setToBranchId] = useState('');
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: branches } = useGetBranches();
  const { data: awaitingData, isLoading: awaitingLoading } = useGetOrders(awaitingParams);
  const { data: warehouseData, isLoading: warehouseLoading } = useGetOrders(warehouseParams);
  const { data: transfers, isLoading: transfersLoading } = useGetOrderTransfers(transferParams);
  const { data: transferHistory, isLoading: transferHistoryLoading } = useGetOrderTransfers(transferHistoryParams);
  const receiveOrder = useReceiveOrder();
  const transferOrderOut = useTransferOrderOut();
  const receiveTransfer = useReceiveOrderTransfer();

  const refresh = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: getGetOrdersQueryKey(awaitingParams) }),
      queryClient.invalidateQueries({ queryKey: getGetOrdersQueryKey(warehouseParams) }),
      queryClient.invalidateQueries({ queryKey: getGetOrderTransfersQueryKey(transferParams) }),
      queryClient.invalidateQueries({ queryKey: getGetOrderTransfersQueryKey(transferHistoryParams) }),
      queryClient.invalidateQueries({ queryKey: getGetOrdersQueryKey({}) }),
    ]);
  };

  const handleReceiveOrder = async (id: number) => {
    try {
      await receiveOrder.mutateAsync({ id });
      await refresh();
      toast({ title: 'تم الاستلام الداخلي', description: 'دخل الطلب مخزن الفرع وأصبح جاهزًا للتشغيل' });
    } catch (error: any) {
      toast({ variant: 'destructive', title: 'تعذر الاستلام', description: error.message });
    }
  };

  const handleTransferOut = async () => {
    if (!selectedOrder || !toBranchId) return;
    try {
      await transferOrderOut.mutateAsync({ id: selectedOrder.id, data: { toBranchId: Number(toBranchId) } });
      await refresh();
      setSelectedOrder(null);
      setToBranchId('');
      toast({ title: 'تم تسجيل Transfer Out', description: 'الطلب في انتظار تأكيد الاستلام من الفرع الآخر' });
    } catch (error: any) {
      toast({ variant: 'destructive', title: 'تعذر التحويل', description: error.message });
    }
  };

  const handleReceiveTransfer = async (id: number) => {
    try {
      await receiveTransfer.mutateAsync({ id });
      await refresh();
      toast({ title: 'تم تأكيد Transfer In', description: 'دخل الطلب مخزن الفرع المستلم' });
    } catch (error: any) {
      toast({ variant: 'destructive', title: 'تعذر تأكيد الاستلام', description: error.message });
    }
  };

  const orderRows = (data: any) => data?.orders || [];

  // Scan-to-receive: type or scan (QR / barcode scanners type the code + Enter) one or many order numbers.
  const [scanValue, setScanValue] = useState('');
  const [scanning, setScanning] = useState(false);
  const [scanLog, setScanLog] = useState<{ orderNumber: string; ok: boolean; message: string }[]>([]);
  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault();
    const numbers = scanValue.split(/[\s,;]+/).map((v) => v.trim()).filter(Boolean);
    if (numbers.length === 0) return;
    setScanning(true);
    try {
      const res = await apiFetch<{ results: { orderNumber: string; ok: boolean; message: string }[]; received: number }>(
        '/orders/receive-by-number',
        { method: 'POST', body: JSON.stringify({ orderNumbers: numbers }) },
      );
      setScanLog((prev) => [...res.results, ...prev].slice(0, 12));
      setScanValue('');
      if (res.received > 0) await refresh();
    } catch (error: any) {
      toast({ variant: 'destructive', title: 'تعذر الاستلام', description: error.message });
    } finally {
      setScanning(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">المخزن والتحويلات</h1>
        <p className="text-muted-foreground">استلام من التاجر، إدخال للمخزن، وتحويل آمن بين الفروع</p>
      </div>

      <Card className="border-border/40 bg-card/60">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-primary text-base">
            <ScanLine className="w-5 h-5" /> استلام سريع بالمسح
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <form onSubmit={handleScan} className="flex gap-2">
            <Input
              autoFocus
              dir="ltr"
              className="font-mono"
              placeholder="امسح أو اكتب رقم الطلب (ALG-...) — يمكن لصق عدة أرقام"
              value={scanValue}
              onChange={(e) => setScanValue(e.target.value)}
              disabled={scanning}
            />
            <Button type="submit" disabled={scanning || !scanValue.trim()} className="shrink-0">
              {scanning ? 'جاري...' : 'استلام'}
            </Button>
          </form>
          {scanLog.length > 0 && (
            <ul className="space-y-1 text-sm">
              {scanLog.map((r, i) => (
                <li key={`${r.orderNumber}-${i}`} className={`flex items-center gap-2 ${r.ok ? 'text-emerald-500' : 'text-destructive'}`}>
                  <span className="font-mono font-bold">{r.orderNumber}</span>
                  <span className="text-xs">{r.message}</span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Card className="border-amber-500/20 bg-amber-500/5">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-amber-500">
            <ArrowDownToLine className="w-5 h-5" /> بانتظار الاستلام من التاجر
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader><TableRow>
              <TableHead className="text-right">رقم الطلب</TableHead>
              <TableHead className="text-right">العميل</TableHead>
              <TableHead className="text-right">التاجر</TableHead>
              <TableHead className="text-right">الإجراء</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {awaitingLoading ? (
                <TableRow><TableCell colSpan={4} className="text-center py-6">جاري التحميل...</TableCell></TableRow>
              ) : orderRows(awaitingData).length === 0 ? (
                <TableRow><TableCell colSpan={4} className="text-center py-6 text-muted-foreground">لا توجد طلبات بانتظار الاستلام</TableCell></TableRow>
              ) : orderRows(awaitingData).map((order: any) => (
                <TableRow key={order.id}>
                  <TableCell className="font-mono font-bold text-primary">{order.orderNumber}</TableCell>
                  <TableCell>{order.customerName}</TableCell>
                  <TableCell>{order.merchantName}</TableCell>
                  <TableCell>
                    <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700" onClick={() => handleReceiveOrder(order.id)} disabled={receiveOrder.isPending}>
                      <CheckCircle2 className="w-4 h-4 ml-1" /> استلام وإدخال المخزن
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="border-blue-500/20 bg-blue-500/5">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-blue-400">
            <ArrowUpFromLine className="w-5 h-5" /> تحويلات بانتظار الاستلام
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader><TableRow>
              <TableHead className="text-right">مستند التحويل</TableHead>
              <TableHead className="text-right">رقم الطلب</TableHead>
              <TableHead className="text-right">من</TableHead>
              <TableHead className="text-right">إلى</TableHead>
              <TableHead className="text-right">أنشأه / التاريخ</TableHead>
              <TableHead className="text-right">الإجراء</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {transfersLoading ? (
                <TableRow><TableCell colSpan={6} className="text-center py-6">جاري التحميل...</TableCell></TableRow>
              ) : !transfers?.length ? (
                <TableRow><TableCell colSpan={6} className="text-center py-6 text-muted-foreground">لا توجد تحويلات معلقة</TableCell></TableRow>
              ) : transfers.map((transfer) => (
                <TableRow key={transfer.id}>
                  <TableCell className="font-mono font-bold text-blue-400">{transfer.transferNumber}</TableCell>
                  <TableCell className="font-mono font-bold text-primary">{transfer.orderNumber}</TableCell>
                  <TableCell>{transfer.fromBranchName}</TableCell>
                  <TableCell>{transfer.toBranchName}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    <div>{transfer.createdByName || '—'}</div>
                    <div>{new Date(transfer.createdAt).toLocaleString('ar-EG')}</div>
                  </TableCell>
                  <TableCell>
                    <Button size="sm" variant="outline" className="border-blue-500/40 text-blue-400" onClick={() => handleReceiveTransfer(transfer.id)} disabled={receiveTransfer.isPending}>
                      <CheckCircle2 className="w-4 h-4 ml-1" /> تأكيد Transfer In
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="border-emerald-500/20 bg-emerald-500/5">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-emerald-500">
            <CheckCircle2 className="w-5 h-5" /> سجل التحويلات المستلمة
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader><TableRow>
              <TableHead className="text-right">مستند التحويل</TableHead>
              <TableHead className="text-right">رقم الطلب</TableHead>
              <TableHead className="text-right">من / إلى</TableHead>
              <TableHead className="text-right">أنشأه</TableHead>
              <TableHead className="text-right">استلمه</TableHead>
              <TableHead className="text-right">وقت الاستلام</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {transferHistoryLoading ? (
                <TableRow><TableCell colSpan={6} className="text-center py-6">جاري التحميل...</TableCell></TableRow>
              ) : !transferHistory?.length ? (
                <TableRow><TableCell colSpan={6} className="text-center py-6 text-muted-foreground">لا يوجد سجل تحويلات مستلمة</TableCell></TableRow>
              ) : transferHistory.slice(0, 30).map((transfer) => (
                <TableRow key={transfer.id}>
                  <TableCell className="font-mono font-bold text-emerald-500">{transfer.transferNumber}</TableCell>
                  <TableCell className="font-mono">{transfer.orderNumber}</TableCell>
                  <TableCell className="text-xs">{transfer.fromBranchName} ← {transfer.toBranchName}</TableCell>
                  <TableCell className="text-sm">{transfer.createdByName || '—'}</TableCell>
                  <TableCell className="text-sm">{transfer.receivedByName || '—'}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{transfer.receivedAt ? new Date(transfer.receivedAt).toLocaleString('ar-EG') : '—'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card className="border-border/40 bg-card/60">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2"><WarehouseIcon className="w-5 h-5 text-primary" /> الطلبات داخل مخزن الفرع</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
            {warehouseLoading ? <div className="text-muted-foreground">جاري التحميل...</div> :
              orderRows(warehouseData).length === 0 ? <div className="text-muted-foreground">لا توجد طلبات داخل المخزن</div> :
              orderRows(warehouseData).map((order: any) => (
                <div key={order.id} className="rounded-lg border border-border/50 bg-muted/10 p-4 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <Package className="w-4 h-4 text-primary shrink-0" />
                      <span className="font-mono font-bold text-primary">{order.orderNumber}</span>
                    </div>
                    <div className="text-sm truncate mt-1">{order.customerName}</div>
                    <Badge variant="outline" className="mt-2 text-xs">داخل المخزن</Badge>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => setSelectedOrder(order)}>
                    <ArrowUpFromLine className="w-4 h-4 ml-1" /> Transfer Out
                  </Button>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>

      <Dialog open={!!selectedOrder} onOpenChange={(open) => { if (!open) { setSelectedOrder(null); setToBranchId(''); } }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>تحويل الطلب إلى فرع آخر</DialogTitle>
            <DialogDescription>سيخرج الطلب من مخزن الفرع الحالي، ولن يدخل مخزن الفرع الآخر إلا بعد تأكيد الاستلام.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2 py-4">
            <div className="text-sm font-bold">{selectedOrder?.orderNumber} — {selectedOrder?.customerName}</div>
            <Select value={toBranchId} onValueChange={setToBranchId}>
              <SelectTrigger><SelectValue placeholder="اختر الفرع المستلم" /></SelectTrigger>
              <SelectContent>
                {(branches || []).filter((branch) => branch.id !== selectedOrder?.branchId).map((branch) => (
                  <SelectItem key={branch.id} value={String(branch.id)}>{branch.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedOrder(null)}>إلغاء</Button>
            <Button onClick={handleTransferOut} disabled={!toBranchId || transferOrderOut.isPending}>تأكيد Transfer Out</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}