import React, { useState } from 'react';
import { Link } from 'wouter';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { FileSpreadsheet, KeyRound, Copy, Trash2, Plug } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiFetch } from '@/lib/extra-api';

function ImportCallout() {
  return (
    <Card className="border-primary/30 bg-primary/5">
      <CardContent className="p-5 flex flex-wrap items-center gap-4">
        <div className="w-11 h-11 rounded-xl bg-primary/15 text-primary flex items-center justify-center shrink-0"><FileSpreadsheet className="w-6 h-6" /></div>
        <div className="flex-1 min-w-[14rem]">
          <p className="font-bold">رفع الطلبات بالجملة من Excel / Google Sheets</p>
          <p className="text-sm text-muted-foreground">انسخ الصفوف والصقها مباشرة، أو ارفع ملف، أو الصق رابط Google Sheet، أو الصق رسائل واتساب — مع تصحيح تلقائي وبوالص جاهزة للطباعة.</p>
        </div>
        <Link href="/orders/new?mode=grid"><Button>افتح شاشة الإنشاء السريع</Button></Link>
      </CardContent>
    </Card>
  );
}

type ApiKeyRow = { id: number; name: string; keyPrefix: string; lastUsedAt: string | null; createdAt: string; revokedAt: string | null };

function ApiKeys() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [name, setName] = useState('');
  const [newKey, setNewKey] = useState<string | null>(null);
  const { data: keys } = useQuery({ queryKey: ['api-keys'], queryFn: () => apiFetch<ApiKeyRow[]>('/integrations/keys') });
  const base = `${window.location.origin}/api`;

  const create = async () => {
    try {
      const res = await apiFetch<ApiKeyRow & { key: string }>('/integrations/keys', { method: 'POST', body: JSON.stringify({ name }) });
      setNewKey(res.key);
      setName('');
      qc.invalidateQueries({ queryKey: ['api-keys'] });
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر إنشاء المفتاح', description: e.message });
    }
  };
  const revoke = async (id: number) => {
    if (!window.confirm('إلغاء هذا المفتاح؟ أي متجر يستخدمه سيتوقف فوراً.')) return;
    try {
      await apiFetch(`/integrations/keys/${id}`, { method: 'DELETE' });
      qc.invalidateQueries({ queryKey: ['api-keys'] });
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر الإلغاء', description: e.message });
    }
  };
  const copy = async (text: string) => {
    try { await navigator.clipboard.writeText(text); toast({ title: 'تم النسخ' }); } catch { toast({ variant: 'destructive', title: 'تعذر النسخ' }); }
  };

  const curl = `curl -X POST ${base}/integrations/orders \\
  -H "X-API-Key: YOUR_KEY" -H "Content-Type: application/json" \\
  -d '{"reference":"SHOP-1001","customerName":"أحمد محمد","customerPhone":"01012345678",
       "governorate":"القاهرة","area":"مدينة نصر","customerAddress":"15 شارع عباس العقاد",
       "packageValue":350}'`;

  return (
    <Card className="border-border/40 bg-card/60">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><Plug className="w-5 h-5 text-primary" /> ربط متجرك الإلكتروني (API)</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          اربط متجرك (Shopify / WooCommerce / موقعك) ليرسل الطلبات للغزالي تلقائياً ويعرف حالتها لحظة بلحظة. المفتاح يظهر <b>مرة واحدة فقط</b> عند إنشائه.
        </p>

        <div className="flex gap-2">
          <Input placeholder="اسم المفتاح (مثال: متجر Shopify)" value={name} onChange={(e) => setName(e.target.value)} maxLength={60} />
          <Button onClick={create} disabled={!name.trim()} className="shrink-0"><KeyRound className="w-4 h-4 ml-1" /> إنشاء مفتاح</Button>
        </div>

        {newKey && (
          <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-3 space-y-2">
            <p className="text-sm font-semibold text-emerald-500">انسخ المفتاح الآن — لن يظهر مرة أخرى:</p>
            <div className="flex gap-2 items-center">
              <code dir="ltr" className="flex-1 text-xs break-all bg-background/60 rounded px-2 py-1.5 font-mono">{newKey}</code>
              <Button size="sm" variant="outline" onClick={() => copy(newKey)}><Copy className="w-3.5 h-3.5" /></Button>
            </div>
            <Button size="sm" variant="ghost" onClick={() => setNewKey(null)}>تم، أخفِ المفتاح</Button>
          </div>
        )}

        <div className="rounded-md border border-border/50 overflow-x-auto">
          <Table>
            <TableHeader className="bg-muted/30"><TableRow>
              <TableHead className="text-right">الاسم</TableHead><TableHead className="text-right">المفتاح</TableHead>
              <TableHead className="text-right">آخر استخدام</TableHead><TableHead className="text-right">الحالة</TableHead><TableHead />
            </TableRow></TableHeader>
            <TableBody>
              {!keys?.length ? (
                <TableRow><TableCell colSpan={5} className="text-center py-6 text-muted-foreground">لا توجد مفاتيح بعد</TableCell></TableRow>
              ) : keys.map((k) => (
                <TableRow key={k.id}>
                  <TableCell className="font-medium">{k.name}</TableCell>
                  <TableCell dir="ltr" className="text-right font-mono text-xs">{k.keyPrefix}…</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{k.lastUsedAt ? new Date(k.lastUsedAt).toLocaleString('ar-EG') : 'لم يُستخدم'}</TableCell>
                  <TableCell>{k.revokedAt
                    ? <Badge variant="outline" className="text-muted-foreground">ملغي</Badge>
                    : <Badge variant="outline" className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">فعّال</Badge>}</TableCell>
                  <TableCell>{!k.revokedAt && <Button size="sm" variant="ghost" className="text-destructive h-8 w-8 p-0" onClick={() => revoke(k.id)} aria-label="إلغاء"><Trash2 className="w-4 h-4" /></Button>}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <details className="rounded-lg border border-border/40 p-3 text-sm">
          <summary className="cursor-pointer font-semibold">طريقة الاستخدام (للمطوّر)</summary>
          <div className="mt-3 space-y-3">
            <div>
              <div className="flex items-center justify-between mb-1"><span className="font-medium">إنشاء طلب</span>
                <Button size="sm" variant="ghost" onClick={() => copy(curl)}><Copy className="w-3.5 h-3.5 ml-1" /> نسخ</Button></div>
              <pre dir="ltr" className="text-xs bg-muted/30 rounded p-3 overflow-x-auto whitespace-pre-wrap">{curl}</pre>
              <p className="text-xs text-muted-foreground mt-1">
                إعادة إرسال نفس <code>reference</code> لا ينشئ طلباً مكرراً (يرجع نفس الطلب). الرد يتضمن <code>orderNumber</code> و<code>shippingFee</code> و<code>totalToCollect</code>.
              </p>
            </div>
            <ul className="text-xs space-y-1 text-muted-foreground" dir="ltr">
              <li><code>GET {base}/integrations/orders/ALG-12345678</code> — حالة الطلب والتسلسل الزمني</li>
              <li><code>GET {base}/integrations/shipping-fee?governorate=القاهرة&amp;area=مدينة نصر</code> — سعر الشحن لمتجرك (للـ checkout)</li>
            </ul>
          </div>
        </details>
      </CardContent>
    </Card>
  );
}

export default function Integrations() {
  return (
    <div className="space-y-5 max-w-3xl">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">الاستيراد والربط</h1>
        <p className="text-muted-foreground">ارفع طلباتك بالجملة أو اربط متجرك الإلكتروني مباشرة</p>
      </div>
      <ImportCallout />
      <ApiKeys />
    </div>
  );
}
