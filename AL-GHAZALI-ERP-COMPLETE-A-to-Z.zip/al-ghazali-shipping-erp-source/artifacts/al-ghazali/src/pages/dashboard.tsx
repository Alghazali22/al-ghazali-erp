import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useGetDashboardStats, useGetRecentOrders, useGetOrderStatusBreakdown, useGetRevenueTrend } from '@workspace/api-client-react';
import { Package, Truck, CheckCircle2, XCircle, DollarSign, Users, Store, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, AreaChart, Area } from 'recharts';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const StatCard = ({ title, value, icon: Icon, delay, isCurrency = false }: any) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.4 }}
    >
      <Card className="border-border/40 bg-card/60 backdrop-blur-sm overflow-hidden group relative hover:shadow-[0_8px_30px_rgba(245,158,11,0.1)] transition-all duration-500 hover:-translate-y-1">
        <div className="absolute top-0 right-0 w-24 h-24 bg-primary/10 rounded-full blur-2xl -mr-10 -mt-10 group-hover:bg-primary/20 transition-all duration-500"></div>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
              <h3 className="text-3xl font-bold tracking-tight text-foreground">
                {isCurrency ? `${Number(value).toLocaleString()} ج.م` : Number(value).toLocaleString()}
              </h3>
            </div>
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform duration-500">
              <Icon className="w-6 h-6" />
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useGetDashboardStats({});
  const { data: recentOrders, isLoading: ordersLoading } = useGetRecentOrders({ limit: 5 });
  const { data: statusBreakdown, isLoading: breakdownLoading } = useGetOrderStatusBreakdown({});
  const { data: revenueTrend, isLoading: trendLoading } = useGetRevenueTrend({ days: 7 });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered': return 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20';
      case 'pending': return 'bg-amber-500/10 text-amber-500 border-amber-500/20';
      case 'in_transit': return 'bg-orange-500/10 text-orange-500 border-orange-500/20';
      case 'returned': return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'ready': return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'delivered': return 'مكتمل';
      case 'pending': return 'قيد الانتظار';
      case 'in_transit': return 'في الطريق';
      case 'returned': return 'مرتجع';
      case 'ready': return 'جاهز';
      default: return status;
    }
  };

  if (statsLoading) return <div className="animate-pulse space-y-8">
    <div className="h-10 bg-muted/50 rounded w-48 mb-8"></div>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {[...Array(4)].map((_, i) => <div key={i} className="h-32 bg-muted/30 rounded-xl"></div>)}
    </div>
  </div>;

  return (
    <div className="space-y-8 pb-12">
      <div>
        <h1 className="text-3xl font-bold tracking-tight mb-2">نظرة عامة</h1>
        <p className="text-muted-foreground">ملخص أداء العمليات للشحن اليوم</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="إجمالي الطلبات" value={stats?.totalOrders || 0} icon={Package} delay={0.1} />
        <StatCard title="في الطريق" value={stats?.inTransitOrders || 0} icon={Truck} delay={0.2} />
        <StatCard title="تم التوصيل اليوم" value={stats?.deliveredToday || 0} icon={CheckCircle2} delay={0.3} />
        <StatCard title="المرتجعات اليوم" value={stats?.returnedToday || 0} icon={XCircle} delay={0.4} />
        <StatCard title="إيرادات اليوم" value={stats?.revenue || 0} icon={DollarSign} delay={0.5} isCurrency={true} />
        <StatCard title="المندوبين النشطين" value={stats?.activeDrivers || 0} icon={Users} delay={0.6} />
        <StatCard title="التجار النشطين" value={stats?.activeMerchants || 0} icon={Store} delay={0.7} />
        <StatCard title="نقدية معلقة" value={stats?.pendingCash || 0} icon={Clock} delay={0.8} isCurrency={true} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="lg:col-span-2">
          <Card className="h-full border-border/40 bg-card/40 backdrop-blur-md">
            <CardHeader>
              <CardTitle>اتجاه الإيرادات (7 أيام)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full">
                {trendLoading ? <div className="h-full w-full bg-muted/20 animate-pulse rounded" /> : (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={revenueTrend}>
                      <defs>
                        <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                      <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${value}ج`} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                        itemStyle={{ color: 'hsl(var(--foreground))' }}
                      />
                      <Area type="monotone" dataKey="revenue" stroke="hsl(var(--primary))" strokeWidth={3} fillOpacity={1} fill="url(#colorRev)" />
                    </AreaChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
          <Card className="h-full border-border/40 bg-card/40 backdrop-blur-md">
            <CardHeader>
              <CardTitle>حالات الطلبات</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full">
                {breakdownLoading ? <div className="h-full w-full bg-muted/20 animate-pulse rounded" /> : (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={statusBreakdown} layout="vertical" margin={{ left: 0, right: 0, top: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" horizontal={false} />
                      <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} hide />
                      <YAxis dataKey="status" type="category" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} width={80} tickFormatter={getStatusLabel} />
                      <Tooltip 
                        cursor={{fill: 'hsl(var(--muted)/0.3)'}}
                        contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                      />
                      <Bar dataKey="count" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} barSize={20} />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
        <Card className="border-border/40 bg-card/40 backdrop-blur-md">
          <CardHeader>
            <CardTitle>أحدث الطلبات</CardTitle>
          </CardHeader>
          <CardContent>
            {ordersLoading ? (
               <div className="space-y-4">
                 {[...Array(5)].map((_, i) => <div key={i} className="h-12 bg-muted/20 animate-pulse rounded"></div>)}
               </div>
            ) : (
              <div className="rounded-md border border-border/50">
                <Table>
                  <TableHeader className="bg-muted/30">
                    <TableRow>
                      <TableHead className="text-right">رقم التتبع</TableHead>
                      <TableHead className="text-right">العميل</TableHead>
                      <TableHead className="text-right">التاجر</TableHead>
                      <TableHead className="text-right">المنطقة</TableHead>
                      <TableHead className="text-right">الحالة</TableHead>
                      <TableHead className="text-right">المبلغ</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentOrders?.map((order) => (
                      <TableRow key={order.id} className="hover:bg-muted/30 transition-colors">
                        <TableCell className="font-mono text-primary font-medium">{order.orderNumber}</TableCell>
                        <TableCell>{order.customerName}</TableCell>
                        <TableCell>{order.merchantName}</TableCell>
                        <TableCell>{order.governorate} - {order.area}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={`${getStatusColor(order.status)} px-3 py-1 font-semibold`}>
                            {getStatusLabel(order.status)}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-medium">{order.totalToCollect} ج.م</TableCell>
                      </TableRow>
                    ))}
                    {recentOrders?.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                          لا توجد طلبات حديثة
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}