import React, { useState } from 'react';
import { useTrackOrder } from '@workspace/api-client-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Package, Search, Truck, CheckCircle2, Clock, XCircle, MapPin, KeyRound } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import logoPath from '@assets/al-ghazali-logo.png';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { LiveApproach, type LiveInfo } from '@/components/LiveApproach';

export default function TrackOrder() {
  const initialOrder = new URLSearchParams(window.location.search).get('order') || '';
  const [orderNumber, setOrderNumber] = useState(initialOrder);
  const [searchedNumber, setSearchedNumber] = useState(initialOrder);

  const { data: trackingInfo, isLoading, isError } = useTrackOrder(searchedNumber, {
    query: {
      enabled: !!searchedNumber,
      queryKey: ['track', searchedNumber],
      // While the courier is on the way keep the page fresh (position + ETA).
      refetchInterval: (query: any) => (query.state.data?.status === 'in_transit' ? 15_000 : false),
    }
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (orderNumber.trim()) {
      setSearchedNumber(orderNumber.trim());
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'delivered': return <CheckCircle2 className="w-8 h-8 text-emerald-500" />;
      case 'in_transit': return <Truck className="w-8 h-8 text-orange-500" />;
      case 'returned':
      case 'final_return': return <XCircle className="w-8 h-8 text-destructive" />;
      case 'ready': return <Package className="w-8 h-8 text-blue-500" />;
      default: return <Clock className="w-8 h-8 text-amber-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered': return 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20';
      case 'pending': return 'bg-amber-500/10 text-amber-500 border-amber-500/20';
      case 'in_transit': return 'bg-orange-500/10 text-orange-500 border-orange-500/20';
      case 'returned': return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'ready': return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'delivered': return 'مكتمل';
      case 'pending': return 'قيد الانتظار';
      case 'in_transit': return 'في الطريق';
      case 'returned': return 'مرتجع';
      case 'ready': return 'جاهز';
      default: return status;
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center py-12 px-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent pointer-events-none"></div>
      
      <div className="w-full max-w-3xl z-10 space-y-8">
        <div className="text-center space-y-4">
          <img src={logoPath} alt="Al-Ghazali Logo" className="w-24 h-24 mx-auto object-contain drop-shadow-[0_0_15px_rgba(245,158,11,0.5)]" />
          <h1 className="text-4xl font-bold tracking-tight text-foreground">تتبع شحنتك</h1>
          <p className="text-muted-foreground text-lg max-w-md mx-auto">
            أدخل رقم التتبع الخاص بك لمعرفة حالة شحنتك ومكانها الحالي.
          </p>
        </div>

        <Card className="border-primary/20 shadow-[0_0_30px_rgba(245,158,11,0.05)] bg-card/80 backdrop-blur-md">
          <CardContent className="p-6">
            <form onSubmit={handleSearch} className="flex gap-4">
              <div className="relative flex-1">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
                <Input 
                  value={orderNumber}
                  onChange={(e) => setOrderNumber(e.target.value)}
                  placeholder="رقم التتبع (مثل: ALG-12345)"
                  className="pl-4 pr-10 h-14 text-lg bg-background/50 border-border/50 focus:border-primary/50 text-left dir-ltr"
                />
              </div>
              <Button type="submit" className="h-14 px-8 text-lg font-bold bg-primary hover:bg-primary/90 shadow-[0_0_15px_rgba(245,158,11,0.3)]">
                تتبع
              </Button>
            </form>
          </CardContent>
        </Card>

        <AnimatePresence mode="wait">
          {isLoading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex justify-center py-12">
              <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            </motion.div>
          )}

          {isError && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <Card className="border-destructive/30 bg-destructive/5 text-center py-12">
                <CardContent>
                  <XCircle className="w-16 h-16 text-destructive mx-auto mb-4" />
                  <h3 className="text-2xl font-bold mb-2">الشحنة غير موجودة</h3>
                  <p className="text-muted-foreground">تأكد من رقم التتبع وحاول مرة أخرى.</p>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {trackingInfo && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-6">
              <Card className="border-border/40 bg-card/60 backdrop-blur-sm overflow-hidden relative">
                <div className="absolute top-0 right-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-50"></div>
                <CardContent className="p-8">
                  <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-8">
                    <div className="text-center md:text-right space-y-1">
                      <p className="text-muted-foreground text-sm font-medium uppercase tracking-wider">رقم التتبع</p>
                      <p className="text-3xl font-mono font-bold text-primary">{trackingInfo.orderNumber}</p>
                    </div>
                    
                    <div className="flex flex-col items-center justify-center p-4 bg-muted/10 rounded-2xl border border-border/30 min-w-[200px]">
                      <div className="mb-2">
                        {getStatusIcon(trackingInfo.status)}
                      </div>
                      <Badge variant="outline" className={`${getStatusColor(trackingInfo.status)} px-4 py-1.5 text-base font-bold`}>
                        {getStatusLabel(trackingInfo.status)}
                      </Badge>
                    </div>
                    
                    <div className="text-center md:text-left space-y-1">
                      <p className="text-muted-foreground text-sm font-medium">العميل</p>
                      <p className="text-xl font-bold">{trackingInfo.customerName}</p>
                      {trackingInfo.estimatedDelivery && (
                        <p className="text-sm text-primary mt-2">متوقع التوصيل: {new Date(trackingInfo.estimatedDelivery).toLocaleDateString('ar-EG')}</p>
                      )}
                    </div>
                  </div>

                  {(trackingInfo as any).live && (
                    <div className="mb-8">
                      <LiveApproach orderNumber={trackingInfo.orderNumber} live={(trackingInfo as any).live as LiveInfo} />
                    </div>
                  )}

                  {trackingInfo.otp && trackingInfo.status === 'in_transit' && (
                    <div className="mb-8 rounded-2xl border border-primary/30 bg-primary/5 p-6 text-center">
                      <div className="flex items-center justify-center gap-2 mb-2 text-primary">
                        <KeyRound className="w-5 h-5" />
                        <p className="font-bold">كود تأكيد الاستلام (OTP)</p>
                      </div>
                      <p className="text-4xl font-mono font-bold tracking-[0.5em] text-foreground" dir="ltr">
                        {trackingInfo.otp}
                      </p>
                      <p className="text-sm text-muted-foreground mt-3">
                        سلّم هذا الكود لمندوب التوصيل عند استلام شحنتك للتأكيد
                      </p>
                    </div>
                  )}

                  <Separator className="my-8 opacity-50" />

                  <div>
                    <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                      <MapPin className="text-primary w-5 h-5" />
                      سجل التتبع
                    </h3>
                    
                    <div className="space-y-6 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-border before:to-transparent">
                      {trackingInfo.timeline?.map((event: any, index: number) => (
                        <div key={event.id} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                          <div className="flex items-center justify-center w-10 h-10 rounded-full border-4 border-background bg-muted-foreground/20 group-[.is-active]:bg-primary group-[.is-active]:text-primary-foreground shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 z-10 transition-colors">
                            {index === 0 ? <CheckCircle2 className="w-5 h-5" /> : <div className="w-2.5 h-2.5 rounded-full bg-current" />}
                          </div>
                          <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded-xl border border-border/40 bg-card/40 shadow-sm backdrop-blur-sm group-[.is-active]:border-primary/30 transition-all hover:bg-card/60">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-1">
                              <div className="font-bold text-foreground">{getStatusLabel(event.status)}</div>
                              <time className="text-xs font-mono text-muted-foreground">{new Date(event.timestamp).toLocaleString('ar-EG')}</time>
                            </div>
                            <div className="text-sm text-muted-foreground">{event.description}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}