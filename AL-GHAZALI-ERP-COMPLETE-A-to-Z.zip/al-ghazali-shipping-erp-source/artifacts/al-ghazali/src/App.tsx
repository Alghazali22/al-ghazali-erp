import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { AuthProvider, ProtectedRoute, useAuth } from "@/contexts/AuthContext";
import { AppLayout } from "@/components/layout/AppLayout";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { OfflineBanner } from "@/components/OfflineBanner";

// Pages
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import TrackOrder from "@/pages/track";
import Orders from "@/pages/orders";
import NewOrder from "@/pages/orders-new";
import Trips from "@/pages/trips";
import Drivers from "@/pages/drivers";
import Merchants from "@/pages/merchants";
import Employees from "@/pages/employees";
import Branches from "@/pages/branches";
import Zones from "@/pages/zones";
import Settlements from "@/pages/financial/settlements";
import Wallets from "@/pages/financial/wallets";
import Treasury from "@/pages/financial/treasury";
import CS from "@/pages/cs";
import Settings from "@/pages/settings";
import Analytics from "@/pages/analytics";
import Dispatch from "@/pages/dispatch";
import Permissions from "@/pages/permissions";
import MerchantSupport from "@/pages/support";
import Integrations from "@/pages/integrations";
import DriverDashboard from "@/pages/driver-dashboard";
import DriverTracking from "@/pages/driver-tracking";
import Warehouse from "@/pages/warehouse";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function AdminRouter() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/">
          <ProtectedRoute component={Dashboard} requiredRoles={['super_admin','branch_manager','accountant','operations','merchant','cs']} />
        </Route>
        <Route path="/orders">
          <ProtectedRoute component={Orders} requiredRoles={['super_admin','branch_manager','operations','merchant','cs']} />
        </Route>
        <Route path="/warehouse">
          <ProtectedRoute component={Warehouse} requiredRoles={['super_admin','branch_manager','operations']} permission="warehouse.manage" />
        </Route>
        <Route path="/orders/new">
          <ProtectedRoute component={NewOrder} requiredRoles={['super_admin','branch_manager','operations','merchant']} />
        </Route>
        <Route path="/trips">
          <ProtectedRoute component={Trips} requiredRoles={['super_admin','branch_manager','operations']} permission="dispatch.manage" />
        </Route>
        <Route path="/drivers">
          <ProtectedRoute component={Drivers} requiredRoles={['super_admin','branch_manager','operations']} />
        </Route>
        <Route path="/driver-tracking">
          <ProtectedRoute component={DriverTracking} requiredRoles={['super_admin','branch_manager','operations']} permission="tracking.view" />
        </Route>
        <Route path="/merchants">
          <ProtectedRoute component={Merchants} requiredRoles={['super_admin','branch_manager','accountant']} />
        </Route>
        <Route path="/employees">
          <ProtectedRoute component={Employees} requiredRoles={['super_admin']} />
        </Route>
        <Route path="/branches">
          <ProtectedRoute component={Branches} requiredRoles={['super_admin']} />
        </Route>
        <Route path="/zones">
          <ProtectedRoute component={Zones} requiredRoles={['super_admin']} />
        </Route>
        <Route path="/financial/settlements">
          <ProtectedRoute component={Settlements} requiredRoles={['super_admin','branch_manager','accountant']} permission="finance.view" />
        </Route>
        <Route path="/financial/wallets">
          <ProtectedRoute component={Wallets} requiredRoles={['super_admin','accountant','merchant']} />
        </Route>
        <Route path="/financial/treasury">
          <ProtectedRoute component={Treasury} requiredRoles={['super_admin','branch_manager','accountant']} permission="finance.view" />
        </Route>
        <Route path="/cs">
          <ProtectedRoute component={CS} requiredRoles={['super_admin','cs','branch_manager','operations']} permission="support.view" />
        </Route>
        <Route path="/permissions">
          <ProtectedRoute component={Permissions} requiredRoles={['super_admin']} />
        </Route>
        <Route path="/support">
          <ProtectedRoute component={MerchantSupport} requiredRoles={['merchant']} />
        </Route>
        <Route path="/dispatch">
          <ProtectedRoute component={Dispatch} requiredRoles={['super_admin','branch_manager','operations']} permission="dispatch.manage" />
        </Route>
        <Route path="/analytics">
          <ProtectedRoute component={Analytics} requiredRoles={['super_admin','accountant','branch_manager','operations','merchant']} permission="analytics.view" />
        </Route>
        <Route path="/integrations">
          <ProtectedRoute component={Integrations} requiredRoles={['merchant']} permission="integrations.manage" />
        </Route>
        <Route path="/settings">
          <ProtectedRoute component={Settings} requiredRoles={['super_admin']} />
        </Route>
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/track" component={TrackOrder} />
      {/* Driver-only mobile dashboard — no AppLayout wrapper */}
      <Route path="/driver-dashboard">
        <ProtectedRoute component={DriverDashboard} requiredRoles={['driver']} />
      </Route>
      {/* All other protected routes inside AppLayout */}
      <Route path="/.*">
        <AdminRouter />
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
    <OfflineBanner />
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthProvider>
            <Router />
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;
