import { useCallback, useEffect, useRef, useState } from 'react';

export type GpsState = 'idle' | 'acquiring' | 'active' | 'denied' | 'unavailable' | 'offline';

export interface LiveLocationInfo {
  state: GpsState;
  lastSentAt: number | null;
  queued: number;
  accuracy: number | null;
}

interface QueuedPoint {
  lat: number;
  lng: number;
  accuracy?: number;
  speed?: number;
  heading?: number;
  recordedAt: string;
}

const QUEUE_KEY = 'al-ghazali-gps-queue';
const MIN_SEND_MS = 10_000;        // never report more often than this…
const MIN_MOVE_M = 20;             // …unless the driver actually moved this far
const HEARTBEAT_MS = 30_000;       // keep the dispatcher's "live" dot green while parked
const MAX_USEFUL_ACCURACY_M = 150; // ignore coarse fixes (cell-tower / Wi-Fi guesses)
const MAX_QUEUE = 300;             // offline buffer (~50 min of movement)
const BATCH = 100;

function distanceM(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371000;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const x = Math.sin(dLat / 2) ** 2 + Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

function loadQueue(): QueuedPoint[] {
  try {
    const raw = localStorage.getItem(QUEUE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.slice(-MAX_QUEUE) : [];
  } catch {
    return [];
  }
}

function saveQueue(queue: QueuedPoint[]) {
  try {
    localStorage.setItem(QUEUE_KEY, JSON.stringify(queue.slice(-MAX_QUEUE)));
  } catch { /* storage full / private mode: tracking just won't survive a reload */ }
}

/**
 * Streams the driver's GPS position to the dispatcher while `enabled`.
 *  - throttled (time + distance) and accuracy-filtered, so it neither floods the server nor reports junk
 *  - heartbeat so a parked driver still shows as live
 *  - offline buffer: points are queued locally and sent as a batch when the connection returns
 *  - keeps the screen awake (Wake Lock) so the OS does not suspend GPS mid-route
 */
export function useLiveLocation(enabled: boolean): LiveLocationInfo {
  const [info, setInfo] = useState<LiveLocationInfo>({ state: 'idle', lastSentAt: null, queued: 0, accuracy: null });
  const lastSentRef = useRef<{ lat: number; lng: number; at: number } | null>(null);
  const flushingRef = useRef(false);

  const patch = useCallback((p: Partial<LiveLocationInfo>) => setInfo((prev) => ({ ...prev, ...p })), []);

  const flush = useCallback(async () => {
    if (flushingRef.current) return;
    flushingRef.current = true;
    try {
      let queue = loadQueue();
      while (queue.length > 0) {
        if (!navigator.onLine) { patch({ state: 'offline', queued: queue.length }); return; }
        const batch = queue.slice(0, BATCH);
        const token = localStorage.getItem('al-ghazali-token');
        let res: Response;
        try {
          res = await fetch('/api/tracking/location', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
            body: JSON.stringify({ points: batch }),
          });
        } catch {
          patch({ state: 'offline', queued: queue.length }); // network error: keep the queue
          return;
        }
        if (res.ok) {
          queue = queue.slice(batch.length);
          saveQueue(queue);
          patch({ state: 'active', lastSentAt: Date.now(), queued: queue.length });
        } else if (res.status === 429 || res.status >= 500) {
          patch({ queued: queue.length }); // try again later
          return;
        } else if (res.status === 401 || res.status === 403 || res.status === 423 || res.status === 503) {
          return; // session ended / system locked — nothing useful to do
        } else {
          queue = queue.slice(batch.length); // rejected as invalid: drop it, don't retry forever
          saveQueue(queue);
          patch({ queued: queue.length });
        }
      }
    } finally {
      flushingRef.current = false;
    }
  }, [patch]);

  useEffect(() => {
    if (!enabled) { patch({ state: 'idle' }); return; }
    if (!('geolocation' in navigator)) { patch({ state: 'unavailable' }); return; }

    patch({ state: 'acquiring', queued: loadQueue().length });
    let cancelled = false;

    const handleFix = (position: GeolocationPosition) => {
      if (cancelled) return;
      const { latitude, longitude, accuracy, speed, heading } = position.coords;
      patch({ accuracy: Math.round(accuracy) });
      if (accuracy > MAX_USEFUL_ACCURACY_M) { patch({ state: 'acquiring' }); return; }

      const now = Date.now();
      const last = lastSentRef.current;
      const moved = last ? distanceM(last, { lat: latitude, lng: longitude }) : Infinity;
      const elapsed = last ? now - last.at : Infinity;
      if (!(elapsed >= HEARTBEAT_MS || (elapsed >= MIN_SEND_MS && moved >= MIN_MOVE_M))) return;

      lastSentRef.current = { lat: latitude, lng: longitude, at: now };
      const point: QueuedPoint = {
        lat: latitude,
        lng: longitude,
        accuracy: Math.round(accuracy),
        ...(typeof speed === 'number' && Number.isFinite(speed) && speed >= 0 ? { speed } : {}),
        ...(typeof heading === 'number' && Number.isFinite(heading) ? { heading } : {}),
        recordedAt: new Date(position.timestamp || now).toISOString(),
      };
      const queue = loadQueue();
      queue.push(point);
      saveQueue(queue);
      patch({ queued: queue.length });
      void flush();
    };

    const handleError = (err: GeolocationPositionError) => {
      if (cancelled) return;
      if (err.code === err.PERMISSION_DENIED) patch({ state: 'denied' });
      else if (err.code === err.POSITION_UNAVAILABLE) patch({ state: 'unavailable' });
      // TIMEOUT: keep waiting, the next fix will recover on its own
    };

    const watchId = navigator.geolocation.watchPosition(handleFix, handleError, {
      enableHighAccuracy: true,
      maximumAge: 5_000,
      timeout: 30_000,
    });

    // watchPosition may stay silent while the phone is stationary; poll so the position still refreshes.
    const heartbeat = window.setInterval(() => {
      navigator.geolocation.getCurrentPosition(handleFix, handleError, {
        enableHighAccuracy: true, maximumAge: 20_000, timeout: 15_000,
      });
    }, HEARTBEAT_MS);

    const onOnline = () => void flush();
    const onOffline = () => patch({ state: 'offline' });
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    void flush(); // send anything left over from a previous session

    // Keep the screen on while delivering (best effort; unsupported browsers just skip it).
    let wakeLock: any = null;
    const acquireWakeLock = async () => {
      try {
        if ('wakeLock' in navigator && document.visibilityState === 'visible') {
          wakeLock = await (navigator as any).wakeLock.request('screen');
        }
      } catch { /* denied (e.g. battery saver) */ }
    };
    const onVisible = () => { if (document.visibilityState === 'visible') void acquireWakeLock(); };
    document.addEventListener('visibilitychange', onVisible);
    void acquireWakeLock();

    return () => {
      cancelled = true;
      navigator.geolocation.clearWatch(watchId);
      window.clearInterval(heartbeat);
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
      document.removeEventListener('visibilitychange', onVisible);
      try { wakeLock?.release?.(); } catch { /* ignore */ }
    };
  }, [enabled, flush, patch]);

  return info;
}
