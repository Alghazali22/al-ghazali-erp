import { useQuery, useQueryClient } from '@tanstack/react-query';
import { apiFetch } from '@/lib/extra-api';

export type ShiftStatus = 'off' | 'available' | 'break' | 'on_trip';

export interface ShiftMe {
  status: ShiftStatus;
  shift: { id: number; startedAt: string; onBreak: boolean; breakMinutes: number; queuedAt: string } | null;
  queue: { position: number | null; size: number } | null;
  activeTripId: number | null;
  pendingTrip: { id: number; orderCount: number; loadedCount: number; totalToCollect: number; ready: boolean; acceptedAt: string | null } | null;
  cashBalance: number;
  today: { deliveredCount: number; returnedCount: number; collectedAmount: number };
}

export const SHIFT_KEY = ['shift-me'];

/** The courier's duty state, rotation position and any trip waiting for acknowledgement. */
export function useShift(enabled = true) {
  const qc = useQueryClient();
  const query = useQuery({
    queryKey: SHIFT_KEY,
    queryFn: () => apiFetch<ShiftMe>('/shifts/me'),
    enabled,
    // Faster while a trip is being loaded or waits for the courier to accept.
    refetchInterval: (q) => {
      const d = q.state.data as ShiftMe | undefined;
      if (!d) return 15_000;
      if (d.pendingTrip && !d.pendingTrip.acceptedAt) return 5_000;
      if (d.status === 'on_trip') return 10_000;
      return 15_000;
    },
  });
  const refresh = () => qc.invalidateQueries({ queryKey: SHIFT_KEY });
  return { ...query, refresh };
}
