import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { setAuthTokenGetter } from "@workspace/api-client-react";

setAuthTokenGetter(() => localStorage.getItem("al-ghazali-token"));

// Single place that notices an expired / revoked session (any API call, generated hooks
// or raw fetch) and tells the app to sign out. Login failures are excluded.
const originalFetch = window.fetch.bind(window);
window.fetch = async (...args: Parameters<typeof fetch>) => {
  const response = await originalFetch(...args);
  if (response.status === 401) {
    const input = args[0];
    const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
    if (url.includes("/api/") && !url.includes("/auth/login") && localStorage.getItem("al-ghazali-token")) {
      window.dispatchEvent(new Event("auth:expired"));
    }
  }
  return response;
};

createRoot(document.getElementById("root")!).render(<App />);
