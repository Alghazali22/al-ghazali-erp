import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Plus, AlertTriangle, Clock, Send, Loader2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { apiFetch } from '@/lib/extra-api';
import { TICKET_TYPES, PRIORITIES, TICKET_STATUSES, NOTE_KIND_LABELS } from '@/lib/support';

interface TicketRow {
  id: number; type: string; priority: string; status: string; subject: string; orderNumber: string | null; customerName: string | null;
  assigneeId: number | null; assigneeName: string | null; createdByName: string | null; dueAt: string; createdAt: string; overdue: boolean;
}
interface TicketDetail extends TicketRow {
  order: { orderNumber: string; customerName: string; customerPhone: string; governorate: string; area: string; status: string } | null;
  notes: { id: number; kind: string; body: string; authorName: string; createdAt: string }[];
}

const fmt = (iso: string) => new Date(iso).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short', timeZone: 'Africa/Cairo' });
const dueText = (iso: string) => {
  const m = Math.round((new Date(iso).getTime() - Date.now()) / 60_000);
  const abs = Math.abs(m);
  const t = abs < 60 ? `${abs} د` : `${Math.floor(abs / 60)} س`;
  return m >= 0 ? `متبقي ${t}` : `متأخرة ${t}`;
};

function TicketDetailDialog({ ticketId, merchant, onClose }: { ticketId: number | null; merchant: boolean; onClose: () => void }) {
  const { can } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const manage = !merchant && can('support.manage');
  const [reply, setReply] = useState('');
  const [kind, setKind] = useState('note');
  const [busy, setBusy] = useState(false);

  const { data: t } = useQuery({ queryKey: ['ticket', ticketId], queryFn: () => apiFetch<TicketDetail>(`/support/tickets/${ticketId}`), enabled: ticketId !== null, refetchInterval: 15_000 });
  const { data: agents = [] } = useQuery({ queryKey: ['support-agents'], queryFn: () => apiFetch<{ id: number; fullName: string }[]>('/support/agents'), enabled: manage });

  const refresh = () => { qc.invalidateQueries({ queryKey: ['ticket', ticketId] }); qc.invalidateQueries({ queryKey: ['tickets'] }); };
  const patch = async (body: object) => {
    try { await apiFetch(`/support/tickets/${ticketId}`, { method: 'PATCH', body: JSON.stringify(body) }); refresh(); }
    catch (e: any) { toast({ variant: 'destructive', title: 'تعذر التحديث', description: e.message }); }
  };
  const send = async () => {
    setBusy(true);
    try {
      await apiFetch(`/support/tickets/${ticketId}/notes`, { method: 'POST', body: JSON.stringify({ body: reply, kind: merchant ? 'reply' : kind }) });
      setReply(''); refresh();
    } catch (e: any) { toast({ variant: 'destructive', title: 'تعذر الإرسال', description: e.message }); }
    finally { setBusy(false); }
  };
  const closed = t ? ['resolved', 'closed'].includes(t.status) : false;

  return (
    <Dialog open={ticketId !== null} onOpenChange={(v) => { if (!v) onClose(); }}>
      <DialogContent className="sm:max-w-xl max-h-[92vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle>{t ? `#${t.id} — ${t.subject}` : '...'}</DialogTitle>
          <DialogDescription>{t ? `${TICKET_TYPES[t.type]} • فُتحت ${fmt(t.createdAt)}${t.createdByName ? ` بواسطة ${t.createdByName}` : ''}` : ''}</DialogDescription>
        </DialogHeader>
        {!t ? <div className="h-24 rounded-lg bg-muted/20 animate-pulse" /> : (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <Badge variant="outline" className={PRIORITIES[t.priority]?.cls}>{PRIORITIES[t.priority]?.label}</Badge>
              <Badge variant="outline">{TICKET_STATUSES[t.status]}</Badge>
              {!closed && <span className={`flex items-center gap-1 ${t.overdue ? 'text-destructive font-semibold' : 'text-muted-foreground'}`}>{t.overdue ? <AlertTriangle className="w-3.5 h-3.5" /> : <Clock className="w-3.5 h-3.5" />}{dueText(t.dueAt)}</span>}
              {t.order && <span className="mr-auto font-mono text-primary">{t.order.orderNumber} — {t.order.customerName}</span>}
            </div>

            {manage && (
              <div className="grid grid-cols-3 gap-2">
                <select value={t.status} onChange={(e) => patch({ status: e.target.value })} className="h-9 rounded-md border border-border bg-background/50 px-2 text-sm">
                  {Object.entries(TICKET_STATUSES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
                <select value={t.priority} onChange={(e) => patch({ priority: e.target.value })} className="h-9 rounded-md border border-border bg-background/50 px-2 text-sm">
                  {Object.entries(PRIORITIES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                </select>
                <select value={t.assigneeId ?? ''} onChange={(e) => patch({ assigneeId: e.target.value ? Number(e.target.value) : null })} className="h-9 rounded-md border border-border bg-background/50 px-2 text-sm">
                  <option value="">غير مُسندة</option>
                  {agents.map((a) => <option key={a.id} value={a.id}>{a.fullName}</option>)}
                </select>
              </div>
            )}

            <div className="space-y-2">
              {t.notes.length === 0 && <p className="text-xs text-muted-foreground">لا توجد رسائل بعد</p>}
              {t.notes.map((n) => (
                <div key={n.id} className={`rounded-lg px-3 py-2 text-sm ${n.kind === 'status' ? 'bg-muted/10 text-muted-foreground text-xs' : n.kind === 'reply' ? 'bg-primary/10' : 'bg-muted/25'}`}>
                  <div className="flex justify-between text-[11px] text-muted-foreground"><span>{NOTE_KIND_LABELS[n.kind] ?? n.kind} — {n.authorName}</span><span>{fmt(n.createdAt)}</span></div>
                  <p className="mt-0.5 whitespace-pre-wrap">{n.body}</p>
                </div>
              ))}
            </div>

            {(merchant ? !closed : manage || can('support.view')) && !(merchant && closed) && (
              <div className="space-y-2">
                <textarea value={reply} onChange={(e) => setReply(e.target.value)} rows={3} maxLength={1500} placeholder={merchant ? 'اكتب رسالتك لفريق الدعم...' : 'اكتب ردّاً أو ملاحظة...'}
                  className="w-full rounded-md border border-border bg-background/50 p-3 text-sm outline-none focus:border-primary" />
                <div className="flex gap-2">
                  {!merchant && manage && (
                    <select value={kind} onChange={(e) => setKind(e.target.value)} className="h-9 rounded-md border border-border bg-background/50 px-2 text-sm">
                      <option value="note">ملاحظة داخلية</option><option value="reply">رد ظاهر للتاجر</option><option value="call">مكالمة</option><option value="whatsapp">واتساب</option>
                    </select>
                  )}
                  <Button className="mr-auto" size="sm" disabled={busy || !reply.trim() || (!merchant && !manage)} onClick={send}>
                    {busy ? <Loader2 className="w-4 h-4 animate-spin ml-1" /> : <Send className="w-4 h-4 ml-1" />} إرسال
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

/** Ticket list + creation, used by the care team (staff) and by merchants (their own tickets only). */
export function TicketsPanel({ merchant = false }: { merchant?: boolean }) {
  const { can } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [filter, setFilter] = useState<'active' | 'mine' | 'unassigned' | 'all'>('active');
  const [openId, setOpenId] = useState<number | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({ orderNumber: '', type: merchant ? 'complaint' : 'complaint', priority: 'normal', subject: '', description: '' });
  const [saving, setSaving] = useState(false);

  const query = filter === 'active' ? '?status=active' : filter === 'mine' ? '?status=active&mine=1' : filter === 'unassigned' ? '?status=active&unassigned=1' : '';
  const { data: tickets = [], isLoading } = useQuery({ queryKey: ['tickets', filter], queryFn: () => apiFetch<TicketRow[]>(`/support/tickets${query}`), refetchInterval: 20_000 });
  const overdue = tickets.filter((t) => t.overdue).length;

  const create = async () => {
    setSaving(true);
    try {
      await apiFetch('/support/tickets', { method: 'POST', body: JSON.stringify({ ...form, orderNumber: form.orderNumber.trim() || undefined, description: form.description || undefined }) });
      toast({ title: 'تم فتح التذكرة' });
      setCreateOpen(false); setForm({ ...form, subject: '', description: '', orderNumber: '' });
      qc.invalidateQueries({ queryKey: ['tickets'] });
    } catch (e: any) { toast({ variant: 'destructive', title: 'تعذر فتح التذكرة', description: e.message }); }
    finally { setSaving(false); }
  };

  const filters = merchant ? [['active', 'المفتوحة'], ['all', 'الكل']] as const
    : [['active', 'المفتوحة'], ['mine', 'مُسندة لي'], ['unassigned', 'غير مُسندة'], ['all', 'الكل']] as const;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="inline-flex rounded-lg border border-border/50 overflow-hidden text-sm">
          {filters.map(([k, label]) => (
            <button key={k} type="button" onClick={() => setFilter(k as typeof filter)} className={`px-3 py-1.5 ${filter === k ? 'bg-primary text-primary-foreground' : 'bg-card/60 text-muted-foreground hover:text-foreground'}`}>{label}</button>
          ))}
        </div>
        {overdue > 0 && <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/30"><AlertTriangle className="w-3.5 h-3.5 ml-1" />{overdue} متأخرة عن الموعد</Badge>}
        {can('support.create_ticket') && <Button size="sm" className="mr-auto" onClick={() => setCreateOpen(true)}><Plus className="w-4 h-4 ml-1" /> {merchant ? 'تواصل مع الدعم' : 'تذكرة جديدة'}</Button>}
      </div>

      {isLoading ? <div className="h-24 rounded-xl bg-muted/20 animate-pulse" /> : tickets.length === 0 ? (
        <p className="text-center text-muted-foreground py-10 text-sm">{merchant ? 'لا توجد تذاكر. لو عندك مشكلة في شحنة اضغط «تواصل مع الدعم».' : 'لا توجد تذاكر في هذا العرض'}</p>
      ) : (
        <div className="space-y-2">
          {tickets.map((t) => (
            <Card key={t.id} className={`cursor-pointer hover:border-primary/40 transition-colors ${t.overdue ? 'border-destructive/40' : 'border-border/40'} bg-card/60`} onClick={() => setOpenId(t.id)}>
              <CardContent className="p-3 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-sm">
                <span className="text-muted-foreground font-mono">#{t.id}</span>
                <span className="font-semibold flex-1 min-w-[10rem] truncate">{t.subject}</span>
                <Badge variant="outline" className="text-[10px]">{TICKET_TYPES[t.type]}</Badge>
                <Badge variant="outline" className={`${PRIORITIES[t.priority]?.cls} text-[10px]`}>{PRIORITIES[t.priority]?.label}</Badge>
                <Badge variant="outline" className="text-[10px]">{TICKET_STATUSES[t.status]}</Badge>
                {t.orderNumber && <span className="font-mono text-xs text-primary">{t.orderNumber}</span>}
                {!merchant && <span className="text-xs text-muted-foreground">{t.assigneeName ?? 'غير مُسندة'}</span>}
                {!['resolved', 'closed'].includes(t.status) && <span className={`text-xs ${t.overdue ? 'text-destructive font-semibold' : 'text-muted-foreground'}`}>{dueText(t.dueAt)}</span>}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <TicketDetailDialog ticketId={openId} merchant={merchant} onClose={() => setOpenId(null)} />

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="sm:max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>{merchant ? 'تواصل مع الدعم' : 'تذكرة جديدة'}</DialogTitle>
            <DialogDescription>صِف المشكلة وسنتابعها. اربطها برقم الشحنة لو متعلقة بشحنة.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Input dir="ltr" className="font-mono" placeholder="رقم الشحنة (اختياري) ALG-..." value={form.orderNumber} onChange={(e) => setForm({ ...form, orderNumber: e.target.value })} />
            <div className="flex gap-2">
              <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className="h-10 flex-1 rounded-md border border-border bg-background/50 px-2 text-sm">
                {Object.entries(TICKET_TYPES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
              {!merchant && (
                <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })} className="h-10 flex-1 rounded-md border border-border bg-background/50 px-2 text-sm">
                  {Object.entries(PRIORITIES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                </select>
              )}
            </div>
            <Input placeholder="عنوان المشكلة" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} maxLength={140} />
            <textarea rows={4} placeholder="التفاصيل" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} maxLength={1500}
              className="w-full rounded-md border border-border bg-background/50 p-3 text-sm outline-none focus:border-primary" />
            <Button className="w-full" disabled={saving || form.subject.trim().length < 3} onClick={create}>{saving ? 'جاري الإرسال...' : 'إرسال'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
