import React, { useState, useEffect, useRef } from 'react';
import { Play, Coffee, Square, Clock, Hourglass, PackageCheck, Loader2, Banknote, CheckCircle2, Truck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { apiFetch } from '@/lib/extra-api';
import type { ShiftMe } from '@/hooks/use-shift';

const minutesSince = (iso: string) => Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60_000));
const fmtDuration = (m: number) => (m < 60 ? `${m} دقيقة` : `${Math.floor(m / 60)} ساعة${m % 60 ? ` و${m % 60} د` : ''}`);

/** Courier-side shift control: start / break / end, rotation position, and acknowledging a loaded trip. */
export function ShiftPanel({ me, onChange }: { me: ShiftMe; onChange: () => void }) {
  const { toast } = useToast();
  const [busy, setBusy] = useState<string | null>(null);
  const [endOpen, setEndOpen] = useState(false);

  const call = async (key: string, path: string, body?: unknown, okTitle?: string) => {
    setBusy(key);
    try {
      const res = await apiFetch<any>(path, { method: 'POST', body: body ? JSON.stringify(body) : undefined });
      if (okTitle) toast({ title: okTitle });
      onChange();
      return res;
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر تنفيذ الإجراء', description: e.message });
      return null;
    } finally {
      setBusy(null);
    }
  };

  // ---- not on duty ----
  if (me.status === 'off') {
    return (
      <div className="rounded-2xl border border-primary/30 bg-primary/5 p-5 text-center space-y-3">
        <div className="w-14 h-14 rounded-full bg-primary/15 text-primary flex items-center justify-center mx-auto"><Play className="w-7 h-7" /></div>
        <div>
          <p className="font-bold text-lg">أنت خارج الشيفت</p>
          <p className="text-sm text-muted-foreground mt-1">ابدأ شيفتك لتدخل في دور التوزيع وتستلم الشحنات. موقعك يُشارَك مع الإدارة أثناء الشيفت فقط.</p>
        </div>
        <Button size="lg" className="w-full h-12 text-base" disabled={busy === 'start'} onClick={() => call('start', '/shifts/start', undefined, 'تم بدء الشيفت — بالتوفيق!')}>
          {busy === 'start' ? <Loader2 className="w-5 h-5 animate-spin ml-2" /> : <Play className="w-5 h-5 ml-2" />} ابدأ الشيفت
        </Button>
      </div>
    );
  }

  const onBreak = me.status === 'break';
  const onTrip = me.status === 'on_trip';
  const startedMin = me.shift ? minutesSince(me.shift.startedAt) : 0;
  const waitingMin = me.shift && me.status === 'available' ? minutesSince(me.shift.queuedAt) : 0;

  const pending = me.pendingTrip;
  const alertedRef = useRef<string | null>(null);
  useEffect(() => {
    if (!pending?.ready || pending.acceptedAt) return;
    const key = `${pending.id}:${pending.loadedCount}`;
    if (alertedRef.current === key) return;
    alertedRef.current = key;
    try {
      const Ctx = window.AudioContext || (window as any).webkitAudioContext;
      if (Ctx) {
        const ctx = new Ctx();
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = 'sine'; o.frequency.value = 880;
        g.gain.value = 0.08;
        o.connect(g); g.connect(ctx.destination);
        o.start();
        setTimeout(() => { o.stop(); ctx.close(); }, 220);
        setTimeout(() => {
          const ctx2 = new Ctx();
          const o2 = ctx2.createOscillator();
          const g2 = ctx2.createGain();
          o2.type = 'sine'; o2.frequency.value = 1175;
          g2.gain.value = 0.08;
          o2.connect(g2); g2.connect(ctx2.destination);
          o2.start();
          setTimeout(() => { o2.stop(); ctx2.close(); }, 280);
        }, 260);
      }
      if (navigator.vibrate) navigator.vibrate([80, 40, 80]);
    } catch { /* ignore */ }
  }, [pending?.id, pending?.ready, pending?.acceptedAt, pending?.loadedCount]);

  return (
    <div className="space-y-3">
      <div className="rounded-2xl border border-border/50 bg-card/70 p-4 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${onTrip ? 'bg-orange-500' : onBreak ? 'bg-amber-500' : 'bg-emerald-500 animate-pulse'}`} />
            <span className="font-bold">{onTrip ? 'في رحلة توصيل' : onBreak ? 'في استراحة' : 'متاح في الدور'}</span>
          </div>
          <span className="text-xs text-muted-foreground flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> الشيفت من {fmtDuration(startedMin)}</span>
        </div>

        {me.status === 'available' && me.queue && (
          <div className="rounded-xl bg-primary/10 px-4 py-3 flex items-center gap-4">
            <div className="text-center">
              <div className="text-3xl font-extrabold text-primary leading-none">{me.queue.position ?? '—'}</div>
              <div className="text-[11px] text-muted-foreground mt-1">ترتيبك</div>
            </div>
            <div className="text-sm flex-1">
              {me.queue.position === 1
                ? <b className="text-primary">الدور عليك الآن — انتظر الإسناد من الفرع</b>
                : <>أمامك <b>{(me.queue.position ?? 1) - 1}</b> {((me.queue.position ?? 1) - 1) === 1 ? 'مندوب' : 'مناديب'} من أصل {me.queue.size} في الانتظار</>}
              <div className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5"><Hourglass className="w-3 h-3" /> بتنتظر من {fmtDuration(waitingMin)}</div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          <div className="rounded-lg bg-background/50 py-2"><div className="font-bold text-base text-emerald-500">{me.today.deliveredCount}</div>تم تسليمها</div>
          <div className="rounded-lg bg-background/50 py-2"><div className="font-bold text-base text-destructive">{me.today.returnedCount}</div>مرتجعة</div>
          <div className="rounded-lg bg-background/50 py-2"><div className="font-bold text-base font-mono">{Math.round(me.cashBalance)}</div>كاش معك ج.م</div>
        </div>

        <div className="flex gap-2">
          {!onTrip && (
            <Button variant="outline" className="flex-1" disabled={busy === 'break'} onClick={() => call('break', '/shifts/break', { action: onBreak ? 'end' : 'start' }, onBreak ? 'أهلاً بعودتك — رجعت لآخر الدور' : 'استمتع باستراحتك')}>
              {busy === 'break' ? <Loader2 className="w-4 h-4 animate-spin ml-1.5" /> : <Coffee className="w-4 h-4 ml-1.5" />} {onBreak ? 'العودة من الاستراحة' : 'استراحة'}
            </Button>
          )}
          <Button variant="outline" className="flex-1 border-destructive/40 text-destructive hover:bg-destructive/10" onClick={() => setEndOpen(true)}>
            <Square className="w-4 h-4 ml-1.5" /> إنهاء الشيفت
          </Button>
        </div>
      </div>

      {/* ---- a trip is being prepared for me ---- */}
      {pending && !onTrip && (
        <div className="rounded-2xl border border-orange-500/30 bg-orange-500/5 p-4 space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-500/15 text-orange-500 flex items-center justify-center shrink-0"><Truck className="w-5 h-5" /></div>
            <div className="flex-1">
              <p className="font-bold">رحلة جديدة لك: {pending.orderCount} شحنة</p>
              <p className="text-sm text-muted-foreground">إجمالي التحصيل المتوقع <b className="text-foreground">{Math.round(pending.totalToCollect).toLocaleString('en-US')} ج.م</b></p>
            </div>
          </div>
          {!pending.ready ? (
            <div className="space-y-1.5">
              <div className="h-2 rounded-full bg-muted overflow-hidden"><div className="h-full bg-orange-500 transition-all" style={{ width: `${(pending.loadedCount / pending.orderCount) * 100}%` }} /></div>
              <p className="text-xs text-muted-foreground flex items-center gap-1.5"><Loader2 className="w-3.5 h-3.5 animate-spin" /> جاري تحميل شحناتك… {pending.loadedCount} من {pending.orderCount}</p>
            </div>
          ) : pending.acceptedAt ? (
            <p className="text-sm text-emerald-500 flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4" /> أكدت الاستلام — بانتظار تحرّكك من الفرع</p>
          ) : (
            <>
              <p className="text-xs text-muted-foreground">عُدّ الشحنات في الحقيبة وتأكد أنها {pending.orderCount} بالضبط قبل التأكيد — بعد التأكيد تتحمل مسؤوليتها.</p>
              <Button className="w-full h-11" disabled={busy === 'accept'} onClick={() => call('accept', `/trips/${pending.id}/accept`, undefined, 'تم تأكيد الاستلام')}>
                {busy === 'accept' ? <Loader2 className="w-4 h-4 animate-spin ml-2" /> : <PackageCheck className="w-4 h-4 ml-2" />} استلمت الشحنات كاملة ({pending.orderCount})
              </Button>
            </>
          )}
        </div>
      )}

      {/* ---- end shift ---- */}
      <Dialog open={endOpen} onOpenChange={setEndOpen}>
        <DialogContent className="sm:max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle>إنهاء الشيفت؟</DialogTitle>
            <DialogDescription>ملخص شيفتك حتى الآن</DialogDescription>
          </DialogHeader>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">مدة الشيفت</span><b>{fmtDuration(startedMin)}</b></div>
            <div className="flex justify-between"><span className="text-muted-foreground">تم تسليمها</span><b className="text-emerald-500">{me.today.deliveredCount}</b></div>
            <div className="flex justify-between"><span className="text-muted-foreground">مرتجعة</span><b>{me.today.returnedCount}</b></div>
            <div className="flex justify-between"><span className="text-muted-foreground">تحصيل الشيفت</span><b className="font-mono">{Math.round(me.today.collectedAmount)} ج.م</b></div>
            {me.cashBalance > 0 && (
              <div className="rounded-lg bg-amber-500/10 border border-amber-500/20 p-3 text-amber-500 flex items-start gap-2">
                <Banknote className="w-4 h-4 mt-0.5 shrink-0" />
                <span>معك كاش <b>{Math.round(me.cashBalance)} ج.م</b> لازم تسلّمه للمحاسب في الفرع قبل ما تمشي.</span>
              </div>
            )}
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setEndOpen(false)}>رجوع</Button>
            <Button variant="destructive" disabled={busy === 'end'} onClick={async () => { const r = await call('end', '/shifts/end', undefined, 'تم إنهاء الشيفت'); if (r) setEndOpen(false); }}>
              {busy === 'end' ? 'جاري الإنهاء...' : 'إنهاء الشيفت'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
