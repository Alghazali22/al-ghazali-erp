import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ClipboardPaste, FileSpreadsheet, Link2, MessageSquareText, Download, Trash2, Plus, XCircle, AlertTriangle,
  CheckCircle2, Wand2, Loader2, Send, MessageCircle, Eraser,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { apiFetch } from '@/lib/extra-api';
import { parseCsv, templateCsv } from '@/lib/csv';
import { readXlsx } from '@/lib/xlsx';
import { parseCustomerBlocks } from '@/lib/smartParse';
import { whatsappUrl } from '@/lib/share';
import type { ZoneLite } from '@/lib/zoneMatch';
import { BatchSuccess, type CreatedOrder } from '@/components/BatchSuccess';
import {
  GRID_COLUMNS, emptyRow, isBlankRow, normalizeRow, validateRow, signature, looksLikeHeader, rowsFromTable,
  type GridRow, type EditableKey, type RowIssue,
} from '@/lib/orderRows';
import { normalizeEgyptPhone } from '@/lib/egypt';

interface Confidence { score: number; level: 'high' | 'medium' | 'low'; reasons: { text: string; impact: number }[]; advice: string | null }
interface Preview {
  sig: string;
  ok: boolean;
  error?: string;
  duplicate?: boolean;
  shippingFee?: number;
  totalToCollect?: number;
  zoneMatched?: boolean;
  possibleDuplicate?: string | null;
  confidence?: Confidence;
}

const CHUNK_PREVIEW = 200;
const CHUNK_CREATE = 100;
const MIN_ROWS = 5;
const draftKey = (userKey: string | number) => `alg-grid-draft-v1-${userKey}`;

const toPayload = (r: GridRow) => ({
  reference: r.reference || undefined,
  customerName: r.customerName,
  customerPhone: normalizeEgyptPhone(r.customerPhone) ?? r.customerPhone,
  customerPhone2: r.customerPhone2 ? normalizeEgyptPhone(r.customerPhone2) ?? r.customerPhone2 : undefined,
  governorate: r.governorate,
  area: r.area,
  customerAddress: r.customerAddress,
  packageValue: Number(r.packageValue),
  notes: r.notes || undefined,
});

const CONF_STYLE = {
  high: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/30',
  medium: 'bg-amber-500/10 text-amber-500 border-amber-500/30',
  low: 'bg-destructive/10 text-destructive border-destructive/30',
} as const;

export function OrderGrid({ zones, merchantId, merchantName, userKey }: {
  zones: (ZoneLite & { id: number })[];
  merchantId: number | null;
  merchantName: string;
  userKey: string | number;
}) {
  const { toast } = useToast();
  const [rows, setRows] = useState<GridRow[]>(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(draftKey(userKey)) ?? 'null');
      if (Array.isArray(saved) && saved.length) return saved as GridRow[];
    } catch { /* ignore corrupted draft */ }
    return Array.from({ length: MIN_ROWS }, emptyRow);
  });
  const [previews, setPreviews] = useState<Record<string, Preview>>({});
  const [fixedIds, setFixedIds] = useState<Set<string>>(new Set());
  const [filter, setFilter] = useState<'all' | 'risky' | 'errors'>('all');
  const [busy, setBusy] = useState<'create' | 'file' | 'sheet' | null>(null);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);
  const [batch, setBatch] = useState<CreatedOrder[] | null>(null);
  const [waOpen, setWaOpen] = useState(false);
  const [waText, setWaText] = useState('');
  const [sheetOpen, setSheetOpen] = useState(false);
  const [sheetUrl, setSheetUrl] = useState(() => localStorage.getItem('alg-last-sheet-url') ?? '');
  const focus = useRef<{ row: number; col: number } | null>(null);
  const previewRun = useRef(0);
  const fileInput = useRef<HTMLInputElement>(null);

  // ---- draft autosave: a browser crash or accidental refresh never loses a sheet of orders ----
  useEffect(() => {
    const t = setTimeout(() => {
      try {
        const meaningful = rows.filter((r) => !isBlankRow(r));
        if (meaningful.length) localStorage.setItem(draftKey(userKey), JSON.stringify(rows));
        else localStorage.removeItem(draftKey(userKey));
      } catch { /* storage full */ }
    }, 500);
    return () => clearTimeout(t);
  }, [rows, userKey]);

  // Spreadsheet feel: always keep a blank row at the bottom, and never fewer than MIN_ROWS.
  useEffect(() => {
    setRows((prev) => {
      let next = prev;
      if (!prev.length || !isBlankRow(prev[prev.length - 1])) next = [...prev, emptyRow()];
      while (next.length < MIN_ROWS) next = [...next, emptyRow()];
      return next === prev ? prev : next;
    });
  }, [rows]);

  const issues = useMemo(() => {
    const map = new Map<string, RowIssue[]>();
    const phoneCount = new Map<string, number>();
    const refCount = new Map<string, number>();
    for (const r of rows) {
      if (isBlankRow(r)) continue;
      const p = normalizeEgyptPhone(r.customerPhone);
      if (p) phoneCount.set(p, (phoneCount.get(p) ?? 0) + 1);
      if (r.reference) refCount.set(r.reference, (refCount.get(r.reference) ?? 0) + 1);
    }
    for (const r of rows) {
      if (isBlankRow(r)) continue;
      const list = validateRow(r, zones);
      const p = normalizeEgyptPhone(r.customerPhone);
      if (p && (phoneCount.get(p) ?? 0) > 1) list.push({ level: 'warning', message: 'نفس رقم الهاتف مكرر في الجدول', field: 'customerPhone' });
      if (r.reference && (refCount.get(r.reference) ?? 0) > 1) list.push({ level: 'error', message: 'رقم الطلب عندك مكرر في الجدول', field: 'reference' });
      map.set(r.id, list);
    }
    return map;
  }, [rows, zones]);

  const serverErrorOf = useCallback((r: GridRow) => {
    const p = previews[r.id];
    return p && p.ok === false && p.sig === signature(r) ? p.error ?? 'مرفوض من السيرفر' : null; // ignore errors about an older version of the row
  }, [previews]);
  const hasError = useCallback((r: GridRow) => (issues.get(r.id) ?? []).some((i) => i.level === 'error') || !!serverErrorOf(r), [issues, serverErrorOf]);

  // ---- live server preview: price, duplicate warning and delivery-confidence, debounced ----
  useEffect(() => {
    if (!merchantId) return;
    const candidates = rows.filter((r) => !isBlankRow(r) && !(issues.get(r.id) ?? []).some((i) => i.level === 'error') && previews[r.id]?.sig !== signature(r));
    if (!candidates.length) return;
    const run = ++previewRun.current;
    const t = setTimeout(async () => {
      try {
        for (let i = 0; i < candidates.length; i += CHUNK_PREVIEW) {
          const chunk = candidates.slice(i, i + CHUNK_PREVIEW);
          const res = await apiFetch<{ results: any[] }>('/orders/bulk', {
            method: 'POST',
            body: JSON.stringify({ merchantId, dryRun: true, rows: chunk.map(toPayload) }),
          });
          if (run !== previewRun.current) return; // newer edit superseded this run
          setPreviews((prev) => {
            const next = { ...prev };
            res.results.forEach((r, idx) => {
              const row = chunk[idx];
              next[row.id] = r.ok
                ? { sig: signature(row), ok: true, duplicate: r.duplicate, ...(r.preview ?? {}) }
                : { sig: signature(row), ok: false, error: r.error };
            });
            return next;
          });
        }
      } catch { /* preview is best-effort; creation validates again */ }
    }, 900);
    return () => clearTimeout(t);
  }, [rows, issues, merchantId, previews]);

  // ---- editing ----
  const setCell = (rowId: string, key: EditableKey, value: string) =>
    setRows((prev) => prev.map((r) => (r.id === rowId ? { ...r, [key]: value } : r)));

  const cleanRow = (rowId: string) => {
    setRows((prev) => prev.map((r) => {
      if (r.id !== rowId || isBlankRow(r)) return r;
      const { row, fixes } = normalizeRow(r, zones);
      if (fixes.length) setFixedIds((s) => new Set(s).add(rowId));
      return row;
    }));
  };

  const removeRow = (rowId: string) => setRows((prev) => prev.filter((r) => r.id !== rowId));

  const appendRows = (incoming: GridRow[], fixes: number) => {
    if (!incoming.length) { toast({ variant: 'destructive', title: 'لم يتم العثور على بيانات صالحة' }); return; }
    setRows((prev) => [...prev.filter((r) => !isBlankRow(r)), ...incoming]);
    setFixedIds((s) => { const n = new Set(s); incoming.forEach((r) => n.add(r.id)); return n; });
    setBatch(null);
    toast({ title: `تمت إضافة ${incoming.length} صف`, description: fixes ? `وتم تصحيح ${fixes} خطأ تلقائياً (هاتف/منطقة/قيمة)` : undefined });
  };

  const handleTable = (table: string[][], pastedAt?: { row: number; col: number }) => {
    if (!table.length) return;
    const emptyGrid = rows.every(isBlankRow);
    if (!pastedAt || emptyGrid || looksLikeHeader(table[0])) {
      const { rows: imported, fixes } = rowsFromTable(table, zones);
      appendRows(imported, fixes);
      return;
    }
    // Excel-style: drop the block onto the cells starting at the focused cell.
    setRows((prev) => {
      const next = prev.map((r) => ({ ...r }));
      table.forEach((cells, i) => {
        const rowIndex = pastedAt.row + i;
        while (next.length <= rowIndex) next.push(emptyRow());
        cells.forEach((value, j) => {
          const col = GRID_COLUMNS[pastedAt.col + j];
          if (col) next[rowIndex][col.key] = value.trim();
        });
        next[rowIndex] = normalizeRow(next[rowIndex], zones).row;
      });
      return next;
    });
    toast({ title: `تم لصق ${table.length} صف` });
  };

  const onPaste = (e: React.ClipboardEvent) => {
    // React events bubble out of dialogs (portals): only react to pastes made inside the table itself.
    if (!(e.target as HTMLElement).closest?.('[data-order-grid]')) return;
    const text = e.clipboardData.getData('text/plain');
    if (!/[\t\n]/.test(text.trim())) return; // a single value: let the input take it normally
    e.preventDefault();
    handleTable(parseCsv(text), focus.current ?? undefined);
  };

  const pasteFromClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (!text.trim()) { toast({ variant: 'destructive', title: 'الحافظة فارغة', description: 'انسخ الخلايا من Excel أو Google Sheets أولاً' }); return; }
      handleTable(parseCsv(text));
    } catch {
      toast({ title: 'اضغط داخل الجدول ثم Ctrl+V', description: 'المتصفح لم يسمح بقراءة الحافظة تلقائياً' });
    }
  };

  const onFile = async (file: File | undefined) => {
    if (!file) return;
    setBusy('file');
    try {
      const name = file.name.toLowerCase();
      let table: string[][];
      if (name.endsWith('.xlsx')) table = await readXlsx(await file.arrayBuffer());
      else if (name.endsWith('.xls')) throw new Error('صيغة xls القديمة غير مدعومة — احفظ الملف بصيغة xlsx أو CSV');
      else table = parseCsv(await file.text());
      handleTable(table);
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر قراءة الملف', description: e.message });
    } finally {
      setBusy(null);
      if (fileInput.current) fileInput.current.value = '';
    }
  };

  const importSheet = async () => {
    setBusy('sheet');
    try {
      const { csv } = await apiFetch<{ csv: string }>('/import/google-sheet', { method: 'POST', body: JSON.stringify({ url: sheetUrl }) });
      localStorage.setItem('alg-last-sheet-url', sheetUrl);
      setSheetOpen(false);
      handleTable(parseCsv(csv));
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر قراءة الشيت', description: e.message });
    } finally {
      setBusy(null);
    }
  };

  const importWhatsapp = () => {
    const parsed = parseCustomerBlocks(waText, zones);
    const imported = parsed.map((c) => normalizeRow({ ...emptyRow(), ...c }, zones));
    setWaOpen(false);
    setWaText('');
    appendRows(imported.map((x) => x.row), imported.reduce((a, x) => a + x.fixes.length, 0));
  };

  const downloadTemplate = () => {
    const url = URL.createObjectURL(new Blob([templateCsv()], { type: 'text/csv;charset=utf-8' }));
    const a = document.createElement('a');
    a.href = url; a.download = 'orders-template.csv';
    document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  };

  // ---- summary ----
  const filled = rows.filter((r) => !isBlankRow(r));
  const sendable = filled.filter((r) => !hasError(r));
  const totals = sendable.reduce((acc, r) => {
    const p = previews[r.id];
    acc.cod += p?.totalToCollect ?? 0;
    acc.shipping += p?.shippingFee ?? 0;
    if (p?.confidence) { acc.scoreSum += p.confidence.score; acc.scored += 1; if (p.confidence.level === 'low') acc.low += 1; }
    return acc;
  }, { cod: 0, shipping: 0, scoreSum: 0, scored: 0, low: 0 });
  const errorCount = filled.length - sendable.length;

  const visible = rows.filter((r) => {
    if (filter === 'errors') return !isBlankRow(r) && hasError(r);
    if (filter === 'risky') return previews[r.id]?.confidence?.level === 'low' || previews[r.id]?.confidence?.level === 'medium';
    return true;
  });

  // ---- create ----
  const submit = async () => {
    if (!merchantId) return;
    if (errorCount > 0 && !window.confirm(`${errorCount} صف به أخطاء ولن يُرسل. هل تريد إنشاء ${sendable.length} شحنة الصالحة فقط؟`)) return;
    setBusy('create');
    setProgress({ done: 0, total: sendable.length });
    const created: CreatedOrder[] = [];
    const doneIds = new Set<string>();
    const failures: Record<string, Preview> = {};
    try {
      for (let i = 0; i < sendable.length; i += CHUNK_CREATE) {
        const chunk = sendable.slice(i, i + CHUNK_CREATE);
        const res = await apiFetch<{ results: any[] }>('/orders/bulk', {
          method: 'POST',
          body: JSON.stringify({ merchantId, rows: chunk.map(toPayload) }),
        });
        res.results.forEach((r, idx) => {
          const row = chunk[idx];
          if (r.ok && r.order) {
            created.push({ ...r.order });
            doneIds.add(row.id);
          } else if (r.ok && r.duplicate) {
            doneIds.add(row.id); // already imported earlier (same reference): treat as done
          } else {
            failures[row.id] = { sig: signature(row), ok: false, error: r.error };
          }
        });
        setProgress({ done: Math.min(i + CHUNK_CREATE, sendable.length), total: sendable.length });
      }
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'توقف الإنشاء', description: `${e.message} — الصفوف التي لم تُنشأ ما زالت في الجدول` });
    } finally {
      setRows((prev) => prev.filter((r) => !doneIds.has(r.id)));
      setPreviews((prev) => ({ ...prev, ...failures }));
      if (created.length) setBatch(created);
      setBusy(null);
      setProgress(null);
    }
  };

  const clearAll = () => {
    if (filled.length && !window.confirm('مسح كل الصفوف؟')) return;
    setRows(Array.from({ length: MIN_ROWS }, emptyRow));
    setPreviews({});
    setFixedIds(new Set());
    setBatch(null);
  };

  const govList = useMemo(() => [...new Set(zones.map((z) => z.governorate))], [zones]);
  const areasByGov = useMemo(() => {
    const m = new Map<string, string[]>();
    zones.forEach((z) => m.set(z.governorate, [...(m.get(z.governorate) ?? []), z.area]));
    return m;
  }, [zones]);

  const confirmMessage = (r: GridRow, p: Preview) =>
    `مرحباً ${r.customerName} 👋\nمعك ${merchantName}. بنأكد طلبك قبل الشحن:\n📍 ${r.governorate} — ${r.area}\n${r.customerAddress}\n💰 المطلوب تحصيله: ${p.totalToCollect} ج.م\nمن فضلك رد بـ «نعم» لتأكيد الطلب، أو اكتب لنا لو في تعديل. شكراً 🌟`;

  return (
    <div className="space-y-4" onPaste={onPaste}>
      {batch && (
        <BatchSuccess orders={batch} merchantName={merchantName} remainingFailures={errorCount}
          onReset={() => { setBatch(null); }} />
      )}

      {/* ---- import toolbar ---- */}
      <div className="rounded-xl border border-border/40 bg-card/60 p-3 sm:p-4 space-y-3">
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={pasteFromClipboard}><ClipboardPaste className="w-4 h-4 ml-1.5" /> لصق من Excel / Sheets</Button>
          <label className="inline-flex">
            <input ref={fileInput} type="file" accept=".xlsx,.csv,.txt,text/csv" className="hidden" onChange={(e) => void onFile(e.target.files?.[0])} />
            <span className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md border border-border bg-background text-sm font-medium cursor-pointer hover:bg-muted/40">
              {busy === 'file' ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileSpreadsheet className="w-4 h-4" />} رفع ملف Excel / CSV
            </span>
          </label>
          <Button variant="outline" size="sm" onClick={() => setSheetOpen(true)}><Link2 className="w-4 h-4 ml-1.5" /> رابط Google Sheet</Button>
          <Button variant="outline" size="sm" className="border-primary/40 text-primary" onClick={() => setWaOpen(true)}><MessageSquareText className="w-4 h-4 ml-1.5" /> الصق رسائل واتساب</Button>
          <Button variant="ghost" size="sm" onClick={downloadTemplate}><Download className="w-4 h-4 ml-1.5" /> النموذج</Button>
          <Button variant="ghost" size="sm" className="mr-auto text-muted-foreground" onClick={clearAll}><Eraser className="w-4 h-4 ml-1.5" /> مسح الكل</Button>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">
          الأسرع: افتح Excel أو Google Sheets، <b>انسخ الصفوف (Ctrl+C)</b> ثم اضغط داخل الجدول بالأسفل واعمل <b>Ctrl+V</b> — بدون ملفات.
          النظام يصلّح الهواتف والمناطق وقيمة الشحنة تلقائياً ويحسب السعر ومؤشر ثقة التسليم لكل صف.
        </p>
      </div>

      {/* ---- summary ---- */}
      <div className="flex flex-wrap items-center gap-2 text-sm">
        <Badge variant="outline">{filled.length} صف</Badge>
        <Badge variant="outline" className="bg-emerald-500/10 text-emerald-500 border-emerald-500/30">{sendable.length} جاهز</Badge>
        {errorCount > 0 && <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/30">{errorCount} به أخطاء</Badge>}
        {totals.cod > 0 && <span className="text-muted-foreground">تحصيل متوقع <b className="text-foreground">{Math.round(totals.cod).toLocaleString('en-US')} ج.م</b> · شحن <b className="text-foreground">{Math.round(totals.shipping).toLocaleString('en-US')} ج.م</b></span>}
        {totals.scored > 0 && <span className="text-muted-foreground">متوسط ثقة التسليم <b className="text-foreground">{Math.round(totals.scoreSum / totals.scored)}%</b></span>}
        <div className="mr-auto inline-flex rounded-lg border border-border/50 overflow-hidden text-xs">
          {([['all', 'الكل'], ['errors', 'الأخطاء'], ['risky', `تحتاج تأكيد${totals.low ? ` (${totals.low})` : ''}`]] as const).map(([k, label]) => (
            <button key={k} type="button" onClick={() => setFilter(k)} className={`px-3 py-1.5 ${filter === k ? 'bg-primary text-primary-foreground' : 'bg-card/60 text-muted-foreground hover:text-foreground'}`}>{label}</button>
          ))}
        </div>
      </div>

      {/* ---- grid ---- */}
      <div data-order-grid className="rounded-xl border border-border/40 bg-card/40 overflow-x-auto">
        <datalist id="alg-gov-list">{govList.map((g) => <option key={g} value={g} />)}</datalist>
        <table className="w-full text-sm border-separate border-spacing-0">
          <thead className="sticky top-0 z-10 bg-muted/60 backdrop-blur">
            <tr>
              <th className="px-2 py-2 w-9 text-xs text-muted-foreground">#</th>
              {GRID_COLUMNS.map((c) => <th key={c.key} style={{ minWidth: c.width }} className="px-2 py-2 text-right text-xs font-semibold text-muted-foreground whitespace-nowrap">{c.label}</th>)}
              <th className="px-2 py-2 text-xs text-muted-foreground whitespace-nowrap">الشحن</th>
              <th className="px-2 py-2 text-xs text-muted-foreground whitespace-nowrap">الإجمالي</th>
              <th className="px-2 py-2 text-xs text-muted-foreground whitespace-nowrap">ثقة التسليم</th>
              <th className="w-9" />
            </tr>
          </thead>
          <tbody>
            {visible.map((r) => {
              const rowIndex = rows.indexOf(r);
              const list = issues.get(r.id) ?? [];
              const p = previews[r.id];
              const blank = isBlankRow(r);
              const errors = list.filter((i) => i.level === 'error');
              const warnings = list.filter((i) => i.level === 'warning');
              const serverError = serverErrorOf(r);
              const rowOk = !blank && !errors.length && !serverError;
              return (
                <tr key={r.id} className={`border-t border-border/20 ${serverError || errors.length ? 'bg-destructive/5' : ''}`}>
                  <td className="px-2 text-center align-middle">
                    {blank ? <span className="text-xs text-muted-foreground/50">{rowIndex + 1}</span>
                      : serverError || errors.length ? <span title={[...errors.map((i) => i.message), serverError].filter(Boolean).join('\n')}><XCircle className="w-4 h-4 text-destructive mx-auto" /></span>
                      : warnings.length || p?.possibleDuplicate || (p && p.zoneMatched === false) ? <span title={[...warnings.map((i) => i.message), p?.possibleDuplicate ? `يوجد طلب مفتوح لنفس الرقم (${p.possibleDuplicate})` : '', p && p.zoneMatched === false ? 'سعر افتراضي: المنطقة غير مسعّرة' : ''].filter(Boolean).join('\n')}><AlertTriangle className="w-4 h-4 text-amber-500 mx-auto" /></span>
                      : <span title={fixedIds.has(r.id) ? 'تم تصحيح بعض البيانات تلقائياً' : 'جاهز'}>{fixedIds.has(r.id) ? <Wand2 className="w-4 h-4 text-primary mx-auto" /> : <CheckCircle2 className="w-4 h-4 text-emerald-500 mx-auto" />}</span>}
                  </td>
                  {GRID_COLUMNS.map((c, colIndex) => {
                    const cellIssue = list.find((i) => i.field === c.key) ?? null;
                    const border = cellIssue?.level === 'error' ? 'border-destructive/60 bg-destructive/5' : cellIssue ? 'border-amber-500/50' : 'border-transparent';
                    const listId = c.list === 'gov' ? 'alg-gov-list' : c.list === 'area' ? `alg-area-${r.id}` : undefined;
                    return (
                      <td key={c.key} className="p-0.5">
                        <input
                          value={r[c.key]}
                          dir={c.ltr ? 'ltr' : undefined}
                          list={listId}
                          title={cellIssue?.message}
                          onFocus={() => { focus.current = { row: rowIndex, col: colIndex }; }}
                          onChange={(e) => setCell(r.id, c.key, e.target.value)}
                          onBlur={() => cleanRow(r.id)}
                          className={`w-full h-9 px-2 rounded-md bg-background/40 border ${border} focus:border-primary focus:bg-background outline-none text-sm ${c.ltr ? 'text-right' : ''}`}
                          style={{ minWidth: c.width }}
                          aria-label={c.label}
                        />
                        {c.list === 'area' && <datalist id={`alg-area-${r.id}`}>{(areasByGov.get(r.governorate) ?? []).map((a) => <option key={a} value={a} />)}</datalist>}
                      </td>
                    );
                  })}
                  <td className="px-2 text-center font-mono text-xs">{p?.shippingFee ?? ''}</td>
                  <td className="px-2 text-center font-mono text-xs font-bold">{p?.totalToCollect ?? ''}</td>
                  <td className="px-2 text-center">
                    {p?.confidence && rowOk ? (
                      <div className="inline-flex items-center gap-1">
                        <span title={`${p.confidence.reasons.map((x) => `${x.impact > 0 ? '+' : ''}${x.impact} ${x.text}`).join('\n')}${p.confidence.advice ? `\n→ ${p.confidence.advice}` : ''}`}
                          className={`inline-block min-w-[2.6rem] rounded-full border px-2 py-0.5 text-xs font-bold ${CONF_STYLE[p.confidence.level]}`}>{p.confidence.score}%</span>
                        {p.confidence.level !== 'high' && normalizeEgyptPhone(r.customerPhone) && (
                          <a href={whatsappUrl(r.customerPhone, confirmMessage(r, p))} target="_blank" rel="noreferrer" title="اطلب تأكيد العميل على واتساب قبل الشحن"
                            className="text-emerald-500 hover:text-emerald-400"><MessageCircle className="w-4 h-4" /></a>
                        )}
                      </div>
                    ) : null}
                  </td>
                  <td className="px-1 text-center">
                    {!blank && <button type="button" onClick={() => removeRow(r.id)} className="p-1 text-muted-foreground hover:text-destructive" aria-label="حذف الصف"><Trash2 className="w-4 h-4" /></button>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <Button variant="outline" size="sm" onClick={() => setRows((p) => [...p, emptyRow()])}><Plus className="w-4 h-4 ml-1" /> صف</Button>
        <div className="mr-auto flex items-center gap-3">
          {progress && <span className="text-sm text-muted-foreground">جاري الإنشاء {progress.done}/{progress.total}…</span>}
          <Button size="lg" onClick={submit} disabled={!merchantId || sendable.length === 0 || busy === 'create'} className="bg-primary hover:bg-primary/90">
            {busy === 'create' ? <Loader2 className="w-4 h-4 animate-spin ml-2" /> : <Send className="w-4 h-4 ml-2" />}
            إنشاء {sendable.length || ''} شحنة
          </Button>
        </div>
      </div>
      {!merchantId && <p className="text-sm text-amber-500">اختر التاجر أولاً لحساب الأسعار وإنشاء الشحنات.</p>}

      {/* ---- Google Sheet dialog ---- */}
      <Dialog open={sheetOpen} onOpenChange={setSheetOpen}>
        <DialogContent className="sm:max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>استيراد من Google Sheet</DialogTitle>
            <DialogDescription>
              افتح الشيت ← مشاركة ← «أي شخص لديه الرابط» (عارض) ← انسخ الرابط والصقه هنا. نقرأ البيانات فقط ولا نطلب حسابك على جوجل.
            </DialogDescription>
          </DialogHeader>
          <Input dir="ltr" placeholder="https://docs.google.com/spreadsheets/d/..." value={sheetUrl} onChange={(e) => setSheetUrl(e.target.value)} />
          <p className="text-xs text-muted-foreground">لو الشيت فيه عدة أوراق، افتح الورقة المطلوبة قبل نسخ الرابط. الأعمدة: الاسم، الهاتف، المحافظة، المنطقة، العنوان، القيمة (بعناوين أو بدونها).</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSheetOpen(false)}>إلغاء</Button>
            <Button onClick={importSheet} disabled={!sheetUrl.trim() || busy === 'sheet'}>{busy === 'sheet' ? 'جاري القراءة...' : 'استيراد'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ---- WhatsApp paste dialog ---- */}
      <Dialog open={waOpen} onOpenChange={setWaOpen}>
        <DialogContent className="sm:max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><MessageSquareText className="w-5 h-5 text-primary" /> الصق رسائل العملاء</DialogTitle>
            <DialogDescription>الصق بيانات العملاء زي ما وصلتك على واتساب أو فيسبوك — كل عميل يفصله سطر فاضي. النظام يستخرج الاسم والهاتف والعنوان والمحافظة والمنطقة والمبلغ.</DialogDescription>
          </DialogHeader>
          <textarea
            value={waText}
            onChange={(e) => setWaText(e.target.value)}
            rows={9}
            placeholder={'احمد محمد\n01012345678\n15 شارع عباس العقاد مدينة نصر القاهرة\nالمبلغ 350\n\nسارة علي 01112345678 10 شارع الهرم الجيزة 420 جنيه'}
            className="w-full rounded-md border border-border bg-background/50 p-3 text-sm outline-none focus:border-primary"
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setWaOpen(false)}>إلغاء</Button>
            <Button onClick={importWhatsapp} disabled={!waText.trim()}><Wand2 className="w-4 h-4 ml-1.5" /> حلّل وأضف للجدول</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
