import React from 'react';
import { MapPin, MapPinOff, WifiOff, Loader2 } from 'lucide-react';
import type { LiveLocationInfo } from '@/hooks/use-live-location';

/** Tells the driver — in plain words — whether dispatch can currently see them. */
export function GpsStatusBanner({ info }: { info: LiveLocationInfo }) {
  const { state, queued, accuracy } = info;
  if (state === 'idle') return null;

  const config = {
    active:      { tone: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20', Icon: MapPin, text: 'موقعك يصل للإدارة مباشرة', hint: accuracy ? `دقة GPS ≈ ${accuracy} م` : '' },
    acquiring:   { tone: 'bg-amber-500/10 text-amber-500 border-amber-500/20', Icon: Loader2, text: 'جاري تحديد موقعك…', hint: accuracy ? `الإشارة ضعيفة (≈ ${accuracy} م) — اخرج لمكان مفتوح` : 'تأكد أن GPS مفعّل' },
    offline:     { tone: 'bg-orange-500/10 text-orange-500 border-orange-500/20', Icon: WifiOff, text: 'لا يوجد إنترنت — الموقع محفوظ وسيُرسل عند عودة الاتصال', hint: queued ? `${queued} نقطة في الانتظار` : '' },
    denied:      { tone: 'bg-destructive/10 text-destructive border-destructive/20', Icon: MapPinOff, text: 'إذن الموقع مرفوض — الإدارة لا ترى موقعك', hint: 'فعّل إذن الموقع للموقع من إعدادات المتصفح ثم حدّث الصفحة' },
    unavailable: { tone: 'bg-destructive/10 text-destructive border-destructive/20', Icon: MapPinOff, text: 'تعذر الحصول على موقعك', hint: 'فعّل خدمات الموقع (GPS) في الهاتف' },
  }[state];

  return (
    <div role="status" className={`flex items-start gap-2 rounded-lg border px-3 py-2 text-xs ${config.tone}`}>
      <config.Icon className={`w-4 h-4 shrink-0 mt-0.5 ${state === 'acquiring' ? 'animate-spin' : ''}`} />
      <div>
        <p className="font-semibold">{config.text}</p>
        {config.hint && <p className="opacity-80 mt-0.5">{config.hint}</p>}
      </div>
    </div>
  );
}
