import React from 'react';
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent,
  SidebarMenu, SidebarMenuButton, SidebarMenuItem,
  SidebarProvider, SidebarTrigger
} from '@/components/ui/sidebar';
import { Sheet, SheetContent } from '@/components/ui/sheet';
import { Link, useLocation, Redirect } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { ChangePasswordDialog } from '@/components/ChangePasswordDialog';
import {
  LayoutDashboard, Package, Truck, Users, Store,
  Building2, Map, Wallet, Settings, LogOut,
  Search, UserCircle, AlertCircle, ShieldAlert, Menu, Navigation, Warehouse, BarChart3, Plug, ClipboardList, LifeBuoy, ShieldCheck } from 'lucide-react';
import logoPath from '@assets/al-ghazali-logo.png';
import { useGetAnnouncement, useGetSystemStatus } from '@workspace/api-client-react';

const navItems = [
  { name: 'القيادة', path: '/', icon: LayoutDashboard, roles: ['super_admin', 'branch_manager', 'accountant', 'operations', 'merchant', 'cs'], mobileShow: true },
  { name: 'الطلبات', path: '/orders', icon: Package, roles: ['super_admin', 'branch_manager', 'operations', 'merchant', 'cs'], mobileShow: true },
  { name: 'المخزن والتحويلات', path: '/warehouse', icon: Warehouse, roles: ['super_admin', 'branch_manager', 'operations'], permission: 'warehouse.manage', mobileShow: false },
  { name: 'إضافة طلب', path: '/orders/new', icon: Package, roles: ['super_admin', 'branch_manager', 'operations', 'merchant'], mobileShow: false },
  { name: 'الرحلات', path: '/trips', icon: Truck, roles: ['super_admin', 'branch_manager', 'operations'], permission: 'dispatch.manage', mobileShow: true },
  { name: 'المندوبين', path: '/drivers', icon: Users, roles: ['super_admin', 'branch_manager', 'operations'], mobileShow: true },
  { name: 'تتبع المندوبين', path: '/driver-tracking', icon: Navigation, roles: ['super_admin', 'branch_manager', 'operations'], permission: 'tracking.view', mobileShow: false },
  { name: 'التجار', path: '/merchants', icon: Store, roles: ['super_admin', 'branch_manager', 'accountant'], mobileShow: false },
  { name: 'الموظفين', path: '/employees', icon: UserCircle, roles: ['super_admin'], mobileShow: false },
  { name: 'الفروع', path: '/branches', icon: Building2, roles: ['super_admin'], mobileShow: false },
  { name: 'المناطق والتسعير', path: '/zones', icon: Map, roles: ['super_admin'], mobileShow: false },
  { name: 'تسويات المندوبين', path: '/financial/settlements', icon: Wallet, roles: ['super_admin', 'branch_manager', 'accountant'], permission: 'finance.view', mobileShow: false },
  { name: 'محافظ التجار', path: '/financial/wallets', icon: Wallet, roles: ['super_admin', 'accountant', 'merchant'], mobileShow: false },
  { name: 'الخزينة', path: '/financial/treasury', icon: Wallet, roles: ['super_admin', 'branch_manager', 'accountant'], permission: 'finance.view', mobileShow: false },
  { name: 'غرفة العمليات', path: '/dispatch', icon: ClipboardList, roles: ['super_admin', 'branch_manager', 'operations'], permission: 'dispatch.manage', mobileShow: false },
  { name: 'الدعم الفني', path: '/support', icon: LifeBuoy, roles: ['merchant'], mobileShow: false },
  { name: 'الصلاحيات والمراجعة', path: '/permissions', icon: ShieldCheck, roles: ['super_admin'], mobileShow: false },
  { name: 'التحليلات', path: '/analytics', icon: BarChart3, roles: ['super_admin', 'accountant', 'branch_manager', 'operations', 'merchant'], permission: 'analytics.view', mobileShow: false },
  { name: 'الاستيراد والربط', path: '/integrations', icon: Plug, roles: ['merchant'], permission: 'integrations.manage', mobileShow: false },
  { name: 'خدمة العملاء', path: '/cs', icon: Search, roles: ['super_admin', 'cs', 'branch_manager', 'operations'], permission: 'support.view', mobileShow: false },
  { name: 'الإعدادات', path: '/settings', icon: Settings, roles: ['super_admin'], mobileShow: false },
];

function NavSidebarContent({ items, location, logout, user }: {
  items: typeof navItems;
  location: string;
  logout: () => void;
  user: any;
}) {
  return (
    <SidebarContent>
      <div className="p-4 flex flex-col items-center border-b border-sidebar-border/50">
        <img src={logoPath} alt="Al-Ghazali Logo" className="w-14 h-14 object-contain mb-2 drop-shadow-md" />
        <div className="font-bold text-base text-sidebar-primary tracking-wide text-center">الغزالي للشحن</div>
        {user && <div className="text-xs text-sidebar-foreground/60 mt-1">{user.fullName}</div>}
      </div>
      <SidebarGroup>
        <SidebarGroupContent>
          <SidebarMenu>
            {items.map((item) => {
              const isActive = location === item.path || (item.path !== '/' && location.startsWith(item.path));
              return (
                <SidebarMenuItem key={item.path}>
                  <SidebarMenuButton asChild isActive={isActive} className={`w-full justify-start text-right transition-all duration-200 ${isActive ? 'bg-sidebar-accent text-sidebar-primary' : 'hover:bg-sidebar-accent/50'}`}>
                    <Link href={item.path} className="flex items-center gap-3 px-3 py-2 w-full">
                      <item.icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-sidebar-primary drop-shadow-[0_0_8px_rgba(245,158,11,0.5)]' : 'text-sidebar-foreground/60'}`} />
                      <span className="font-medium text-sm">{item.name}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              );
            })}
            <SidebarMenuItem className="mt-4 border-t border-sidebar-border/50 pt-2">
              <SidebarMenuButton asChild className="w-full justify-start text-right hover:bg-destructive/10 hover:text-destructive text-sidebar-foreground/80 transition-colors">
                <button onClick={logout} className="flex items-center gap-3 px-3 py-2 w-full text-right cursor-pointer">
                  <LogOut className="w-4 h-4 shrink-0" />
                  <span className="font-medium text-sm">تسجيل الخروج</span>
                </button>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarGroupContent>
      </SidebarGroup>
    </SidebarContent>
  );
}

export function AppLayout({ children }: { children: React.ReactNode }) {
  const { user, logout, can } = useAuth();
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const { data: announcement } = useGetAnnouncement();
  const { data: systemStatus } = useGetSystemStatus();

  // Strict RBAC: drivers must use the dedicated mobile dashboard
  if (user?.role === 'driver') {
    return <Redirect to="/driver-dashboard" />;
  }

  if (systemStatus?.isShutdown && user?.role !== 'super_admin') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-background text-foreground p-4 text-center">
        <ShieldAlert className="w-20 h-20 text-destructive mb-6" />
        <h1 className="text-3xl font-bold mb-4">النظام متوقف حالياً</h1>
        <p className="text-lg text-muted-foreground max-w-md">{systemStatus.shutdownMessage}</p>
      </div>
    );
  }

  const allowedItems = navItems.filter(item => user && (item.roles.includes(user.role) || (!!(item as any).permission && can((item as any).permission))));
  const mobileNavItems = allowedItems.filter(i => i.mobileShow).slice(0, 4);

  return (
    <SidebarProvider>
      <div className="min-h-screen w-full flex bg-background text-foreground flex-row-reverse overflow-hidden">
        {/* Desktop Sidebar */}
        <Sidebar side="right" className="border-l border-sidebar-border bg-sidebar hidden md:flex">
          <NavSidebarContent items={allowedItems} location={location} logout={logout} user={user} />
        </Sidebar>

        {/* Mobile Drawer */}
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetContent side="right" className="p-0 w-64 border-l border-sidebar-border bg-sidebar">
            <div className="h-full overflow-y-auto">
              <SidebarProvider>
                <div className="w-full">
                  <div className="p-4 flex flex-col items-center border-b border-sidebar-border/50">
                    <img src={logoPath} alt="Logo" className="w-12 h-12 object-contain mb-2 drop-shadow-md" />
                    <div className="font-bold text-base text-sidebar-primary text-center">الغزالي للشحن</div>
                    <div className="text-xs text-sidebar-foreground/70 mt-1">{user?.fullName}</div>
                    <div className="text-[10px] text-sidebar-primary/80 uppercase tracking-wider">{user?.role.replace('_', ' ')}</div>
                  </div>
                  <nav className="p-2 space-y-0.5">
                    {allowedItems.map((item) => {
                      const isActive = location === item.path || (item.path !== '/' && location.startsWith(item.path));
                      return (
                        <Link key={item.path} href={item.path} onClick={() => setMobileOpen(false)}
                          className={`flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium w-full transition-colors ${isActive ? 'bg-sidebar-accent text-sidebar-primary' : 'text-sidebar-foreground/80 hover:bg-sidebar-accent/50'}`}
                        >
                          <item.icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-sidebar-primary' : 'text-sidebar-foreground/60'}`} />
                          {item.name}
                        </Link>
                      );
                    })}
                    <button
                      onClick={() => { setMobileOpen(false); logout(); }}
                      className="flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium w-full text-right text-sidebar-foreground/80 hover:bg-destructive/10 hover:text-destructive mt-4 border-t border-sidebar-border/50 pt-4 transition-colors"
                    >
                      <LogOut className="w-4 h-4 shrink-0" />
                      تسجيل الخروج
                    </button>
                  </nav>
                </div>
              </SidebarProvider>
            </div>
          </SheetContent>
        </Sheet>

        {/* Main content */}
        <main className="flex-1 flex flex-col h-screen overflow-hidden min-w-0">
          {announcement?.isActive && announcement.message && (
            <div className="bg-primary text-primary-foreground px-4 py-2 text-center text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 shadow-md z-50 shrink-0">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              {announcement.message}
            </div>
          )}

          <header className="h-14 flex items-center px-4 border-b border-border/40 bg-card/50 backdrop-blur-sm z-40 sticky top-0 shrink-0 gap-3">
            <button
              className="md:hidden p-2 rounded-md text-foreground/70 hover:text-primary hover:bg-primary/10 transition-colors"
              onClick={() => setMobileOpen(true)}
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="hidden md:block">
              <SidebarTrigger className="text-foreground/70 hover:text-primary transition-colors" />
            </div>
            <div className="flex-1" />
            <ChangePasswordDialog />
            <div className="md:hidden flex items-center gap-2">
              <div className="text-right">
                <div className="text-xs font-bold text-foreground leading-none">{user?.fullName}</div>
                <div className="text-[10px] text-primary/80 mt-0.5">{user?.role.replace('_', ' ')}</div>
              </div>
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                <UserCircle className="w-4 h-4" />
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-auto pb-20 md:pb-0 custom-scrollbar">
            <div className="max-w-7xl mx-auto w-full p-4 sm:p-6 md:p-8">
              {children}
            </div>
          </div>

          {/* Mobile Bottom Navigation */}
          <nav className="md:hidden fixed bottom-0 inset-x-0 z-50 border-t border-border/50 bg-card/95 backdrop-blur-xl safe-area-inset-bottom">
            <div className="flex items-stretch">
              {mobileNavItems.map((item) => {
                const isActive = location === item.path || (item.path !== '/' && location.startsWith(item.path));
                return (
                  <Link key={item.path} href={item.path}
                    className={`flex-1 flex flex-col items-center justify-center gap-0.5 py-2.5 px-1 text-center transition-colors relative ${isActive ? 'text-primary' : 'text-muted-foreground hover:text-foreground'}`}
                  >
                    <item.icon className={`w-5 h-5 ${isActive ? 'drop-shadow-[0_0_6px_rgba(245,158,11,0.5)]' : ''}`} />
                    <span className="text-[10px] font-medium">{item.name}</span>
                    {isActive && <div className="absolute top-0 w-8 h-0.5 bg-primary rounded-b" />}
                  </Link>
                );
              })}
              <button
                onClick={() => setMobileOpen(true)}
                className="flex-1 flex flex-col items-center justify-center gap-0.5 py-2.5 px-1 text-muted-foreground hover:text-foreground transition-colors"
              >
                <Menu className="w-5 h-5" />
                <span className="text-[10px] font-medium">المزيد</span>
              </button>
            </div>
          </nav>
        </main>
      </div>
    </SidebarProvider>
  );
}
