import React from 'react';

interface State { hasError: boolean }

/** Without this, any render error left the user staring at a blank white screen. */
export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: unknown) {
    console.error('UI crashed:', error);
  }

  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      <div dir="rtl" className="min-h-screen flex flex-col items-center justify-center gap-4 bg-background text-foreground p-6 text-center">
        <h1 className="text-2xl font-bold">حدث خطأ غير متوقع</h1>
        <p className="text-muted-foreground max-w-sm">نعتذر عن ذلك. جرّب إعادة تحميل الصفحة، وإذا استمرت المشكلة تواصل مع الإدارة.</p>
        <div className="flex gap-3">
          <button className="px-4 py-2 rounded-md bg-primary text-primary-foreground font-medium" onClick={() => window.location.reload()}>
            إعادة التحميل
          </button>
          <button className="px-4 py-2 rounded-md border border-border font-medium" onClick={() => { window.location.href = import.meta.env.BASE_URL; }}>
            الرئيسية
          </button>
        </div>
      </div>
    );
  }
}
