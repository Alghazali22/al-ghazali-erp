import React, { useState } from 'react';
import { KeyRound } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { apiFetch } from '@/lib/extra-api';

/** Admin tool: set a new password for a user who forgot theirs (previously impossible). */
export function ResetPasswordButton({ user }: { user: { id: number; fullName: string; role?: string } }) {
  const { user: me } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [password, setPassword] = useState('');
  const [saving, setSaving] = useState(false);

  if (!me || (me.role !== 'super_admin' && me.role !== 'branch_manager') || me.id === user.id) return null;

  const submit = async () => {
    setSaving(true);
    try {
      await apiFetch(`/users/${user.id}/reset-password`, { method: 'POST', body: JSON.stringify({ newPassword: password }) });
      toast({ title: 'تم تغيير كلمة المرور', description: `سلّم كلمة المرور الجديدة إلى ${user.fullName}` });
      setOpen(false);
      setPassword('');
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر تغيير كلمة المرور', description: e.message });
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <Button type="button" variant="ghost" size="sm" title="إعادة تعيين كلمة المرور" aria-label="إعادة تعيين كلمة المرور"
        className="h-8 w-8 p-0 text-muted-foreground hover:text-primary" onClick={() => setOpen(true)}>
        <KeyRound className="w-3.5 h-3.5" />
      </Button>
      <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) setPassword(''); }}>
        <DialogContent className="sm:max-w-sm" dir="rtl">
          <DialogHeader>
            <DialogTitle>إعادة تعيين كلمة المرور</DialogTitle>
            <DialogDescription>{user.fullName}</DialogDescription>
          </DialogHeader>
          <Input type="text" autoComplete="off" placeholder="كلمة المرور الجديدة (8 أحرف على الأقل)" value={password} onChange={(e) => setPassword(e.target.value)} />
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>إلغاء</Button>
            <Button onClick={submit} disabled={saving || password.length < 8}>{saving ? 'جاري الحفظ...' : 'حفظ'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
