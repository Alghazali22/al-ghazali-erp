import React, { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { Truck, MapPin, Clock, LocateFixed, CheckCircle2, Loader2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import 'leaflet/dist/leaflet.css';

export interface LiveInfo {
  canPin: boolean;
  hasPin: boolean;
  destLat: number | null;
  destLng: number | null;
  tracking: boolean;
  stopsAhead?: number;
  etaMinutes?: number | null;
  etaPrecise?: boolean;
  driverFirstName?: string | null;
  driverLat?: number | null;
  driverLng?: number | null;
  connection?: string;
  updatedAgoSeconds?: number | null;
}

const driverIcon = L.divIcon({
  className: 'live-driver-icon',
  html: '<div style="width:36px;height:36px;border-radius:50%;background:#0f172a;border:3px solid #f59e0b;display:flex;align-items:center;justify-content:center;font-size:18px;box-shadow:0 2px 8px rgba(0,0,0,.4)">🛵</div>',
  iconSize: [36, 36], iconAnchor: [18, 18],
});
const homeIcon = L.divIcon({
  className: 'live-home-icon',
  html: '<div style="width:34px;height:34px;border-radius:50%;background:#10b981;border:3px solid white;display:flex;align-items:center;justify-content:center;font-size:17px;box-shadow:0 2px 8px rgba(0,0,0,.4)">🏠</div>',
  iconSize: [34, 34], iconAnchor: [17, 17],
});

function FitBoth({ points }: { points: [number, number][] }) {
  const map = useMap();
  React.useEffect(() => {
    if (points.length === 1) map.setView(points[0], 15);
    else if (points.length > 1) map.fitBounds(L.latLngBounds(points), { padding: [40, 40], maxZoom: 16 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [points.map((p) => p.join(',')).join('|')]);
  return null;
}

function PinForm({ orderNumber, onDone }: { orderNumber: string; onDone: () => void }) {
  const [last4, setLast4] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const submit = () => {
    setError('');
    if (!/^\d{4}$/.test(last4)) { setError('اكتب آخر 4 أرقام من رقم هاتفك'); return; }
    if (!('geolocation' in navigator)) { setError('متصفحك لا يدعم تحديد الموقع'); return; }
    setBusy(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const res = await fetch(`/api/track/${encodeURIComponent(orderNumber)}/location`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phoneLast4: last4, lat: pos.coords.latitude, lng: pos.coords.longitude }),
          });
          const body = await res.json().catch(() => ({}));
          if (!res.ok) { setError(body.error || 'تعذر حفظ الموقع'); return; }
          onDone();
        } catch {
          setError('خطأ في الاتصال، حاول مرة أخرى');
        } finally {
          setBusy(false);
        }
      },
      (err) => {
        setBusy(false);
        setError(err.code === err.PERMISSION_DENIED ? 'من فضلك اسمح للموقع بالوصول لموقعك ثم أعد المحاولة' : 'تعذر تحديد موقعك، تأكد من تفعيل GPS');
      },
      { enableHighAccuracy: true, timeout: 20_000 },
    );
  };

  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">
        اقف في مكان الاستلام واضغط الزر ليصل المندوب إليك مباشرة بدون اتصالات أو لف. للتأكد أن الطلب طلبك، اكتب آخر 4 أرقام من رقم هاتفك.
      </p>
      <div className="flex gap-2">
        <Input dir="ltr" inputMode="numeric" maxLength={4} placeholder="آخر 4 أرقام من الهاتف" value={last4}
          onChange={(e) => setLast4(e.target.value.replace(/\D/g, ''))} className="font-mono text-center" />
        <Button onClick={submit} disabled={busy} className="shrink-0">
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <LocateFixed className="w-4 h-4 ml-1" />}
          حدّد موقعي
        </Button>
      </div>
      {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
    </div>
  );
}

/** Customer-facing "your courier is on the way" card + exact-location pin. */
export function LiveApproach({ orderNumber, live }: { orderNumber: string; live: LiveInfo }) {
  const queryClient = useQueryClient();
  const refresh = () => queryClient.invalidateQueries({ queryKey: ['track', orderNumber] });

  const points: [number, number][] = [];
  if (live.driverLat != null && live.driverLng != null) points.push([live.driverLat, live.driverLng]);
  if (live.destLat != null && live.destLng != null) points.push([live.destLat, live.destLng]);

  const eta = live.etaMinutes;
  const headline =
    !live.tracking ? null
    : live.stopsAhead === 0 ? 'المندوب في طريقه إليك الآن'
    : `أمام المندوب ${live.stopsAhead} ${live.stopsAhead === 1 ? 'طلب' : 'طلبات'} قبل طلبك`;

  if (!live.tracking && !live.canPin) return null;

  return (
    <Card className="border-border/40 bg-card/60 overflow-hidden">
      <CardContent className="p-5 sm:p-6 space-y-4">
        {live.tracking && (
          <>
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-xl bg-orange-500/10 text-orange-500 flex items-center justify-center shrink-0"><Truck className="w-6 h-6" /></div>
              <div className="flex-1">
                <p className="font-bold text-lg">{headline}</p>
                <p className="text-sm text-muted-foreground">
                  {live.driverFirstName ? `الكابتن ${live.driverFirstName}` : 'الكابتن'}
                  {live.connection && live.connection !== 'live' ? ' — إشارته ضعيفة حالياً' : ''}
                </p>
              </div>
              {eta != null && (
                <div className="text-center bg-primary/10 text-primary rounded-xl px-3 py-2 shrink-0">
                  <div className="flex items-center gap-1 text-xs"><Clock className="w-3 h-3" /> الوصول خلال</div>
                  <div className="text-xl font-bold font-mono">≈ {eta} د</div>
                </div>
              )}
            </div>
            {eta != null && !live.etaPrecise && live.canPin && (
              <p className="text-xs text-amber-500">الوقت تقريبي لأن موقعك الدقيق غير محدد — حدّده بالأسفل لتقدير أدق.</p>
            )}
          </>
        )}

        {points.length > 0 && (
          <div className="rounded-xl overflow-hidden border border-border/40" style={{ height: 260 }}>
            <MapContainer center={points[0]} zoom={14} style={{ height: '100%', width: '100%' }} scrollWheelZoom={false}>
              <TileLayer attribution="&copy; OpenStreetMap contributors" url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
              <FitBoth points={points} />
              {live.driverLat != null && live.driverLng != null && (
                <Marker position={[live.driverLat, live.driverLng]} icon={driverIcon}><Popup>المندوب</Popup></Marker>
              )}
              {live.destLat != null && live.destLng != null && (
                <Marker position={[live.destLat, live.destLng]} icon={homeIcon}><Popup>موقع التسليم</Popup></Marker>
              )}
            </MapContainer>
          </div>
        )}
        {live.tracking && live.driverLat == null && (
          <p className="text-xs text-muted-foreground">سيظهر موقع المندوب على الخريطة عندما يقترب من طلبك.</p>
        )}

        {live.canPin && (
          <div className="rounded-xl border border-border/40 bg-muted/10 p-4">
            <div className="flex items-center gap-2 font-bold mb-2">
              {live.hasPin ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : <MapPin className="w-5 h-5 text-primary" />}
              {live.hasPin ? 'تم تحديد موقعك — شكراً لك' : 'وصّلنا لموقعك بدقة'}
            </div>
            {live.hasPin
              ? <p className="text-sm text-muted-foreground">المندوب يرى موقعك الدقيق ويصل إليك مباشرة. تقدر تحدّثه لو انتقلت.</p>
              : null}
            <PinForm orderNumber={orderNumber} onDone={refresh} />
          </div>
        )}
      </CardContent>
    </Card>
  );
}
