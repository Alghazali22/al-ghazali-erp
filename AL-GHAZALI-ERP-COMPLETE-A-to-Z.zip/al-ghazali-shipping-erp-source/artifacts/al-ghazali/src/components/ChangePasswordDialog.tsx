import React, { useState } from 'react';
import { KeyRound } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

const MIN_LENGTH = 8;

/** Lets any logged-in user change their own password (there was no way to before). */
export function ChangePasswordDialog({ className = '' }: { className?: string }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const reset = () => { setCurrent(''); setNext(''); setConfirm(''); setError(''); };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (next.length < MIN_LENGTH) { setError(`كلمة المرور الجديدة يجب ألا تقل عن ${MIN_LENGTH} أحرف`); return; }
    if (next !== confirm) { setError('تأكيد كلمة المرور غير مطابق'); return; }
    setSaving(true);
    try {
      const token = localStorage.getItem('al-ghazali-token');
      const res = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ currentPassword: current, newPassword: next }),
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) { setError(body.error || 'تعذر تغيير كلمة المرور'); return; }
      toast({ title: 'تم تغيير كلمة المرور بنجاح' });
      setOpen(false);
      reset();
    } catch {
      setError('خطأ في الاتصال، حاول مرة أخرى');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) reset(); }}>
      <DialogTrigger asChild>
        <button
          type="button"
          title="تغيير كلمة المرور"
          aria-label="تغيير كلمة المرور"
          className={`p-2 rounded-md text-foreground/70 hover:text-primary hover:bg-primary/10 transition-colors ${className}`}
        >
          <KeyRound className="w-4 h-4" />
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-sm" dir="rtl">
        <DialogHeader>
          <DialogTitle>تغيير كلمة المرور</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="cp-current">كلمة المرور الحالية</Label>
            <Input id="cp-current" type="password" autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} required />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="cp-new">كلمة المرور الجديدة</Label>
            <Input id="cp-new" type="password" autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} required minLength={MIN_LENGTH} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="cp-confirm">تأكيد كلمة المرور الجديدة</Label>
            <Input id="cp-confirm" type="password" autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required />
          </div>
          {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
          <DialogFooter>
            <Button type="submit" disabled={saving} className="w-full">{saving ? 'جاري الحفظ...' : 'حفظ'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
