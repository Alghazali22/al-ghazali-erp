import React, { useState } from 'react';
import { Sparkles, Loader2, Route, Package } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';
import { apiFetch } from '@/lib/extra-api';

interface Proposal {
  driverId: number; driverName: string; orderIds: number[]; count: number;
  totalToCollect: number; estimatedKm: number; topAreas: { area: string; count: number }[];
}
interface Plan { proposals: Proposal[]; unassigned: number; poolSize: number; maxPerDriver?: number }

/**
 * One click turns "N parcels in the warehouse" into balanced, geographically-clustered trips
 * (sweep clustering) with each trip's stops already ordered into a short route.
 */
interface BoardDriver { driverId: number; driverName: string; status: 'off' | 'available' | 'break' | 'on_trip'; queuePosition: number | null }
const STATUS_LABEL = { off: 'خارج الشيفت', break: 'استراحة', on_trip: 'في رحلة', available: '' } as const;

export function SmartDispatchDialog({ open, onOpenChange, onCreated }: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreated: () => void;
}) {
  const { toast } = useToast();
  // Only couriers who are on shift and free can take a trip; they are offered in rotation order (longest-waiting first).
  const { data: board } = useQuery({
    queryKey: ['shift-board'],
    queryFn: () => apiFetch<{ drivers: BoardDriver[] }>('/shifts/board'),
    enabled: open,
    refetchInterval: open ? 10_000 : false,
  });
  const drivers = board?.drivers ?? [];
  const availableDrivers = drivers.filter((d) => d.status === 'available');
  const [takeN, setTakeN] = useState('');
  const [selected, setSelected] = useState<number[]>([]);
  const [maxPerDriver, setMaxPerDriver] = useState('40');
  const [plan, setPlan] = useState<Plan | null>(null);
  const [busy, setBusy] = useState<'plan' | 'create' | null>(null);

  const reset = () => { setPlan(null); setSelected([]); setBusy(null); };
  const toggle = (id: number) => { setPlan(null); setSelected((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id])); };

  const compute = async () => {
    setBusy('plan');
    try {
      setPlan(await apiFetch<Plan>('/trips/auto-plan', { method: 'POST', body: JSON.stringify({ driverIds: selected, maxPerDriver: Number(maxPerDriver) || 40 }) }));
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر حساب التوزيع', description: e.message });
    } finally { setBusy(null); }
  };

  const create = async () => {
    if (!plan) return;
    setBusy('create');
    let made = 0;
    try {
      for (const p of plan.proposals) {
        const trip = await apiFetch<{ id: number }>('/trips', { method: 'POST', body: JSON.stringify({ driverId: p.driverId, orderIds: p.orderIds }) });
        await apiFetch(`/trips/${trip.id}/optimize`, { method: 'POST' });
        made++;
      }
      toast({ title: `تم إنشاء ${made} رحلة مرتبة`, description: 'راجعها ثم اضغط "تأكيد وإرسال" لكل رحلة' });
      onCreated();
      onOpenChange(false);
      reset();
    } catch (e: any) {
      toast({ variant: 'destructive', title: made ? `أُنشئت ${made} رحلة ثم توقف` : 'تعذر إنشاء الرحلات', description: e.message });
      if (made) onCreated();
    } finally { setBusy(null); }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) reset(); }}>
      <DialogContent className="sm:max-w-xl max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Sparkles className="w-5 h-5 text-primary" /> التوزيع الذكي للطلبات</DialogTitle>
          <DialogDescription>اختر المناديب المتاحين اليوم، وسيقسّم النظام طلبات المخزن الجاهزة حسب الموقع بالتساوي ويرتّب خط سير كل مندوب.</DialogDescription>
        </DialogHeader>

        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <p className="text-sm font-semibold ml-auto">المناديب على الشيفت ({availableDrivers.length}) — مرتّبين بالدور</p>
            <Input type="number" min={1} max={availableDrivers.length || 1} placeholder="أول كام مندوب؟" className="w-32 h-8" value={takeN} onChange={(e) => setTakeN(e.target.value)} />
            <Button size="sm" variant="outline" disabled={!Number(takeN)} onClick={() => { setPlan(null); setSelected(availableDrivers.slice(0, Number(takeN)).map((d) => d.driverId)); }}>اختر</Button>
          </div>
          <div className="grid grid-cols-2 gap-2 max-h-48 overflow-auto">
            {drivers.map((d) => {
              const can = d.status === 'available';
              return (
                <label key={d.driverId} className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-sm ${can ? 'cursor-pointer' : 'opacity-50 cursor-not-allowed'} ${selected.includes(d.driverId) ? 'border-primary bg-primary/5' : 'border-border/50'}`}>
                  <input type="checkbox" disabled={!can} checked={selected.includes(d.driverId)} onChange={() => toggle(d.driverId)} />
                  {d.queuePosition && <span className="w-5 h-5 rounded-full bg-primary text-primary-foreground text-[11px] font-bold flex items-center justify-center shrink-0">{d.queuePosition}</span>}
                  <span className="truncate">{d.driverName}</span>
                  {!can && <span className="text-[10px] text-muted-foreground mr-auto">{STATUS_LABEL[d.status]}</span>}
                </label>
              );
            })}
            {drivers.length === 0 && <p className="text-sm text-muted-foreground col-span-2">لا يوجد مناديب مفعّلون</p>}
          </div>
          {availableDrivers.length === 0 && drivers.length > 0 && (
            <p className="text-xs text-amber-500">لا يوجد مندوب متاح الآن — اطلب منهم بدء الشيفت أو ابدأه لهم من «الدور والمناديب».</p>
          )}
          <div className="flex items-center gap-2 text-sm">
            <span className="text-muted-foreground">أقصى عدد طلبات للمندوب:</span>
            <Input type="number" min={1} max={100} className="w-24 h-8" value={maxPerDriver} onChange={(e) => { setPlan(null); setMaxPerDriver(e.target.value); }} />
          </div>
        </div>

        {plan && (
          <div className="space-y-2">
            {plan.proposals.length === 0 ? (
              <p className="text-sm text-muted-foreground py-3">لا توجد طلبات جاهزة داخل المخزن للتوزيع حالياً.</p>
            ) : (
              <>
                <p className="text-sm font-semibold">المقترح ({plan.poolSize} طلب جاهز)</p>
                {plan.proposals.map((p) => (
                  <div key={p.driverId} className="rounded-lg border border-border/50 p-3 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-bold">{p.driverName}</span>
                      <span className="flex items-center gap-1 text-sm font-mono"><Package className="w-3.5 h-3.5" />{p.count} طلب</span>
                    </div>
                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                      <span>تحصيل متوقع: <b className="text-foreground">{p.totalToCollect} ج.م</b></span>
                      <span className="flex items-center gap-1"><Route className="w-3 h-3" /> ≈ {p.estimatedKm} كم</span>
                    </div>
                    {p.topAreas.length > 0 && <p className="text-xs">{p.topAreas.map((a) => `${a.area} (${a.count})`).join(' • ')}</p>}
                  </div>
                ))}
                {plan.unassigned > 0 && (
                  <p role="alert" className="text-xs text-amber-500">{plan.unassigned} طلب لم يُوزَّع لتجاوز الحد الأقصى — زد الحد أو أضف مناديب.</p>
                )}
              </>
            )}
          </div>
        )}

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={busy !== null}>إلغاء</Button>
          {!plan || plan.proposals.length === 0 ? (
            <Button onClick={compute} disabled={selected.length === 0 || busy !== null}>
              {busy === 'plan' ? <Loader2 className="w-4 h-4 animate-spin ml-1" /> : <Sparkles className="w-4 h-4 ml-1" />} احسب التوزيع
            </Button>
          ) : (
            <Button onClick={create} disabled={busy !== null}>
              {busy === 'create' ? <Loader2 className="w-4 h-4 animate-spin ml-1" /> : null} إنشاء {plan.proposals.length} رحلة
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
