import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Wand2, MessageSquareText, UserCheck, Loader2, Send, ShieldCheck, ShieldAlert, MessageCircle, AlertTriangle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { apiFetch } from '@/lib/extra-api';
import { parseCustomerBlocks } from '@/lib/smartParse';
import { normalizeEgyptPhone } from '@/lib/egypt';
import { whatsappUrl } from '@/lib/share';
import { emptyRow, normalizeRow, validateRow, signature, type GridRow, type EditableKey } from '@/lib/orderRows';
import type { ZoneLite } from '@/lib/zoneMatch';
import { BatchSuccess, type CreatedOrder } from '@/components/BatchSuccess';

interface Preview {
  shippingFee: number; totalToCollect: number; zoneMatched: boolean; possibleDuplicate: string | null;
  confidence: { score: number; level: 'high' | 'medium' | 'low'; reasons: { text: string; impact: number }[]; advice: string | null };
}
interface Known { customerName: string; customerPhone2: string | null; customerAddress: string; governorate: string; area: string; orders: number }

const LEVEL = {
  high: { label: 'ثقة عالية', cls: 'text-emerald-500 border-emerald-500/30 bg-emerald-500/10', Icon: ShieldCheck },
  medium: { label: 'ثقة متوسطة', cls: 'text-amber-500 border-amber-500/30 bg-amber-500/10', Icon: ShieldAlert },
  low: { label: 'ثقة منخفضة', cls: 'text-destructive border-destructive/30 bg-destructive/10', Icon: ShieldAlert },
} as const;

const fieldCls = 'w-full h-10 px-3 rounded-md border border-border bg-background/50 text-sm outline-none focus:border-primary';

export function SingleOrderForm({ zones, merchantId, merchantName }: {
  zones: (ZoneLite & { id: number })[];
  merchantId: number | null;
  merchantName: string;
}) {
  const { toast } = useToast();
  const [row, setRow] = useState<GridRow>(emptyRow());
  const [pasteOpen, setPasteOpen] = useState(false);
  const [pasteText, setPasteText] = useState('');
  const [known, setKnown] = useState<Known | null>(null);
  const [preview, setPreview] = useState<{ sig: string; data?: Preview; error?: string } | null>(null);
  const [saving, setSaving] = useState(false);
  const [created, setCreated] = useState<CreatedOrder | null>(null);
  const lookedUp = useRef('');

  const set = (key: EditableKey, value: string) => setRow((r) => ({ ...r, [key]: value }));
  const issues = useMemo(() => validateRow(row, zones), [row, zones]);
  const errors = issues.filter((i) => i.level === 'error');
  const govList = useMemo(() => [...new Set(zones.filter((z) => z.isActive !== false).map((z) => z.governorate))], [zones]);
  const areaList = useMemo(() => zones.filter((z) => z.governorate === row.governorate && z.isActive !== false).map((z) => z.area), [zones, row.governorate]);

  const applySmartPaste = () => {
    const [first] = parseCustomerBlocks(pasteText, zones);
    if (!first) { toast({ variant: 'destructive', title: 'لم أتمكن من استخراج بيانات', description: 'تأكد أن النص يحتوي رقم هاتف وعنواناً' }); return; }
    const { row: cleaned } = normalizeRow({ ...emptyRow(), ...first }, zones);
    setRow((r) => ({ ...cleaned, id: r.id }));
    setPasteOpen(false);
    setPasteText('');
    toast({ title: 'تم ملء البيانات', description: 'راجع الحقول وصحّح أي شيء قبل الإنشاء' });
  };

  // Returning customer: offer to reuse this merchant's own previous order data for the phone.
  useEffect(() => {
    const phone = normalizeEgyptPhone(row.customerPhone);
    if (!phone || !merchantId || lookedUp.current === phone) return;
    const t = setTimeout(async () => {
      lookedUp.current = phone;
      try {
        const res = await apiFetch<any>(`/customers/lookup?phone=${encodeURIComponent(phone)}&merchantId=${merchantId}`);
        setKnown(res.found ? res : null);
      } catch { setKnown(null); }
    }, 500);
    return () => clearTimeout(t);
  }, [row.customerPhone, merchantId]);

  const useKnown = () => {
    if (!known) return;
    setRow((r) => ({
      ...r, customerName: known.customerName, customerAddress: known.customerAddress,
      governorate: known.governorate, area: known.area, customerPhone2: known.customerPhone2 ?? r.customerPhone2,
    }));
    setKnown(null);
  };

  // Live price + delivery-confidence preview (server-authoritative).
  useEffect(() => {
    if (!merchantId || errors.length) { setPreview(null); return; }
    const sig = signature(row);
    if (preview?.sig === sig) return;
    const t = setTimeout(async () => {
      try {
        const res = await apiFetch<{ results: any[] }>('/orders/bulk', {
          method: 'POST',
          body: JSON.stringify({ merchantId, dryRun: true, rows: [{
            customerName: row.customerName, customerPhone: normalizeEgyptPhone(row.customerPhone) ?? row.customerPhone,
            customerPhone2: row.customerPhone2 ? normalizeEgyptPhone(row.customerPhone2) ?? row.customerPhone2 : undefined,
            governorate: row.governorate, area: row.area, customerAddress: row.customerAddress,
            packageValue: Number(row.packageValue), notes: row.notes || undefined,
          }] }),
        });
        const r = res.results[0];
        setPreview(r?.ok ? { sig, data: r.preview } : { sig, error: r?.error ?? 'تعذر التحقق' });
      } catch { setPreview(null); }
    }, 700);
    return () => clearTimeout(t);
  }, [row, merchantId, errors.length, preview?.sig]);

  const submit = async () => {
    if (!merchantId || errors.length) return;
    setSaving(true);
    try {
      const o = await apiFetch<any>('/orders', {
        method: 'POST',
        body: JSON.stringify({
          merchantId,
          customerName: row.customerName, customerPhone: normalizeEgyptPhone(row.customerPhone) ?? row.customerPhone,
          customerPhone2: row.customerPhone2 ? normalizeEgyptPhone(row.customerPhone2) ?? row.customerPhone2 : undefined,
          governorate: row.governorate, area: row.area, customerAddress: row.customerAddress,
          packageValue: Number(row.packageValue), notes: row.notes || undefined,
        }),
      });
      setCreated({
        orderNumber: o.orderNumber, customerName: o.customerName, customerPhone: o.customerPhone,
        customerAddress: o.customerAddress, governorate: o.governorate, area: o.area,
        totalToCollect: o.totalToCollect, notes: o.notes, packageValue: o.packageValue, shippingFee: o.shippingFee,
      });
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'تعذر إنشاء الطلب', description: e?.data?.error || e?.message });
    } finally {
      setSaving(false);
    }
  };

  const reset = () => { setCreated(null); setRow(emptyRow()); setPreview(null); setKnown(null); lookedUp.current = ''; };

  if (created) return <BatchSuccess orders={[created]} merchantName={merchantName} onReset={reset} />;

  const fresh = preview && preview.sig === signature(row) ? preview : null;
  const conf = fresh?.data?.confidence;
  const Level = conf ? LEVEL[conf.level] : null;

  return (
    <div className="space-y-4">
      {/* ---- smart paste ---- */}
      <Card className="border-primary/30 bg-primary/5">
        <CardContent className="p-4 space-y-3">
          <button type="button" onClick={() => setPasteOpen((v) => !v)} className="w-full flex items-center gap-2 text-right font-bold text-primary">
            <MessageSquareText className="w-5 h-5" /> الصق رسالة العميل (واتساب / فيسبوك) ودع النظام يملأ الحقول
            <span className="mr-auto text-xs font-normal text-muted-foreground">{pasteOpen ? 'إخفاء' : 'جرّبها'}</span>
          </button>
          {pasteOpen && (
            <>
              <textarea value={pasteText} onChange={(e) => setPasteText(e.target.value)} rows={5}
                placeholder={'احمد محمد\n01012345678\n15 شارع عباس العقاد مدينة نصر القاهرة\nالمبلغ 350'}
                className="w-full rounded-md border border-border bg-background/60 p-3 text-sm outline-none focus:border-primary" />
              <Button size="sm" onClick={applySmartPaste} disabled={!pasteText.trim()}><Wand2 className="w-4 h-4 ml-1.5" /> املأ الحقول</Button>
            </>
          )}
        </CardContent>
      </Card>

      {/* ---- customer ---- */}
      <Card className="border-border/40 bg-card/60">
        <CardContent className="p-4 sm:p-5 space-y-4">
          <h3 className="text-sm font-bold text-muted-foreground">بيانات العميل</h3>
          <div className="grid sm:grid-cols-2 gap-3">
            <label className="space-y-1 text-sm">الهاتف *<Input dir="ltr" inputMode="tel" className="text-right" value={row.customerPhone} onChange={(e) => set('customerPhone', e.target.value)} onBlur={() => setRow((r) => normalizeRow(r, zones).row)} placeholder="01012345678" /></label>
            <label className="space-y-1 text-sm">هاتف بديل<Input dir="ltr" inputMode="tel" className="text-right" value={row.customerPhone2} onChange={(e) => set('customerPhone2', e.target.value)} onBlur={() => setRow((r) => normalizeRow(r, zones).row)} /></label>
          </div>
          {known && (
            <button type="button" onClick={useKnown} className="w-full flex items-center gap-2 rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-500 text-right">
              <UserCheck className="w-4 h-4 shrink-0" />
              <span className="flex-1">عميل سابق: <b>{known.customerName}</b> ({known.orders} {known.orders === 1 ? 'طلب' : 'طلبات'}) — اضغط لاستخدام بياناته</span>
            </button>
          )}
          <label className="space-y-1 text-sm block">الاسم *<Input value={row.customerName} onChange={(e) => set('customerName', e.target.value)} /></label>
        </CardContent>
      </Card>

      {/* ---- address ---- */}
      <Card className="border-border/40 bg-card/60">
        <CardContent className="p-4 sm:p-5 space-y-4">
          <h3 className="text-sm font-bold text-muted-foreground">العنوان</h3>
          <div className="grid sm:grid-cols-2 gap-3">
            <label className="space-y-1 text-sm">المحافظة *
              <select className={fieldCls} value={row.governorate} onChange={(e) => setRow((r) => ({ ...r, governorate: e.target.value, area: '' }))}>
                <option value="">اختر المحافظة</option>
                {govList.map((g) => <option key={g} value={g}>{g}</option>)}
              </select>
            </label>
            <label className="space-y-1 text-sm">المنطقة *
              <select className={fieldCls} value={row.area} onChange={(e) => set('area', e.target.value)} disabled={!row.governorate}>
                <option value="">{row.governorate ? 'اختر المنطقة' : 'اختر المحافظة أولاً'}</option>
                {areaList.map((a) => <option key={a} value={a}>{a}</option>)}
              </select>
            </label>
          </div>
          <label className="space-y-1 text-sm block">العنوان بالتفصيل *
            <textarea rows={2} value={row.customerAddress} onChange={(e) => set('customerAddress', e.target.value)}
              placeholder="الشارع، رقم العمارة، الدور، الشقة، علامة مميزة"
              className="w-full rounded-md border border-border bg-background/50 p-3 text-sm outline-none focus:border-primary" />
          </label>
        </CardContent>
      </Card>

      {/* ---- shipment ---- */}
      <Card className="border-border/40 bg-card/60">
        <CardContent className="p-4 sm:p-5 space-y-4">
          <h3 className="text-sm font-bold text-muted-foreground">الشحنة</h3>
          <div className="grid sm:grid-cols-2 gap-3">
            <label className="space-y-1 text-sm">قيمة الشحنة (ج.م) *<Input dir="ltr" inputMode="decimal" className="text-right" value={row.packageValue} onChange={(e) => set('packageValue', e.target.value)} onBlur={() => setRow((r) => normalizeRow(r, zones).row)} placeholder="0 للمدفوع مسبقاً" /></label>
            <label className="space-y-1 text-sm">ملاحظات<Input value={row.notes} onChange={(e) => set('notes', e.target.value)} placeholder="اتصل قبل الوصول..." /></label>
          </div>
        </CardContent>
      </Card>

      {/* ---- live price + confidence ---- */}
      {fresh?.error && <p role="alert" className="text-sm text-destructive flex items-center gap-1.5"><AlertTriangle className="w-4 h-4" /> {fresh.error}</p>}
      {fresh?.data && conf && Level && (
        <Card className="border-border/40 bg-card/60">
          <CardContent className="p-4 sm:p-5 space-y-3">
            <div className="flex flex-wrap items-center gap-4">
              <div className="text-sm space-y-0.5">
                <div>رسوم الشحن: <b className="font-mono">{fresh.data.shippingFee} ج.م</b>{!fresh.data.zoneMatched && <span className="text-amber-500 text-xs mr-2">(سعر افتراضي)</span>}</div>
                <div>المطلوب تحصيله: <b className="font-mono text-lg text-primary">{fresh.data.totalToCollect} ج.م</b></div>
              </div>
              <div className={`mr-auto inline-flex items-center gap-2 rounded-xl border px-3 py-2 ${Level.cls}`}>
                <Level.Icon className="w-5 h-5" />
                <div className="leading-tight"><div className="font-bold">{conf.score}% — {Level.label}</div><div className="text-[11px] opacity-80">احتمال التسليم والتحصيل من أول زيارة</div></div>
              </div>
            </div>
            {fresh.data.possibleDuplicate && (
              <p className="text-sm text-amber-500 flex items-center gap-1.5"><AlertTriangle className="w-4 h-4" /> يوجد طلب مفتوح لنفس الرقم ({fresh.data.possibleDuplicate}) — تأكد أنه ليس تكراراً.</p>
            )}
            <ul className="text-xs space-y-1">
              {conf.reasons.map((r, i) => <li key={i} className={r.impact < 0 ? 'text-muted-foreground' : 'text-emerald-500/90'}><span className="font-mono">{r.impact > 0 ? '+' : ''}{r.impact}</span> {r.text}</li>)}
            </ul>
            {conf.advice && (
              <div className="flex flex-wrap items-center gap-3 rounded-lg bg-amber-500/10 border border-amber-500/20 px-3 py-2 text-sm">
                <span className="flex-1 min-w-[12rem]">{conf.advice}</span>
                {normalizeEgyptPhone(row.customerPhone) && (
                  <a href={whatsappUrl(row.customerPhone, `مرحباً ${row.customerName} 👋\nمعك ${merchantName}. بنأكد طلبك قبل الشحن:\n📍 ${row.governorate} — ${row.area}\n${row.customerAddress}\n💰 المطلوب تحصيله: ${fresh.data.totalToCollect} ج.م\nمن فضلك رد بـ «نعم» لتأكيد الطلب. شكراً 🌟`)}
                    target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 text-emerald-500 font-semibold hover:underline">
                    <MessageCircle className="w-4 h-4" /> أرسل طلب تأكيد على واتساب
                  </a>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <div className="flex items-center gap-3">
        {errors.length > 0 && row.customerPhone && <p className="text-xs text-muted-foreground">{errors[0].message}</p>}
        <Button size="lg" className="mr-auto bg-primary hover:bg-primary/90" onClick={submit} disabled={!merchantId || errors.length > 0 || saving}>
          {saving ? <Loader2 className="w-4 h-4 animate-spin ml-2" /> : <Send className="w-4 h-4 ml-2" />} إنشاء الطلب وطباعة البوليصة
        </Button>
      </div>
      {!merchantId && <p className="text-sm text-amber-500">اختر التاجر أولاً.</p>}
    </div>
  );
}
