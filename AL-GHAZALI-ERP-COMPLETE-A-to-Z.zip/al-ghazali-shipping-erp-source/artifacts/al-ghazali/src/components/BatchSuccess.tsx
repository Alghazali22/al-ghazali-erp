import React from 'react';
import { CheckCircle2, Printer, Download, MessageCircle, Plus, Package } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { printLabels, type LabelOrder } from '@/lib/labels';
import { trackingLink, whatsappUrl } from '@/lib/share';

export interface CreatedOrder extends LabelOrder {
  packageValue: number;
  shippingFee: number;
}

const csvCell = (v: unknown) => {
  let t = v === null || v === undefined ? '' : String(v);
  if (/^[=+\-@\t\r]/.test(t)) t = `'${t}`; // spreadsheet formula-injection guard
  return `"${t.replace(/"/g, '""')}"`;
};

function downloadReport(orders: CreatedOrder[]) {
  const header = ['رقم الشحنة', 'العميل', 'الهاتف', 'المحافظة', 'المنطقة', 'العنوان', 'قيمة الشحنة', 'الشحن', 'المطلوب تحصيله', 'رابط التتبع'];
  const lines = [header.map(csvCell).join(',')];
  for (const o of orders) {
    lines.push([o.orderNumber, o.customerName, o.customerPhone, o.governorate, o.area, o.customerAddress,
      o.packageValue, o.shippingFee, o.totalToCollect, trackingLink(o.orderNumber)].map(csvCell).join(','));
  }
  const url = URL.createObjectURL(new Blob([`\uFEFF${lines.join('\r\n')}`], { type: 'text/csv;charset=utf-8' }));
  const a = document.createElement('a');
  a.href = url; a.download = `shipments-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}

/** Shown after shipments are created: print labels, export a report, message customers, start another batch. */
export function BatchSuccess({ orders, merchantName, remainingFailures = 0, onReset }: {
  orders: CreatedOrder[];
  merchantName: string;
  remainingFailures?: number;
  onReset: () => void;
}) {
  const { toast } = useToast();
  const totalCod = orders.reduce((a, o) => a + o.totalToCollect, 0);
  const totalShipping = orders.reduce((a, o) => a + o.shippingFee, 0);

  const print = (list: CreatedOrder[]) => {
    printLabels(list, merchantName).catch((e: Error) => toast({ variant: 'destructive', title: 'تعذر الطباعة', description: e.message }));
  };

  return (
    <Card className="border-emerald-500/30 bg-emerald-500/5">
      <CardContent className="p-5 sm:p-6 space-y-5">
        <div className="flex items-start gap-3">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/15 text-emerald-500 flex items-center justify-center shrink-0"><CheckCircle2 className="w-7 h-7" /></div>
          <div>
            <h2 className="text-xl font-bold">تم إنشاء {orders.length} {orders.length === 1 ? 'شحنة' : 'شحنات'} بنجاح</h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              إجمالي التحصيل المتوقع <b className="text-foreground">{Math.round(totalCod).toLocaleString('en-US')} ج.م</b> · رسوم الشحن <b className="text-foreground">{Math.round(totalShipping).toLocaleString('en-US')} ج.م</b>
            </p>
            {remainingFailures > 0 && <p className="text-sm text-amber-500 mt-1">{remainingFailures} صف لم يُنشأ — لا يزال في الجدول لتصحيحه.</p>}
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button onClick={() => print(orders)}><Printer className="w-4 h-4 ml-1.5" /> طباعة كل البوالص ({orders.length})</Button>
          <Button variant="outline" onClick={() => downloadReport(orders)}><Download className="w-4 h-4 ml-1.5" /> تقرير Excel</Button>
          <Button variant="outline" onClick={onReset}><Plus className="w-4 h-4 ml-1.5" /> دفعة جديدة</Button>
        </div>

        <details className="rounded-lg border border-border/40 bg-background/40" open={orders.length <= 8}>
          <summary className="cursor-pointer px-3 py-2 text-sm font-semibold">الشحنات وإرسال رابط التتبع للعملاء</summary>
          <ul className="divide-y divide-border/30">
            {orders.map((o) => (
              <li key={o.orderNumber} className="flex flex-wrap items-center gap-x-3 gap-y-1 px-3 py-2 text-sm">
                <span className="font-mono font-bold text-primary">{o.orderNumber}</span>
                <span className="flex-1 min-w-[8rem] truncate">{o.customerName} — {o.area}</span>
                <span className="font-mono text-xs">{o.totalToCollect} ج.م</span>
                <a
                  href={whatsappUrl(o.customerPhone, `مرحباً ${o.customerName} 👋\nشحنتك من ${merchantName} في الطريق عبر الغزالي للشحن.\nرقم الشحنة: ${o.orderNumber}\nتابعها وحدّد موقعك بدقة من هنا:\n${trackingLink(o.orderNumber)}`)}
                  target="_blank" rel="noreferrer"
                  className="inline-flex items-center gap-1 text-xs text-emerald-500 hover:underline"
                ><MessageCircle className="w-3.5 h-3.5" /> واتساب</a>
                <button type="button" onClick={() => print([o])} className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground" aria-label="طباعة بوليصة">
                  <Printer className="w-3.5 h-3.5" /> بوليصة
                </button>
              </li>
            ))}
          </ul>
        </details>
        <p className="text-xs text-muted-foreground flex items-center gap-1.5"><Package className="w-3.5 h-3.5" /> الصق البوليصة على الشحنة وسلّمها لفرع الغزالي أو المندوب — وسيتم استلامها بمسح الـ QR.</p>
      </CardContent>
    </Card>
  );
}
