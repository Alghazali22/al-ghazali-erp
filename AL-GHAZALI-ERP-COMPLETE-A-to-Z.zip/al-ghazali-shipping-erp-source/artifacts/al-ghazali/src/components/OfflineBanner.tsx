import React, { useEffect, useState } from 'react';
import { WifiOff } from 'lucide-react';

/** Drivers work on mobile data; make connection loss visible instead of silently failing. */
export function OfflineBanner() {
  const [online, setOnline] = useState(typeof navigator === 'undefined' ? true : navigator.onLine);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);
  if (online) return null;
  return (
    <div role="status" dir="rtl" className="fixed top-0 inset-x-0 z-[100] bg-destructive text-destructive-foreground text-center text-xs sm:text-sm py-1.5 flex items-center justify-center gap-2">
      <WifiOff className="w-4 h-4" /> لا يوجد اتصال بالإنترنت — سيتم استئناف العمل تلقائياً عند عودته
    </div>
  );
}
