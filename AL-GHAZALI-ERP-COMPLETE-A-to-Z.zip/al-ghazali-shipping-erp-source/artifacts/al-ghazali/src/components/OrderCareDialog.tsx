import React, { useEffect, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Phone, MessageCircle, PhoneOff, PhoneCall, CalendarClock, TicketPlus, Loader2, MapPin, Clock } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { apiFetch } from '@/lib/extra-api';
import { NOTE_KIND_LABELS, TICKET_TYPES, PRIORITIES, TICKET_STATUSES, WHATSAPP_TEMPLATES, whatsappFor } from '@/lib/support';

const fmt = (iso: string) => new Date(iso).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short', timeZone: 'Africa/Cairo' });

/** One screen with everything the care team needs for an order: contact, log, reschedule, tickets, timeline. */
export function OrderCareDialog({ orderId, onClose, onChanged }: { orderId: number | null; onClose: () => void; onChanged?: () => void }) {
  const { can } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const open = orderId !== null;
  const canManage = can('support.manage');
  const canReschedule = can('support.reschedule');
  const canTicket = can('support.create_ticket');

  const { data: order } = useQuery({ queryKey: ['care-order', orderId], queryFn: () => apiFetch<any>(`/orders/${orderId}`), enabled: open });
  const { data: care } = useQuery({
    queryKey: ['care-notes', orderId],
    queryFn: () => apiFetch<{ notes: { id: number; kind: string; body: string; authorName: string; createdAt: string }[]; tickets: { id: number; subject: string; status: string; priority: string }[] }>(`/support/orders/${orderId}/notes`),
    enabled: open,
  });

  const [noteText, setNoteText] = useState('');
  const [preferred, setPreferred] = useState('');
  const [ticketOpen, setTicketOpen] = useState(false);
  const [ticket, setTicket] = useState({ subject: '', type: 'complaint', priority: 'normal' });
  const [busy, setBusy] = useState<string | null>(null);
  useEffect(() => { if (!open) { setNoteText(''); setPreferred(''); setTicketOpen(false); } }, [open]);

  const refresh = () => { qc.invalidateQueries({ queryKey: ['care-notes', orderId] }); qc.invalidateQueries({ queryKey: ['care-order', orderId] }); qc.invalidateQueries({ queryKey: ['support-queue'] }); onChanged?.(); };

  const run = async (key: string, fn: () => Promise<unknown>, ok: string) => {
    setBusy(key);
    try { await fn(); toast({ title: ok }); refresh(); }
    catch (e: any) { toast({ variant: 'destructive', title: 'تعذر تنفيذ الإجراء', description: e.message }); }
    finally { setBusy(null); }
  };

  const logNote = (kind: string, body: string) =>
    apiFetch(`/support/orders/${orderId}/notes`, { method: 'POST', body: JSON.stringify({ kind, body }) });

  const sendTemplate = (t: (typeof WHATSAPP_TEMPLATES)[number]) => {
    window.open(whatsappFor(order.customerPhone, t.text(order)), '_blank', 'noopener');
    if (canManage) void logNote('whatsapp', `أُرسلت رسالة: ${t.label}`).then(refresh).catch(() => {});
  };

  const backInWarehouse = !!order?.returnedToBranchAt;

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) onClose(); }}>
      <DialogContent className="sm:max-w-2xl max-h-[92vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span className="font-mono text-primary">{order?.orderNumber ?? '...'}</span>
            {order && <Badge variant="outline" className="text-xs">{order.status}</Badge>}
          </DialogTitle>
          <DialogDescription>{order ? `${order.merchantName} • ${order.governorate} — ${order.area}` : 'جاري التحميل...'}</DialogDescription>
        </DialogHeader>

        {!order ? <div className="h-32 rounded-lg bg-muted/20 animate-pulse" /> : (
          <div className="space-y-5">
            <div className="rounded-xl border border-border/40 p-3 space-y-1.5 text-sm">
              <div className="flex items-center justify-between gap-2"><b>{order.customerName}</b>
                <a href={`tel:${order.customerPhone}`} className="font-mono text-primary inline-flex items-center gap-1" dir="ltr"><Phone className="w-3.5 h-3.5" />{order.customerPhone}</a></div>
              <p className="text-muted-foreground flex items-start gap-1.5"><MapPin className="w-3.5 h-3.5 mt-0.5 shrink-0" />{order.customerAddress}</p>
              {order.customerPhone2 && <p className="text-xs text-muted-foreground" dir="ltr">بديل: {order.customerPhone2}</p>}
            </div>

            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-2">رسائل واتساب جاهزة</p>
              <div className="flex flex-wrap gap-1.5">
                {WHATSAPP_TEMPLATES.map((t) => (
                  <Button key={t.key} size="sm" variant="outline" className="text-emerald-500 border-emerald-500/30" onClick={() => sendTemplate(t)}>
                    <MessageCircle className="w-3.5 h-3.5 ml-1" /> {t.label}
                  </Button>
                ))}
              </div>
            </div>

            {canManage && (
              <div className="space-y-2">
                <p className="text-xs font-semibold text-muted-foreground">سجّل نتيجة المكالمة أو أضف ملاحظة</p>
                <Input value={noteText} onChange={(e) => setNoteText(e.target.value)} placeholder="تفاصيل (اختياري للمكالمات)" maxLength={1000} />
                <div className="flex flex-wrap gap-1.5">
                  <Button size="sm" variant="outline" disabled={busy !== null} onClick={() => run('answered', () => logNote('call_answered', noteText.trim() || 'تم الاتصال بالعميل'), 'تم تسجيل المكالمة').then(() => setNoteText(''))}><PhoneCall className="w-3.5 h-3.5 ml-1" /> رد</Button>
                  <Button size="sm" variant="outline" disabled={busy !== null} onClick={() => run('noanswer', () => logNote('call_no_answer', noteText.trim() || 'لم يرد العميل'), 'تم تسجيل المكالمة').then(() => setNoteText(''))}><PhoneOff className="w-3.5 h-3.5 ml-1" /> لم يرد</Button>
                  <Button size="sm" variant="outline" disabled={busy !== null || !noteText.trim()} onClick={() => run('note', () => logNote('note', noteText.trim()), 'تمت الإضافة').then(() => setNoteText(''))}>إضافة ملاحظة</Button>
                </div>
              </div>
            )}

            {canReschedule && order.status === 'returned' && (
              <div className="rounded-xl border border-primary/30 bg-primary/5 p-3 space-y-2">
                <p className="font-semibold text-sm flex items-center gap-1.5"><CalendarClock className="w-4 h-4 text-primary" /> إعادة جدولة التسليم</p>
                {backInWarehouse ? (
                  <>
                    <Input value={preferred} onChange={(e) => setPreferred(e.target.value)} placeholder="الموعد المفضّل للعميل (مثال: بكره بعد 5 المغرب)" maxLength={200} />
                    <Button size="sm" disabled={busy !== null} onClick={() => run('redeliver', () => apiFetch(`/support/orders/${orderId}/redeliver`, { method: 'POST', body: JSON.stringify({ preferredTime: preferred || undefined }) }), 'أُعيدت الشحنة لقائمة التوزيع')}>
                      {busy === 'redeliver' ? <Loader2 className="w-4 h-4 animate-spin ml-1" /> : null} إعادة للتوزيع
                    </Button>
                  </>
                ) : <p className="text-xs text-amber-500">الشحنة لم تصل مخزن الفرع بعد — انتظر حتى تُستلم من المندوب.</p>}
              </div>
            )}

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-muted-foreground">التذاكر ({care?.tickets.length ?? 0})</p>
                {canTicket && <Button size="sm" variant="ghost" onClick={() => setTicketOpen((v) => !v)}><TicketPlus className="w-3.5 h-3.5 ml-1" /> تذكرة جديدة</Button>}
              </div>
              {ticketOpen && (
                <div className="rounded-lg border border-border/40 p-3 space-y-2">
                  <Input value={ticket.subject} onChange={(e) => setTicket({ ...ticket, subject: e.target.value })} placeholder="عنوان التذكرة" maxLength={140} />
                  <div className="flex gap-2">
                    <select value={ticket.type} onChange={(e) => setTicket({ ...ticket, type: e.target.value })} className="h-9 flex-1 rounded-md border border-border bg-background/50 px-2 text-sm">
                      {Object.entries(TICKET_TYPES).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                    </select>
                    <select value={ticket.priority} onChange={(e) => setTicket({ ...ticket, priority: e.target.value })} className="h-9 flex-1 rounded-md border border-border bg-background/50 px-2 text-sm">
                      {Object.entries(PRIORITIES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                    </select>
                  </div>
                  <Button size="sm" disabled={busy !== null || ticket.subject.trim().length < 3}
                    onClick={() => run('ticket', () => apiFetch('/support/tickets', { method: 'POST', body: JSON.stringify({ ...ticket, orderId }) }), 'تم فتح التذكرة').then(() => { setTicketOpen(false); setTicket({ subject: '', type: 'complaint', priority: 'normal' }); })}>فتح التذكرة</Button>
                </div>
              )}
              {care?.tickets.map((t) => (
                <div key={t.id} className="flex items-center justify-between rounded-lg border border-border/30 px-3 py-1.5 text-sm">
                  <span>#{t.id} {t.subject}</span>
                  <span className="flex gap-1.5"><Badge variant="outline" className={`${PRIORITIES[t.priority]?.cls} text-[10px]`}>{PRIORITIES[t.priority]?.label}</Badge><Badge variant="outline" className="text-[10px]">{TICKET_STATUSES[t.status]}</Badge></span>
                </div>
              ))}
            </div>

            <div className="space-y-1.5">
              <p className="text-xs font-semibold text-muted-foreground">سجل التواصل الداخلي</p>
              {care?.notes.length ? care.notes.map((n) => (
                <div key={n.id} className="rounded-lg bg-muted/20 px-3 py-2 text-sm">
                  <div className="flex justify-between text-[11px] text-muted-foreground"><span>{NOTE_KIND_LABELS[n.kind] ?? n.kind} — {n.authorName}</span><span>{fmt(n.createdAt)}</span></div>
                  <p className="mt-0.5">{n.body}</p>
                </div>
              )) : <p className="text-xs text-muted-foreground">لا توجد ملاحظات بعد</p>}
            </div>

            <div className="space-y-1.5">
              <p className="text-xs font-semibold text-muted-foreground flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> تسلسل الطلب (ما يراه العميل)</p>
              <ul className="text-xs space-y-1 border-r-2 border-border/40 pr-3">
                {[...(order.timeline ?? [])].reverse().slice(0, 8).map((e: any) => (
                  <li key={e.id}><span className="text-muted-foreground">{fmt(e.timestamp)}</span> — {e.description}</li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
