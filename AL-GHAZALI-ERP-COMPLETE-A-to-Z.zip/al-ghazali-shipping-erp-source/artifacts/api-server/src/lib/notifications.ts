/**
 * External notifications (SMS / WhatsApp).
 * Configure via environment variables — if keys are missing, calls no-op safely.
 *
 * Supported:
 *   SMS_PROVIDER=twilio | console
 *   TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM_NUMBER
 *   WHATSAPP_PROVIDER=twilio | meta | console
 *   WHATSAPP_FROM_NUMBER  (e.g. whatsapp:+1415... for Twilio)
 *   META_WHATSAPP_TOKEN, META_WHATSAPP_PHONE_ID  (Cloud API)
 *   PUBLIC_APP_URL  (used in tracking links)
 */

type NotifyResult = { ok: boolean; channel: string; detail?: string };

function env(name: string): string {
  return (process.env[name] || "").trim();
}

function normalizePhoneEG(raw: string): string | null {
  let d = raw.replace(/\D/g, "");
  if (d.startsWith("0020")) d = d.slice(4);
  if (d.startsWith("20") && d.length >= 12) d = d.slice(2);
  if (d.startsWith("0") && d.length === 11) d = d.slice(1);
  if (d.length === 10 && d.startsWith("1")) return `+20${d}`;
  if (d.length >= 10) return d.startsWith("+") ? d : `+${d}`;
  return null;
}

async function twilioSend(to: string, body: string, asWhatsApp: boolean): Promise<NotifyResult> {
  const sid = env("TWILIO_ACCOUNT_SID");
  const token = env("TWILIO_AUTH_TOKEN");
  const from = asWhatsApp
    ? env("WHATSAPP_FROM_NUMBER") || env("TWILIO_WHATSAPP_FROM")
    : env("TWILIO_FROM_NUMBER");
  if (!sid || !token || !from) {
    return { ok: false, channel: asWhatsApp ? "whatsapp" : "sms", detail: "twilio_not_configured" };
  }
  const toAddr = asWhatsApp ? (to.startsWith("whatsapp:") ? to : `whatsapp:${to}`) : to;
  const fromAddr = asWhatsApp ? (from.startsWith("whatsapp:") ? from : `whatsapp:${from}`) : from;
  const auth = Buffer.from(`${sid}:${token}`).toString("base64");
  const params = new URLSearchParams({ To: toAddr, From: fromAddr, Body: body });
  const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
    method: "POST",
    headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: params,
  });
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    return { ok: false, channel: asWhatsApp ? "whatsapp" : "sms", detail: `twilio_${res.status}:${t.slice(0, 200)}` };
  }
  return { ok: true, channel: asWhatsApp ? "whatsapp" : "sms" };
}

async function metaWhatsAppSend(to: string, body: string): Promise<NotifyResult> {
  const token = env("META_WHATSAPP_TOKEN");
  const phoneId = env("META_WHATSAPP_PHONE_ID");
  if (!token || !phoneId) return { ok: false, channel: "whatsapp", detail: "meta_not_configured" };
  const digits = to.replace(/\D/g, "");
  const res = await fetch(`https://graph.facebook.com/v19.0/${phoneId}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: digits,
      type: "text",
      text: { body },
    }),
  });
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    return { ok: false, channel: "whatsapp", detail: `meta_${res.status}:${t.slice(0, 200)}` };
  }
  return { ok: true, channel: "whatsapp" };
}

export async function sendSms(phone: string, message: string): Promise<NotifyResult> {
  const to = normalizePhoneEG(phone);
  if (!to) return { ok: false, channel: "sms", detail: "invalid_phone" };
  const provider = (env("SMS_PROVIDER") || "console").toLowerCase();
  if (provider === "twilio") return twilioSend(to, message, false);
  console.log(`[SMS:console] to=${to} msg=${message.slice(0, 120)}`);
  return { ok: true, channel: "sms", detail: "console" };
}

export async function sendWhatsApp(phone: string, message: string): Promise<NotifyResult> {
  const to = normalizePhoneEG(phone);
  if (!to) return { ok: false, channel: "whatsapp", detail: "invalid_phone" };
  const provider = (env("WHATSAPP_PROVIDER") || "console").toLowerCase();
  if (provider === "twilio") return twilioSend(to, message, true);
  if (provider === "meta") return metaWhatsAppSend(to, message);
  console.log(`[WA:console] to=${to} msg=${message.slice(0, 120)}`);
  return { ok: true, channel: "whatsapp", detail: "console" };
}

export function trackingUrl(orderNumber: string): string {
  const base = env("PUBLIC_APP_URL") || "https://localhost";
  return `${base.replace(/\/$/, "")}/track?order=${encodeURIComponent(orderNumber)}`;
}

export async function notifyCustomerOrderCreated(opts: {
  phone: string;
  customerName: string;
  orderNumber: string;
  otp?: string | null;
}): Promise<void> {
  const link = trackingUrl(opts.orderNumber);
  const otpPart = opts.otp ? `\nكود التسليم: ${opts.otp}` : "";
  const msg = `مرحباً ${opts.customerName}\nشحنة الغزالي رقم ${opts.orderNumber} قيد التجهيز.${otpPart}\nتتبع: ${link}`;
  // Prefer WhatsApp; fall back to SMS. Fire-and-forget.
  void sendWhatsApp(opts.phone, msg).then((r) => {
    if (!r.ok) void sendSms(opts.phone, msg);
  });
}

export async function notifyCustomerDelivered(opts: {
  phone: string;
  customerName: string;
  orderNumber: string;
}): Promise<void> {
  const msg = `تم تسليم شحنة الغزالي ${opts.orderNumber} بنجاح. شكراً لثقتك.`;
  void sendWhatsApp(opts.phone, msg).then((r) => {
    if (!r.ok) void sendSms(opts.phone, msg);
  });
}

export async function notifyCustomerOutForDelivery(opts: {
  phone: string;
  customerName: string;
  orderNumber: string;
  otp?: string | null;
}): Promise<void> {
  const link = trackingUrl(opts.orderNumber);
  const otpPart = opts.otp ? `\nأعطِ المندوب كود التسليم: ${opts.otp}` : "";
  const msg = `${opts.customerName}، مندوب الغزالي في الطريق لشحنة ${opts.orderNumber}.${otpPart}\nتتبع حي: ${link}`;
  void sendWhatsApp(opts.phone, msg).then((r) => {
    if (!r.ok) void sendSms(opts.phone, msg);
  });
}


export async function notifyDriverTripReady(opts: {
  phone?: string | null;
  driverName: string;
  orderCount: number;
  totalToCollect: number;
}): Promise<void> {
  if (!opts.phone) return;
  const msg = `${opts.driverName}، رحلة جديدة جاهزة: ${opts.orderCount} شحنة — تحصيل متوقع ${Math.round(opts.totalToCollect)} ج.م. افتح تطبيق الغزالي وأكد استلام الشحنات.`;
  void sendWhatsApp(opts.phone, msg).then((r) => {
    if (!r.ok) void sendSms(opts.phone!, msg);
  });
}
