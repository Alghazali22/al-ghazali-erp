import type { Request } from "express";

/** Parse a positive integer id (route param / query). Returns null when invalid. */
export function parseId(value: unknown): number | null {
  const n = typeof value === "number" ? value : Number(String(value ?? ""));
  return Number.isInteger(n) && n > 0 && n <= 2_147_483_647 ? n : null;
}

/** Clamp pagination input to safe bounds (never NaN, never unbounded). */
export function parsePagination(
  query: Request["query"],
  opts: { defaultLimit?: number; maxLimit?: number } = {},
): { page: number; limit: number; offset: number } {
  const { defaultLimit = 20, maxLimit = 100 } = opts;
  const rawPage = Number(query.page);
  const rawLimit = Number(query.limit);
  const page = Number.isInteger(rawPage) && rawPage >= 1 ? Math.min(rawPage, 100_000) : 1;
  const limit = Number.isInteger(rawLimit) && rawLimit >= 1 ? Math.min(rawLimit, maxLimit) : defaultLimit;
  return { page, limit, offset: (page - 1) * limit };
}

/** Escape LIKE/ILIKE wildcards so user input is matched literally. */
export function escapeLike(input: string): string {
  return input.replace(/[\\%_]/g, (c) => `\\${c}`);
}

/**
 * Parse a money amount. Accepts numbers or numeric strings, rounds to 2 decimals.
 * Returns null for NaN / Infinity / negative / above `max`.
 */
export function parseMoney(value: unknown, opts: { max?: number; allowZero?: boolean } = {}): number | null {
  const { max = 10_000_000, allowZero = false } = opts;
  if (value === null || value === undefined || value === "") return null;
  const n = typeof value === "number" ? value : Number(String(value).trim());
  if (!Number.isFinite(n)) return null;
  const rounded = Math.round(n * 100) / 100;
  if (rounded < 0 || (rounded === 0 && !allowZero) || rounded > max) return null;
  return rounded;
}

/** Round to 2 decimals (money arithmetic helper). */
export function round2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

export function asTrimmedString(value: unknown, maxLength = 500): string | null {
  if (typeof value !== "string") return null;
  const t = value.trim();
  if (!t || t.length > maxLength) return null;
  return t;
}

export function optionalString(value: unknown, maxLength = 500): string | null | undefined {
  if (value === undefined) return undefined;
  if (value === null) return null;
  if (typeof value !== "string") return undefined;
  const t = value.trim();
  if (t.length > maxLength) return undefined;
  return t === "" ? null : t;
}

/** Normalise Eastern-Arabic / Persian digits to Western digits. */
export function normalizeDigits(value: string): string {
  return value
    .replace(/[\u0660-\u0669]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .replace(/[\u06f0-\u06f9]/g, (d) => String(d.charCodeAt(0) - 0x06f0));
}

/** Loose phone validation: 7-15 digits, optional leading +. Returns normalised string or null. */
export function parsePhone(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const cleaned = normalizeDigits(value).replace(/[\s\-()]/g, "");
  return /^\+?\d{7,15}$/.test(cleaned) ? cleaned : null;
}

export function isOneOf<T extends string>(value: unknown, allowed: readonly T[]): value is T {
  return typeof value === "string" && (allowed as readonly string[]).includes(value);
}

/** Postgres unique-violation check (works for pg and drizzle-wrapped errors). */
export function isUniqueViolation(err: unknown): boolean {
  const e = err as any;
  return e?.code === "23505" || e?.cause?.code === "23505";
}

export const USER_ROLES = [
  "super_admin", "branch_manager", "accountant", "operations", "cs", "driver", "merchant",
] as const;
export type UserRole = (typeof USER_ROLES)[number];

export const ORDER_STATUSES = [
  "pending", "ready", "in_transit", "delivered", "partial_delivery", "returned", "final_return",
] as const;

/** Roles scoped to a single branch. */
export const BRANCH_SCOPED_ROLES = ["branch_manager", "cs", "operations"] as const;

/** Last 10 digits of a phone number — a normalised key that matches 010..., +2010... and 2010... forms. */
export function phoneKey(phone: string): string {
  return normalizeDigits(phone).replace(/\D/g, "").slice(-10);
}
