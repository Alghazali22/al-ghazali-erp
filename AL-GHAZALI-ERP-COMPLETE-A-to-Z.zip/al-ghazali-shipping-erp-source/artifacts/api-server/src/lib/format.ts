export function iso(value: unknown): string | null {
  if (value instanceof Date) return value.toISOString();
  return (value as string | null | undefined) ?? null;
}

export function num(value: unknown): number {
  const n = parseFloat(String(value ?? "0"));
  return Number.isFinite(n) ? n : 0;
}

/** Strip secrets and convert numeric columns. Single source of truth (was duplicated). */
export function formatUser(user: any) {
  const { passwordHash: _passwordHash, ...rest } = user;
  return {
    ...rest,
    cashBalance: num(rest.cashBalance),
    settlementCredit: num(rest.settlementCredit),
    walletBalance: num(rest.walletBalance),
    pendingBalance: num(rest.pendingBalance),
    totalWithdrawn: num(rest.totalWithdrawn),
    createdAt: iso(rest.createdAt),
  };
}
