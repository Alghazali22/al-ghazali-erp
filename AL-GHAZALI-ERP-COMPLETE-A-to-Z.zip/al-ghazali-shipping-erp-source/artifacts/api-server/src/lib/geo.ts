import { cairoHour } from "./time";

export interface Pt { lat: number; lng: number }

// Estimation constants (heuristics — there is no live-traffic feed behind them).
export const ROAD_FACTOR = 1.35;     // straight-line distance → realistic road distance
export const AVG_SPEED_KMH = 28;     // average urban courier speed incl. lights
export const SERVICE_TIME_MIN = 8;   // time per stop (parking, hand-off, OTP, payment)

export function haversineKm(a: Pt, b: Pt): number {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const x = Math.sin(dLat / 2) ** 2 +
    Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
}

export function bearing(from: Pt, to: Pt): number {
  const lat1 = (from.lat * Math.PI) / 180;
  const lat2 = (to.lat * Math.PI) / 180;
  const dLng = ((to.lng - from.lng) * Math.PI) / 180;
  const y = Math.sin(dLng) * Math.cos(lat2);
  const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
  return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
}

export function cairoDayOfWeek(d = new Date()): number {
  const name = new Intl.DateTimeFormat("en-US", { timeZone: "Africa/Cairo", weekday: "short" }).format(d);
  return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].indexOf(name);
}

/** Rule-based congestion multiplier by Cairo local time (Friday is the quiet day). */
export function getTrafficMultiplier(hour: number, dayOfWeek: number): number {
  const friday = dayOfWeek === 5;
  if (!friday && ((hour >= 7 && hour < 10) || (hour >= 15 && hour < 20))) return 1.6;
  if (hour >= 22 || hour < 6) return 0.85;
  return friday ? 1.0 : 1.15;
}

export function currentTrafficMultiplier(now = new Date()): number {
  return getTrafficMultiplier(cairoHour(now), cairoDayOfWeek(now));
}

/** Walks a list of stops from `start`; returns the cumulative ETA (minutes) for each stop, null once coordinates run out. */
export function estimateStops(start: Pt | null, stops: (Pt | null)[], traffic: number) {
  let cursor = start;
  let minutes = 0;
  return stops.map((stop) => {
    if (!cursor || !stop) { cursor = null; return { etaMinutes: null as number | null, distanceKm: null as number | null }; }
    const km = haversineKm(cursor, stop) * ROAD_FACTOR;
    minutes += (km / AVG_SPEED_KMH) * 60 * traffic + SERVICE_TIME_MIN;
    cursor = stop;
    return { etaMinutes: Math.round(minutes), distanceKm: Math.round(km * 10) / 10 };
  });
}

export function pathLengthKm(start: Pt | null, stops: Pt[]): number {
  let total = 0;
  let cursor = start;
  for (const s of stops) {
    if (cursor) total += haversineKm(cursor, s) * ROAD_FACTOR;
    cursor = s;
  }
  return Math.round(total * 10) / 10;
}

/** Open-path route ordering: nearest-neighbour construction + 2-opt refinement. `start` stays fixed. */
export function optimizeRoute<T extends { pt: Pt }>(start: Pt | null, items: T[]): T[] {
  if (items.length <= 2 && !start) return [...items];
  const remaining = [...items];
  const ordered: T[] = [];

  let cursor: Pt;
  if (start) {
    cursor = start;
  } else {
    // No known start: begin from the stop farthest from the group's centre (an end of the cluster).
    const c = { lat: items.reduce((a, i) => a + i.pt.lat, 0) / items.length, lng: items.reduce((a, i) => a + i.pt.lng, 0) / items.length };
    let far = 0;
    remaining.forEach((it, idx) => { if (haversineKm(c, it.pt) > haversineKm(c, remaining[far].pt)) far = idx; });
    const first = remaining.splice(far, 1)[0];
    ordered.push(first);
    cursor = first.pt;
  }
  while (remaining.length) {
    let best = 0;
    let bestD = Infinity;
    remaining.forEach((it, idx) => {
      const d = haversineKm(cursor, it.pt);
      if (d < bestD) { bestD = d; best = idx; }
    });
    const next = remaining.splice(best, 1)[0];
    ordered.push(next);
    cursor = next.pt;
  }

  // 2-opt on the open path (the fixed start, when present, is never moved).
  const offset = start ? 1 : 0;
  const pts: Pt[] = start ? [start, ...ordered.map((o) => o.pt)] : ordered.map((o) => o.pt);
  const order = ordered.map((_, i) => i);
  const d = (a: number, b: number) => haversineKm(pts[a + 0], pts[b + 0]);
  const idx = (i: number) => (i < offset ? i : offset + order[i - offset]);
  const n = pts.length;
  let improved = true;
  let guard = 0;
  while (improved && guard++ < 40) {
    improved = false;
    for (let i = Math.max(offset, 1) - (start ? 0 : 0); i < n - 1; i++) {
      for (let j = i + 1; j < n; j++) {
        const before = i > 0 ? d(idx(i - 1), idx(i)) : 0;
        const after = j < n - 1 ? d(idx(j), idx(j + 1)) : 0;
        const newBefore = i > 0 ? d(idx(i - 1), idx(j)) : 0;
        const newAfter = j < n - 1 ? d(idx(i), idx(j + 1)) : 0;
        if (newBefore + newAfter + 1e-9 < before + after) {
          // reverse the segment [i..j] (positions inside `order`)
          const a = i - offset;
          const b = j - offset;
          const seg = order.slice(a, b + 1).reverse();
          order.splice(a, b - a + 1, ...seg);
          improved = true;
        }
      }
    }
  }
  return order.map((i) => ordered[i]);
}

/** Sweep clustering: split stops into `k` contiguous angular sectors of near-equal size. */
export function sweepPartition<T extends { pt: Pt }>(items: T[], k: number): T[][] {
  if (k <= 1 || items.length <= 1) return [items];
  const c = { lat: items.reduce((a, i) => a + i.pt.lat, 0) / items.length, lng: items.reduce((a, i) => a + i.pt.lng, 0) / items.length };
  const withAngle = items
    .map((it) => ({ it, ang: Math.atan2(it.pt.lat - c.lat, it.pt.lng - c.lng) }))
    .sort((a, b) => a.ang - b.ang);
  // Start the sweep at the widest angular gap so a dense cluster is never cut in half.
  let gapAt = 0;
  let gapSize = -1;
  withAngle.forEach((cur, i) => {
    const next = withAngle[(i + 1) % withAngle.length];
    const gap = (next.ang - cur.ang + 2 * Math.PI) % (2 * Math.PI);
    if (gap > gapSize) { gapSize = gap; gapAt = (i + 1) % withAngle.length; }
  });
  const rotated = [...withAngle.slice(gapAt), ...withAngle.slice(0, gapAt)].map((x) => x.it);
  const chunks: T[][] = [];
  const size = Math.ceil(rotated.length / k);
  for (let i = 0; i < k; i++) chunks.push(rotated.slice(i * size, (i + 1) * size));
  return chunks.filter((c2) => c2.length > 0);
}

// ---------------------------------------------------------------------------
// Governorate centres — fallback when a zone has no coordinates of its own, so ETA, route
// optimisation and smart dispatch work out of the box (coarse), and get precise as zones are filled in.
// ---------------------------------------------------------------------------
const GOVERNORATE_CENTERS: Record<string, Pt> = {
  "القاهرة": { lat: 30.0444, lng: 31.2357 }, "الجيزة": { lat: 30.0131, lng: 31.2089 },
  "الإسكندرية": { lat: 31.2001, lng: 29.9187 }, "القليوبية": { lat: 30.466, lng: 31.185 },
  "الشرقية": { lat: 30.5877, lng: 31.502 }, "الدقهلية": { lat: 31.0409, lng: 31.3785 },
  "الغربية": { lat: 30.7865, lng: 31.0004 }, "المنوفية": { lat: 30.5972, lng: 30.9876 },
  "البحيرة": { lat: 31.0341, lng: 30.4682 }, "كفر الشيخ": { lat: 31.1107, lng: 30.9388 },
  "دمياط": { lat: 31.4165, lng: 31.8133 }, "بورسعيد": { lat: 31.2653, lng: 32.3019 },
  "الإسماعيلية": { lat: 30.5965, lng: 32.2715 }, "السويس": { lat: 29.9668, lng: 32.5498 },
  "شمال سيناء": { lat: 31.1316, lng: 33.7984 }, "جنوب سيناء": { lat: 28.241, lng: 33.6221 },
  "الفيوم": { lat: 29.3084, lng: 30.8428 }, "بني سويف": { lat: 29.0661, lng: 31.0994 },
  "المنيا": { lat: 28.1099, lng: 30.7503 }, "أسيوط": { lat: 27.1783, lng: 31.1859 },
  "سوهاج": { lat: 26.5569, lng: 31.6948 }, "قنا": { lat: 26.1551, lng: 32.716 },
  "الأقصر": { lat: 25.6872, lng: 32.6396 }, "أسوان": { lat: 24.0889, lng: 32.8998 },
  "البحر الأحمر": { lat: 27.2579, lng: 33.8116 }, "الوادي الجديد": { lat: 25.439, lng: 30.5586 },
  "مطروح": { lat: 31.3543, lng: 27.2373 },
};

const normalizeArabic = (s: string) =>
  s.replace(/محافظة/g, "").replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").replace(/\s+/g, " ").trim();

const NORMALIZED_CENTERS = new Map(Object.entries(GOVERNORATE_CENTERS).map(([k, v]) => [normalizeArabic(k), v]));

export function governorateCenter(name: string | null | undefined): Pt | null {
  if (!name) return null;
  return NORMALIZED_CENTERS.get(normalizeArabic(name)) ?? null;
}
