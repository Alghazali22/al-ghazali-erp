export type Role = "super_admin" | "branch_manager" | "accountant" | "operations" | "cs" | "driver" | "merchant";

export interface PermissionDef {
  key: string;
  label: string;
  /** Roles that have it by default. Per-employee grants/revokes are layered on top. */
  roles: Role[];
  /** Cannot be handed to anyone else (only super_admin has it). */
  locked?: boolean;
}
export interface PermissionGroup { key: string; label: string; permissions: PermissionDef[] }

const STAFF: Role[] = ["super_admin", "branch_manager", "operations"];

/**
 * The single source of truth for "who can do what". The defaults below reproduce exactly what each role could
 * already do before this catalog existed; the super admin can then grant/revoke individual permissions per employee.
 * Data SCOPE (own branch vs every branch, own orders vs all) still comes from the role — a permission only
 * answers "may this person perform this kind of action at all".
 */
export const PERMISSION_GROUPS: PermissionGroup[] = [
  { key: "orders", label: "الطلبات", permissions: [
    { key: "orders.bulk_import", label: "رفع طلبات بالجملة (Excel / Google Sheets)", roles: ["merchant", ...STAFF] },
    { key: "orders.export", label: "تصدير الطلبات إلى Excel", roles: ["super_admin", "branch_manager", "accountant", "operations", "cs", "merchant"] },
    { key: "orders.deliver", label: "تسليم أو إرجاع شحنة (بكود التأكيد)", roles: ["driver", ...STAFF] },
    { key: "orders.emergency_otp", label: "عرض كود الطوارئ (OTP)", roles: ["super_admin", "branch_manager"] },
    { key: "orders.status_override", label: "تغيير حالة الطلب يدوياً", roles: ["super_admin"] },
    { key: "orders.delete", label: "حذف طلب", roles: ["super_admin"] },
  ] },
  { key: "ops", label: "العمليات والمخزن", permissions: [
    { key: "warehouse.manage", label: "استلام الشحنات وتحويلها بين الفروع", roles: STAFF },
    { key: "dispatch.manage", label: "إنشاء الرحلات والتحميل والتوزيع الذكي واستلام المرتجعات", roles: STAFF },
    { key: "dispatch.shifts", label: "إدارة شيفتات المناديب وترتيب الدور", roles: STAFF },
    { key: "dispatch.override", label: "تجاوز شروط انطلاق الرحلة", roles: ["super_admin", "branch_manager"] },
    { key: "trips.delete", label: "حذف رحلة", roles: ["super_admin"] },
    { key: "tracking.view", label: "تتبع المناديب مباشرة على الخريطة", roles: STAFF },
  ] },
  { key: "finance", label: "المالية", permissions: [
    { key: "finance.view", label: "عرض أرصدة المناديب والخزينة والمعاملات", roles: ["super_admin", "branch_manager", "accountant"] },
    { key: "finance.settle", label: "تسوية كاش المناديب", roles: ["super_admin", "branch_manager", "accountant"] },
    { key: "finance.approve_withdrawals", label: "الموافقة على طلبات سحب التجار أو رفضها", roles: ["super_admin", "accountant"] },
  ] },
  { key: "people", label: "المستخدمون", permissions: [
    { key: "users.create", label: "إضافة مستخدمين", roles: ["super_admin", "branch_manager"] },
    { key: "users.reset_password", label: "إعادة تعيين كلمات المرور", roles: ["super_admin", "branch_manager"] },
    { key: "users.toggle", label: "تفعيل وتعطيل الحسابات", roles: ["super_admin", "branch_manager"] },
    { key: "users.delete", label: "حذف مستخدم", roles: ["super_admin"] },
  ] },
  { key: "config", label: "الإعدادات", permissions: [
    { key: "zones.manage", label: "إدارة المناطق وأسعار الشحن", roles: ["super_admin"] },
    { key: "pricing.manage", label: "أسعار التجار الخاصة", roles: ["super_admin"] },
    { key: "branches.manage", label: "إدارة الفروع", roles: ["super_admin"] },
    { key: "branches.lockdown", label: "قفل فرع في الطوارئ", roles: ["super_admin", "branch_manager"] },
    { key: "system.announcement", label: "إعلان النظام", roles: ["super_admin"] },
    { key: "system.shutdown", label: "إيقاف النظام", roles: ["super_admin"] },
  ] },
  { key: "insight", label: "التحليلات والعملاء", permissions: [
    { key: "analytics.view", label: "صفحة التحليلات", roles: ["super_admin", "accountant", "branch_manager", "operations", "merchant"] },
    { key: "analytics.team", label: "أداء المناديب والتجار في التحليلات", roles: ["super_admin", "accountant", "branch_manager", "operations"] },
    { key: "customers.reputation", label: "سمعة العميل (مرتجعات الشبكة)", roles: ["merchant", "super_admin", "branch_manager", "operations", "cs"] },
    { key: "customers.lookup", label: "بحث العملاء السابقين", roles: ["merchant", ...STAFF] },
    { key: "integrations.manage", label: "مفاتيح API وربط المتاجر", roles: ["merchant", "super_admin"] },
  ] },
  { key: "support", label: "خدمة العملاء", permissions: [
    { key: "support.view", label: "مركز خدمة العملاء وطابور المتابعة", roles: ["cs", ...STAFF] },
    { key: "support.manage", label: "تسجيل المكالمات وإدارة التذاكر", roles: ["cs", "super_admin", "branch_manager"] },
    { key: "support.reschedule", label: "إعادة جدولة تسليم شحنة مرتجعة", roles: ["cs", "super_admin", "branch_manager"] },
    { key: "support.create_ticket", label: "فتح تذكرة دعم", roles: ["merchant", "cs", ...STAFF] },
  ] },
  { key: "admin", label: "الإدارة العليا", permissions: [
    { key: "audit.view", label: "سجل العمليات الحساسة", roles: ["super_admin"] },
    { key: "permissions.manage", label: "إدارة الصلاحيات", roles: ["super_admin"], locked: true },
  ] },
];

const ALL: PermissionDef[] = PERMISSION_GROUPS.flatMap((g) => g.permissions);
export const ALL_PERMISSION_KEYS = ALL.map((p) => p.key);
const BY_KEY = new Map(ALL.map((p) => [p.key, p]));

export const isValidPermission = (key: string) => BY_KEY.has(key);
export const isGrantable = (key: string) => BY_KEY.has(key) && !BY_KEY.get(key)!.locked;

/** Customers-of-the-company roles never receive extra grants (a merchant must not be able to approve payouts). */
const EXTERNAL_ROLES: Role[] = ["merchant", "driver"];
export const canHaveGrants = (role: string) => !EXTERNAL_ROLES.includes(role as Role) && role !== "super_admin";

export function roleDefaults(role: string): Set<string> {
  return new Set(ALL.filter((p) => p.roles.includes(role as Role)).map((p) => p.key));
}

export function effectivePermissions(role: string, grant: string[] = [], revoke: string[] = []): Set<string> {
  if (role === "super_admin") return new Set(ALL_PERMISSION_KEYS); // the owner can never be locked out
  const set = roleDefaults(role);
  if (canHaveGrants(role)) for (const g of grant) if (isGrantable(g)) set.add(g);
  for (const r of revoke) if (isValidPermission(r)) set.delete(r);
  set.delete("permissions.manage");
  return set;
}
