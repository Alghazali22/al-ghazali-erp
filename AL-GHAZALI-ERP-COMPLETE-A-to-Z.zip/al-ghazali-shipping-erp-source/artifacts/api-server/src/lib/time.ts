// The business operates in Cairo time. The server runs in UTC, so "today",
// "rush hour", etc. must be computed explicitly in Africa/Cairo.
const TZ = "Africa/Cairo";

const fmt = new Intl.DateTimeFormat("en-US", {
  timeZone: TZ,
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hourCycle: "h23",
});

function parts(d: Date) {
  const out: Record<string, number> = {};
  for (const p of fmt.formatToParts(d)) {
    if (p.type !== "literal") out[p.type] = Number(p.value);
  }
  return out as { year: number; month: number; day: number; hour: number; minute: number; second: number };
}

function wallClockAsUtc(d: Date): number {
  const p = parts(d);
  return Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
}

export function cairoHour(d: Date = new Date()): number {
  return parts(d).hour;
}

/** The instant at which the Cairo calendar day containing `d` started. */
export function startOfCairoDay(d: Date = new Date()): Date {
  const p = parts(d);
  const target = Date.UTC(p.year, p.month - 1, p.day, 0, 0, 0);
  let guess = target;
  for (let i = 0; i < 3; i++) {
    const offset = wallClockAsUtc(new Date(guess)) - guess;
    guess = target - offset;
  }
  return new Date(guess);
}

/** Start of the Cairo day `daysAgo` days before today's. */
export function startOfCairoDayAgo(daysAgo: number, now: Date = new Date()): Date {
  const today = startOfCairoDay(now);
  // +12h lands safely mid-day regardless of DST shifts
  return startOfCairoDay(new Date(today.getTime() - daysAgo * 86_400_000 + 12 * 3_600_000));
}

export function cairoDateKey(d: Date): string {
  const p = parts(d);
  return `${p.year}-${String(p.month).padStart(2, "0")}-${String(p.day).padStart(2, "0")}`;
}
