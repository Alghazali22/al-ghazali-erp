import type { Request, Response, NextFunction } from "express";

interface Bucket { count: number; resetAt: number }

/**
 * Small in-memory fixed-window rate limiter (no extra dependency).
 * NOTE: state is per-process. On multi-instance autoscale deployments each
 * instance enforces its own window, which is still a strong brute-force brake.
 */
export function rateLimit(opts: {
  windowMs: number;
  max: number;
  key?: (req: Request) => string;
  message?: string;
}) {
  const { windowMs, max, message = "محاولات كثيرة، برجاء المحاولة لاحقاً" } = opts;
  const buckets = new Map<string, Bucket>();

  const sweep = setInterval(() => {
    const now = Date.now();
    for (const [k, b] of buckets) if (b.resetAt <= now) buckets.delete(k);
  }, Math.max(windowMs, 60_000));
  sweep.unref();

  return (req: Request, res: Response, next: NextFunction): void => {
    const key = opts.key ? opts.key(req) : (req.ip ?? "unknown");
    const now = Date.now();
    let b = buckets.get(key);
    if (!b || b.resetAt <= now) {
      b = { count: 0, resetAt: now + windowMs };
      buckets.set(key, b);
    }
    b.count += 1;
    if (b.count > max) {
      res.setHeader("Retry-After", String(Math.ceil((b.resetAt - now) / 1000)));
      res.status(429).json({ error: message });
      return;
    }
    next();
  };
}
