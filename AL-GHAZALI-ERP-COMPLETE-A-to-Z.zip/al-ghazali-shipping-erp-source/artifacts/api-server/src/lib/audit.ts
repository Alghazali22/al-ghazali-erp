import type { Request } from "express";
import { db, auditLogTable } from "@workspace/db";
import { getAuth } from "../middlewares/auth";
import { logger } from "./logger";

/**
 * Records a sensitive action. Never throws: failing to write the log must not fail (or roll back) the
 * business action itself, but it is reported loudly in the server log.
 */
export async function audit(
  req: Request,
  action: string,
  target?: { type: string; id: string | number } | null,
  details?: string,
): Promise<void> {
  try {
    const user = getAuth(req);
    await db.insert(auditLogTable).values({
      actorId: user.userId, actorName: user.name, actorRole: user.role,
      action, targetType: target?.type ?? null, targetId: target ? String(target.id) : null,
      details: details?.slice(0, 500) ?? null, branchId: user.branchId,
    });
  } catch (err) {
    logger.error({ err, action }, "audit log write failed");
  }
}
