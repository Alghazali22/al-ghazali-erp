import { db, driverShiftsTable, tripsTable, ordersTable, orderEventsTable } from "@workspace/db";
import { and, eq, inArray, isNull, gte, sql, lt, notInArray } from "drizzle-orm";

export type ShiftStatus = "off" | "available" | "break" | "on_trip";

export interface DriverShiftState {
  driverId: number;
  status: ShiftStatus;
  shiftId: number | null;
  startedAt: Date | null;
  queuedAt: Date | null;
  breakStartedAt: Date | null;
  breakMinutes: number;
  activeTripId: number | null;
}

type Tx = Pick<typeof db, "select" | "update" | "insert">;

/**
 * A courier's duty state, derived from facts rather than a flag that can drift:
 *  on_trip   — has a trip that has left (or is leaving) the branch
 *  break     — shift open, on break
 *  available — shift open, waiting in the rotation
 *  off       — no open shift
 */
export async function getShiftStates(driverIds: number[], client: Tx = db): Promise<Map<number, DriverShiftState>> {
  const result = new Map<number, DriverShiftState>();
  if (driverIds.length === 0) return result;

  const [shifts, trips] = await Promise.all([
    client.select().from(driverShiftsTable).where(and(inArray(driverShiftsTable.driverId, driverIds), isNull(driverShiftsTable.endedAt))),
    client.select({ id: tripsTable.id, driverId: tripsTable.driverId }).from(tripsTable)
      .where(and(inArray(tripsTable.driverId, driverIds), inArray(tripsTable.status, ["confirmed", "in_progress"]))),
  ]);
  const shiftByDriver = new Map(shifts.map((s) => [s.driverId, s]));
  const tripByDriver = new Map(trips.map((t) => [t.driverId, t.id]));

  for (const driverId of driverIds) {
    const shift = shiftByDriver.get(driverId) ?? null;
    const tripId = tripByDriver.get(driverId) ?? null;
    const status: ShiftStatus = tripId ? "on_trip" : shift ? (shift.breakStartedAt ? "break" : "available") : "off";
    result.set(driverId, {
      driverId, status, shiftId: shift?.id ?? null,
      startedAt: shift?.startedAt ?? null, queuedAt: shift?.queuedAt ?? null,
      breakStartedAt: shift?.breakStartedAt ?? null, breakMinutes: shift?.breakMinutes ?? 0,
      activeTripId: tripId,
    });
  }
  return result;
}

/**
 * Rotation order ("الدور"): available couriers sorted by how long they have waited (queued_at ascending).
 * Returns driverId → position (1 = next up). Only meaningful within ONE branch.
 */
export function rotationPositions(states: DriverShiftState[]): Map<number, number> {
  const waiting = states
    .filter((s) => s.status === "available" && s.queuedAt)
    .sort((a, b) => a.queuedAt!.getTime() - b.queuedAt!.getTime() || a.driverId - b.driverId);
  return new Map(waiting.map((s, i) => [s.driverId, i + 1]));
}

/** After finishing a trip (or returning from a break) the courier goes to the back of the line. */
export async function rejoinQueue(driverId: number, client: Tx = db): Promise<void> {
  await client.update(driverShiftsTable).set({ queuedAt: new Date() })
    .where(and(eq(driverShiftsTable.driverId, driverId), isNull(driverShiftsTable.endedAt)));
}

/** What a courier achieved during a shift — stored on the row when it closes. */
export async function shiftSummary(driverId: number, since: Date, client: Tx = db) {
  const [delivered, returned] = await Promise.all([
    client.select({
      cnt: sql<number>`count(*)`,
      collected: sql<string>`coalesce(sum(${ordersTable.collectedAmount}), 0)`,
    }).from(ordersTable).where(and(
      eq(ordersTable.driverId, driverId),
      inArray(ordersTable.status, ["delivered", "partial_delivery"]),
      gte(ordersTable.deliveredAt, since),
    )),
    client.select({ cnt: sql<number>`count(distinct ${orderEventsTable.orderId})` }).from(orderEventsTable).where(and(
      eq(orderEventsTable.actorId, driverId),
      inArray(orderEventsTable.status, ["returned", "final_return"]),
      gte(orderEventsTable.createdAt, since),
    )),
  ]);
  return {
    deliveredCount: Number(delivered[0]?.cnt ?? 0),
    returnedCount: Number(returned[0]?.cnt ?? 0),
    collectedAmount: Number(delivered[0]?.collected ?? 0),
  };
}

/** Safety net: a shift someone forgot to close (phone died, left without ending) is closed after 20 h. */
export async function closeStaleShifts(maxHours = 20): Promise<number> {
  const cutoff = new Date(Date.now() - maxHours * 3_600_000);
  const onTrip = db.select({ id: tripsTable.driverId }).from(tripsTable).where(inArray(tripsTable.status, ["confirmed", "in_progress"]));
  const closed = await db.update(driverShiftsTable).set({ endedAt: new Date(), endReason: "auto" })
    .where(and(isNull(driverShiftsTable.endedAt), lt(driverShiftsTable.startedAt, cutoff), notInArray(driverShiftsTable.driverId, onTrip)))
    .returning({ id: driverShiftsTable.id });
  return closed.length;
}
