export type ConfidenceLevel = "high" | "medium" | "low";

export interface ConfidenceInput {
  /** Outcomes of this phone number across the whole platform (anonymous counts). */
  reputation: { delivered: number; returned: number };
  /** Last-90-days outcomes in the destination area, or null when unknown. */
  area: { closed: number; returned: number } | null;
  totalToCollect: number;
  address: string;
  hasSecondPhone: boolean;
}

export interface Confidence {
  score: number; // 5..99 — estimated chance the parcel is delivered and paid on the first visit
  level: ConfidenceLevel;
  reasons: { text: string; impact: number }[];
  advice: string | null;
}

/**
 * "Delivery confidence": a transparent, rule-based estimate shown BEFORE a parcel is shipped, so the
 * merchant can confirm risky orders first. Every point added or removed is listed in `reasons`.
 * It is a heuristic built from real outcome data — not a guarantee, and not machine-learned.
 */
export function computeConfidence(input: ConfidenceInput): Confidence {
  const reasons: { text: string; impact: number }[] = [];
  let score = 85;
  const add = (impact: number, text: string) => { score += impact; reasons.push({ text, impact }); };

  const { delivered, returned } = input.reputation;
  const closed = delivered + returned;
  const returnRate = closed > 0 ? returned / closed : 0;
  if (closed >= 3 && returnRate >= 0.5) add(-40, "رقم العميل له تاريخ مرتجعات مرتفع في الشبكة");
  else if (closed >= 2 && returnRate >= 0.3) add(-18, "رقم العميل له نسبة مرتجعات ملحوظة");
  else if (delivered >= 2 && returned === 0) add(8, "عميل سابق استلم شحناته بانتظام");
  else if (closed === 0) add(-3, "عميل جديد بلا تاريخ");

  if (input.area && input.area.closed >= 8) {
    const areaRate = input.area.returned / input.area.closed;
    if (areaRate >= 0.35) add(-18, "المنطقة ترتفع فيها المرتجعات مؤخراً");
    else if (areaRate >= 0.2) add(-8, "المنطقة بها مرتجعات أعلى من المعتاد");
    else if (areaRate <= 0.05) add(4, "المنطقة نسبة نجاح التسليم فيها ممتازة");
  }

  if (input.totalToCollect >= 3000) add(-8, "قيمة التحصيل عالية");
  else if (input.totalToCollect >= 1500) add(-3, "قيمة التحصيل مرتفعة نسبياً");

  const address = input.address.trim();
  if (address.length < 15) add(-10, "العنوان قصير وغير واضح");
  else if (!/\d/.test(address)) add(-4, "العنوان بلا رقم مبنى أو شارع");

  if (input.hasSecondPhone) add(2, "يوجد رقم بديل للتواصل");

  score = Math.max(5, Math.min(99, Math.round(score)));
  const level: ConfidenceLevel = score >= 75 ? "high" : score >= 55 ? "medium" : "low";
  const advice =
    level === "low" ? "يُنصح بتأكيد الطلب مع العميل (واتساب أو مكالمة) قبل الشحن"
    : level === "medium" ? "يفضّل تأكيد العنوان مع العميل قبل الشحن"
    : null;
  return { score, level, reasons, advice };
}
