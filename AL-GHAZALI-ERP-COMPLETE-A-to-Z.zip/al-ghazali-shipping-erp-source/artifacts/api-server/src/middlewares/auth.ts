import type { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { db, usersTable, branchesTable, systemSettingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { effectivePermissions } from "../lib/permissions";

const JWT_SECRET = process.env.SESSION_SECRET;
if (!JWT_SECRET) {
  throw new Error("SESSION_SECRET must be configured.");
}
if (JWT_SECRET.length < 32) {
  // Not fatal (would break existing deployments) but loudly flagged.
  console.warn("[auth] SESSION_SECRET is shorter than 32 characters — use a long random value.");
}

const JWT_EXPIRES_IN = (process.env.JWT_EXPIRES_IN ?? "7d") as jwt.SignOptions["expiresIn"];

export interface AuthPayload {
  userId: number;
  role: string;
  branchId: number | null;
}

/** The authenticated user as loaded from the database for THIS request (never trusted from the token). */
export interface RequestUser extends AuthPayload {
  name: string;
  permissions: Set<string>;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: RequestUser;
    }
  }
}

export function getAuth(req: Request): RequestUser {
  return req.user as RequestUser;
}

export const can = (user: { permissions: Set<string> } | undefined, permission: string): boolean =>
  !!user && user.permissions.has(permission);

export function signToken(payload: AuthPayload): string {
  return jwt.sign(
    { userId: payload.userId, role: payload.role, branchId: payload.branchId },
    JWT_SECRET!,
    { expiresIn: JWT_EXPIRES_IN, algorithm: "HS256" },
  );
}

export function verifyToken(token: string): AuthPayload | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET!, { algorithms: ["HS256"] }) as Partial<AuthPayload>;
    if (typeof decoded.userId !== "number") return null;
    return { userId: decoded.userId, role: String(decoded.role), branchId: decoded.branchId ?? null };
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// System state (global shutdown + per-branch lockdown), cached briefly so the
// check costs nothing on the hot path. Enforced server-side — previously the
// shutdown/lockdown flags only changed what the UI displayed.
// ---------------------------------------------------------------------------
interface SystemState {
  at: number;
  shutdown: boolean;
  shutdownMessage: string | null;
  lockedBranches: Map<number, string | null>;
}
let cachedState: SystemState | null = null;
const STATE_TTL_MS = 5_000;

export function invalidateSystemState(): void {
  cachedState = null;
}

async function getSystemState(): Promise<SystemState> {
  const now = Date.now();
  if (cachedState && now - cachedState.at < STATE_TTL_MS) return cachedState;
  const [settings] = await db.select().from(systemSettingsTable).limit(1);
  const locked = await db
    .select({ id: branchesTable.id, reason: branchesTable.lockReason })
    .from(branchesTable)
    .where(eq(branchesTable.isLocked, true));
  cachedState = {
    at: now,
    shutdown: !!settings?.isShutdown,
    shutdownMessage: settings?.shutdownMessage ?? null,
    lockedBranches: new Map(locked.map((b) => [b.id, b.reason ?? null])),
  };
  return cachedState;
}

/**
 * Global shutdown + per-branch lockdown. Returns the error response to send, or null when access is fine.
 * Shared by JWT sessions (requireAuth) and API-key integrations so neither can bypass it.
 */
export async function checkSystemAccess(
  role: string,
  branchId: number | null,
  method: string,
): Promise<{ status: number; body: { error: string; code: string } } | null> {
  if (role === "super_admin") return null;
  const state = await getSystemState();
  if (state.shutdown) {
    return { status: 503, body: { error: state.shutdownMessage || "النظام متوقف مؤقتاً", code: "SYSTEM_SHUTDOWN" } };
  }
  const isWrite = !["GET", "HEAD", "OPTIONS"].includes(method);
  if (isWrite && branchId && state.lockedBranches.has(branchId)) {
    return { status: 423, body: { error: state.lockedBranches.get(branchId) || "الفرع مغلق مؤقتاً بواسطة الإدارة", code: "BRANCH_LOCKED" } };
  }
  return null;
}

const STATE_EXEMPT_PATHS = new Set(["/auth/me", "/auth/logout"]);

export async function requireAuth(req: Request, res: Response, next: NextFunction): Promise<void> {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  const payload = verifyToken(authHeader.slice(7));
  if (!payload) {
    res.status(401).json({ error: "Invalid token" });
    return;
  }

  // Always trust the database, not the token, for role/branch/active state so a
  // disabled or re-assigned user loses access immediately.
  const [row] = await db
    .select({
      id: usersTable.id, role: usersTable.role, branchId: usersTable.branchId, isActive: usersTable.isActive,
      fullName: usersTable.fullName, grant: usersTable.permissionsGrant, revoke: usersTable.permissionsRevoke,
    })
    .from(usersTable)
    .where(eq(usersTable.id, payload.userId));
  if (!row || !row.isActive) {
    res.status(401).json({ error: "Account is disabled" });
    return;
  }
  req.user = {
    userId: row.id, role: row.role, branchId: row.branchId, name: row.fullName,
    permissions: effectivePermissions(row.role, row.grant ?? [], row.revoke ?? []),
  };

  if (!STATE_EXEMPT_PATHS.has(req.path)) {
    const blocked = await checkSystemAccess(row.role, row.branchId, req.method);
    if (blocked) { res.status(blocked.status).json(blocked.body); return; }
  }
  next();
}

/** Capability check: the user needs this permission (role default + personal grant − personal revoke). */
export function requirePermission(permission: string) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!can(req.user, permission)) {
      res.status(403).json({ error: "ليس لديك صلاحية تنفيذ هذا الإجراء", code: "PERMISSION_DENIED", permission });
      return;
    }
    next();
  };
}

/** Identity-bound roles (e.g. a courier acting on themself) OR anyone holding the permission. */
export function requireSelfRoleOrPermission(selfRoles: string[], permission: string) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const user = req.user;
    if (user && (selfRoles.includes(user.role) || can(user, permission))) { next(); return; }
    res.status(403).json({ error: "ليس لديك صلاحية تنفيذ هذا الإجراء", code: "PERMISSION_DENIED", permission });
  };
}

export function requireRole(...roles: string[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const user = req.user;
    if (!user || !roles.includes(user.role)) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }
    next();
  };
}

// ---------------------------------------------------------------------------
// Passwords (scrypt, `salt:hash` format — unchanged, existing hashes keep working)
// ---------------------------------------------------------------------------
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [salt, hash] = stored.split(":");
    if (!salt || !hash) return false;
    const derived = scryptSync(password, salt, 64);
    const expected = Buffer.from(hash, "hex");
    return expected.length === derived.length && timingSafeEqual(derived, expected);
  } catch {
    return false;
  }
}

let dummyHash: string | null = null;
/** Hash to verify against when the username doesn't exist, so timing doesn't reveal valid usernames. */
export function getDummyHash(): string {
  if (!dummyHash) dummyHash = hashPassword(randomBytes(12).toString("hex"));
  return dummyHash;
}

export const MIN_PASSWORD_LENGTH = 8;
