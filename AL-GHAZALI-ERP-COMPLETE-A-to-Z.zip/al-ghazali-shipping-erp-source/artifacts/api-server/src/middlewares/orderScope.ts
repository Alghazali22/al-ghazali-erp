import { eq, sql } from "drizzle-orm";
import { ordersTable, usersTable } from "@workspace/db";
import { AuthPayload } from "./auth";
import { BRANCH_SCOPED_ROLES } from "../lib/validate";

const isBranchScoped = (role: string) => (BRANCH_SCOPED_ROLES as readonly string[]).includes(role);
const DENY_ALL = () => sql`false`;

/**
 * Row-level data isolation: every role sees only the orders relevant to
 * their own permissions. super_admin and accountant are business-wide
 * (accountant needs cross-branch financial visibility); every other role
 * is scoped to its own orders (merchant/driver) or its own branch
 * (branch_manager/cs/operations).
 *
 * Fail-closed: a branch-scoped user with no branch, or an unknown role,
 * sees nothing (previously they saw everything).
 */
export function getRoleOrderConditions(authUser: AuthPayload): any[] {
  const role = authUser.role;
  if (role === "super_admin" || role === "accountant") return [];
  if (role === "merchant") return [eq(ordersTable.merchantId, authUser.userId)];
  if (role === "driver") return [eq(ordersTable.driverId, authUser.userId)];
  if (isBranchScoped(role)) {
    return authUser.branchId ? [eq(ordersTable.branchId, authUser.branchId)] : [DENY_ALL()];
  }
  return [DENY_ALL()];
}

/** Same branch isolation, applied to queries against the users table (e.g. driver/merchant lists). */
export function getRoleUserBranchCondition(authUser: AuthPayload): any[] {
  if (isBranchScoped(authUser.role)) {
    return authUser.branchId ? [eq(usersTable.branchId, authUser.branchId)] : [DENY_ALL()];
  }
  return [];
}

/** Whether this role is allowed to see business-wide (cross-branch) figures. */
export function isGlobalScope(authUser: AuthPayload): boolean {
  return authUser.role === "super_admin" || authUser.role === "accountant";
}

/** Whether a specific order record is visible/editable by this user, given their role scope. */
export function canAccessOrder(authUser: AuthPayload, order: { merchantId: number; driverId: number | null; branchId: number | null }): boolean {
  const role = authUser.role;
  if (role === "super_admin" || role === "accountant") return true;
  if (role === "merchant") return order.merchantId === authUser.userId;
  if (role === "driver") return order.driverId === authUser.userId;
  if (isBranchScoped(role)) {
    return !!authUser.branchId && order.branchId === authUser.branchId;
  }
  return false;
}

/** Can this user act on (view/edit) another user's record? Used by users/financial routes. */
export function canManageUserRecord(
  authUser: AuthPayload,
  target: { id: number; role: string; branchId: number | null },
): boolean {
  if (authUser.role === "super_admin") return true;
  if (authUser.userId === target.id) return true;
  if (authUser.role === "accountant") return target.role === "merchant" || target.role === "driver";
  if (isBranchScoped(authUser.role)) {
    if (!authUser.branchId || target.branchId !== authUser.branchId) return false;
    return target.role === "driver" || target.role === "merchant" || target.role === "cs" || target.role === "operations";
  }
  return false;
}
