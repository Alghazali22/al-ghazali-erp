import { Router } from "express";
import {
  db, ordersTable, orderEventsTable, orderNotesTable, ticketsTable, ticketNotesTable, usersTable,
} from "@workspace/db";
import { and, asc, desc, eq, inArray, isNull, notInArray, or, sql, count } from "drizzle-orm";
import { requireAuth, requirePermission, requireSelfRoleOrPermission, getAuth, can, type RequestUser } from "../middlewares/auth";
import { getRoleOrderConditions, canAccessOrder } from "../middlewares/orderScope";
import { audit } from "../lib/audit";
import { rateLimit } from "../lib/rateLimit";
import { iso } from "../lib/format";
import { parseId, asTrimmedString, optionalString, isOneOf } from "../lib/validate";

const router = Router();

const TICKET_TYPES = ["complaint", "delay", "address_change", "reschedule", "damaged", "cod_dispute", "other"] as const;
const PRIORITIES = ["low", "normal", "high", "urgent"] as const;
const STATUSES = ["open", "in_progress", "waiting", "resolved", "closed"] as const;
const CLOSED = ["resolved", "closed"];
const NOTE_KINDS = ["note", "call_answered", "call_no_answer", "whatsapp", "reschedule"] as const;
const SLA_HOURS: Record<(typeof PRIORITIES)[number], number> = { urgent: 2, high: 8, normal: 24, low: 72 };

const DELAY_HOURS = 6;        // in transit with no movement for this long
const STUCK_HOURS = 48;       // received but still not dispatched after this long

const writeLimiter = rateLimit({ windowMs: 60_000, max: 60, key: (req) => `support:${req.user?.userId ?? req.ip}` });

const dueFrom = (from: Date, priority: (typeof PRIORITIES)[number]) => new Date(from.getTime() + SLA_HOURS[priority] * 3_600_000);

/** Tickets: staff see their branch's tickets (super admin: all); a merchant sees only the ones they opened. */
function ticketScope(user: RequestUser): any[] {
  if (user.role === "merchant") return [eq(ticketsTable.createdById, user.userId)];
  if (user.role === "super_admin") return [];
  return [user.branchId ? eq(ticketsTable.branchId, user.branchId) : sql`false`];
}

async function loadTicket(user: RequestUser, idParam: unknown) {
  const id = parseId(idParam);
  if (!id) return { error: { status: 400, message: "رقم التذكرة غير صحيح" } };
  const [ticket] = await db.select().from(ticketsTable).where(and(eq(ticketsTable.id, id), ...ticketScope(user)));
  return ticket ? { ticket } : { error: { status: 404, message: "التذكرة غير موجودة" } };
}

// ---------------------------------------------------------------------------
// Follow-up queue: what the care team should be calling today
// ---------------------------------------------------------------------------
router.get("/support/queue", requireAuth, requirePermission("support.view"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const scope = getRoleOrderConditions(authUser);
  const now = Date.now();
  const lastEvent = sql<Date | null>`(select max(e.created_at) from order_events e where e.order_id = ${ordersTable.id})`;
  const cols = {
    id: ordersTable.id, orderNumber: ordersTable.orderNumber, customerName: ordersTable.customerName,
    customerPhone: ordersTable.customerPhone, governorate: ordersTable.governorate, area: ordersTable.area,
    status: ordersTable.status, attemptCount: ordersTable.attemptCount, createdAt: ordersTable.createdAt,
    returnedToBranchAt: ordersTable.returnedToBranchAt, lastEventAt: lastEvent,
  };
  const delayedCutoff = new Date(now - DELAY_HOURS * 3_600_000).toISOString();
  const stuckCutoff = new Date(now - STUCK_HOURS * 3_600_000);

  const [failed, delayed, stuck] = await Promise.all([
    db.select(cols).from(ordersTable).where(and(eq(ordersTable.status, "returned"), ...scope)).orderBy(desc(lastEvent)).limit(100),
    db.select(cols).from(ordersTable).where(and(eq(ordersTable.status, "in_transit"), sql`${lastEvent} < ${delayedCutoff}`, ...scope)).orderBy(asc(lastEvent)).limit(100),
    db.select(cols).from(ordersTable).where(and(inArray(ordersTable.status, ["pending", "ready"]), sql`${ordersTable.createdAt} < ${stuckCutoff.toISOString()}`, ...scope)).orderBy(asc(ordersTable.createdAt)).limit(100),
  ]);

  const ids = [...new Set([...failed, ...delayed, ...stuck].map((o) => o.id))];
  const [notes, ticketCounts] = ids.length ? await Promise.all([
    db.select().from(orderNotesTable).where(inArray(orderNotesTable.orderId, ids)).orderBy(desc(orderNotesTable.createdAt)),
    db.select({ orderId: ticketsTable.orderId, cnt: count() }).from(ticketsTable)
      .where(and(inArray(ticketsTable.orderId, ids), notInArray(ticketsTable.status, CLOSED))).groupBy(ticketsTable.orderId),
  ]) : [[], []] as any[];
  const lastNote = new Map<number, (typeof notes)[number]>();
  for (const n of notes as any[]) if (!lastNote.has(n.orderId)) lastNote.set(n.orderId, n);
  const openTickets = new Map((ticketCounts as any[]).map((t) => [t.orderId, Number(t.cnt)]));

  const shape = (kind: "failed" | "delayed" | "stuck") => (o: (typeof failed)[number]) => {
    const since = kind === "stuck" ? o.createdAt : (o.lastEventAt ?? o.createdAt);
    const note = lastNote.get(o.id);
    return {
      kind, orderId: o.id, orderNumber: o.orderNumber, customerName: o.customerName, customerPhone: o.customerPhone,
      governorate: o.governorate, area: o.area, status: o.status, attemptCount: o.attemptCount,
      backInWarehouse: !!o.returnedToBranchAt,
      hoursSince: Math.max(0, Math.round((now - new Date(since).getTime()) / 3_600_000)),
      lastContact: note ? { at: iso(note.createdAt), kind: note.kind, by: note.authorName } : null,
      openTickets: openTickets.get(o.id) ?? 0,
    };
  };

  res.json({
    failed: failed.map(shape("failed")),
    delayed: delayed.map(shape("delayed")),
    stuck: stuck.map(shape("stuck")),
    thresholds: { delayHours: DELAY_HOURS, stuckHours: STUCK_HOURS },
  });
});

// ---------------------------------------------------------------------------
// Contact log (internal)
// ---------------------------------------------------------------------------
router.get("/support/orders/:id/notes", requireAuth, requirePermission("support.view"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم الطلب غير صحيح" }); return; }
  const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, id));
  if (!order || !canAccessOrder(getAuth(req), order)) { res.status(404).json({ error: "الطلب غير موجود" }); return; }
  const [notes, tickets] = await Promise.all([
    db.select().from(orderNotesTable).where(eq(orderNotesTable.orderId, id)).orderBy(desc(orderNotesTable.createdAt)).limit(100),
    db.select({ id: ticketsTable.id, subject: ticketsTable.subject, status: ticketsTable.status, priority: ticketsTable.priority })
      .from(ticketsTable).where(eq(ticketsTable.orderId, id)).orderBy(desc(ticketsTable.id)),
  ]);
  res.json({
    notes: notes.map((n) => ({ id: n.id, kind: n.kind, body: n.body, authorName: n.authorName, createdAt: iso(n.createdAt) })),
    tickets,
  });
});

router.post("/support/orders/:id/notes", requireAuth, requirePermission("support.manage"), writeLimiter, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const id = parseId(req.params.id);
  const kind = req.body?.kind ?? "note";
  const body = asTrimmedString(req.body?.body, 1000);
  if (!id) { res.status(400).json({ error: "رقم الطلب غير صحيح" }); return; }
  if (!isOneOf(kind, NOTE_KINDS)) { res.status(400).json({ error: "نوع الملاحظة غير صحيح" }); return; }
  if (!body) { res.status(400).json({ error: "اكتب نص الملاحظة" }); return; }
  const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, id));
  if (!order || !canAccessOrder(authUser, order)) { res.status(404).json({ error: "الطلب غير موجود" }); return; }
  const [note] = await db.insert(orderNotesTable).values({ orderId: id, authorId: authUser.userId, authorName: authUser.name, kind, body }).returning();
  res.status(201).json({ id: note.id, kind: note.kind, body: note.body, authorName: note.authorName, createdAt: iso(note.createdAt) });
});

// Customer asked for another delivery attempt: put a returned parcel (already back on the shelf) into the ready pool.
router.post("/support/orders/:id/redeliver", requireAuth, requirePermission("support.reschedule"), writeLimiter, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم الطلب غير صحيح" }); return; }
  const preferred = optionalString(req.body?.preferredTime, 200) ?? null;

  const result = await db.transaction(async (tx) => {
    const [order] = await tx.select().from(ordersTable).where(eq(ordersTable.id, id)).for("update");
    if (!order || !canAccessOrder(authUser, order)) return { status: 404, error: "الطلب غير موجود" };
    if (order.status !== "returned") return { status: 409, error: order.status === "final_return" ? "هذا مرتجع نهائي (استنفد 3 محاولات)" : "الشحنة ليست في حالة مرتجع" };
    if (!order.returnedToBranchAt) return { status: 409, error: "الشحنة لم تصل مخزن الفرع بعد — انتظر حتى تُستلم من المندوب" };
    if (order.inventoryStatus !== "in_warehouse") return { status: 409, error: "الشحنة ليست داخل مخزن الفرع" };

    await tx.update(ordersTable).set({ status: "ready", tripId: null, driverId: null, loadedAt: null, stopSequence: null }).where(eq(ordersTable.id, id));
    await tx.insert(orderEventsTable).values({
      orderId: id, status: "ready",
      description: "بناءً على طلبك تمت إعادة جدولة التسليم وستصلك الشحنة قريباً",
      actorId: authUser.userId, actorName: authUser.name,
    });
    await tx.insert(orderNotesTable).values({
      orderId: id, authorId: authUser.userId, authorName: authUser.name, kind: "reschedule",
      body: `إعادة جدولة التسليم${preferred ? ` — الموعد المفضل للعميل: ${preferred}` : ""}`,
    });
    return { ok: true as const, orderNumber: order.orderNumber };
  });
  if ("error" in result) { res.status(result.status).json({ error: result.error }); return; }
  await audit(req, "support.reschedule", { type: "order", id }, result.orderNumber);
  res.json({ ok: true });
});

// ---------------------------------------------------------------------------
// Tickets
// ---------------------------------------------------------------------------
router.get("/support/agents", requireAuth, requirePermission("support.view"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const conds: any[] = [eq(usersTable.isActive, true), inArray(usersTable.role, ["cs", "operations", "branch_manager", "super_admin"])];
  if (authUser.role !== "super_admin") conds.push(authUser.branchId ? eq(usersTable.branchId, authUser.branchId) : sql`false`);
  const agents = await db.select({ id: usersTable.id, fullName: usersTable.fullName, role: usersTable.role }).from(usersTable).where(and(...conds)).orderBy(usersTable.fullName);
  res.json(agents);
});

router.get("/support/tickets", requireAuth, requireSelfRoleOrPermission(["merchant"], "support.view"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const conds: any[] = [...ticketScope(authUser)];
  const { status, mine } = req.query;
  if (status === "active") conds.push(notInArray(ticketsTable.status, CLOSED));
  else if (typeof status === "string" && isOneOf(status, STATUSES)) conds.push(eq(ticketsTable.status, status));
  if (mine === "1" && authUser.role !== "merchant") conds.push(eq(ticketsTable.assigneeId, authUser.userId));
  if (req.query.unassigned === "1") conds.push(isNull(ticketsTable.assigneeId));

  const rows = await db.select().from(ticketsTable).where(conds.length ? and(...conds) : undefined)
    .orderBy(sql`case when ${ticketsTable.status} in ('resolved','closed') then 1 else 0 end`, asc(ticketsTable.dueAt)).limit(200);

  const orderIds = [...new Set(rows.map((t) => t.orderId).filter((v): v is number => !!v))];
  const userIds = [...new Set(rows.flatMap((t) => [t.assigneeId, t.createdById]).filter((v): v is number => !!v))];
  const [orders, users] = await Promise.all([
    orderIds.length ? db.select({ id: ordersTable.id, orderNumber: ordersTable.orderNumber, customerName: ordersTable.customerName }).from(ordersTable).where(inArray(ordersTable.id, orderIds)) : [],
    userIds.length ? db.select({ id: usersTable.id, fullName: usersTable.fullName }).from(usersTable).where(inArray(usersTable.id, userIds)) : [],
  ]);
  const orderMap = new Map(orders.map((o) => [o.id, o]));
  const userMap = new Map(users.map((u) => [u.id, u.fullName]));
  const now = Date.now();

  res.json(rows.map((t) => ({
    id: t.id, type: t.type, priority: t.priority, status: t.status, subject: t.subject,
    orderNumber: t.orderId ? orderMap.get(t.orderId)?.orderNumber ?? null : null,
    customerName: t.orderId ? orderMap.get(t.orderId)?.customerName ?? null : null,
    assigneeId: t.assigneeId, assigneeName: t.assigneeId ? userMap.get(t.assigneeId) ?? null : null,
    createdByName: userMap.get(t.createdById) ?? null,
    dueAt: iso(t.dueAt), createdAt: iso(t.createdAt), resolvedAt: iso(t.resolvedAt),
    overdue: !CLOSED.includes(t.status) && t.dueAt.getTime() < now,
  })));
});

router.post("/support/tickets", requireAuth, requirePermission("support.create_ticket"), writeLimiter, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const body = req.body ?? {};
  const type = body.type ?? "other";
  const priority = body.priority ?? "normal";
  const subject = asTrimmedString(body.subject, 140);
  const description = optionalString(body.description, 1500) ?? null;
  if (!isOneOf(type, TICKET_TYPES)) { res.status(400).json({ error: "نوع التذكرة غير صحيح" }); return; }
  if (!isOneOf(priority, PRIORITIES)) { res.status(400).json({ error: "الأولوية غير صحيحة" }); return; }
  if (!subject || subject.length < 3) { res.status(400).json({ error: "اكتب عنواناً للتذكرة (3 أحرف على الأقل)" }); return; }
  // Merchants can't set urgency themselves; the care team triages.
  const finalPriority = authUser.role === "merchant" ? "normal" : priority;

  let orderId: number | null = null;
  let branchId: number | null = authUser.branchId;
  const orderNumber = typeof body.orderNumber === "string" ? body.orderNumber.trim().toUpperCase() : null;
  if (orderNumber || body.orderId) {
    const [order] = orderNumber
      ? await db.select().from(ordersTable).where(eq(ordersTable.orderNumber, orderNumber))
      : await db.select().from(ordersTable).where(eq(ordersTable.id, parseId(body.orderId) ?? -1));
    if (!order || !canAccessOrder(authUser, order)) { res.status(404).json({ error: "رقم الشحنة غير موجود" }); return; }
    orderId = order.id;
    branchId = order.branchId;
  }

  const now = new Date();
  const ticket = await db.transaction(async (tx) => {
    const [created] = await tx.insert(ticketsTable).values({
      orderId, type, priority: finalPriority, subject, createdById: authUser.userId, branchId, dueAt: dueFrom(now, finalPriority),
    }).returning();
    if (description) {
      await tx.insert(ticketNotesTable).values({
        ticketId: created.id, authorId: authUser.userId, authorName: authUser.name,
        kind: authUser.role === "merchant" ? "reply" : "note", body: description,
      });
    }
    return created;
  });
  res.status(201).json({ id: ticket.id });
});

router.get("/support/tickets/:id", requireAuth, requireSelfRoleOrPermission(["merchant"], "support.view"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const loaded = await loadTicket(authUser, req.params.id);
  if ("error" in loaded) { res.status(loaded.error!.status).json({ error: loaded.error!.message }); return; }
  const { ticket } = loaded;

  const [notes, [order], people] = await Promise.all([
    db.select().from(ticketNotesTable).where(eq(ticketNotesTable.ticketId, ticket.id)).orderBy(asc(ticketNotesTable.createdAt)),
    ticket.orderId ? db.select({
      id: ordersTable.id, orderNumber: ordersTable.orderNumber, customerName: ordersTable.customerName, customerPhone: ordersTable.customerPhone,
      governorate: ordersTable.governorate, area: ordersTable.area, status: ordersTable.status,
    }).from(ordersTable).where(eq(ordersTable.id, ticket.orderId)) : Promise.resolve([] as any[]),
    db.select({ id: usersTable.id, fullName: usersTable.fullName }).from(usersTable).where(inArray(usersTable.id, [ticket.createdById, ...(ticket.assigneeId ? [ticket.assigneeId] : [])])),
  ]);
  const names = new Map(people.map((p) => [p.id, p.fullName]));
  // Internal call/WhatsApp/status notes are never shown to a merchant — only public replies.
  const visible = authUser.role === "merchant" ? notes.filter((n) => n.kind === "reply") : notes;

  res.json({
    id: ticket.id, type: ticket.type, priority: ticket.priority, status: ticket.status, subject: ticket.subject,
    assigneeId: ticket.assigneeId, assigneeName: ticket.assigneeId ? names.get(ticket.assigneeId) ?? null : null,
    createdByName: names.get(ticket.createdById) ?? null,
    dueAt: iso(ticket.dueAt), createdAt: iso(ticket.createdAt), resolvedAt: iso(ticket.resolvedAt),
    overdue: !CLOSED.includes(ticket.status) && ticket.dueAt.getTime() < Date.now(),
    order: order ?? null,
    notes: visible.map((n) => ({ id: n.id, kind: n.kind, body: n.body, authorName: n.authorName, createdAt: iso(n.createdAt) })),
  });
});

router.patch("/support/tickets/:id", requireAuth, requirePermission("support.manage"), writeLimiter, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const loaded = await loadTicket(authUser, req.params.id);
  if ("error" in loaded) { res.status(loaded.error!.status).json({ error: loaded.error!.message }); return; }
  const { ticket } = loaded;
  const body = req.body ?? {};
  const updates: any = { updatedAt: new Date() };
  const log: string[] = [];

  if (body.status !== undefined) {
    if (!isOneOf(body.status, STATUSES)) { res.status(400).json({ error: "الحالة غير صحيحة" }); return; }
    if (body.status !== ticket.status) {
      updates.status = body.status;
      updates.resolvedAt = CLOSED.includes(body.status) ? new Date() : null;
      log.push(`الحالة: ${ticket.status} ← ${body.status}`);
    }
  }
  if (body.priority !== undefined) {
    if (!isOneOf(body.priority, PRIORITIES)) { res.status(400).json({ error: "الأولوية غير صحيحة" }); return; }
    if (body.priority !== ticket.priority) {
      updates.priority = body.priority;
      updates.dueAt = dueFrom(ticket.createdAt, body.priority); // SLA follows the new urgency, counted from creation
      log.push(`الأولوية: ${ticket.priority} ← ${body.priority}`);
    }
  }
  if (body.assigneeId !== undefined) {
    if (body.assigneeId === null) { updates.assigneeId = null; log.push("إلغاء الإسناد"); }
    else {
      const assigneeId = parseId(body.assigneeId);
      const [agent] = assigneeId ? await db.select({ id: usersTable.id, role: usersTable.role, isActive: usersTable.isActive, branchId: usersTable.branchId, fullName: usersTable.fullName }).from(usersTable).where(eq(usersTable.id, assigneeId)) : [];
      if (!agent || !agent.isActive || !["cs", "operations", "branch_manager", "super_admin"].includes(agent.role)) { res.status(400).json({ error: "الموظف غير صالح للإسناد" }); return; }
      if (agent.role !== "super_admin" && ticket.branchId && agent.branchId !== ticket.branchId) { res.status(400).json({ error: "الموظف من فرع آخر" }); return; }
      updates.assigneeId = agent.id;
      if (updates.status === undefined && ticket.status === "open") updates.status = "in_progress";
      log.push(`الإسناد إلى ${agent.fullName}`);
    }
  }
  if (log.length === 0) { res.status(400).json({ error: "لا توجد تغييرات" }); return; }

  await db.transaction(async (tx) => {
    await tx.update(ticketsTable).set(updates).where(eq(ticketsTable.id, ticket.id));
    await tx.insert(ticketNotesTable).values({ ticketId: ticket.id, authorId: authUser.userId, authorName: authUser.name, kind: "status", body: log.join(" — ") });
  });
  res.json({ ok: true });
});

router.post("/support/tickets/:id/notes", requireAuth, requireSelfRoleOrPermission(["merchant"], "support.view"), writeLimiter, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const loaded = await loadTicket(authUser, req.params.id);
  if ("error" in loaded) { res.status(loaded.error!.status).json({ error: loaded.error!.message }); return; }
  const { ticket } = loaded;
  const text = asTrimmedString(req.body?.body, 1500);
  if (!text) { res.status(400).json({ error: "اكتب نص الرسالة" }); return; }

  let kind: string = "reply";
  if (authUser.role !== "merchant") {
    if (!can(authUser, "support.manage")) { res.status(403).json({ error: "ليس لديك صلاحية الرد على التذاكر", code: "PERMISSION_DENIED" }); return; }
    kind = isOneOf(req.body?.kind, ["note", "call", "whatsapp", "reply"] as const) ? req.body.kind : "note";
  }
  if (CLOSED.includes(ticket.status) && authUser.role === "merchant") { res.status(409).json({ error: "التذكرة مغلقة. افتح تذكرة جديدة إذا لزم" }); return; }

  const [note] = await db.insert(ticketNotesTable).values({ ticketId: ticket.id, authorId: authUser.userId, authorName: authUser.name, kind, body: text }).returning();
  await db.update(ticketsTable).set({ updatedAt: new Date() }).where(eq(ticketsTable.id, ticket.id));
  res.status(201).json({ id: note.id, kind: note.kind, body: note.body, authorName: note.authorName, createdAt: iso(note.createdAt) });
});

export default router;
