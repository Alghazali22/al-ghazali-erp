import { Router } from "express";
import { db } from "@workspace/db";
import { tripsTable, ordersTable, usersTable, branchesTable, orderEventsTable, zonesTable } from "@workspace/db";
import { eq, and, inArray, sql, notInArray, isNull } from "drizzle-orm";
import { requireAuth, requireRole, getAuth, type AuthPayload, requirePermission, requireSelfRoleOrPermission, can } from "../middlewares/auth";
import { iso, num } from "../lib/format";
import { parseId, isOneOf } from "../lib/validate";
import { optimizeRoute, sweepPartition, pathLengthKm, haversineKm, governorateCenter, type Pt } from "../lib/geo";
import { connectionStatus } from "./tracking";
import { getShiftStates, rejoinQueue } from "../lib/shifts";
import { canAccessOrder } from "../middlewares/orderScope";
import { audit } from "../lib/audit";
import { rateLimit } from "../lib/rateLimit";

const router = Router();

const TRIP_STATUSES = ["draft", "confirmed", "in_progress", "completed"] as const;
const FINAL_ORDER_STATUSES = ["delivered", "partial_delivery", "final_return"] as const;
const TRIP_TERMINAL_STATUSES = ["delivered", "partial_delivery", "returned", "final_return"];
const DISPATCH_ROLES = ["super_admin", "branch_manager", "operations"];
const MAX_ORDERS_PER_TRIP = 200;

/** Batch formatter (was 3 queries per trip). */
async function formatTrips(trips: any[]) {
  if (trips.length === 0) return [];
  const tripIds = trips.map((t) => t.id as number);
  const driverIds = [...new Set(trips.map((t) => t.driverId as number))];
  const branchIds = [...new Set(trips.map((t) => t.branchId as number))];
  const [drivers, branches, orders] = await Promise.all([
    db.select({ id: usersTable.id, fullName: usersTable.fullName }).from(usersTable).where(inArray(usersTable.id, driverIds)),
    db.select({ id: branchesTable.id, name: branchesTable.name }).from(branchesTable).where(inArray(branchesTable.id, branchIds)),
    db.select().from(ordersTable).where(inArray(ordersTable.tripId, tripIds)),
  ]);
  const driverMap = new Map(drivers.map((d) => [d.id, d.fullName]));
  const branchMap = new Map(branches.map((b) => [b.id, b.name]));

  return trips.map((trip) => {
    const tripOrders = orders.filter((o) => o.tripId === trip.id)
      .sort((a, b) => (a.stopSequence ?? 1e9) - (b.stopSequence ?? 1e9) || a.id - b.id);
    return {
      ...trip,
      driverName: driverMap.get(trip.driverId) ?? "Unknown",
      branchName: branchMap.get(trip.branchId) ?? "Unknown",
      orderCount: tripOrders.length,
      loadedCount: tripOrders.filter((o) => o.loadedAt && !(FINAL_ORDER_STATUSES as readonly string[]).includes(o.status)).length,
      activeCount: tripOrders.filter((o) => !(FINAL_ORDER_STATUSES as readonly string[]).includes(o.status)).length,
      acceptedAt: iso(trip.acceptedAt),
      departedAt: iso(trip.departedAt),
      overrideReason: trip.overrideReason ?? null,
      totalToCollect: tripOrders.reduce((sum, o) => sum + num(o.totalToCollect), 0),
      orders: tripOrders.map((o) => ({
        id: o.id, orderNumber: o.orderNumber, customerName: o.customerName, status: o.status, totalToCollect: num(o.totalToCollect),
        stopSequence: o.stopSequence, area: o.area, governorate: o.governorate,
        loadedAt: iso(o.loadedAt), returnedToBranchAt: iso(o.returnedToBranchAt),
      })),
      confirmedAt: iso(trip.confirmedAt),
      completedAt: iso(trip.completedAt),
      createdAt: iso(trip.createdAt),
    };
  });
}

/** Who may see / operate a trip. Drivers: their own. Branch staff: their branch. Admin: all. */
function canAccessTrip(user: AuthPayload, trip: { driverId: number; branchId: number }): boolean {
  if (user.role === "super_admin") return true;
  if (user.role === "driver") return trip.driverId === user.userId;
  // Any other holder of dispatch permissions (manager, operations, or a staff member granted access) is branch-scoped.
  return !!user.branchId && trip.branchId === user.branchId;
}

router.get("/trips", requireAuth, requireSelfRoleOrPermission(["driver"], "dispatch.manage"), async (req, res): Promise<void> => {
  const { status, driverId, branchId } = req.query;
  const authUser = getAuth(req);
  const conds: any[] = [];
  if (status !== undefined) {
    if (!isOneOf(status, TRIP_STATUSES)) { res.status(400).json({ error: "حالة غير صحيحة" }); return; }
    conds.push(eq(tripsTable.status, status));
  }
  if (driverId !== undefined) {
    const v = parseId(driverId);
    if (!v) { res.status(400).json({ error: "رقم المندوب غير صحيح" }); return; }
    conds.push(eq(tripsTable.driverId, v));
  }
  if (branchId !== undefined) {
    const v = parseId(branchId);
    if (!v) { res.status(400).json({ error: "رقم الفرع غير صحيح" }); return; }
    conds.push(eq(tripsTable.branchId, v));
  }
  if (authUser.role === "driver") conds.push(eq(tripsTable.driverId, authUser.userId));
  if (authUser.role !== "super_admin" && authUser.role !== "driver") {
    conds.push(authUser.branchId ? eq(tripsTable.branchId, authUser.branchId) : sql`false`);
  }
  const trips = await db.select().from(tripsTable)
    .where(conds.length ? and(...conds) : undefined)
    .orderBy(sql`${tripsTable.createdAt} desc`, sql`${tripsTable.id} desc`)
    .limit(300);
  res.json(await formatTrips(trips));
});

router.post("/trips", requireAuth, requirePermission("dispatch.manage"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const driverId = parseId(req.body?.driverId);
  if (!driverId) { res.status(400).json({ error: "يجب اختيار المندوب" }); return; }

  const rawIds = req.body?.orderIds;
  let orderIds: number[] = [];
  if (rawIds !== undefined && rawIds !== null) {
    if (!Array.isArray(rawIds) || rawIds.length > MAX_ORDERS_PER_TRIP) {
      res.status(400).json({ error: `قائمة الطلبات غير صحيحة (الحد الأقصى ${MAX_ORDERS_PER_TRIP})` });
      return;
    }
    const parsed = rawIds.map(parseId);
    if (parsed.some((v) => v === null)) { res.status(400).json({ error: "قائمة الطلبات تحتوي رقماً غير صحيح" }); return; }
    orderIds = [...new Set(parsed as number[])];
  }

  const [driver] = await db.select({ role: usersTable.role, isActive: usersTable.isActive, branchId: usersTable.branchId })
    .from(usersTable).where(eq(usersTable.id, driverId));
  if (!driver || driver.role !== "driver" || !driver.isActive) {
    res.status(400).json({ error: "المندوب غير موجود أو غير مفعّل" });
    return;
  }
  const branchId = driver.branchId ?? authUser.branchId;
  if (!branchId) { res.status(400).json({ error: "المندوب غير مرتبط بفرع" }); return; }
  if (authUser.role !== "super_admin" && branchId !== authUser.branchId) {
    res.status(403).json({ error: "لا يمكنك إنشاء رحلة لمندوب من فرع آخر" });
    return;
  }

  // Assignment guard: a parcel is only handed to a courier who is actually here and free.
  const allowOverride = req.body?.override === true && can(authUser, "dispatch.override");
  const driverState = (await getShiftStates([driverId])).get(driverId)!;
  if (driverState.status === "on_trip") {
    res.status(409).json({ error: "هذا المندوب لديه رحلة جارية — لا يمكن إسناد رحلة أخرى له قبل أن يُغلقها", code: "DRIVER_ON_TRIP" });
    return;
  }
  if (driverState.status === "off" && !allowOverride) {
    res.status(409).json({ error: "المندوب لم يبدأ الشيفت. اطلب منه بدء الشيفت من تطبيقه (أو ابدأه من غرفة العمليات)", code: "DRIVER_OFF_SHIFT" });
    return;
  }
  if (driverState.status === "break" && !allowOverride) {
    res.status(409).json({ error: "المندوب في استراحة حالياً", code: "DRIVER_ON_BREAK" });
    return;
  }

  const result = await db.transaction(async (tx) => {
    if (orderIds.length) {
      const selected = await tx.select({
        id: ordersTable.id, orderNumber: ordersTable.orderNumber, branchId: ordersTable.branchId,
        inventoryStatus: ordersTable.inventoryStatus, tripId: ordersTable.tripId, status: ordersTable.status,
        returnedToBranchAt: ordersTable.returnedToBranchAt,
      }).from(ordersTable).where(inArray(ordersTable.id, orderIds)).for("update");

      const invalid = selected.filter((o) =>
        o.branchId !== branchId ||
        o.inventoryStatus !== "in_warehouse" ||
        // already on another trip — unless it is a returned parcel that came back and was scanned in
        (o.tripId !== null && !(o.status === "returned" && o.returnedToBranchAt)) ||
        // a returned parcel is not in the warehouse until someone scans it back in
        (o.status === "returned" && !o.returnedToBranchAt) ||
        (FINAL_ORDER_STATUSES as readonly string[]).includes(o.status),
      );
      if (selected.length !== orderIds.length || invalid.length > 0) {
        return {
          error: {
            error: "لا يمكن إنشاء الرحلة إلا للطلبات المتاحة داخل مخزن نفس الفرع وغير المضافة لرحلة أخرى",
            orders: invalid.map((o) => o.orderNumber),
          },
        };
      }
    }
    const [trip] = await tx.insert(tripsTable).values({ driverId, branchId }).returning();
    if (orderIds.length) {
      await tx.update(ordersTable).set({ tripId: trip.id, driverId, loadedAt: null, returnedToBranchAt: null, stopSequence: null }).where(inArray(ordersTable.id, orderIds));
    }
    return { trip };
  });

  if ("error" in result) { res.status(400).json(result.error); return; }
  res.status(201).json((await formatTrips([result.trip]))[0]);
});

router.get("/trips/:id", requireAuth, requireSelfRoleOrPermission(["driver"], "dispatch.manage"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم الرحلة غير صحيح" }); return; }
  const [trip] = await db.select().from(tripsTable).where(eq(tripsTable.id, id));
  if (!trip) { res.status(404).json({ error: "Not found" }); return; }
  // IDOR fix: previously any logged-in user (even a merchant) could read any trip.
  if (!canAccessTrip(getAuth(req), trip)) { res.status(403).json({ error: "غير مصرح" }); return; }
  res.json((await formatTrips([trip]))[0]);
});

router.delete("/trips/:id", requireAuth, requirePermission("trips.delete"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم الرحلة غير صحيح" }); return; }
  const outcome = await db.transaction(async (tx) => {
    const [trip] = await tx.select({ id: tripsTable.id, status: tripsTable.status }).from(tripsTable).where(eq(tripsTable.id, id)).for("update");
    if (!trip) return "missing" as const;
    if (trip.status === "in_progress") return "running" as const;
    await tx.update(ordersTable).set({ tripId: null, loadedAt: null, stopSequence: null }).where(eq(ordersTable.tripId, id));
    await tx.delete(tripsTable).where(eq(tripsTable.id, id));
    return "ok" as const;
  });
  if (outcome === "missing") { res.status(404).json({ error: "Not found" }); return; }
  if (outcome === "running") { res.status(409).json({ error: "لا يمكن حذف رحلة جارية، أغلقها أولاً بعد تسليم أو إرجاع الطلبات" }); return; }
  await audit(req, "trip.delete", { type: "trip", id });
  res.status(204).send();
});

// ---------------------------------------------------------------------------
// Loading station → handover → departure
// ---------------------------------------------------------------------------
const scanLimiter = rateLimit({
  windowMs: 60_000,
  max: 120,
  key: (req) => `scan:${req.user?.userId ?? req.ip}`,
});

const normalizeNumbers = (raw: unknown): string[] | null => {
  if (!Array.isArray(raw) || raw.length === 0 || raw.length > 200) return null;
  return [...new Set(raw.map((v) => String(v ?? "").trim().toUpperCase()).filter(Boolean))];
};

async function loadDraftTrip(req: any, res: any): Promise<(typeof tripsTable.$inferSelect) | null> {
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم الرحلة غير صحيح" }); return null; }
  const [trip] = await db.select().from(tripsTable).where(eq(tripsTable.id, id));
  if (!trip) { res.status(404).json({ error: "Not found" }); return null; }
  if (!canAccessTrip(getAuth(req), trip)) { res.status(403).json({ error: "غير مصرح" }); return null; }
  if (trip.status !== "draft") { res.status(409).json({ error: "الرحلة خرجت من الفرع بالفعل — لا يمكن تعديل تحميلها" }); return null; }
  return trip;
}

// Scan parcels (QR / order number) as they are put into the courier's bag.
router.post("/trips/:id/load-scan", requireAuth, requirePermission("dispatch.manage"), scanLimiter, async (req, res): Promise<void> => {
  const numbers = normalizeNumbers(req.body?.orderNumbers);
  if (!numbers) { res.status(400).json({ error: "أدخل من 1 إلى 200 رقم شحنة" }); return; }
  const trip = await loadDraftTrip(req, res);
  if (!trip) return;
  const authUser = getAuth(req);

  const orders = await db.select().from(ordersTable).where(inArray(ordersTable.orderNumber, numbers));
  const byNumber = new Map(orders.map((o) => [o.orderNumber, o]));
  const [driver] = await db.select({ fullName: usersTable.fullName }).from(usersTable).where(eq(usersTable.id, trip.driverId));
  const [actor] = await db.select({ fullName: usersTable.fullName }).from(usersTable).where(eq(usersTable.id, authUser.userId));

  const results: { orderNumber: string; ok: boolean; message: string }[] = [];
  const toLoad: number[] = [];
  for (const n of numbers) {
    const o = byNumber.get(n);
    if (!o) results.push({ orderNumber: n, ok: false, message: "رقم الشحنة غير موجود" });
    else if (o.tripId !== trip.id) results.push({ orderNumber: n, ok: false, message: o.tripId ? `هذه الشحنة ضمن رحلة أخرى (#${o.tripId})` : "هذه الشحنة ليست ضمن هذه الرحلة" });
    else if ((FINAL_ORDER_STATUSES as readonly string[]).includes(o.status)) results.push({ orderNumber: n, ok: false, message: "الشحنة مغلقة بالفعل" });
    else if (o.loadedAt) results.push({ orderNumber: n, ok: true, message: "تم مسحها من قبل" });
    else { toLoad.push(o.id); results.push({ orderNumber: n, ok: true, message: "تم التحميل" }); }
  }

  if (toLoad.length) {
    await db.transaction(async (tx) => {
      await tx.update(ordersTable).set({ loadedAt: new Date() }).where(inArray(ordersTable.id, toLoad));
      await tx.insert(orderEventsTable).values(toLoad.map((orderId) => ({
        orderId, status: "ready",
        description: `تم تحميل الشحنة مع المندوب ${driver?.fullName ?? ""} في الفرع`,
        actorId: authUser.userId, actorName: actor?.fullName ?? "الفرع",
      })));
      // The courier must re-confirm if what is in his bag changed after he acknowledged.
      await tx.update(tripsTable).set({ acceptedAt: null, acceptedById: null }).where(eq(tripsTable.id, trip.id));
    });
  }
  const [updated] = await db.select().from(tripsTable).where(eq(tripsTable.id, trip.id));
  const formattedTrip = (await formatTrips([updated]))[0];

  // Nudge courier when every parcel in the trip has been scanned into the bag.
  try {
    const bag = await db.select({ loadedAt: ordersTable.loadedAt, totalToCollect: ordersTable.totalToCollect })
      .from(ordersTable).where(eq(ordersTable.tripId, trip.id));
    const allLoaded = bag.length > 0 && bag.every((o) => !!o.loadedAt);
    if (allLoaded && toLoad.length > 0) {
      const [drv] = await db.select({ fullName: usersTable.fullName, phone: usersTable.phone })
        .from(usersTable).where(eq(usersTable.id, trip.driverId));
      const total = bag.reduce((s, o) => s + Number(o.totalToCollect || 0), 0);
      const { notifyDriverTripReady } = await import("../lib/notifications");
      void notifyDriverTripReady({
        phone: drv?.phone,
        driverName: drv?.fullName || "المندوب",
        orderCount: bag.length,
        totalToCollect: total,
      });
    }
  } catch { /* optional notifications */ }

  res.json({ results, trip: formattedTrip });
});

// Take a parcel out of the trip at the station (damaged, not ready, wrong courier…).
router.post("/trips/:id/remove-order", requireAuth, requirePermission("dispatch.manage"), async (req, res): Promise<void> => {
  const orderNumber = String(req.body?.orderNumber ?? "").trim().toUpperCase();
  if (!orderNumber) { res.status(400).json({ error: "رقم الشحنة مطلوب" }); return; }
  const trip = await loadDraftTrip(req, res);
  if (!trip) return;
  const [order] = await db.select({ id: ordersTable.id, tripId: ordersTable.tripId }).from(ordersTable).where(eq(ordersTable.orderNumber, orderNumber));
  if (!order || order.tripId !== trip.id) { res.status(404).json({ error: "الشحنة ليست ضمن هذه الرحلة" }); return; }
  await db.transaction(async (tx) => {
    await tx.update(ordersTable).set({ tripId: null, driverId: null, loadedAt: null, stopSequence: null }).where(eq(ordersTable.id, order.id));
    await tx.update(tripsTable).set({ acceptedAt: null, acceptedById: null }).where(eq(tripsTable.id, trip.id));
  });
  const [updated] = await db.select().from(tripsTable).where(eq(tripsTable.id, trip.id));
  res.json((await formatTrips([updated]))[0]);
});

// The courier acknowledges in his app that the loaded parcels are in his bag.
router.post("/trips/:id/accept", requireAuth, requireRole("driver"), async (req, res): Promise<void> => {
  const trip = await loadDraftTrip(req, res);
  if (!trip) return;
  const authUser = getAuth(req);
  if (trip.driverId !== authUser.userId) { res.status(403).json({ error: "هذه الرحلة ليست لك" }); return; }

  const orders = await db.select({ status: ordersTable.status, loadedAt: ordersTable.loadedAt }).from(ordersTable).where(eq(ordersTable.tripId, trip.id));
  const active = orders.filter((o) => !(FINAL_ORDER_STATUSES as readonly string[]).includes(o.status));
  if (active.length === 0) { res.status(400).json({ error: "لا توجد شحنات في الرحلة" }); return; }
  const missing = active.filter((o) => !o.loadedAt).length;
  if (missing > 0) { res.status(409).json({ error: `لسه ${missing} شحنة لم تُحمَّل معك — انتظر حتى ينتهي التحميل`, code: "NOT_LOADED" }); return; }

  const [updated] = await db.update(tripsTable).set({ acceptedAt: new Date(), acceptedById: authUser.userId })
    .where(and(eq(tripsTable.id, trip.id), eq(tripsTable.status, "draft"))).returning();
  if (!updated) { res.status(409).json({ error: "الرحلة تغيّرت، حدّث الصفحة" }); return; }
  res.json((await formatTrips([updated]))[0]);
});

// Departure. Requires: every parcel scanned in, the courier's acknowledgement, and the courier being on duty.
// A branch manager / admin may override each of those, with a written reason that is stored on the trip.
router.post("/trips/:id/confirm", requireAuth, requirePermission("dispatch.manage"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  const authUser = getAuth(req);
  if (!id) { res.status(400).json({ error: "رقم الرحلة غير صحيح" }); return; }

  const wantsOverride = req.body?.override === true;
  const reason = typeof req.body?.reason === "string" ? req.body.reason.trim().slice(0, 300) : "";
  const canOverride = can(authUser, "dispatch.override");
  if (wantsOverride && !canOverride) { res.status(403).json({ error: "التجاوز متاح لمدير الفرع أو المدير العام فقط" }); return; }
  if (wantsOverride && reason.length < 3) { res.status(400).json({ error: "اكتب سبب التجاوز (3 أحرف على الأقل)" }); return; }
  const override = wantsOverride && canOverride;

  const result = await db.transaction(async (tx) => {
    const [existing] = await tx.select().from(tripsTable).where(eq(tripsTable.id, id)).for("update");
    if (!existing) return { status: 404, body: { error: "Not found" } };
    if (!canAccessTrip(authUser, existing)) return { status: 403, body: { error: "غير مصرح" } };
    // Previously re-confirming a completed trip reset delivered orders back to in_transit.
    if (existing.status !== "draft") return { status: 409, body: { error: "تم تأكيد هذه الرحلة من قبل" } };

    const tripOrders = await tx.select({ id: ordersTable.id, orderNumber: ordersTable.orderNumber, status: ordersTable.status, loadedAt: ordersTable.loadedAt })
      .from(ordersTable).where(eq(ordersTable.tripId, id));
    const movable = tripOrders.filter((o) => !(FINAL_ORDER_STATUSES as readonly string[]).includes(o.status));
    if (movable.length === 0) return { status: 400, body: { error: "لا يمكن تأكيد رحلة بدون طلبات" } };

    const driverState = (await getShiftStates([existing.driverId], tx)).get(existing.driverId)!;
    if (driverState.status === "on_trip") return { status: 409, body: { error: "هذا المندوب لديه رحلة جارية بالفعل", code: "DRIVER_ON_TRIP" } };
    if (!override) {
      if (driverState.status === "off") return { status: 409, body: { error: "المندوب لم يبدأ الشيفت", code: "DRIVER_OFF_SHIFT" } };
      if (driverState.status === "break") return { status: 409, body: { error: "المندوب في استراحة", code: "DRIVER_ON_BREAK" } };
      const notLoaded = movable.filter((o) => !o.loadedAt);
      if (notLoaded.length > 0) {
        return { status: 409, body: { error: `${notLoaded.length} من ${movable.length} شحنة لم تُمسح بعد في محطة التحميل`, code: "NOT_LOADED", missing: notLoaded.map((o) => o.orderNumber) } };
      }
      if (!existing.acceptedAt) return { status: 409, body: { error: "المندوب لم يؤكد استلام الشحنات في تطبيقه بعد", code: "NOT_ACCEPTED" } };
    }

    const now = new Date();
    const [trip] = await tx.update(tripsTable).set({
      status: "in_progress", confirmedAt: now, departedAt: now, overrideReason: override ? reason : null,
    }).where(eq(tripsTable.id, id)).returning();
    const [driver] = await tx.select({ fullName: usersTable.fullName }).from(usersTable).where(eq(usersTable.id, trip.driverId));
    const driverName = driver?.fullName ?? "المندوب";
    const ids = movable.map((o) => o.id);

    await tx.update(ordersTable).set({ status: "in_transit" }).where(inArray(ordersTable.id, ids));
    await tx.insert(orderEventsTable).values(ids.map((orderId) => ({
      orderId,
      status: "in_transit",
      description: `كابتن الغزالي (${driverName}) في طريقه إليك اليوم`,
      actorId: trip.driverId,
      actorName: driverName,
    })));
    return { trip };
  });

  if ("body" in result) { res.status(result.status as number).json(result.body); return; }
  if (override) await audit(req, "trip.override_departure", { type: "trip", id }, reason);
  res.json((await formatTrips([result.trip]))[0]);
});

// ---------------------------------------------------------------------------
// Returned parcels coming back to the branch
// ---------------------------------------------------------------------------
router.get("/returns/pending", requireAuth, requirePermission("dispatch.manage"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const conds: any[] = [inArray(ordersTable.status, ["returned", "final_return"]), isNull(ordersTable.returnedToBranchAt)];
  if (authUser.role !== "super_admin") conds.push(authUser.branchId ? eq(ordersTable.branchId, authUser.branchId) : sql`false`);
  const rows = await db.select({
    id: ordersTable.id, orderNumber: ordersTable.orderNumber, customerName: ordersTable.customerName, area: ordersTable.area,
    status: ordersTable.status, driverId: ordersTable.driverId, tripId: ordersTable.tripId, driverName: usersTable.fullName,
  }).from(ordersTable).leftJoin(usersTable, eq(ordersTable.driverId, usersTable.id))
    .where(and(...conds)).orderBy(ordersTable.id).limit(500);
  res.json(rows);
});

// Branch staff scan returned parcels back into the warehouse; only then can the trip be closed
// and the parcel be dispatched again.
router.post("/returns/check-in", requireAuth, requirePermission("dispatch.manage"), scanLimiter, async (req, res): Promise<void> => {
  const numbers = normalizeNumbers(req.body?.orderNumbers);
  if (!numbers) { res.status(400).json({ error: "أدخل من 1 إلى 200 رقم شحنة" }); return; }
  const authUser = getAuth(req);
  const [actor] = await db.select({ fullName: usersTable.fullName }).from(usersTable).where(eq(usersTable.id, authUser.userId));

  const orders = await db.select().from(ordersTable).where(inArray(ordersTable.orderNumber, numbers));
  const byNumber = new Map(orders.map((o) => [o.orderNumber, o]));
  const results: { orderNumber: string; ok: boolean; message: string }[] = [];
  const ids: number[] = [];
  for (const n of numbers) {
    const o = byNumber.get(n);
    if (!o) results.push({ orderNumber: n, ok: false, message: "رقم الشحنة غير موجود" });
    else if (!canAccessOrder(authUser, o)) results.push({ orderNumber: n, ok: false, message: "الشحنة تابعة لفرع آخر" });
    else if (o.status !== "returned" && o.status !== "final_return") results.push({ orderNumber: n, ok: false, message: "هذه الشحنة ليست مرتجعة" });
    else if (o.returnedToBranchAt) results.push({ orderNumber: n, ok: true, message: "تم استلامها من قبل" });
    else { ids.push(o.id); results.push({ orderNumber: n, ok: true, message: "تم استلام المرتجع في المخزن" }); }
  }
  if (ids.length) {
    await db.transaction(async (tx) => {
      await tx.update(ordersTable).set({ returnedToBranchAt: new Date() }).where(inArray(ordersTable.id, ids));
      await tx.insert(orderEventsTable).values(ids.map((orderId) => ({
        orderId, status: "returned", description: "تم استلام المرتجع فعلياً في مخزن الفرع",
        actorId: authUser.userId, actorName: actor?.fullName ?? "الفرع",
      })));
    });
  }
  res.json({ results, received: ids.length });
});

router.post("/trips/:id/complete", requireAuth, requirePermission("dispatch.manage"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  const authUser = getAuth(req);
  if (!id) { res.status(400).json({ error: "رقم الرحلة غير صحيح" }); return; }
  const [existingTrip] = await db.select().from(tripsTable).where(eq(tripsTable.id, id));
  if (!existingTrip) { res.status(404).json({ error: "Not found" }); return; }
  if (!canAccessTrip(authUser, existingTrip)) { res.status(403).json({ error: "غير مصرح" }); return; }
  if (existingTrip.status === "completed") { res.status(409).json({ error: "الرحلة مغلقة بالفعل" }); return; }

  const orders = await db.select({ id: ordersTable.id, orderNumber: ordersTable.orderNumber, status: ordersTable.status })
    .from(ordersTable).where(eq(ordersTable.tripId, id));
  const pendingOrders = orders.filter((o) => !TRIP_TERMINAL_STATUSES.includes(o.status));
  const notBack = await db.select({ orderNumber: ordersTable.orderNumber }).from(ordersTable)
    .where(and(eq(ordersTable.tripId, id), inArray(ordersTable.status, ["returned", "final_return"]), isNull(ordersTable.returnedToBranchAt)));
  if (notBack.length > 0) {
    res.status(400).json({
      error: `لا يمكن إغلاق الرحلة قبل استلام ${notBack.length} مرتجع في المخزن (امسحها من «استلام المرتجعات»)`,
      code: "RETURNS_NOT_CHECKED_IN",
      orders: notBack.map((o) => o.orderNumber),
    });
    return;
  }
  if (pendingOrders.length > 0) {
    res.status(400).json({
      error: "لا يمكن إغلاق الرحلة قبل تسليم أو إرجاع كل الطلبات",
      pendingOrders: pendingOrders.map((o) => ({ id: o.id, orderNumber: o.orderNumber, status: o.status })),
    });
    return;
  }

  const [trip] = await db.update(tripsTable).set({ status: "completed", completedAt: new Date() })
    .where(and(eq(tripsTable.id, id), notInArray(tripsTable.status, ["completed"]))).returning();
  if (!trip) { res.status(409).json({ error: "الرحلة مغلقة بالفعل" }); return; }
  await rejoinQueue(trip.driverId); // back of the line: whoever waited longest goes out next
  res.json((await formatTrips([trip]))[0]);
});

// ---------------------------------------------------------------------------
// Smart dispatch
// ---------------------------------------------------------------------------
type ZoneRow = { governorate: string; area: string; lat: unknown; lng: unknown };
type StopOrder = { id: number; governorate: string; area: string; customerLat: unknown; customerLng: unknown; totalToCollect: unknown };

const toNum = (v: unknown): number | null => {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

/** Customer's own pin if they shared one, otherwise the zone centre. */
function stopPoint(order: StopOrder, zoneMap: Map<string, ZoneRow>): Pt | null {
  const pinLat = toNum(order.customerLat), pinLng = toNum(order.customerLng);
  if (pinLat !== null && pinLng !== null) return { lat: pinLat, lng: pinLng };
  const zone = zoneMap.get(`${order.governorate}|${order.area}`);
  const lat = toNum(zone?.lat), lng = toNum(zone?.lng);
  return lat !== null && lng !== null ? { lat, lng } : governorateCenter(order.governorate);
}

async function loadZoneMap() {
  const zones = await db.select({ governorate: zonesTable.governorate, area: zonesTable.area, lat: zonesTable.lat, lng: zonesTable.lng }).from(zonesTable);
  return new Map(zones.map((z) => [`${z.governorate}|${z.area}`, z as ZoneRow]));
}

function driverPosition(d: { lat: unknown; lng: unknown; at: Date | null }): Pt | null {
  const lat = toNum(d.lat), lng = toNum(d.lng);
  const { status } = connectionStatus(d.at);
  return lat !== null && lng !== null && (status === "live" || status === "stale") ? { lat, lng } : null;
}

// New: reorder a trip's stops into a short route (nearest-neighbour + 2-opt) starting from the driver.
router.post("/trips/:id/optimize", requireAuth, requirePermission("dispatch.manage"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  const authUser = getAuth(req);
  if (!id) { res.status(400).json({ error: "رقم الرحلة غير صحيح" }); return; }
  const [trip] = await db.select().from(tripsTable).where(eq(tripsTable.id, id));
  if (!trip) { res.status(404).json({ error: "Not found" }); return; }
  if (!canAccessTrip(authUser, trip)) { res.status(403).json({ error: "غير مصرح" }); return; }
  if (trip.status === "completed") { res.status(409).json({ error: "الرحلة مغلقة بالفعل" }); return; }

  const [orders, zoneMap, [driver]] = await Promise.all([
    db.select().from(ordersTable).where(and(eq(ordersTable.tripId, id), notInArray(ordersTable.status, [...FINAL_ORDER_STATUSES, "returned"]))),
    loadZoneMap(),
    db.select({ lat: usersTable.currentLat, lng: usersTable.currentLng, at: usersTable.locationUpdatedAt }).from(usersTable).where(eq(usersTable.id, trip.driverId)),
  ]);
  if (orders.length === 0) { res.status(400).json({ error: "لا توجد طلبات قابلة للترتيب في هذه الرحلة" }); return; }

  const start = driver ? driverPosition(driver) : null;
  const located: { o: (typeof orders)[number]; pt: Pt }[] = [];
  const unlocated: (typeof orders)[number][] = [];
  for (const o of orders) {
    const pt = stopPoint(o, zoneMap);
    if (pt) located.push({ o, pt }); else unlocated.push(o);
  }
  const currentOrder = [...located].sort((a, b) => (a.o.stopSequence ?? 1e9) - (b.o.stopSequence ?? 1e9) || a.o.id - b.o.id);
  const beforeKm = pathLengthKm(start, currentOrder.map((x) => x.pt));
  const ordered = located.length ? optimizeRoute(start, located) : [];
  const afterKm = pathLengthKm(start, ordered.map((x) => x.pt));
  unlocated.sort((a, b) => a.area.localeCompare(b.area, "ar") || a.id - b.id);

  const finalIds = [...ordered.map((x) => x.o.id), ...unlocated.map((o) => o.id)];
  await db.transaction(async (tx) => {
    for (let i = 0; i < finalIds.length; i++) {
      await tx.update(ordersTable).set({ stopSequence: i + 1 }).where(eq(ordersTable.id, finalIds[i]));
    }
  });

  res.json({
    trip: (await formatTrips([trip]))[0],
    optimization: {
      stops: finalIds.length,
      locatedStops: located.length,
      unlocatedStops: unlocated.length,
      beforeKm, afterKm,
      savedPercent: beforeKm > 0 ? Math.max(0, Math.round(((beforeKm - afterKm) / beforeKm) * 100)) : 0,
    },
  });
});

// New: propose a balanced split of the warehouse's ready orders across the selected drivers.
// Read-only (nothing is created) — the app then creates one trip per proposal and optimises it.
router.post("/trips/auto-plan", requireAuth, requirePermission("dispatch.manage"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const rawDrivers = req.body?.driverIds;
  if (!Array.isArray(rawDrivers) || rawDrivers.length === 0 || rawDrivers.length > 50) {
    res.status(400).json({ error: "اختر من 1 إلى 50 مندوباً" });
    return;
  }
  const parsedIds = rawDrivers.map(parseId);
  if (parsedIds.some((v) => v === null)) { res.status(400).json({ error: "قائمة المناديب غير صحيحة" }); return; }
  const driverIds = [...new Set(parsedIds as number[])];
  const rawMax = Number(req.body?.maxPerDriver);
  const maxPerDriver = Number.isInteger(rawMax) && rawMax >= 1 ? Math.min(rawMax, 100) : 40;

  const drivers = await db.select({
    id: usersTable.id, fullName: usersTable.fullName, branchId: usersTable.branchId, role: usersTable.role, isActive: usersTable.isActive,
    lat: usersTable.currentLat, lng: usersTable.currentLng, at: usersTable.locationUpdatedAt,
  }).from(usersTable).where(inArray(usersTable.id, driverIds));
  if (drivers.length !== driverIds.length || drivers.some((d) => d.role !== "driver" || !d.isActive)) {
    res.status(400).json({ error: "أحد المناديب غير موجود أو غير مفعّل" });
    return;
  }
  const branchId = authUser.role === "super_admin" ? drivers[0].branchId : authUser.branchId;
  if (!branchId || drivers.some((d) => d.branchId !== branchId)) {
    res.status(400).json({ error: "يجب أن يكون كل المناديب من نفس الفرع" });
    return;
  }
  const shiftStates = await getShiftStates(driverIds);
  const unavailable = drivers.filter((d) => shiftStates.get(d.id)!.status !== "available");
  if (unavailable.length && req.body?.ignoreShifts !== true) {
    res.status(409).json({
      error: `هؤلاء المناديب غير متاحين الآن (لم يبدؤوا الشيفت أو في رحلة/استراحة): ${unavailable.map((d) => d.fullName).join("، ")}`,
      code: "DRIVERS_UNAVAILABLE",
      drivers: unavailable.map((d) => ({ id: d.id, name: d.fullName, status: shiftStates.get(d.id)!.status })),
    });
    return;
  }

  const [pool, zoneMap] = await Promise.all([
    db.select().from(ordersTable).where(and(
      eq(ordersTable.branchId, branchId),
      eq(ordersTable.inventoryStatus, "in_warehouse"),
      isNull(ordersTable.tripId),
      inArray(ordersTable.status, ["ready", "returned"]),
    )).orderBy(ordersTable.id).limit(1000),
    loadZoneMap(),
  ]);
  if (pool.length === 0) { res.json({ proposals: [], unassigned: 0, poolSize: 0 }); return; }

  const located: { o: (typeof pool)[number]; pt: Pt }[] = [];
  const unlocated: (typeof pool)[number][] = [];
  for (const o of pool) {
    const pt = stopPoint(o, zoneMap);
    if (pt) located.push({ o, pt }); else unlocated.push(o);
  }

  type Bucket = { driver: (typeof drivers)[number]; start: Pt | null; items: { o: (typeof pool)[number]; pt: Pt }[]; extra: (typeof pool)[number][] };
  const buckets: Bucket[] = drivers.map((d) => ({ driver: d, start: driverPosition(d), items: [], extra: [] }));

  // Clusters → nearest free driver (biggest cluster first).
  const chunks = sweepPartition(located, buckets.length).sort((a, b) => b.length - a.length);
  const free = new Set(buckets.map((_, i) => i));
  for (const chunk of chunks) {
    const centre: Pt = { lat: chunk.reduce((a, x) => a + x.pt.lat, 0) / chunk.length, lng: chunk.reduce((a, x) => a + x.pt.lng, 0) / chunk.length };
    let best = -1, bestD = Infinity;
    for (const i of free) {
      const d = buckets[i].start ? haversineKm(buckets[i].start!, centre) : 0;
      if (d < bestD) { bestD = d; best = i; }
    }
    free.delete(best);
    buckets[best].items = chunk;
  }

  let unassigned = 0;
  for (const b of buckets) {
    if (b.items.length > maxPerDriver) { unassigned += b.items.length - maxPerDriver; b.items = b.items.slice(0, maxPerDriver); }
  }
  // Orders with no coordinates: prefer a driver already serving that area, else the least loaded.
  for (const o of unlocated) {
    const sameArea = buckets.find((b) => b.items.length + b.extra.length < maxPerDriver &&
      (b.items.some((x) => x.o.area === o.area && x.o.governorate === o.governorate) || b.extra.some((x) => x.area === o.area)));
    const target = sameArea ?? [...buckets].filter((b) => b.items.length + b.extra.length < maxPerDriver)
      .sort((a, b) => (a.items.length + a.extra.length) - (b.items.length + b.extra.length))[0];
    if (target) target.extra.push(o); else unassigned++;
  }

  const proposals = buckets
    .filter((b) => b.items.length + b.extra.length > 0)
    .map((b) => {
      const route = b.items.length ? optimizeRoute(b.start, b.items) : [];
      const orders = [...route.map((x) => x.o), ...b.extra];
      const areaCount = new Map<string, number>();
      for (const o of orders) areaCount.set(o.area, (areaCount.get(o.area) ?? 0) + 1);
      return {
        driverId: b.driver.id,
        driverName: b.driver.fullName,
        orderIds: orders.map((o) => o.id),
        orderNumbers: orders.map((o) => o.orderNumber),
        count: orders.length,
        totalToCollect: Math.round(orders.reduce((a, o) => a + num(o.totalToCollect), 0) * 100) / 100,
        estimatedKm: pathLengthKm(b.start, route.map((x) => x.pt)),
        topAreas: [...areaCount.entries()].sort((a, b2) => b2[1] - a[1]).slice(0, 3).map(([area, n]) => ({ area, count: n })),
      };
    });

  res.json({ proposals, unassigned, poolSize: pool.length, maxPerDriver });
});

export default router;
