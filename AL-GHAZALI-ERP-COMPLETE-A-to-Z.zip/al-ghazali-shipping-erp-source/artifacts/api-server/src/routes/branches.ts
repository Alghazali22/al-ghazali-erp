import { Router } from "express";
import { db } from "@workspace/db";
import { branchesTable, usersTable, ordersTable, tripsTable, treasuryTable } from "@workspace/db";
import { eq, count, inArray } from "drizzle-orm";
import { requireAuth, requireRole, getAuth, invalidateSystemState, requirePermission } from "../middlewares/auth";
import { audit } from "../lib/audit";
import { iso } from "../lib/format";
import { parseId, asTrimmedString, optionalString } from "../lib/validate";

const router = Router();

/** Batch formatter: 2 queries total (was 2 per branch). */
async function formatBranches(branches: any[]) {
  if (branches.length === 0) return [];
  const branchIds = branches.map((b) => b.id as number);
  const managerIds = [...new Set(branches.map((b) => b.managerId as number | null).filter((v): v is number => !!v))];
  const [managers, counts] = await Promise.all([
    managerIds.length
      ? db.select({ id: usersTable.id, fullName: usersTable.fullName }).from(usersTable).where(inArray(usersTable.id, managerIds))
      : Promise.resolve([] as { id: number; fullName: string }[]),
    db.select({ branchId: ordersTable.branchId, cnt: count() }).from(ordersTable)
      .where(inArray(ordersTable.branchId, branchIds)).groupBy(ordersTable.branchId),
  ]);
  const managerMap = new Map(managers.map((m) => [m.id, m.fullName]));
  const countMap = new Map(counts.map((c) => [c.branchId, Number(c.cnt)]));
  return branches.map((b) => ({
    ...b,
    managerName: b.managerId ? managerMap.get(b.managerId) ?? null : null,
    orderCount: countMap.get(b.id) ?? 0,
    createdAt: iso(b.createdAt),
  }));
}

async function validateManager(managerId: unknown): Promise<{ ok: true; id: number | null } | { ok: false }> {
  if (managerId === undefined || managerId === null) return { ok: true, id: null };
  const id = parseId(managerId);
  if (!id) return { ok: false };
  const [u] = await db.select({ role: usersTable.role }).from(usersTable).where(eq(usersTable.id, id));
  return u && u.role === "branch_manager" ? { ok: true, id } : { ok: false };
}

router.get("/branches", requireAuth, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  let branches = await db.select().from(branchesTable).orderBy(branchesTable.id);
  // Merchants and drivers only need to know their own branch.
  if (authUser.role === "merchant" || authUser.role === "driver") {
    branches = branches.filter((b) => b.id === authUser.branchId);
  }
  res.json(await formatBranches(branches));
});

router.post("/branches", requireAuth, requirePermission("branches.manage"), async (req, res): Promise<void> => {
  const body = req.body ?? {};
  const name = asTrimmedString(body.name, 120);
  const governorate = asTrimmedString(body.governorate, 100);
  if (!name || !governorate) { res.status(400).json({ error: "اسم الفرع والمحافظة مطلوبان" }); return; }
  const manager = await validateManager(body.managerId);
  if (!manager.ok) { res.status(400).json({ error: "مدير الفرع غير صحيح" }); return; }

  const branch = await db.transaction(async (tx) => {
    const [created] = await tx.insert(branchesTable).values({
      name, governorate,
      address: optionalString(body.address, 300) ?? null,
      phone: optionalString(body.phone, 30) ?? null,
      managerId: manager.id,
    }).returning();
    // Every branch gets its cash drawer up-front so settlements/withdrawals never hit a missing treasury.
    await tx.insert(treasuryTable).values({ branchId: created.id }).onConflictDoNothing();
    return created;
  });
  res.status(201).json((await formatBranches([branch]))[0]);
});

router.get("/branches/:id", requireAuth, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم الفرع غير صحيح" }); return; }
  if ((authUser.role === "merchant" || authUser.role === "driver") && authUser.branchId !== id) {
    res.status(403).json({ error: "غير مصرح" });
    return;
  }
  const [branch] = await db.select().from(branchesTable).where(eq(branchesTable.id, id));
  if (!branch) { res.status(404).json({ error: "Not found" }); return; }
  res.json((await formatBranches([branch]))[0]);
});

router.patch("/branches/:id", requireAuth, requirePermission("branches.manage"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم الفرع غير صحيح" }); return; }
  const body = req.body ?? {};
  const updates: any = {};
  if (body.name !== undefined) {
    const v = asTrimmedString(body.name, 120);
    if (!v) { res.status(400).json({ error: "اسم الفرع غير صحيح" }); return; }
    updates.name = v;
  }
  if (body.governorate !== undefined) {
    const v = asTrimmedString(body.governorate, 100);
    if (!v) { res.status(400).json({ error: "المحافظة غير صحيحة" }); return; }
    updates.governorate = v;
  }
  if (body.address !== undefined) updates.address = optionalString(body.address, 300) ?? null;
  if (body.phone !== undefined) updates.phone = optionalString(body.phone, 30) ?? null;
  if (body.managerId !== undefined) {
    const manager = await validateManager(body.managerId);
    if (!manager.ok) { res.status(400).json({ error: "مدير الفرع غير صحيح" }); return; }
    updates.managerId = manager.id;
  }
  if (Object.keys(updates).length === 0) { res.status(400).json({ error: "لا توجد بيانات للتحديث" }); return; }
  const [branch] = await db.update(branchesTable).set(updates).where(eq(branchesTable.id, id)).returning();
  if (!branch) { res.status(404).json({ error: "Not found" }); return; }
  res.json((await formatBranches([branch]))[0]);
});

router.delete("/branches/:id", requireAuth, requirePermission("branches.manage"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم الفرع غير صحيح" }); return; }

  const outcome = await db.transaction(async (tx) => {
    const [branch] = await tx.select({ id: branchesTable.id }).from(branchesTable).where(eq(branchesTable.id, id));
    if (!branch) return "missing" as const;
    // Previously orders were silently re-pointed to branch #1 (which is the branch being deleted when id=1).
    const [orderRow] = await tx.select({ cnt: count() }).from(ordersTable).where(eq(ordersTable.branchId, id));
    const [tripRow] = await tx.select({ cnt: count() }).from(tripsTable).where(eq(tripsTable.branchId, id));
    if (Number(orderRow?.cnt ?? 0) > 0 || Number(tripRow?.cnt ?? 0) > 0) return "in_use" as const;

    await tx.update(usersTable).set({ branchId: null }).where(eq(usersTable.branchId, id));
    await tx.delete(branchesTable).where(eq(branchesTable.id, id));
    return "ok" as const;
  });

  if (outcome === "missing") { res.status(404).json({ error: "Not found" }); return; }
  if (outcome === "in_use") {
    res.status(409).json({ error: "لا يمكن حذف فرع عليه طلبات أو رحلات. يمكنك إيقافه بدلاً من حذفه (قفل الفرع)" });
    return;
  }
  invalidateSystemState();
  await audit(req, "branch.delete", { type: "branch", id });
  res.status(204).send();
});

router.post("/branches/:id/lockdown", requireAuth, requirePermission("branches.lockdown"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم الفرع غير صحيح" }); return; }
  const { locked, reason } = req.body ?? {};
  if (typeof locked !== "boolean") { res.status(400).json({ error: "حالة القفل مطلوبة" }); return; }

  if (authUser.role === "branch_manager") {
    // A manager may only lock their own branch (emergency stop); unlocking is reserved for the
    // super admin, because writes from a locked branch are rejected by the server.
    if (authUser.branchId !== id) { res.status(403).json({ error: "يمكنك قفل فرعك فقط" }); return; }
    if (!locked) { res.status(403).json({ error: "فتح الفرع المقفول متاح للمدير العام فقط" }); return; }
  }

  const [branch] = await db.update(branchesTable).set({
    isLocked: locked,
    lockReason: locked ? (optionalString(reason, 300) ?? null) : null,
  }).where(eq(branchesTable.id, id)).returning();
  if (!branch) { res.status(404).json({ error: "Not found" }); return; }
  invalidateSystemState();
  await audit(req, locked ? "branch.lock" : "branch.unlock", { type: "branch", id }, optionalString(reason, 300) ?? undefined);
  res.json((await formatBranches([branch]))[0]);
});

export default router;
