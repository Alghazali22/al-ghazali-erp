import { Router, type Request, type Response, type NextFunction } from "express";
import { createHash, randomBytes } from "node:crypto";
import { db, apiKeysTable, usersTable, ordersTable, orderEventsTable, zonesTable, merchantPricingTable } from "@workspace/db";
import { and, eq, isNull, desc, count } from "drizzle-orm";
import { requireAuth, requireRole, getAuth, checkSystemAccess, requirePermission } from "../middlewares/auth";
import { rateLimit } from "../lib/rateLimit";
import { effectivePermissions } from "../lib/permissions";
import { iso, num } from "../lib/format";
import { parseId, asTrimmedString } from "../lib/validate";
import { createOrderCore } from "./orders";

const router = Router();
const MAX_ACTIVE_KEYS = 5;

const sha256 = (value: string) => createHash("sha256").update(value).digest("hex");
const formatKey = (k: typeof apiKeysTable.$inferSelect) => ({
  id: k.id, name: k.name, keyPrefix: k.keyPrefix,
  lastUsedAt: iso(k.lastUsedAt), createdAt: iso(k.createdAt), revokedAt: iso(k.revokedAt),
});

// ---------------------------------------------------------------------------
// Key management (logged-in merchant, or super admin on behalf of a merchant)
// ---------------------------------------------------------------------------
function targetMerchantId(req: Request): number | null {
  const authUser = getAuth(req);
  if (authUser.role === "merchant") return authUser.userId;
  return parseId(req.query.merchantId ?? req.body?.merchantId);
}

router.get("/integrations/keys", requireAuth, requirePermission("integrations.manage"), async (req, res): Promise<void> => {
  const merchantId = targetMerchantId(req);
  if (!merchantId) { res.status(400).json({ error: "رقم التاجر مطلوب" }); return; }
  const keys = await db.select().from(apiKeysTable).where(eq(apiKeysTable.merchantId, merchantId)).orderBy(desc(apiKeysTable.createdAt));
  res.json(keys.map(formatKey));
});

router.post("/integrations/keys", requireAuth, requirePermission("integrations.manage"), async (req, res): Promise<void> => {
  const merchantId = targetMerchantId(req);
  const name = asTrimmedString(req.body?.name, 60);
  if (!merchantId) { res.status(400).json({ error: "رقم التاجر مطلوب" }); return; }
  if (!name) { res.status(400).json({ error: "اسم المفتاح مطلوب (مثال: متجر Shopify)" }); return; }

  const [merchant] = await db.select({ role: usersTable.role }).from(usersTable).where(eq(usersTable.id, merchantId));
  if (!merchant || merchant.role !== "merchant") { res.status(404).json({ error: "التاجر غير موجود" }); return; }
  const [{ active }] = await db.select({ active: count() }).from(apiKeysTable)
    .where(and(eq(apiKeysTable.merchantId, merchantId), isNull(apiKeysTable.revokedAt)));
  if (Number(active) >= MAX_ACTIVE_KEYS) {
    res.status(400).json({ error: `الحد الأقصى ${MAX_ACTIVE_KEYS} مفاتيح فعّالة. ألغِ مفتاحاً قديماً أولاً` });
    return;
  }

  // 256 bits of randomness; only the hash is stored, so the key can be shown exactly once.
  const key = `alg_live_${randomBytes(32).toString("base64url")}`;
  const [created] = await db.insert(apiKeysTable).values({
    merchantId, name, keyPrefix: key.slice(0, 13), keyHash: sha256(key),
  }).returning();
  res.status(201).json({ ...formatKey(created), key });
});

router.delete("/integrations/keys/:id", requireAuth, requirePermission("integrations.manage"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم غير صحيح" }); return; }
  const conditions = [eq(apiKeysTable.id, id), isNull(apiKeysTable.revokedAt)];
  if (authUser.role === "merchant") conditions.push(eq(apiKeysTable.merchantId, authUser.userId));
  const [revoked] = await db.update(apiKeysTable).set({ revokedAt: new Date() }).where(and(...conditions)).returning();
  if (!revoked) { res.status(404).json({ error: "المفتاح غير موجود أو تم إلغاؤه" }); return; }
  res.json(formatKey(revoked));
});

// ---------------------------------------------------------------------------
// Public store API (authenticated with X-API-Key)
// ---------------------------------------------------------------------------
async function requireApiKey(req: Request, res: Response, next: NextFunction): Promise<void> {
  const header = req.headers["x-api-key"];
  const key = typeof header === "string" ? header.trim() : "";
  if (!key.startsWith("alg_live_") || key.length > 100) {
    res.status(401).json({ error: "مفتاح API غير صحيح أو مفقود (X-API-Key)" });
    return;
  }
  const [row] = await db.select({
    keyId: apiKeysTable.id, lastUsedAt: apiKeysTable.lastUsedAt,
    userId: usersTable.id, role: usersTable.role, branchId: usersTable.branchId, isActive: usersTable.isActive, fullName: usersTable.fullName,
  }).from(apiKeysTable)
    .innerJoin(usersTable, eq(apiKeysTable.merchantId, usersTable.id))
    .where(and(eq(apiKeysTable.keyHash, sha256(key)), isNull(apiKeysTable.revokedAt)));
  if (!row || !row.isActive || row.role !== "merchant") {
    res.status(401).json({ error: "مفتاح API غير صحيح أو ملغي" });
    return;
  }
  const blocked = await checkSystemAccess(row.role, row.branchId, req.method);
  if (blocked) { res.status(blocked.status).json(blocked.body); return; }

  // Cheap "last used" stamp, at most once a minute per key.
  if (!row.lastUsedAt || Date.now() - row.lastUsedAt.getTime() > 60_000) {
    void db.update(apiKeysTable).set({ lastUsedAt: new Date() }).where(eq(apiKeysTable.id, row.keyId)).catch(() => {});
  }
  req.user = { userId: row.userId, role: "merchant", branchId: row.branchId, name: row.fullName, permissions: effectivePermissions("merchant") };
  next();
}

const apiLimiter = rateLimit({
  windowMs: 60_000,
  max: 120,
  key: (req) => `api:${String(req.headers["x-api-key"] ?? req.ip).slice(0, 30)}`,
});

router.post("/integrations/orders", apiLimiter, requireApiKey, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const body = req.body ?? {};
  const reference = typeof body.reference === "string" ? body.reference : null;
  const result = await createOrderCore(authUser, body, { source: "api", externalRef: reference });
  if (!result.ok) { res.status(result.status).json({ error: result.error }); return; }
  const o = result.order;
  // 201 for a new order, 200 when this `reference` was already submitted (safe to retry).
  res.status(result.duplicate ? 200 : 201).json({
    orderNumber: o.orderNumber,
    reference: o.externalRef,
    status: o.status,
    shippingFee: num(o.shippingFee),
    totalToCollect: num(o.totalToCollect),
    trackingPath: `/track?order=${o.orderNumber}`,
    duplicate: result.duplicate,
  });
});

router.get("/integrations/orders/:orderNumber", apiLimiter, requireApiKey, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const orderNumber = String(req.params.orderNumber ?? "").trim().toUpperCase().slice(0, 40);
  const [order] = await db.select().from(ordersTable)
    .where(and(eq(ordersTable.orderNumber, orderNumber), eq(ordersTable.merchantId, authUser.userId)));
  if (!order) { res.status(404).json({ error: "الطلب غير موجود" }); return; }
  const events = await db.select().from(orderEventsTable).where(eq(orderEventsTable.orderId, order.id)).orderBy(orderEventsTable.createdAt);
  res.json({
    orderNumber: order.orderNumber,
    reference: order.externalRef,
    status: order.status,
    totalToCollect: num(order.totalToCollect),
    collectedAmount: order.collectedAmount ? num(order.collectedAmount) : null,
    deliveredAt: iso(order.deliveredAt),
    timeline: events.map((e) => ({ status: e.status, description: e.description, timestamp: iso(e.createdAt) })),
  });
});

// Shipping quote for the store's checkout (uses this merchant's own negotiated prices).
router.get("/integrations/shipping-fee", apiLimiter, requireApiKey, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const governorate = asTrimmedString(req.query.governorate, 100);
  const area = asTrimmedString(req.query.area, 100);
  if (!governorate || !area) { res.status(400).json({ error: "المحافظة والمنطقة مطلوبتان" }); return; }
  const [zone] = await db.select().from(zonesTable).where(and(eq(zonesTable.governorate, governorate), eq(zonesTable.area, area)));
  if (!zone || !zone.isActive) { res.json({ available: false, fee: null }); return; }
  const [override] = await db.select().from(merchantPricingTable)
    .where(and(eq(merchantPricingTable.merchantId, authUser.userId), eq(merchantPricingTable.zoneId, zone.id)));
  res.json({ available: true, fee: override ? num(override.customPrice) : num(zone.basePrice) });
});

export default router;
