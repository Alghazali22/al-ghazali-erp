import { Router } from "express";
import { db } from "@workspace/db";
import { ordersTable, usersTable, orderEventsTable, branchesTable } from "@workspace/db";
import { eq, and, count, sum, sql, gte, lt, desc, inArray } from "drizzle-orm";
import { requireAuth, getAuth } from "../middlewares/auth";
import { getRoleOrderConditions, getRoleUserBranchCondition, isGlobalScope } from "../middlewares/orderScope";
import { iso, num } from "../lib/format";
import { parseId } from "../lib/validate";
import { startOfCairoDay, startOfCairoDayAgo, cairoDateKey } from "../lib/time";

const router = Router();

const STATUSES = ["pending", "ready", "in_transit", "delivered", "partial_delivery", "returned", "final_return"] as const;

/** Role scope + (for global roles only) an optional explicit branch filter. */
function orderScope(authUser: ReturnType<typeof getAuth>, branchIdParam: unknown): { cond: any[]; error?: string } {
  const cond: any[] = [...getRoleOrderConditions(authUser)];
  // Only super_admin/accountant may explicitly filter by an arbitrary branch;
  // every other role is locked to its own scope regardless of query params.
  if (isGlobalScope(authUser) && branchIdParam !== undefined) {
    const bid = parseId(branchIdParam);
    if (!bid) return { cond, error: "رقم الفرع غير صحيح" };
    cond.push(eq(ordersTable.branchId, bid));
  }
  return { cond };
}

router.get("/dashboard/stats", requireAuth, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const { cond, error } = orderScope(authUser, req.query.branchId);
  if (error) { res.status(400).json({ error }); return; }

  const userBranchCond = getRoleUserBranchCondition(authUser);
  const todayIso = startOfCairoDay().toISOString();
  const where = cond.length ? and(...cond) : undefined;

  // One aggregate query instead of six (and "today" is now the Cairo business day, not server-UTC).
  const [row] = await db.select({
    total: count(),
    pending: sql<number>`count(*) filter (where ${ordersTable.status} = 'pending')`,
    inTransit: sql<number>`count(*) filter (where ${ordersTable.status} = 'in_transit')`,
    deliveredToday: sql<number>`count(*) filter (where ${ordersTable.status} = 'delivered' and ${ordersTable.deliveredAt} >= ${todayIso})`,
    revenue: sql<string>`coalesce(sum(${ordersTable.shippingFee}) filter (where ${ordersTable.status} = 'delivered'), 0)`,
    successful: sql<number>`count(*) filter (where ${ordersTable.status} in ('delivered', 'partial_delivery'))`,
    closed: sql<number>`count(*) filter (where ${ordersTable.status} in ('delivered', 'partial_delivery', 'returned', 'final_return'))`,
  }).from(ordersTable).where(where);

  // "Returned today" used the order's *creation* date; use the actual return events instead.
  const [returnedRow] = await db.select({ cnt: sql<number>`count(distinct ${orderEventsTable.orderId})` })
    .from(orderEventsTable)
    .innerJoin(ordersTable, eq(orderEventsTable.orderId, ordersTable.id))
    .where(and(
      inArray(orderEventsTable.status, ["returned", "final_return"]),
      gte(orderEventsTable.createdAt, startOfCairoDay()),
      ...cond,
    ));

  // Business-wide staffing/cash figures are only meaningful (and only visible)
  // to roles with a management view: super_admin (all branches), accountant
  // (cross-branch finance), and branch_manager/operations (their own branch).
  const showOpsFigures = authUser.role !== "merchant" && authUser.role !== "driver" && authUser.role !== "cs";
  let activeDrivers = 0, activeMerchants = 0, pendingCash = 0;
  if (showOpsFigures) {
    const [activeDriversRow] = await db.select({ cnt: count() }).from(usersTable).where(and(eq(usersTable.role, "driver"), eq(usersTable.isActive, true), ...userBranchCond));
    const [activeMerchantsRow] = await db.select({ cnt: count() }).from(usersTable).where(and(eq(usersTable.role, "merchant"), eq(usersTable.isActive, true), ...(isGlobalScope(authUser) ? [] : userBranchCond)));
    const [pendingCashRow] = await db.select({ total: sum(usersTable.cashBalance) }).from(usersTable).where(and(eq(usersTable.role, "driver"), ...userBranchCond));
    activeDrivers = Number(activeDriversRow?.cnt ?? 0);
    activeMerchants = Number(activeMerchantsRow?.cnt ?? 0);
    pendingCash = num(pendingCashRow?.total);
  }

  const closed = Number(row?.closed ?? 0);
  const successful = Number(row?.successful ?? 0);

  res.json({
    totalOrders: Number(row?.total ?? 0),
    pendingOrders: Number(row?.pending ?? 0),
    inTransitOrders: Number(row?.inTransit ?? 0),
    deliveredToday: Number(row?.deliveredToday ?? 0),
    returnedToday: Number(returnedRow?.cnt ?? 0),
    revenue: num(row?.revenue),
    activeDrivers,
    activeMerchants,
    // Was "delivered today ÷ all orders ever" (which trends to 0%). Now: successful ÷ orders that reached an outcome.
    deliveryRate: closed > 0 ? Math.round((successful / closed) * 100) : 0,
    pendingCash,
  });
});

router.get("/dashboard/recent-orders", requireAuth, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const rawLimit = Number(req.query.limit);
  const limit = Number.isInteger(rawLimit) && rawLimit >= 1 ? Math.min(rawLimit, 50) : 10;
  const cond = getRoleOrderConditions(authUser);
  const orders = await db.select().from(ordersTable)
    .where(cond.length ? and(...cond) : undefined)
    .orderBy(desc(ordersTable.createdAt), desc(ordersTable.id)).limit(limit);

  const merchantIds = [...new Set(orders.map((o) => o.merchantId))];
  const branchIds = [...new Set(orders.map((o) => o.branchId))];
  const driverIds = [...new Set(orders.map((o) => o.driverId).filter((v): v is number => !!v))];
  const userIds = [...new Set([...merchantIds, ...driverIds])];
  const [users, branches] = await Promise.all([
    userIds.length ? db.select({ id: usersTable.id, fullName: usersTable.fullName, merchantLogo: usersTable.merchantLogo }).from(usersTable).where(inArray(usersTable.id, userIds)) : [],
    branchIds.length ? db.select({ id: branchesTable.id, name: branchesTable.name }).from(branchesTable).where(inArray(branchesTable.id, branchIds)) : [],
  ]);
  const userMap = new Map(users.map((u) => [u.id, u]));
  const branchMap = new Map(branches.map((b) => [b.id, b.name]));

  const maskFinancials = authUser.role === "cs";
  res.json(orders.map((o) => ({
    id: o.id, orderNumber: o.orderNumber, status: o.status,
    customerName: o.customerName, governorate: o.governorate, area: o.area,
    packageValue: maskFinancials ? null : num(o.packageValue),
    shippingFee: maskFinancials ? null : num(o.shippingFee),
    totalToCollect: maskFinancials ? null : num(o.totalToCollect),
    merchantName: userMap.get(o.merchantId)?.fullName ?? "تاجر",
    merchantLogo: userMap.get(o.merchantId)?.merchantLogo ?? null,
    branchName: branchMap.get(o.branchId) ?? "الفرع",
    driverName: o.driverId ? userMap.get(o.driverId)?.fullName ?? null : null,
    createdAt: iso(o.createdAt),
    customerPhone: o.customerPhone, customerPhone2: o.customerPhone2,
    customerAddress: o.customerAddress, merchantId: o.merchantId,
    branchId: o.branchId, driverId: o.driverId, tripId: o.tripId,
    attemptCount: o.attemptCount, collectedAmount: maskFinancials ? null : (o.collectedAmount ? num(o.collectedAmount) : null),
    deliveredAt: iso(o.deliveredAt),
    notes: o.notes, timeline: [],
  })));
});

router.get("/dashboard/order-status-breakdown", requireAuth, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const { cond, error } = orderScope(authUser, req.query.branchId);
  if (error) { res.status(400).json({ error }); return; }
  const rows = await db.select({ status: ordersTable.status, cnt: count() }).from(ordersTable)
    .where(cond.length ? and(...cond) : undefined)
    .groupBy(ordersTable.status);
  const map = new Map(rows.map((r) => [r.status as string, Number(r.cnt)]));
  res.json(STATUSES.map((status) => ({ status, count: map.get(status) ?? 0 })));
});

router.get("/dashboard/revenue-trend", requireAuth, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const rawDays = Number(req.query.days);
  // Clamped: an unbounded `days` used to run 2 queries per day (a trivial DoS).
  const days = Number.isInteger(rawDays) && rawDays >= 1 ? Math.min(rawDays, 90) : 7;
  const baseCond = getRoleOrderConditions(authUser);

  const rangeStart = startOfCairoDayAgo(days - 1);
  const rangeEnd = new Date(startOfCairoDay().getTime() + 36 * 3_600_000); // safely past the end of today
  const cairoDay = (col: any) => sql<string>`to_char((${col} at time zone 'UTC') at time zone 'Africa/Cairo', 'YYYY-MM-DD')`;

  const deliveredDay = cairoDay(ordersTable.deliveredAt);
  const createdDay = cairoDay(ordersTable.createdAt);
  const [revenueRows, orderRows] = await Promise.all([
    db.select({ day: deliveredDay, total: sum(ordersTable.shippingFee) }).from(ordersTable)
      .where(and(eq(ordersTable.status, "delivered"), gte(ordersTable.deliveredAt, rangeStart), lt(ordersTable.deliveredAt, rangeEnd), ...baseCond))
      .groupBy(deliveredDay),
    db.select({ day: createdDay, cnt: count() }).from(ordersTable)
      .where(and(gte(ordersTable.createdAt, rangeStart), lt(ordersTable.createdAt, rangeEnd), ...baseCond))
      .groupBy(createdDay),
  ]);
  const revenueMap = new Map(revenueRows.map((r) => [r.day, num(r.total)]));
  const orderMap = new Map(orderRows.map((r) => [r.day, Number(r.cnt)]));

  const result = [];
  for (let i = days - 1; i >= 0; i--) {
    const key = cairoDateKey(startOfCairoDayAgo(i));
    result.push({ date: key, revenue: revenueMap.get(key) ?? 0, orders: orderMap.get(key) ?? 0 });
  }
  res.json(result);
});

export default router;
