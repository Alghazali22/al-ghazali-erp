import { Router } from "express";
import { db } from "@workspace/db";
import {
  usersTable, settlementsTable, withdrawalRequestsTable, treasuryTable,
  transactionsTable, ordersTable, branchesTable,
} from "@workspace/db";
import { eq, and, desc, sql, count, inArray, isNotNull } from "drizzle-orm";
import { requireAuth, requireRole, getAuth, requirePermission } from "../middlewares/auth";
import { audit } from "../lib/audit";
import { iso, num } from "../lib/format";
import { parseId, parsePagination, parseMoney, round2, isOneOf, optionalString } from "../lib/validate";

const router = Router();

const FINANCE_ROLES = ["super_admin", "branch_manager", "accountant"];
const TRANSACTION_TYPES = ["driver_settlement", "merchant_withdrawal", "shipping_fee", "return_fee", "adjustment"] as const;
const WITHDRAWAL_STATUSES = ["pending", "approved", "rejected"] as const;

class BusinessError extends Error {
  constructor(message: string, public status = 400) {
    super(message);
  }
}

/** Create the branch treasury row on first use, then lock it for the surrounding transaction. */
async function lockTreasury(tx: any, branchId: number) {
  await tx.insert(treasuryTable).values({ branchId }).onConflictDoNothing();
  const [treasury] = await tx.select().from(treasuryTable).where(eq(treasuryTable.branchId, branchId)).for("update");
  return treasury;
}

async function branchNameMap(ids: number[]): Promise<Map<number, string>> {
  const unique = [...new Set(ids)];
  if (!unique.length) return new Map();
  const rows = await db.select({ id: branchesTable.id, name: branchesTable.name }).from(branchesTable).where(inArray(branchesTable.id, unique));
  return new Map(rows.map((r) => [r.id, r.name]));
}

router.get("/financial/driver-balances", requireAuth, requirePermission("finance.view"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const conditions: any[] = [eq(usersTable.role, "driver")];
  // (Previously a second .where() silently replaced the role filter, returning ALL users when branchId was passed.)
  if (authUser.role === "branch_manager") {
    conditions.push(authUser.branchId ? eq(usersTable.branchId, authUser.branchId) : sql`false`);
  } else if (req.query.branchId !== undefined) {
    const bid = parseId(req.query.branchId);
    if (!bid) { res.status(400).json({ error: "رقم الفرع غير صحيح" }); return; }
    conditions.push(eq(usersTable.branchId, bid));
  }
  const drivers = await db.select().from(usersTable).where(and(...conditions)).orderBy(usersTable.id);
  const driverIds = drivers.map((d) => d.id);

  const [counts, branches] = await Promise.all([
    driverIds.length
      ? db.select({ driverId: ordersTable.driverId, cnt: count() }).from(ordersTable)
          .where(and(inArray(ordersTable.driverId, driverIds), eq(ordersTable.status, "delivered")))
          .groupBy(ordersTable.driverId)
      : Promise.resolve([] as { driverId: number | null; cnt: number }[]),
    branchNameMap(drivers.map((d) => d.branchId).filter((v): v is number => !!v)),
  ]);
  const countMap = new Map(counts.map((c) => [c.driverId, Number(c.cnt)]));

  res.json(drivers.map((d) => ({
    driverId: d.id,
    driverName: d.fullName,
    profilePhoto: d.profilePhoto,
    cashBalance: num(d.cashBalance),
    orderCount: countMap.get(d.id) ?? 0,
    branchName: d.branchId ? branches.get(d.branchId) ?? "الفرع" : "بلا فرع",
  })));
});

router.post("/financial/settle-driver/:driverId", requireAuth, requirePermission("finance.settle"), async (req, res): Promise<void> => {
  const driverId = parseId(req.params.driverId);
  const authUser = getAuth(req);
  if (!driverId) { res.status(400).json({ error: "رقم المندوب غير صحيح" }); return; }
  const amount = parseMoney(req.body?.amount);
  if (amount === null) { res.status(400).json({ error: "مبلغ التسوية غير صحيح" }); return; }
  const notes = optionalString(req.body?.notes, 500) ?? null;

  const [actor] = await db.select({ fullName: usersTable.fullName }).from(usersTable).where(eq(usersTable.id, authUser.userId));
  const settledBy = actor?.fullName ?? "محاسب";

  try {
    const result = await db.transaction(async (tx) => {
      const [driver] = await tx.select().from(usersTable).where(eq(usersTable.id, driverId)).for("update");
      if (!driver || driver.role !== "driver") throw new BusinessError("المندوب غير موجود", 404);
      if (authUser.role === "branch_manager" && (!authUser.branchId || driver.branchId !== authUser.branchId)) {
        throw new BusinessError("لا يمكنك تسوية مندوب تابع لفرع آخر", 403);
      }
      const branchId = driver.branchId ?? authUser.branchId;
      if (!branchId) throw new BusinessError("المندوب غير مرتبط بفرع");
      if (amount > num(driver.cashBalance) + 0.001) throw new BusinessError("مبلغ التسوية أكبر من رصيد الكاش على المندوب");

      // Match the cash handed in against this driver's delivered orders, oldest first. Each matched
      // order moves the merchant's net from "pending" to "ready to withdraw" — money only becomes
      // withdrawable once the company actually holds the cash.
      let credit = round2(num(driver.settlementCredit) + amount);
      const unsettled = await tx.select({
        id: ordersTable.id, merchantId: ordersTable.merchantId,
        collectedAmount: ordersTable.collectedAmount, shippingFee: ordersTable.shippingFee,
      }).from(ordersTable)
        .where(and(eq(ordersTable.driverId, driverId), inArray(ordersTable.status, ["delivered", "partial_delivery"]), eq(ordersTable.cashSettled, false)))
        .orderBy(ordersTable.deliveredAt, ordersTable.id)
        .for("update");
      const releaseByMerchant = new Map<number, number>();
      const settledIds: number[] = [];
      for (const o of unsettled) {
        const collected = num(o.collectedAmount);
        if (collected > credit + 0.001) break;
        credit = round2(credit - collected);
        settledIds.push(o.id);
        const net = round2(collected - num(o.shippingFee));
        if (net > 0) releaseByMerchant.set(o.merchantId, round2((releaseByMerchant.get(o.merchantId) ?? 0) + net));
      }
      if (settledIds.length) {
        await tx.update(ordersTable).set({ cashSettled: true }).where(inArray(ordersTable.id, settledIds));
      }
      for (const [merchantId, net] of releaseByMerchant) {
        await tx.update(usersTable).set({
          pendingBalance: sql`${usersTable.pendingBalance} - ${net}`,
          walletBalance: sql`${usersTable.walletBalance} + ${net}`,
        }).where(eq(usersTable.id, merchantId));
      }
      await tx.update(usersTable).set({
        cashBalance: sql`${usersTable.cashBalance} - ${amount}`,
        settlementCredit: String(credit),
      }).where(eq(usersTable.id, driverId));
      const [settlement] = await tx.insert(settlementsTable).values({
        driverId, amount: String(amount), settledById: authUser.userId, settledByName: settledBy, branchId, notes,
      }).returning();

      await lockTreasury(tx, branchId);
      await tx.update(treasuryTable).set({
        balance: sql`${treasuryTable.balance} + ${amount}`,
        totalIn: sql`${treasuryTable.totalIn} + ${amount}`,
        updatedAt: new Date(),
      }).where(eq(treasuryTable.branchId, branchId));

      await tx.insert(transactionsTable).values({
        type: "driver_settlement",
        amount: String(amount),
        description: `تسوية كاش مع المندوب ${driver.fullName}`,
        reference: `settlement-${settlement.id}`,
        branchId,
      });
      return { settlement, driverName: driver.fullName, releasedOrders: settledIds.length, releasedAmount: round2([...releaseByMerchant.values()].reduce((a, b) => a + b, 0)) };
    });

    await audit(req, "finance.settle_driver", { type: "user", id: driverId }, `تسوية كاش ${amount} ج.م مع ${result.driverName}`);
    res.json({
      id: result.settlement.id,
      driverId,
      driverName: result.driverName,
      amount,
      settledAt: iso(result.settlement.createdAt),
      settledBy,
      releasedOrders: result.releasedOrders,
      releasedAmount: result.releasedAmount,
    });
  } catch (err) {
    if (err instanceof BusinessError) { res.status(err.status).json({ error: err.message }); return; }
    throw err;
  }
});

router.get("/financial/merchant-wallet/:merchantId", requireAuth, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const merchantId = parseId(req.params.merchantId);
  if (!merchantId) { res.status(400).json({ error: "رقم التاجر غير صحيح" }); return; }
  const [merchant] = await db.select().from(usersTable).where(eq(usersTable.id, merchantId));
  if (!merchant || merchant.role !== "merchant") { res.status(404).json({ error: "Not found" }); return; }

  // IDOR fix: any logged-in user could previously read any merchant's wallet.
  const allowed =
    authUser.userId === merchantId ||
    authUser.role === "super_admin" ||
    authUser.role === "accountant" ||
    (authUser.role === "branch_manager" && !!authUser.branchId && merchant.branchId === authUser.branchId);
  if (!allowed) { res.status(403).json({ error: "غير مصرح" }); return; }

  // transactions has no merchant column; a merchant's ledger entries are their payout receipts.
  const receipts = await db.select({ receipt: withdrawalRequestsTable.receiptNumber }).from(withdrawalRequestsTable)
    .where(and(eq(withdrawalRequestsTable.merchantId, merchantId), isNotNull(withdrawalRequestsTable.receiptNumber)))
    .orderBy(desc(withdrawalRequestsTable.createdAt)).limit(50);
  const refs = receipts.map((r) => r.receipt).filter((r): r is string => !!r);
  const recentTxns = refs.length
    ? await db.select().from(transactionsTable).where(inArray(transactionsTable.reference, refs)).orderBy(desc(transactionsTable.createdAt)).limit(10)
    : [];

  res.json({
    merchantId,
    merchantName: merchant.fullName,
    merchantLogo: merchant.merchantLogo,
    pendingBalance: num(merchant.pendingBalance),
    readyBalance: num(merchant.walletBalance),
    totalWithdrawn: num(merchant.totalWithdrawn),
    recentTransactions: recentTxns.map((t) => ({
      id: t.id, type: t.type, amount: num(t.amount),
      description: t.description, reference: t.reference,
      createdAt: iso(t.createdAt),
    })),
  });
});

// New: a merchant's statement — every settled/unsettled delivered order with the net owed.
router.get("/financial/merchant-statement/:merchantId", requireAuth, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const merchantId = parseId(req.params.merchantId);
  if (!merchantId) { res.status(400).json({ error: "رقم التاجر غير صحيح" }); return; }
  const [merchant] = await db.select({ id: usersTable.id, role: usersTable.role, branchId: usersTable.branchId, fullName: usersTable.fullName })
    .from(usersTable).where(eq(usersTable.id, merchantId));
  if (!merchant || merchant.role !== "merchant") { res.status(404).json({ error: "Not found" }); return; }
  const allowed =
    authUser.userId === merchantId ||
    authUser.role === "super_admin" ||
    authUser.role === "accountant" ||
    (authUser.role === "branch_manager" && !!authUser.branchId && merchant.branchId === authUser.branchId);
  if (!allowed) { res.status(403).json({ error: "غير مصرح" }); return; }

  const orders = await db.select().from(ordersTable)
    .where(and(eq(ordersTable.merchantId, merchantId), inArray(ordersTable.status, ["delivered", "partial_delivery"])))
    .orderBy(desc(ordersTable.deliveredAt), desc(ordersTable.id)).limit(200);

  const rows = orders.map((o) => {
    const collected = num(o.collectedAmount);
    const shippingFee = num(o.shippingFee);
    return {
      orderId: o.id,
      orderNumber: o.orderNumber,
      customerName: o.customerName,
      status: o.status,
      collected,
      shippingFee,
      net: round2(collected - shippingFee),
      released: o.cashSettled,
      deliveredAt: iso(o.deliveredAt),
    };
  });
  res.json({
    merchantName: merchant.fullName,
    rows,
    totals: {
      collected: round2(rows.reduce((a, r) => a + r.collected, 0)),
      shippingFee: round2(rows.reduce((a, r) => a + r.shippingFee, 0)),
      net: round2(rows.reduce((a, r) => a + r.net, 0)),
      awaitingCash: round2(rows.filter((r) => !r.released && r.net > 0).reduce((a, r) => a + r.net, 0)),
    },
  });
});

router.get("/financial/withdrawal-requests", requireAuth, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const { status } = req.query;
  if (!["merchant", "super_admin", "accountant", "branch_manager"].includes(authUser.role)) {
    res.status(403).json({ error: "غير مصرح" });
    return;
  }
  const conditions: any[] = [];
  if (status !== undefined) {
    if (!isOneOf(status, WITHDRAWAL_STATUSES)) { res.status(400).json({ error: "حالة غير صحيحة" }); return; }
    conditions.push(eq(withdrawalRequestsTable.status, status));
  }
  if (authUser.role === "merchant") {
    conditions.push(eq(withdrawalRequestsTable.merchantId, authUser.userId));
  } else if (authUser.role === "branch_manager") {
    if (!authUser.branchId) { res.json([]); return; }
    const branchMerchants = db.select({ id: usersTable.id }).from(usersTable).where(eq(usersTable.branchId, authUser.branchId));
    conditions.push(inArray(withdrawalRequestsTable.merchantId, branchMerchants));
  }
  const requests = await db.select().from(withdrawalRequestsTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(withdrawalRequestsTable.createdAt)).limit(300);

  const merchantIds = [...new Set(requests.map((r) => r.merchantId))];
  const merchants = merchantIds.length
    ? await db.select({ id: usersTable.id, fullName: usersTable.fullName }).from(usersTable).where(inArray(usersTable.id, merchantIds))
    : [];
  const nameMap = new Map(merchants.map((m) => [m.id, m.fullName]));

  res.json(requests.map((r) => ({
    ...r,
    amount: num(r.amount),
    merchantName: nameMap.get(r.merchantId) ?? "Unknown",
    processedBy: r.processedByName,
    receiptNumber: r.receiptNumber,
    processedAt: iso(r.processedAt),
    createdAt: iso(r.createdAt),
  })));
});

router.post("/financial/withdrawal-requests", requireAuth, requireRole("merchant"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const amount = parseMoney(req.body?.amount);
  if (amount === null) { res.status(400).json({ error: "مبلغ السحب غير صحيح" }); return; }
  const notes = optionalString(req.body?.notes, 500) ?? null;

  try {
    const result = await db.transaction(async (tx) => {
      const [merchant] = await tx.select().from(usersTable).where(eq(usersTable.id, authUser.userId)).for("update");
      if (!merchant) throw new BusinessError("الحساب غير موجود", 404);
      // Can't request more than the ready balance minus what's already awaiting approval.
      const [pendingRow] = await tx.select({ total: sql<string>`coalesce(sum(${withdrawalRequestsTable.amount}), 0)` })
        .from(withdrawalRequestsTable)
        .where(and(eq(withdrawalRequestsTable.merchantId, authUser.userId), eq(withdrawalRequestsTable.status, "pending")));
      const available = round2(num(merchant.walletBalance) - num(pendingRow?.total));
      if (amount > available + 0.001) {
        throw new BusinessError(`المبلغ المطلوب أكبر من الرصيد المتاح للسحب (${Math.max(0, available)} ج.م)`);
      }
      const [request] = await tx.insert(withdrawalRequestsTable).values({
        merchantId: authUser.userId, amount: String(amount), notes,
      }).returning();
      return { request, merchantName: merchant.fullName };
    });
    const { request, merchantName } = result;
    res.status(201).json({ ...request, amount: num(request.amount), merchantName, createdAt: iso(request.createdAt) });
  } catch (err) {
    if (err instanceof BusinessError) { res.status(err.status).json({ error: err.message }); return; }
    throw err;
  }
});

router.post("/financial/withdrawal-requests/:id/approve", requireAuth, requirePermission("finance.approve_withdrawals"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  const authUser = getAuth(req);
  if (!id) { res.status(400).json({ error: "رقم طلب السحب غير صحيح" }); return; }

  try {
    const result = await db.transaction(async (tx) => {
      const [actor] = await tx.select({ fullName: usersTable.fullName }).from(usersTable).where(eq(usersTable.id, authUser.userId));
      const [request] = await tx.select().from(withdrawalRequestsTable).where(eq(withdrawalRequestsTable.id, id)).for("update");
      if (!request) throw new BusinessError("طلب السحب غير موجود", 404);
      if (request.status !== "pending") throw new BusinessError("تمت معالجة طلب السحب هذا من قبل");

      const amount = num(request.amount);
      if (!Number.isFinite(amount) || amount <= 0) throw new BusinessError("قيمة السحب غير صحيحة");

      const [merchant] = await tx.select().from(usersTable).where(eq(usersTable.id, request.merchantId)).for("update");
      if (!merchant) throw new BusinessError("التاجر غير موجود");
      if (num(merchant.walletBalance) < amount) throw new BusinessError("رصيد محفظة التاجر غير كافٍ للصرف");

      const branchId = merchant.branchId ?? authUser.branchId;
      if (!branchId) throw new BusinessError("التاجر غير مرتبط بفرع");
      const treasury = await lockTreasury(tx, branchId);
      if (num(treasury.balance) < amount) throw new BusinessError("رصيد الخزينة غير كافٍ للصرف");

      const processedAt = new Date();
      const receiptNumber = `PAY-${processedAt.toISOString().slice(0, 10).replace(/-/g, "")}-${String(id).padStart(6, "0")}`;
      const processedByName = actor?.fullName ?? "محاسب";
      const [updated] = await tx.update(withdrawalRequestsTable).set({
        status: "approved", processedById: authUser.userId, processedByName, receiptNumber, processedAt,
      }).where(and(eq(withdrawalRequestsTable.id, id), eq(withdrawalRequestsTable.status, "pending"))).returning();
      if (!updated) throw new BusinessError("تمت معالجة طلب السحب هذا من قبل");

      await tx.update(usersTable).set({
        walletBalance: sql`${usersTable.walletBalance} - ${amount}`,
        totalWithdrawn: sql`${usersTable.totalWithdrawn} + ${amount}`,
      }).where(eq(usersTable.id, request.merchantId));

      await tx.update(treasuryTable).set({
        balance: sql`${treasuryTable.balance} - ${amount}`,
        totalOut: sql`${treasuryTable.totalOut} + ${amount}`,
        updatedAt: processedAt,
      }).where(eq(treasuryTable.branchId, branchId));

      await tx.insert(transactionsTable).values({
        type: "merchant_withdrawal",
        amount: String(amount),
        description: `سند صرف مستحقات التاجر ${merchant.fullName}`,
        reference: receiptNumber,
        branchId,
      });
      return { updated, merchantName: merchant.fullName, processedByName, receiptNumber };
    });

    await audit(req, "finance.approve_withdrawal", { type: "withdrawal", id }, `صرف ${num(result.updated.amount)} ج.م للتاجر ${result.merchantName} (${result.receiptNumber})`);
    const { updated, merchantName, processedByName, receiptNumber } = result;
    res.json({
      ...updated,
      amount: num(updated.amount),
      merchantName,
      processedBy: processedByName,
      receiptNumber,
      processedAt: iso(updated.processedAt),
      createdAt: iso(updated.createdAt),
    });
  } catch (err) {
    if (err instanceof BusinessError) { res.status(err.status).json({ error: err.message }); return; }
    throw err;
  }
});

// New: the schema has a "rejected" status but there was no way to reject a request.
router.post("/financial/withdrawal-requests/:id/reject", requireAuth, requirePermission("finance.approve_withdrawals"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  const authUser = getAuth(req);
  if (!id) { res.status(400).json({ error: "رقم طلب السحب غير صحيح" }); return; }
  const reason = optionalString(req.body?.reason, 300);
  const [actor] = await db.select({ fullName: usersTable.fullName }).from(usersTable).where(eq(usersTable.id, authUser.userId));

  const [updated] = await db.update(withdrawalRequestsTable).set({
    status: "rejected",
    processedById: authUser.userId,
    processedByName: actor?.fullName ?? "محاسب",
    processedAt: new Date(),
    ...(reason ? { notes: reason } : {}),
  }).where(and(eq(withdrawalRequestsTable.id, id), eq(withdrawalRequestsTable.status, "pending"))).returning();
  if (!updated) { res.status(409).json({ error: "طلب السحب غير موجود أو تمت معالجته من قبل" }); return; }

  await audit(req, "finance.reject_withdrawal", { type: "withdrawal", id }, reason ?? undefined);
  const [merchant] = await db.select({ fullName: usersTable.fullName }).from(usersTable).where(eq(usersTable.id, updated.merchantId));
  res.json({
    ...updated,
    amount: num(updated.amount),
    merchantName: merchant?.fullName ?? "Unknown",
    processedBy: updated.processedByName,
    processedAt: iso(updated.processedAt),
    createdAt: iso(updated.createdAt),
  });
});

router.get("/financial/treasury", requireAuth, requirePermission("finance.view"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  let bid: number | null;
  if (authUser.role === "branch_manager") {
    bid = authUser.branchId; // locked to own branch regardless of query params
  } else if (req.query.branchId !== undefined) {
    bid = parseId(req.query.branchId);
    if (!bid) { res.status(400).json({ error: "رقم الفرع غير صحيح" }); return; }
  } else {
    const [first] = await db.select({ id: branchesTable.id }).from(branchesTable).orderBy(branchesTable.id).limit(1);
    bid = first?.id ?? null;
  }
  if (!bid) { res.status(400).json({ error: "لا يوجد فرع" }); return; }

  const [[treasury], names] = await Promise.all([
    db.select().from(treasuryTable).where(eq(treasuryTable.branchId, bid)),
    branchNameMap([bid]),
  ]);
  const branchName = names.get(bid) ?? "الفرع الرئيسي";
  if (!treasury) {
    res.json({ branchId: bid, branchName, balance: 0, totalIn: 0, totalOut: 0, lastUpdated: new Date().toISOString() });
    return;
  }
  res.json({
    branchId: treasury.branchId,
    branchName,
    balance: num(treasury.balance),
    totalIn: num(treasury.totalIn),
    totalOut: num(treasury.totalOut),
    lastUpdated: iso(treasury.updatedAt),
  });
});

router.get("/financial/transactions", requireAuth, requirePermission("finance.view"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const { branchId, type } = req.query;
  const conds: any[] = [];
  if (authUser.role === "branch_manager") {
    conds.push(authUser.branchId ? eq(transactionsTable.branchId, authUser.branchId) : sql`false`);
  } else if (branchId !== undefined) {
    const bid = parseId(branchId);
    if (!bid) { res.status(400).json({ error: "رقم الفرع غير صحيح" }); return; }
    conds.push(eq(transactionsTable.branchId, bid));
  }
  if (type !== undefined) {
    if (!isOneOf(type, TRANSACTION_TYPES)) { res.status(400).json({ error: "نوع غير صحيح" }); return; }
    conds.push(eq(transactionsTable.type, type));
  }
  // `page` was accepted before but ignored; now it actually paginates (50 per page by default).
  const { limit, offset } = parsePagination(req.query, { defaultLimit: 50, maxLimit: 200 });
  const txns = await db.select().from(transactionsTable)
    .where(conds.length ? and(...conds) : undefined)
    .orderBy(desc(transactionsTable.createdAt), desc(transactionsTable.id))
    .limit(limit).offset(offset);
  res.json(txns.map((t) => ({
    id: t.id, type: t.type, amount: num(t.amount),
    description: t.description, reference: t.reference,
    createdAt: iso(t.createdAt),
  })));
});

export default router;
