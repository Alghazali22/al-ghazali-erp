import { Router } from "express";
import { requireAuth, requireRole, requirePermission } from "../middlewares/auth";
import { rateLimit } from "../lib/rateLimit";

const router = Router();

const MAX_BYTES = 2 * 1024 * 1024;
const MAX_REDIRECTS = 5;
const TIMEOUT_MS = 12_000;

const limiter = rateLimit({
  windowMs: 60_000,
  max: 10,
  key: (req) => `sheet:${req.user?.userId ?? req.ip}`,
});

// SSRF guard: the server only ever talks to Google, never to a host the user typed.
const isGoogleHost = (host: string) =>
  host === "docs.google.com" || host.endsWith(".googleusercontent.com");

/** Returns the CSV export URL for a Google Sheets link, or null when it isn't a Sheets link. */
export function toCsvExportUrl(raw: string): string | null {
  let url: URL;
  try { url = new URL(raw.trim()); } catch { return null; }
  if (url.protocol !== "https:" || url.hostname !== "docs.google.com") return null;
  const match = /^\/spreadsheets\/d\/([A-Za-z0-9_-]{20,})/.exec(url.pathname);
  if (!match) return null;
  const gid = /(?:^|[?&#])gid=(\d{1,12})/.exec(url.search + url.hash)?.[1];
  return `https://docs.google.com/spreadsheets/d/${match[1]}/export?format=csv${gid ? `&gid=${gid}` : ""}`;
}

async function fetchLimited(startUrl: string): Promise<{ status: number; contentType: string; text: string }> {
  let current = startUrl;
  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
      const res = await fetch(current, { redirect: "manual", signal: controller.signal, headers: { Accept: "text/csv,*/*" } });
      if (res.status >= 300 && res.status < 400) {
        const location = res.headers.get("location");
        if (!location) throw new Error("redirect without location");
        const next = new URL(location, current);
        if (next.protocol !== "https:" || !isGoogleHost(next.hostname)) throw new Error("redirect outside Google");
        current = next.toString();
        continue;
      }
      // Stream with a hard size cap so a huge sheet can't exhaust memory.
      const reader = res.body?.getReader();
      const chunks: Uint8Array[] = [];
      let size = 0;
      if (reader) {
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          size += value.byteLength;
          if (size > MAX_BYTES) { await reader.cancel(); throw new Error("too large"); }
          chunks.push(value);
        }
      }
      return {
        status: res.status,
        contentType: res.headers.get("content-type") ?? "",
        text: Buffer.concat(chunks).toString("utf-8"),
      };
    } finally {
      clearTimeout(timer);
    }
  }
  throw new Error("too many redirects");
}

// New: paste a Google Sheets link instead of exporting a file. The sheet must be shared as
// "Anyone with the link can view" (we never ask for the merchant's Google credentials).
router.post("/import/google-sheet", requireAuth, requirePermission("orders.bulk_import"), limiter, async (req, res): Promise<void> => {
  const exportUrl = typeof req.body?.url === "string" ? toCsvExportUrl(req.body.url) : null;
  if (!exportUrl) {
    res.status(400).json({ error: "الرابط ليس رابط Google Sheet صحيحاً (يبدأ بـ https://docs.google.com/spreadsheets/d/...)" });
    return;
  }
  try {
    const result = await fetchLimited(exportUrl);
    const looksLikeCsv = result.contentType.includes("text/csv") || result.contentType.includes("text/plain");
    if (result.status !== 200 || !looksLikeCsv) {
      res.status(400).json({ error: "تعذر قراءة الشيت. اجعل مشاركته: «أي شخص لديه الرابط يمكنه العرض» ثم أعد المحاولة" });
      return;
    }
    res.json({ csv: result.text });
  } catch (err) {
    const message = (err as Error)?.message;
    if (message === "too large") { res.status(413).json({ error: "الشيت كبير جداً (الحد 2 ميجا)" }); return; }
    res.status(502).json({ error: "تعذر الاتصال بجوجل لقراءة الشيت، حاول مرة أخرى" });
  }
});

export default router;
