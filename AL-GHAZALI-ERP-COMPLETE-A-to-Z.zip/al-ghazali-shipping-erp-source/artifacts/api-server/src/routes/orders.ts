import { Router } from "express";
import { randomBytes, randomInt, timingSafeEqual } from "node:crypto";
import { db } from "@workspace/db";
import { ordersTable, orderEventsTable, orderTransfersTable, usersTable, branchesTable, zonesTable, merchantPricingTable } from "@workspace/db";
import { eq, and, ilike, sql, desc, count, or, inArray, gte, lt } from "drizzle-orm";
import { requireAuth, requireRole, getAuth, type AuthPayload, requirePermission, can } from "../middlewares/auth";
import { connectionStatus } from "./tracking";
import { currentTrafficMultiplier, estimateStops, governorateCenter } from "../lib/geo";
import { getRoleOrderConditions, canAccessOrder } from "../middlewares/orderScope";
import { audit } from "../lib/audit";
import { rateLimit } from "../lib/rateLimit";
import { computeConfidence, type Confidence } from "../lib/confidence";
import { startOfCairoDay } from "../lib/time";
import { iso, num } from "../lib/format";
import {
  parseId, parsePagination, escapeLike, parseMoney, round2, asTrimmedString, optionalString,
  normalizeDigits, parsePhone, phoneKey, isOneOf, isUniqueViolation, ORDER_STATUSES,
} from "../lib/validate";

const router = Router();

const INVENTORY_STATUSES = ["awaiting_merchant_receipt", "in_warehouse", "transfer_out"] as const;
const FINAL_STATUSES = ["delivered", "partial_delivery", "final_return"] as const;
// Statuses a non-super-admin may set by hand. Money-moving states (delivered / partial /
// returned) must go through /deliver and /return so OTP + cash accounting are never bypassed.
const MANUAL_STATUSES = ["pending", "ready", "in_transit"] as const;
const OTP_MAX_ATTEMPTS = 5;
const OTP_LOCK_MINUTES = 15;
const DEFAULT_SHIPPING_FEE = 25;

// Order numbers are the only secret protecting the public tracking page, so they are
// unpredictable (crypto RNG) and 8 digits long instead of 5.
function generateOrderNumber(): string {
  return `ALG-${randomInt(10_000_000, 100_000_000)}`;
}

function generateOtp(): string {
  return String(randomInt(1000, 10000));
}

function generateTransferNumber(): string {
  return `TRF-${new Date().toISOString().slice(0, 10).replace(/-/g, "")}-${randomBytes(4).toString("hex").toUpperCase()}`;
}

function otpMatches(provided: string, expected: string | null): boolean {
  if (!expected) return false;
  const a = Buffer.from(provided);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

// Linear happy-path progression. Branch statuses (returned/final_return/partial_delivery)
// are reached only through the dedicated /deliver and /return actions, not the quick-advance shortcut.
const STATUS_FLOW = ["pending", "ready", "in_transit", "delivered"];

const uniq = <T,>(arr: T[]) => [...new Set(arr)];

/**
 * Batch formatter: 4 queries total regardless of page size
 * (previously 4+ queries PER order — an N+1 on every list view).
 * The delivery OTP is never included: it was leaking to merchants, drivers and CS.
 */
async function formatOrders(orders: any[], maskFinancials = false) {
  if (orders.length === 0) return [];
  const merchantIds = uniq(orders.map((o) => o.merchantId as number));
  const branchIds = uniq(orders.map((o) => o.branchId as number));
  const driverIds = uniq(orders.map((o) => o.driverId as number | null).filter((v): v is number => !!v));
  const orderIds = orders.map((o) => o.id as number);

  const [merchants, branches, drivers, events] = await Promise.all([
    db.select({ id: usersTable.id, fullName: usersTable.fullName, merchantLogo: usersTable.merchantLogo })
      .from(usersTable).where(inArray(usersTable.id, merchantIds)),
    db.select({ id: branchesTable.id, name: branchesTable.name })
      .from(branchesTable).where(inArray(branchesTable.id, branchIds)),
    driverIds.length
      ? db.select({ id: usersTable.id, fullName: usersTable.fullName }).from(usersTable).where(inArray(usersTable.id, driverIds))
      : Promise.resolve([] as { id: number; fullName: string }[]),
    db.select().from(orderEventsTable).where(inArray(orderEventsTable.orderId, orderIds)).orderBy(orderEventsTable.createdAt),
  ]);

  const merchantMap = new Map(merchants.map((m) => [m.id, m]));
  const branchMap = new Map(branches.map((b) => [b.id, b]));
  const driverMap = new Map(drivers.map((d) => [d.id, d]));
  const eventsByOrder = new Map<number, typeof events>();
  for (const e of events) {
    const list = eventsByOrder.get(e.orderId) ?? [];
    list.push(e);
    eventsByOrder.set(e.orderId, list);
  }

  return orders.map((order) => {
    const { otp: _otp, otpAttempts: _attempts, otpLockedUntil: _lockedUntil, ...safe } = order;
    const merchant = merchantMap.get(order.merchantId);
    return {
      ...safe,
      packageValue: maskFinancials ? null : num(order.packageValue),
      shippingFee: maskFinancials ? null : num(order.shippingFee),
      totalToCollect: maskFinancials ? null : num(order.totalToCollect),
      collectedAmount: maskFinancials ? null : (order.collectedAmount ? num(order.collectedAmount) : null),
      merchantName: merchant?.fullName ?? "Unknown",
      merchantLogo: merchant?.merchantLogo ?? null,
      branchName: branchMap.get(order.branchId)?.name ?? "غير محدد",
      driverName: order.driverId ? driverMap.get(order.driverId)?.fullName ?? null : null,
      customerLat: order.customerLat !== null && order.customerLat !== undefined ? num(order.customerLat) : null,
      customerLng: order.customerLng !== null && order.customerLng !== undefined ? num(order.customerLng) : null,
      customerLocationAt: iso(order.customerLocationAt),
      createdAt: iso(order.createdAt),
      deliveredAt: iso(order.deliveredAt),
      podPhotoUrl: order.podPhotoUrl ?? null,
      podSignature: order.podSignature ? true : false, // never leak the full signature blob in lists
      podCapturedAt: iso(order.podCapturedAt),
      timeline: (eventsByOrder.get(order.id) ?? []).map((e) => ({
        id: e.id,
        status: e.status,
        description: e.description,
        actorName: e.actorName,
        timestamp: iso(e.createdAt),
      })),
    };
  });
}

async function formatOrder(order: any, maskFinancials = false) {
  return (await formatOrders([order], maskFinancials))[0];
}

async function actorName(userId: number, fallback: string): Promise<string> {
  const [actor] = await db.select({ fullName: usersTable.fullName }).from(usersTable).where(eq(usersTable.id, userId));
  return actor?.fullName ?? fallback;
}

router.get("/orders", requireAuth, async (req, res): Promise<void> => {
  const { status, inventoryStatus, branchId, merchantId, driverId, search } = req.query;
  const authUser = getAuth(req);
  const conditions: any[] = [];

  if (status !== undefined) {
    if (!isOneOf(status, ORDER_STATUSES)) { res.status(400).json({ error: "حالة غير صحيحة" }); return; }
    conditions.push(eq(ordersTable.status, status));
  }
  if (inventoryStatus !== undefined) {
    if (!isOneOf(inventoryStatus, INVENTORY_STATUSES)) { res.status(400).json({ error: "حالة المخزن غير صحيحة" }); return; }
    conditions.push(eq(ordersTable.inventoryStatus, inventoryStatus));
  }
  for (const [value, column, label] of [
    [branchId, ordersTable.branchId, "الفرع"],
    [merchantId, ordersTable.merchantId, "التاجر"],
    [driverId, ordersTable.driverId, "المندوب"],
  ] as const) {
    if (value === undefined) continue;
    const parsed = parseId(value);
    if (!parsed) { res.status(400).json({ error: `رقم ${label} غير صحيح` }); return; }
    conditions.push(eq(column, parsed));
  }
  if (typeof search === "string" && search.trim()) {
    const term = `%${escapeLike(search.trim().slice(0, 100))}%`;
    conditions.push(or(
      ilike(ordersTable.customerName, term),
      ilike(ordersTable.orderNumber, term),
      ilike(ordersTable.customerPhone, term),
    ));
  }

  // Strict role-based data isolation
  conditions.push(...getRoleOrderConditions(authUser));

  const { page, limit, offset } = parsePagination(req.query, { defaultLimit: 20, maxLimit: 100 });
  const where = conditions.length ? and(...conditions) : undefined;

  const [orders, [{ total }]] = await Promise.all([
    db.select().from(ordersTable).where(where).orderBy(desc(ordersTable.createdAt), desc(ordersTable.id)).limit(limit).offset(offset),
    db.select({ total: count() }).from(ordersTable).where(where),
  ]);

  // CS role gets financial data masked
  const maskFinancials = authUser.role === "cs";
  res.json({ orders: await formatOrders(orders, maskFinancials), total: Number(total), page, limit });
});

interface OrderPreview {
  shippingFee: number;
  totalToCollect: number;
  /** false ⇒ the governorate/area is not in the price list and the default fee would be applied. */
  zoneMatched: boolean;
  /** Same merchant + same phone already has an open order from the last 3 days (a warning, not an error). */
  possibleDuplicate: string | null;
  confidence: Confidence;
}

type CreateResult =
  | { ok: true; order: any; duplicate: boolean; preview?: OrderPreview }
  | { ok: false; status: number; error: string };

interface CreateOrderOptions {
  source?: "manual" | "import" | "api";
  /** The merchant's own reference. Makes API/import creation idempotent (same ref ⇒ same order). */
  externalRef?: string | null;
  /** Validate and price only — nothing is written. Returns `preview` instead of an order. */
  dryRun?: boolean;
  /** Shared lookups for a batch so 200 rows don't run 400 identical queries. */
  ctx?: PreviewContext;
}

interface PreviewContext {
  reputation: Map<string, { delivered: number; returned: number }>;
  area: Map<string, { closed: number; returned: number } | null>;
}
const newPreviewContext = (): PreviewContext => ({ reputation: new Map(), area: new Map() });

async function getReputation(key: string, ctx: PreviewContext) {
  const cached = ctx.reputation.get(key);
  if (cached) return cached;
  const [row] = await db.select({
    delivered: sql<number>`count(*) filter (where ${ordersTable.status} in ('delivered', 'partial_delivery'))`,
    returned: sql<number>`count(*) filter (where ${ordersTable.status} in ('returned', 'final_return'))`,
  }).from(ordersTable).where(eq(ordersTable.customerPhoneKey, key));
  const value = { delivered: Number(row?.delivered ?? 0), returned: Number(row?.returned ?? 0) };
  ctx.reputation.set(key, value);
  return value;
}

async function getAreaStats(governorate: string, area: string, ctx: PreviewContext) {
  const cacheKey = `${governorate}|${area}`;
  if (ctx.area.has(cacheKey)) return ctx.area.get(cacheKey)!;
  const [row] = await db.select({
    closed: sql<number>`count(*) filter (where ${ordersTable.status} in ('delivered', 'partial_delivery', 'returned', 'final_return'))`,
    returned: sql<number>`count(*) filter (where ${ordersTable.status} in ('returned', 'final_return'))`,
  }).from(ordersTable).where(and(
    eq(ordersTable.governorate, governorate), eq(ordersTable.area, area),
    gte(ordersTable.createdAt, new Date(Date.now() - 90 * 86_400_000)),
  ));
  const value = row ? { closed: Number(row.closed), returned: Number(row.returned) } : null;
  ctx.area.set(cacheKey, value);
  return value;
}

/**
 * Single place where an order is validated, priced and inserted.
 * Used by the manual form, the CSV bulk import and the store (API-key) integration.
 */
async function createOrderCore(authUser: AuthPayload, body: any, opts: CreateOrderOptions = {}): Promise<CreateResult> {
  const fail = (status: number, error: string): CreateResult => ({ ok: false, status, error });

  if (authUser.role === "accountant") return fail(403, "غير مصرح للمحاسب بإنشاء طلبات");
  if (authUser.role === "driver") return fail(403, "غير مصرح للمندوب بإنشاء طلبات");

  body = body ?? {};
  const customerName = asTrimmedString(body.customerName, 120);
  const customerPhone = parsePhone(body.customerPhone);
  const customerAddress = asTrimmedString(body.customerAddress, 500);
  const governorate = asTrimmedString(body.governorate, 100);
  const area = asTrimmedString(body.area, 100);
  const packageValue = parseMoney(body.packageValue, { allowZero: true, max: 1_000_000 });
  const rawPhone2 = body.customerPhone2;
  const customerPhone2 = rawPhone2 ? parsePhone(rawPhone2) : null;
  const notes = optionalString(body.notes, 1000) ?? null;

  if (!customerName) return fail(400, "اسم العميل مطلوب");
  if (!customerPhone) return fail(400, "رقم هاتف العميل غير صحيح");
  if (rawPhone2 && !customerPhone2) return fail(400, "رقم الهاتف الثاني غير صحيح");
  if (!customerAddress) return fail(400, "عنوان العميل مطلوب");
  if (!governorate || !area) return fail(400, "المحافظة والمنطقة مطلوبتان");
  if (packageValue === null) return fail(400, "قيمة الشحنة غير صحيحة");

  // Resolve merchant: merchants order for themselves; staff must name an existing merchant.
  const merchantId = authUser.role === "merchant" ? authUser.userId : parseId(body.merchantId);
  if (!merchantId) return fail(400, "يجب اختيار التاجر");
  const [merchant] = await db.select({ id: usersTable.id, role: usersTable.role, isActive: usersTable.isActive, branchId: usersTable.branchId })
    .from(usersTable).where(eq(usersTable.id, merchantId));
  if (!merchant || merchant.role !== "merchant" || !merchant.isActive) return fail(400, "التاجر غير موجود أو غير مفعّل");

  const externalRef = opts.externalRef ? opts.externalRef.trim().slice(0, 100) || null : null;
  if (externalRef) {
    const [existing] = await db.select().from(ordersTable)
      .where(and(eq(ordersTable.merchantId, merchantId), eq(ordersTable.externalRef, externalRef)));
    if (existing) return { ok: true, order: existing, duplicate: true };
  }

  let branchId = authUser.role === "merchant" ? merchant.branchId : (authUser.branchId ?? merchant.branchId);
  if (!branchId) {
    const [first] = await db.select({ id: branchesTable.id }).from(branchesTable).orderBy(branchesTable.id).limit(1);
    branchId = first?.id ?? null;
  }
  if (!branchId) return fail(400, "لا يوجد فرع مُعرّف في النظام");

  let shippingFee = DEFAULT_SHIPPING_FEE;
  const [zone] = await db.select().from(zonesTable).where(and(eq(zonesTable.governorate, governorate), eq(zonesTable.area, area)));
  if (zone) {
    if (!zone.isActive) return fail(400, "التوصيل لهذه المنطقة غير متاح حالياً");
    const [override] = await db.select().from(merchantPricingTable).where(and(eq(merchantPricingTable.merchantId, merchantId), eq(merchantPricingTable.zoneId, zone.id)));
    shippingFee = override ? num(override.customPrice) : num(zone.basePrice);
  }
  const totalToCollect = round2(packageValue + shippingFee);

  if (opts.dryRun) {
    const ctx = opts.ctx ?? newPreviewContext();
    const key = phoneKey(customerPhone);
    const [reputation, areaStats, [recent]] = await Promise.all([
      getReputation(key, ctx),
      getAreaStats(governorate, area, ctx),
      db.select({ orderNumber: ordersTable.orderNumber }).from(ordersTable).where(and(
        eq(ordersTable.merchantId, merchantId), eq(ordersTable.customerPhoneKey, key),
        inArray(ordersTable.status, ["pending", "ready", "in_transit"]),
        gte(ordersTable.createdAt, new Date(Date.now() - 3 * 86_400_000)),
      )).limit(1),
    ]);
    return {
      ok: true, order: null, duplicate: false,
      preview: {
        shippingFee, totalToCollect, zoneMatched: !!zone,
        possibleDuplicate: recent?.orderNumber ?? null,
        confidence: computeConfidence({ reputation, area: areaStats, totalToCollect, address: customerAddress, hasSecondPhone: !!customerPhone2 }),
      },
    };
  }

  for (let attempt = 0; attempt < 5; attempt++) {
    const orderNumber = generateOrderNumber();
    try {
      const order = await db.transaction(async (tx) => {
        const [created] = await tx.insert(ordersTable).values({
          orderNumber, otp: generateOtp(), status: "pending", inventoryStatus: "awaiting_merchant_receipt",
          customerName, customerPhone, customerPhone2, customerPhoneKey: phoneKey(customerPhone),
          customerAddress, governorate, area,
          packageValue: String(packageValue),
          shippingFee: String(shippingFee),
          totalToCollect: String(totalToCollect),
          notes,
          merchantId,
          branchId: branchId!,
          source: opts.source ?? "manual",
          externalRef,
        }).returning();
        await tx.insert(orderEventsTable).values({
          orderId: created.id,
          status: "pending",
          description: `تم استلام طلبك برقم (${orderNumber}) في الغزالي للشحن وجاري تجهيزه`,
          actorName: "النظام",
        });
        return created;
      });
      // Notify customer with tracking link + OTP when SMS/WhatsApp is configured
      try {
        const { notifyCustomerOrderCreated } = await import("../lib/notifications");
        void notifyCustomerOrderCreated({
          phone: order.customerPhone,
          customerName: order.customerName,
          orderNumber: order.orderNumber,
          otp: order.otp,
        });
      } catch { /* optional */ }
      return { ok: true, order, duplicate: false };
    } catch (err) {
      if (isUniqueViolation(err)) {
        // Same merchant reference raced in from a parallel request ⇒ return that order.
        if (externalRef) {
          const [existing] = await db.select().from(ordersTable)
            .where(and(eq(ordersTable.merchantId, merchantId), eq(ordersTable.externalRef, externalRef)));
          if (existing) return { ok: true, order: existing, duplicate: true };
        }
        continue; // order-number collision: pick another
      }
      throw err;
    }
  }
  return fail(503, "تعذر إنشاء رقم طلب فريد، حاول مرة أخرى");
}

export { createOrderCore };

router.post("/orders", requireAuth, async (req, res): Promise<void> => {
  const result = await createOrderCore(getAuth(req), req.body, { source: "manual" });
  if (!result.ok) { res.status(result.status).json({ error: result.error }); return; }
  res.status(201).json(await formatOrder(result.order));
});

// New: create (or just validate/price) up to 200 orders at once — Excel / Google Sheets / WhatsApp import.
const bulkLimiter = rateLimit({
  windowMs: 60_000,
  max: 10,
  key: (req) => `bulk:${req.user?.userId ?? req.ip}`,
});
const bulkPreviewLimiter = rateLimit({
  windowMs: 60_000,
  max: 30,
  key: (req) => `bulkp:${req.user?.userId ?? req.ip}`,
});

router.post("/orders/bulk", requireAuth, requirePermission("orders.bulk_import"),
  (req, res, next) => (req.body?.dryRun ? bulkPreviewLimiter : bulkLimiter)(req, res, next),
  async (req, res): Promise<void> => {
    const authUser = getAuth(req);
    const rows = req.body?.rows;
    const dryRun = req.body?.dryRun === true;
    if (!Array.isArray(rows) || rows.length === 0 || rows.length > 200) {
      res.status(400).json({ error: "أرسل من 1 إلى 200 طلب في المرة الواحدة" });
      return;
    }
    const ctx = newPreviewContext();
    const results: any[] = [];
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i] ?? {};
      const ref = typeof row.reference === "string" ? row.reference : null;
      const outcome = await createOrderCore(
        authUser,
        { ...row, merchantId: row.merchantId ?? req.body?.merchantId },
        { source: "import", externalRef: ref, dryRun, ctx },
      );
      if (!outcome.ok) { results.push({ row: i + 1, ok: false, error: outcome.error }); continue; }
      if (dryRun) {
        results.push({ row: i + 1, ok: true, duplicate: outcome.duplicate, preview: outcome.preview, orderNumber: outcome.duplicate ? outcome.order?.orderNumber : undefined });
        continue;
      }
      const o = outcome.order;
      results.push({
        row: i + 1, ok: true, orderNumber: o.orderNumber, duplicate: outcome.duplicate,
        // Everything a shipping label needs, so the app can print them straight away.
        order: {
          orderNumber: o.orderNumber, customerName: o.customerName, customerPhone: o.customerPhone,
          customerAddress: o.customerAddress, governorate: o.governorate, area: o.area,
          packageValue: num(o.packageValue), shippingFee: num(o.shippingFee), totalToCollect: num(o.totalToCollect), notes: o.notes,
        },
      });
    }
    res.json({
      dryRun,
      created: dryRun ? 0 : results.filter((r) => r.ok && !r.duplicate).length,
      duplicates: results.filter((r) => r.ok && r.duplicate).length,
      failed: results.filter((r) => !r.ok).length,
      results,
    });
  });

const STATUS_AR: Record<string, string> = {
  pending: "قيد الانتظار", ready: "جاهز", in_transit: "جاري التوصيل", delivered: "تم التسليم",
  partial_delivery: "تسليم جزئي", returned: "مرتجع", final_return: "مرتجع نهائي",
};

/** CSV cell with quoting + spreadsheet-formula injection protection (cells starting = + - @ are neutralised). */
function csvCell(value: unknown): string {
  let text = value === null || value === undefined ? "" : String(value);
  if (/^[=+\-@\t\r]/.test(text)) text = `'${text}`;
  return `"${text.replace(/"/g, '""')}"`;
}

// New: export the (role-scoped, filtered) order list to Excel-friendly CSV.
router.get("/orders/export", requireAuth, requirePermission("orders.export"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  if (authUser.role === "driver") { res.status(403).json({ error: "غير مصرح" }); return; }
  const { status, search, from, to } = req.query;
  const conditions: any[] = [...getRoleOrderConditions(authUser)];

  if (status !== undefined) {
    if (!isOneOf(status, ORDER_STATUSES)) { res.status(400).json({ error: "حالة غير صحيحة" }); return; }
    conditions.push(eq(ordersTable.status, status));
  }
  for (const [value, op] of [[from, "gte"], [to, "lt"]] as const) {
    if (value === undefined) continue;
    if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) { res.status(400).json({ error: "صيغة التاريخ غير صحيحة (YYYY-MM-DD)" }); return; }
    // Calendar days are Cairo days; "to" is inclusive, so compare against the start of the next day.
    const dayStart = startOfCairoDay(new Date(`${value}T12:00:00+02:00`));
    const bound = op === "lt" ? new Date(dayStart.getTime() + 25 * 3_600_000) : dayStart;
    conditions.push(op === "gte" ? gte(ordersTable.createdAt, bound) : lt(ordersTable.createdAt, startOfCairoDay(bound)));
  }
  if (typeof search === "string" && search.trim()) {
    const term = `%${escapeLike(search.trim().slice(0, 100))}%`;
    conditions.push(or(ilike(ordersTable.customerName, term), ilike(ordersTable.orderNumber, term), ilike(ordersTable.customerPhone, term)));
  }

  const orders = await db.select().from(ordersTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(ordersTable.createdAt), desc(ordersTable.id)).limit(5000);

  const userIds = uniq([...orders.map((o) => o.merchantId), ...orders.map((o) => o.driverId).filter((v): v is number => !!v)]);
  const branchIds = uniq(orders.map((o) => o.branchId));
  const [users, branches] = await Promise.all([
    userIds.length ? db.select({ id: usersTable.id, fullName: usersTable.fullName }).from(usersTable).where(inArray(usersTable.id, userIds)) : [],
    branchIds.length ? db.select({ id: branchesTable.id, name: branchesTable.name }).from(branchesTable).where(inArray(branchesTable.id, branchIds)) : [],
  ]);
  const userMap = new Map(users.map((u) => [u.id, u.fullName]));
  const branchMap = new Map(branches.map((b) => [b.id, b.name]));
  const mask = authUser.role === "cs";

  const header = ["رقم الطلب", "الحالة", "العميل", "الهاتف", "المحافظة", "المنطقة", "العنوان", "التاجر", "الفرع", "المندوب",
    "قيمة الشحنة", "رسوم الشحن", "الإجمالي", "المحصل", "المحاولات", "تاريخ الإنشاء", "تاريخ التسليم"];
  const lines = [header.map(csvCell).join(",")];
  for (const o of orders) {
    lines.push([
      o.orderNumber, STATUS_AR[o.status] ?? o.status, o.customerName, o.customerPhone, o.governorate, o.area, o.customerAddress,
      userMap.get(o.merchantId) ?? "", branchMap.get(o.branchId) ?? "", o.driverId ? userMap.get(o.driverId) ?? "" : "",
      mask ? "" : num(o.packageValue), mask ? "" : num(o.shippingFee), mask ? "" : num(o.totalToCollect),
      mask ? "" : (o.collectedAmount ? num(o.collectedAmount) : ""),
      o.attemptCount, iso(o.createdAt) ?? "", iso(o.deliveredAt) ?? "",
    ].map(csvCell).join(","));
  }
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="orders-${new Date().toISOString().slice(0, 10)}.csv"`);
  res.send("\uFEFF" + lines.join("\r\n")); // BOM so Excel reads Arabic correctly
});

router.get("/orders/:id", requireAuth, async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  const authUser = getAuth(req);
  if (!id) { res.status(400).json({ error: "رقم الطلب غير صحيح" }); return; }
  const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, id));
  if (!order) { res.status(404).json({ error: "Not found" }); return; }
  if (!canAccessOrder(authUser, order)) { res.status(403).json({ error: "غير مصرح لك بالاطلاع على هذا الطلب" }); return; }
  res.json(await formatOrder(order, authUser.role === "cs"));
});

router.patch("/orders/:id", requireAuth, async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  const authUser = getAuth(req);
  if (!id) { res.status(400).json({ error: "رقم الطلب غير صحيح" }); return; }

  if (authUser.role === "accountant") {
    res.status(403).json({ error: "المحاسب ليس له صلاحية تعديل بيانات الطلبات" });
    return;
  }
  if (authUser.role === "driver") {
    res.status(403).json({ error: "المندوب ليس له صلاحية تعديل بيانات الطلبات" });
    return;
  }

  const body = req.body ?? {};
  const updates: any = {};

  const [existingOrder] = await db.select().from(ordersTable).where(eq(ordersTable.id, id));
  if (!existingOrder) { res.status(404).json({ error: "Not found" }); return; }
  if (!canAccessOrder(authUser, existingOrder)) { res.status(403).json({ error: "غير مصرح لك بتعديل هذا الطلب" }); return; }
  if (existingOrder.inventoryStatus === "transfer_out") {
    res.status(400).json({ error: "لا يمكن تعديل الطلب أثناء وجوده في تحويل بين الفروع" });
    return;
  }
  const isSuperAdmin = authUser.role === "super_admin";
  if (!isSuperAdmin && (FINAL_STATUSES as readonly string[]).includes(existingOrder.status)) {
    res.status(400).json({ error: "لا يمكن تعديل طلب مكتمل" });
    return;
  }

  // Validate requested status (if any) up-front.
  let status: (typeof ORDER_STATUSES)[number] | undefined;
  if (body.status !== undefined) {
    if (!isOneOf(body.status, ORDER_STATUSES)) { res.status(400).json({ error: "حالة غير صحيحة" }); return; }
    status = body.status;
  }

  const canChangeStatus = isSuperAdmin || authUser.role === "branch_manager" || authUser.role === "operations";
  if (status !== undefined && canChangeStatus) {
    if (!isSuperAdmin && !(MANUAL_STATUSES as readonly string[]).includes(status)) {
      res.status(403).json({ error: "التسليم والمرتجع يتمان فقط من خلال إجراءات التسليم/الإرجاع بكود التأكيد" });
      return;
    }
    if (status !== "pending" && existingOrder.inventoryStatus !== "in_warehouse") {
      res.status(400).json({ error: "لا يمكن تغيير حالة الطلب قبل دخوله مخزن الفرع" });
      return;
    }
    updates.status = status;
  }

  // Free-text fields editable by every role allowed here.
  const phone2 = body.customerPhone2 === undefined ? undefined : (body.customerPhone2 ? parsePhone(body.customerPhone2) : null);
  if (phone2 === null && body.customerPhone2) { res.status(400).json({ error: "رقم الهاتف الثاني غير صحيح" }); return; }
  if (phone2 !== undefined) updates.customerPhone2 = phone2;
  if (body.customerAddress !== undefined) {
    const v = asTrimmedString(body.customerAddress, 500);
    if (!v) { res.status(400).json({ error: "العنوان غير صحيح" }); return; }
    updates.customerAddress = v;
  }
  if (authUser.role !== "cs" && body.notes !== undefined) {
    const v = optionalString(body.notes, 1000);
    if (v !== undefined) updates.notes = v;
  }

  // Dispatch roles may reassign the order to a different driver.
  if (body.driverId !== undefined && (isSuperAdmin || authUser.role === "branch_manager" || authUser.role === "operations")) {
    if (body.driverId === null) {
      updates.driverId = null;
    } else {
      const driverId = parseId(body.driverId);
      if (!driverId) { res.status(400).json({ error: "رقم المندوب غير صحيح" }); return; }
      const [driver] = await db.select({ role: usersTable.role, isActive: usersTable.isActive, branchId: usersTable.branchId })
        .from(usersTable).where(eq(usersTable.id, driverId));
      if (!driver || driver.role !== "driver" || !driver.isActive) {
        res.status(400).json({ error: "المندوب غير موجود أو غير مفعّل" });
        return;
      }
      if (!isSuperAdmin && driver.branchId !== existingOrder.branchId) {
        res.status(400).json({ error: "لا يمكن إسناد الطلب لمندوب من فرع آخر" });
        return;
      }
      updates.driverId = driverId;
    }
    if (updates.driverId !== existingOrder.driverId) { updates.tripId = null; updates.loadedAt = null; updates.stopSequence = null; }
  }

  if (isSuperAdmin) {
    // Super admin has unrestricted edit access to the remaining fields, at any time.
    if (body.customerName !== undefined) {
      const v = asTrimmedString(body.customerName, 120);
      if (!v) { res.status(400).json({ error: "اسم العميل غير صحيح" }); return; }
      updates.customerName = v;
    }
    if (body.customerPhone !== undefined) {
      const v = parsePhone(body.customerPhone);
      if (!v) { res.status(400).json({ error: "رقم هاتف العميل غير صحيح" }); return; }
      updates.customerPhone = v;
    }
    if (body.governorate !== undefined) {
      const v = asTrimmedString(body.governorate, 100);
      if (!v) { res.status(400).json({ error: "المحافظة غير صحيحة" }); return; }
      updates.governorate = v;
    }
    if (body.area !== undefined) {
      const v = asTrimmedString(body.area, 100);
      if (!v) { res.status(400).json({ error: "المنطقة غير صحيحة" }); return; }
      updates.area = v;
    }
    if (body.packageValue !== undefined || body.shippingFee !== undefined) {
      const pv = body.packageValue !== undefined ? parseMoney(body.packageValue, { allowZero: true, max: 1_000_000 }) : num(existingOrder.packageValue);
      const sf = body.shippingFee !== undefined ? parseMoney(body.shippingFee, { allowZero: true, max: 100_000 }) : num(existingOrder.shippingFee);
      if (pv === null || sf === null) { res.status(400).json({ error: "القيم المالية غير صحيحة" }); return; }
      updates.packageValue = String(pv);
      updates.shippingFee = String(sf);
      updates.totalToCollect = String(round2(pv + sf));
    }
  }

  if (Object.keys(updates).length === 0) {
    res.status(400).json({ error: "لا توجد بيانات للتحديث" });
    return;
  }

  const name = await actorName(authUser.userId, "الإدارة");
  const order = await db.transaction(async (tx) => {
    const [updated] = await tx.update(ordersTable).set(updates).where(eq(ordersTable.id, id)).returning();
    if (!updated) return null;

    if (updates.status) {
      await tx.insert(orderEventsTable).values({
        orderId: id, status: updates.status,
        description: `تم تحديث الحالة يدوياً بواسطة ${name}`,
        actorId: authUser.userId,
        actorName: name,
      });
    }
    if (updates.driverId !== undefined && updates.driverId !== existingOrder.driverId) {
      let newDriverName = "بدون طيار";
      if (updates.driverId) {
        const [newDriver] = await tx.select({ fullName: usersTable.fullName }).from(usersTable).where(eq(usersTable.id, updates.driverId));
        newDriverName = newDriver?.fullName ?? "طيار";
      }
      await tx.insert(orderEventsTable).values({
        orderId: id, status: updated.status,
        description: `تم نقل الطلب إلى الطيار (${newDriverName}) بواسطة ${name}`,
        actorId: authUser.userId,
        actorName: name,
      });
    }
    return updated;
  });
  if (!order) { res.status(404).json({ error: "Not found" }); return; }

  res.json(await formatOrder(order, authUser.role === "cs"));
});

const WAREHOUSE_ROLES = ["super_admin", "branch_manager", "operations"];

async function formatTransfers(transfers: any[]) {
  if (transfers.length === 0) return [];
  const orderIds = uniq(transfers.map((t) => t.orderId as number));
  const branchIds = uniq(transfers.flatMap((t) => [t.fromBranchId as number, t.toBranchId as number]));
  const [orders, branches] = await Promise.all([
    db.select({ id: ordersTable.id, orderNumber: ordersTable.orderNumber, customerName: ordersTable.customerName })
      .from(ordersTable).where(inArray(ordersTable.id, orderIds)),
    db.select({ id: branchesTable.id, name: branchesTable.name }).from(branchesTable).where(inArray(branchesTable.id, branchIds)),
  ]);
  const orderMap = new Map(orders.map((o) => [o.id, o]));
  const branchMap = new Map(branches.map((b) => [b.id, b.name]));
  return transfers.map((transfer) => ({
    ...transfer,
    orderNumber: orderMap.get(transfer.orderId)?.orderNumber ?? "غير موجود",
    customerName: orderMap.get(transfer.orderId)?.customerName ?? "غير موجود",
    fromBranchName: branchMap.get(transfer.fromBranchId) ?? "غير محدد",
    toBranchName: branchMap.get(transfer.toBranchId) ?? "غير محدد",
    createdAt: iso(transfer.createdAt),
    receivedAt: iso(transfer.receivedAt),
  }));
}

async function performReceive(authUser: ReturnType<typeof getAuth>, id: number) {
  const name = await actorName(authUser.userId, "الفرع");
  return db.transaction(async (tx) => {
    const [order] = await tx.select().from(ordersTable).where(eq(ordersTable.id, id)).for("update");
    if (!order) return { error: 404 as const, message: "Not found" };
    if (!canAccessOrder(authUser, order)) return { error: 403 as const, message: "لا يمكنك استلام طلب تابع لفرع آخر" };
    if (order.inventoryStatus !== "awaiting_merchant_receipt") {
      return { error: 400 as const, message: "الطلب ليس بانتظار الاستلام من التاجر" };
    }
    const [branch] = await tx.select({ name: branchesTable.name }).from(branchesTable).where(eq(branchesTable.id, order.branchId));
    const [updated] = await tx.update(ordersTable).set({ inventoryStatus: "in_warehouse", status: "ready" })
      .where(eq(ordersTable.id, id)).returning();
    await tx.insert(orderEventsTable).values({
      orderId: id,
      status: "ready",
      description: `تم استلام الشحنة من التاجر وإدخالها مخزن ${branch?.name ?? "الفرع"} بواسطة ${name}`,
      actorId: authUser.userId,
      actorName: name,
    });
    return { order: updated };
  });
}

router.post("/orders/:id/receive", requireAuth, requirePermission("warehouse.manage"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم الطلب غير صحيح" }); return; }
  const result = await performReceive(getAuth(req), id);
  if ("error" in result) { res.status(result.error).json({ error: result.message }); return; }
  res.json(await formatOrder(result.order));
});

// New: warehouse scanning. Scan/type one or many order numbers (QR labels) and receive them in one go.
router.post("/orders/receive-by-number", requireAuth, requirePermission("warehouse.manage"), async (req, res): Promise<void> => {
  const raw = req.body?.orderNumbers;
  if (!Array.isArray(raw) || raw.length === 0 || raw.length > 100) {
    res.status(400).json({ error: "أدخل من 1 إلى 100 رقم طلب" });
    return;
  }
  const numbers = [...new Set(raw.map((v) => String(v ?? "").trim().toUpperCase()).filter(Boolean))];
  const authUser = getAuth(req);
  const results: { orderNumber: string; ok: boolean; message: string }[] = [];
  for (const orderNumber of numbers) {
    const [order] = await db.select({ id: ordersTable.id }).from(ordersTable).where(eq(ordersTable.orderNumber, orderNumber));
    if (!order) { results.push({ orderNumber, ok: false, message: "رقم الطلب غير موجود" }); continue; }
    const outcome = await performReceive(authUser, order.id);
    results.push("error" in outcome
      ? { orderNumber, ok: false, message: outcome.message }
      : { orderNumber, ok: true, message: "تم الاستلام" });
  }
  res.json({ results, received: results.filter((r) => r.ok).length });
});

router.post("/orders/:id/transfer-out", requireAuth, requirePermission("warehouse.manage"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  const authUser = getAuth(req);
  const toBranchId = parseId(req.body?.toBranchId);
  if (!id) { res.status(400).json({ error: "رقم الطلب غير صحيح" }); return; }
  if (!toBranchId) { res.status(400).json({ error: "يجب اختيار الفرع المستلم" }); return; }
  const name = await actorName(authUser.userId, "الفرع");

  const result = await db.transaction(async (tx) => {
    const [order] = await tx.select().from(ordersTable).where(eq(ordersTable.id, id)).for("update");
    if (!order) return { error: 404 as const, message: "Not found" };
    if (!canAccessOrder(authUser, order)) return { error: 403 as const, message: "لا يمكنك نقل طلب تابع لفرع آخر" };
    if (order.inventoryStatus !== "in_warehouse") return { error: 400 as const, message: "لا يمكن تحويل الطلب قبل دخوله مخزن الفرع" };
    if (order.branchId === toBranchId) return { error: 400 as const, message: "لا يمكن تحويل الطلب إلى نفس الفرع" };
    const [toBranch] = await tx.select({ id: branchesTable.id }).from(branchesTable).where(eq(branchesTable.id, toBranchId));
    if (!toBranch) return { error: 404 as const, message: "الفرع المستلم غير موجود" };

    const [transfer] = await tx.insert(orderTransfersTable).values({
      transferNumber: generateTransferNumber(),
      orderId: id,
      fromBranchId: order.branchId,
      toBranchId,
      status: "in_transit",
      createdById: authUser.userId,
      createdByName: name,
    }).returning();
    const [updated] = await tx.update(ordersTable).set({
      branchId: toBranchId,
      inventoryStatus: "transfer_out",
      driverId: null,
      tripId: null,
    }).where(eq(ordersTable.id, id)).returning();
    await tx.insert(orderEventsTable).values({
      orderId: id,
      status: updated.status,
      description: `تم إنشاء مستند التحويل (${transfer.transferNumber}) من الفرع إلى فرع آخر، بانتظار تأكيد الاستلام`,
      actorId: authUser.userId,
      actorName: name,
    });
    return { transfer };
  });

  if ("error" in result) { res.status(result.error).json({ error: result.message }); return; }
  res.json((await formatTransfers([result.transfer]))[0]);
});

router.get("/order-transfers", requireAuth, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  if (!can(authUser, "warehouse.manage")) {
    res.status(403).json({ error: "غير مصرح لك بإدارة تحويلات الفروع" });
    return;
  }
  const { status } = req.query;
  const conditions: any[] = [];
  if (status !== undefined) {
    if (!isOneOf(status, ["in_transit", "received"] as const)) { res.status(400).json({ error: "حالة غير صحيحة" }); return; }
    conditions.push(eq(orderTransfersTable.status, status));
  }
  if (authUser.role !== "super_admin") {
    // Fail-closed: a branch-scoped user without a branch sees nothing (previously: everything).
    conditions.push(authUser.branchId
      ? or(eq(orderTransfersTable.fromBranchId, authUser.branchId), eq(orderTransfersTable.toBranchId, authUser.branchId))
      : sql`false`);
  }
  const transfers = await db.select().from(orderTransfersTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(orderTransfersTable.createdAt))
    .limit(500);
  res.json(await formatTransfers(transfers));
});

router.post("/order-transfers/:id/receive", requireAuth, requirePermission("warehouse.manage"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  const authUser = getAuth(req);
  if (!id) { res.status(400).json({ error: "رقم التحويل غير صحيح" }); return; }
  const name = await actorName(authUser.userId, "الفرع المستلم");

  const result = await db.transaction(async (tx) => {
    const [transfer] = await tx.select().from(orderTransfersTable).where(eq(orderTransfersTable.id, id)).for("update");
    if (!transfer) return { error: 404 as const, message: "التحويل غير موجود" };
    if (transfer.status !== "in_transit") return { error: 400 as const, message: "تم استلام هذا التحويل بالفعل" };
    if (authUser.role !== "super_admin" && transfer.toBranchId !== authUser.branchId) {
      return { error: 403 as const, message: "هذا التحويل ليس موجهاً إلى فرعك" };
    }
    const [order] = await tx.select().from(ordersTable).where(eq(ordersTable.id, transfer.orderId)).for("update");
    if (!order) return { error: 404 as const, message: "الطلب المرتبط بالتحويل غير موجود" };

    await tx.update(orderTransfersTable).set({
      status: "received",
      receivedById: authUser.userId,
      receivedByName: name,
      receivedAt: new Date(),
    }).where(eq(orderTransfersTable.id, id));
    const [updated] = await tx.update(ordersTable).set({ inventoryStatus: "in_warehouse" }).where(eq(ordersTable.id, order.id)).returning();
    await tx.insert(orderEventsTable).values({
      orderId: order.id,
      status: updated.status,
      description: `تم تأكيد استلام مستند التحويل (${transfer.transferNumber}) في الفرع المستلم بواسطة ${name}`,
      actorId: authUser.userId,
      actorName: name,
    });
    return { order: updated };
  });

  if ("error" in result) { res.status(result.error).json({ error: result.message }); return; }
  res.json(await formatOrder(result.order));
});

router.post("/orders/:id/advance-status", requireAuth, requirePermission("orders.status_override"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  const authUser = getAuth(req);
  if (!id) { res.status(400).json({ error: "رقم الطلب غير صحيح" }); return; }
  const name = await actorName(authUser.userId, "الإدارة");

  const result = await db.transaction(async (tx) => {
    const [order] = await tx.select().from(ordersTable).where(eq(ordersTable.id, id)).for("update");
    if (!order) return { error: 404 as const, message: "Not found" };
    if (order.inventoryStatus === "transfer_out") {
      return { error: 400 as const, message: "لا يمكن تشغيل الطلب أثناء وجوده في تحويل بين الفروع" };
    }
    const currentIndex = STATUS_FLOW.indexOf(order.status);
    if (currentIndex === -1) {
      return { error: 400 as const, message: "لا يمكن تقديم حالة هذا الطلب مباشرة، يرجى فتح الطلب لتفاصيل أكثر" };
    }
    if (currentIndex === STATUS_FLOW.length - 1) return { error: 400 as const, message: "الطلب في آخر مرحلة بالفعل" };

    const nextStatus = STATUS_FLOW[currentIndex + 1] as (typeof ORDER_STATUSES)[number];
    const [updated] = await tx.update(ordersTable).set({ status: nextStatus }).where(eq(ordersTable.id, id)).returning();
    await tx.insert(orderEventsTable).values({
      orderId: id, status: nextStatus,
      description: `تم تحديث الحالة إلى (${nextStatus}) مباشرة من قائمة الطلبات بواسطة ${name}`,
      actorId: authUser.userId,
      actorName: name,
    });
    return { order: updated };
  });

  if ("error" in result) { res.status(result.error).json({ error: result.message }); return; }
  res.json(await formatOrder(result.order));
});

router.delete("/orders/:id", requireAuth, requirePermission("orders.delete"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم الطلب غير صحيح" }); return; }
  const [target] = await db.select().from(ordersTable).where(eq(ordersTable.id, id));
  if (target && !canAccessOrder(getAuth(req), target)) { res.status(403).json({ error: "غير مصرح لك بحذف هذا الطلب" }); return; }
  const found = await db.transaction(async (tx) => {
    const [order] = await tx.select({ id: ordersTable.id }).from(ordersTable).where(eq(ordersTable.id, id));
    if (!order) return false;
    await tx.delete(orderEventsTable).where(eq(orderEventsTable.orderId, id));
    await tx.delete(orderTransfersTable).where(eq(orderTransfersTable.orderId, id));
    await tx.delete(ordersTable).where(eq(ordersTable.id, id));
    return true;
  });
  if (!found) { res.status(404).json({ error: "Not found" }); return; }
  await audit(req, "order.delete", { type: "order", id }, target?.orderNumber);
  res.json({ success: true });
});

const deliveryLimiter = rateLimit({
  windowMs: 60_000,
  max: 40,
  key: (req) => `deliver:${req.user?.userId ?? req.ip}`,
});

router.post("/orders/:id/deliver", requireAuth, requirePermission("orders.deliver"), deliveryLimiter, async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  const authUser = getAuth(req);
  if (!id) { res.status(400).json({ error: "رقم الطلب غير صحيح" }); return; }
  const { otp, deliveryType, collectedAmount, returnedItemCount, reason, podPhoto, podSignature } = req.body ?? {};

  const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, id));
  if (!order) { res.status(404).json({ error: "Not found" }); return; }
  if (!canAccessOrder(authUser, order)) { res.status(403).json({ error: "غير مصرح لك بتسليم هذا الطلب" }); return; }
  if (order.inventoryStatus === "transfer_out") {
    res.status(400).json({ error: "لا يمكن تسليم الطلب أثناء وجوده في تحويل بين الفروع" });
    return;
  }
  if (order.inventoryStatus !== "in_warehouse") {
    res.status(400).json({ error: "لا يمكن تسليم الطلب قبل دخوله مخزن الفرع" });
    return;
  }
  if ((FINAL_STATUSES as readonly string[]).includes(order.status)) {
    res.status(409).json({ error: "تم إغلاق هذا الطلب بالفعل ولا يمكن تسليمه مرة أخرى" });
    return;
  }
  if (authUser.role === "driver" && order.status !== "in_transit") {
    res.status(400).json({ error: "الطلب ليس في حالة توصيل" });
    return;
  }

  if (!isOneOf(deliveryType, ["full", "partial"] as const)) {
    res.status(400).json({ error: "نوع التسليم غير صحيح" });
    return;
  }

  // Brute-force protection for the 4-digit OTP.
  if (order.otpLockedUntil && order.otpLockedUntil.getTime() > Date.now()) {
    const minutes = Math.ceil((order.otpLockedUntil.getTime() - Date.now()) / 60_000);
    res.status(429).json({ error: `تم إيقاف إدخال الكود مؤقتاً بسبب محاولات خاطئة كثيرة. حاول بعد ${minutes} دقيقة أو اطلب كود الطوارئ من الإدارة` });
    return;
  }

  // The lock expired: give the driver a fresh set of attempts (otherwise one typo re-locks immediately).
  if (order.otpLockedUntil && order.otpLockedUntil.getTime() <= Date.now()) {
    await db.update(ordersTable).set({ otpAttempts: 0, otpLockedUntil: null }).where(eq(ordersTable.id, id));
  }

  // OTP validation (mandatory). Normalize Eastern Arabic / Persian digits,
  // since some mobile keyboards type those instead of Western digits.
  const normalizedOtp = normalizeDigits(String(otp ?? "")).trim();
  if (!otpMatches(normalizedOtp, order.otp)) {
    const [after] = await db.update(ordersTable).set({
      otpAttempts: sql`${ordersTable.otpAttempts} + 1`,
    }).where(eq(ordersTable.id, id)).returning({ attempts: ordersTable.otpAttempts });
    if ((after?.attempts ?? 0) >= OTP_MAX_ATTEMPTS) {
      // Lock time is computed here (not with DB now()) so it never depends on the DB session timezone.
      await db.update(ordersTable).set({ otpLockedUntil: new Date(Date.now() + OTP_LOCK_MINUTES * 60_000) })
        .where(eq(ordersTable.id, id));
    }
    const remaining = Math.max(0, OTP_MAX_ATTEMPTS - (after?.attempts ?? OTP_MAX_ATTEMPTS));
    res.status(400).json({
      error: remaining > 0
        ? `كود التأكيد (OTP) غير صحيح — متبقي ${remaining} محاولات`
        : `كود التأكيد (OTP) غير صحيح — تم إيقاف الإدخال ${OTP_LOCK_MINUTES} دقيقة`,
    });
    return;
  }

  const totalToCollect = num(order.totalToCollect);
  let collected = totalToCollect;
  if (deliveryType === "partial") {
    const parsed = parseMoney(collectedAmount, { allowZero: true, max: totalToCollect });
    if (parsed === null) {
      res.status(400).json({ error: "يجب إدخال المبلغ الفعلي المحصل للتسليم الجزئي (لا يزيد عن إجمالي الطلب)" });
      return;
    }
    collected = parsed;
  }
  const newStatus = deliveryType === "partial" ? "partial_delivery" : "delivered";
  const itemCount = Number.isInteger(Number(returnedItemCount)) && Number(returnedItemCount) > 0 && Number(returnedItemCount) <= 1000
    ? Number(returnedItemCount) : null;
  const reasonText = typeof reason === "string" ? reason.trim().slice(0, 300) : "";
  const name = await actorName(authUser.userId, "المندوب");

  // Proof of Delivery (optional): signature data-URL + photo data-URL/URL
  let podSignatureVal: string | null = null;
  let podPhotoUrlVal: string | null = null;
  if (typeof podSignature === "string" && podSignature.startsWith("data:image/") && podSignature.length < 400_000) {
    podSignatureVal = podSignature;
  }
  if (typeof podPhoto === "string" && podPhoto.length > 0 && podPhoto.length < 2_500_000) {
    if (podPhoto.startsWith("data:image/") || podPhoto.startsWith("https://") || podPhoto.startsWith("/uploads/")) {
      podPhotoUrlVal = podPhoto.startsWith("data:image/") ? podPhoto.slice(0, 2_000_000) : podPhoto.slice(0, 2000);
    }
  }
  const hasPod = !!(podSignatureVal || podPhotoUrlVal);

  const shippingFee = num(order.shippingFee);
  const netForMerchant = round2(collected - shippingFee);

  // Everything below is one atomic unit and re-validates the order under a row lock,
  // so a double-tap / replayed request can no longer credit balances twice.
  const updated = await db.transaction(async (tx) => {
    const [locked] = await tx.select().from(ordersTable).where(eq(ordersTable.id, id)).for("update");
    if (!locked || (FINAL_STATUSES as readonly string[]).includes(locked.status) || locked.inventoryStatus !== "in_warehouse") return null;

    const [result] = await tx.update(ordersTable).set({
      status: newStatus,
      collectedAmount: String(collected),
      deliveredAt: new Date(),
      otpAttempts: 0,
      otpLockedUntil: null,
      ...(hasPod ? {
        podPhotoUrl: podPhotoUrlVal,
        podSignature: podSignatureVal,
        podCapturedAt: new Date(),
      } : {}),
    }).where(eq(ordersTable.id, id)).returning();

    if (locked.driverId) {
      await tx.update(usersTable).set({ cashBalance: sql`${usersTable.cashBalance} + ${collected}` }).where(eq(usersTable.id, locked.driverId));
    }
    // Merchant pending balance: net of collected minus full shipping fee
    if (netForMerchant > 0) {
      await tx.update(usersTable).set({ pendingBalance: sql`${usersTable.pendingBalance} + ${netForMerchant}` }).where(eq(usersTable.id, locked.merchantId));
    }

    const description = newStatus === "delivered"
      ? `تم تسليم الشحنة بنجاح وتحصيل المبلغ كاملاً (${collected} ج.م). شكراً لتعاملك مع الغزالي للشحن`
      : `تم التسليم الجزئي: تم تحصيل (${collected} ج.م) وصافي التاجر (${Math.max(0, netForMerchant)} ج.م)${itemCount ? `، مرتجع عدد (${itemCount}) قطعة` : ""}${reasonText ? ` — السبب: ${reasonText}` : ""}`;
    await tx.insert(orderEventsTable).values({
      orderId: id, status: newStatus, description, actorId: authUser.userId, actorName: name,
    });
    return result;
  });

  if (!updated) { res.status(409).json({ error: "تم إغلاق هذا الطلب بالفعل ولا يمكن تسليمه مرة أخرى" }); return; }

  // Fire-and-forget customer notification (SMS/WhatsApp when configured)
  try {
    const { notifyCustomerDelivered } = await import("../lib/notifications");
    void notifyCustomerDelivered({
      phone: updated.customerPhone,
      customerName: updated.customerName,
      orderNumber: updated.orderNumber,
    });
  } catch { /* optional module */ }

  res.json(await formatOrder(updated));
});

router.post("/orders/:id/return", requireAuth, requirePermission("orders.deliver"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  const authUser = getAuth(req);
  if (!id) { res.status(400).json({ error: "رقم الطلب غير صحيح" }); return; }
  const shippingFeeCollected = req.body?.shippingFeeCollected === true || req.body?.shippingFeeCollected === "true";
  const reason = typeof req.body?.reason === "string" ? req.body.reason.trim().slice(0, 300) : "";
  const name = await actorName(authUser.userId, "المندوب");

  const result = await db.transaction(async (tx) => {
    const [order] = await tx.select().from(ordersTable).where(eq(ordersTable.id, id)).for("update");
    if (!order) return { error: 404 as const, message: "Not found" };
    if (!canAccessOrder(authUser, order)) return { error: 403 as const, message: "غير مصرح لك بإرجاع هذا الطلب" };
    if (order.inventoryStatus === "transfer_out") {
      return { error: 400 as const, message: "لا يمكن إرجاع الطلب أثناء وجوده في تحويل بين الفروع" };
    }
    if (order.inventoryStatus !== "in_warehouse") {
      return { error: 400 as const, message: "لا يمكن إرجاع الطلب قبل دخوله مخزن الفرع" };
    }
    // Previously a delivered order could be "returned" (and repeatedly), corrupting merchant balances.
    if ((FINAL_STATUSES as readonly string[]).includes(order.status) || order.status === "returned") {
      return { error: 409 as const, message: "تم إغلاق أو إرجاع هذا الطلب بالفعل" };
    }
    if (authUser.role === "driver" && order.status !== "in_transit") {
      return { error: 400 as const, message: "الطلب ليس في حالة توصيل" };
    }

    const newAttempts = (order.attemptCount || 0) + 1;
    const isFinalReturn = newAttempts >= 3;
    const newStatus = isFinalReturn ? "final_return" : "returned";
    const shippingFee = num(order.shippingFee);

    const [updated] = await tx.update(ordersTable).set({ status: newStatus, attemptCount: newAttempts }).where(eq(ordersTable.id, id)).returning();

    if (shippingFeeCollected && order.driverId) {
      await tx.update(usersTable).set({ cashBalance: sql`${usersTable.cashBalance} + ${shippingFee}` }).where(eq(usersTable.id, order.driverId));
    } else if (!shippingFeeCollected) {
      await tx.update(usersTable).set({ pendingBalance: sql`${usersTable.pendingBalance} - ${shippingFee}` }).where(eq(usersTable.id, order.merchantId));
    }

    await tx.insert(orderEventsTable).values({
      orderId: id, status: newStatus,
      description: isFinalReturn
        ? `مرتجع نهائي — تم استنفاد ${newAttempts} محاولات توصيل. السبب: ${reason || "العميل رفض الاستلام"}`
        : `مرتجع (محاولة ${newAttempts}) — ${reason || "العميل رفض الاستلام"}${shippingFeeCollected ? " — تم تحصيل رسوم الشحن" : ""}`,
      actorId: authUser.userId,
      actorName: name,
    });
    return { order: updated };
  });

  if ("error" in result) { res.status(result.error).json({ error: result.message }); return; }
  res.json(await formatOrder(result.order));
});

router.get("/orders/:id/emergency-otp", requireAuth, requirePermission("orders.emergency_otp"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  const authUser = getAuth(req);
  if (!id) { res.status(400).json({ error: "رقم الطلب غير صحيح" }); return; }
  const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, id));
  if (!order) { res.status(404).json({ error: "Not found" }); return; }
  // A branch manager could previously fetch the OTP of any branch's order.
  if (!canAccessOrder(authUser, order)) { res.status(403).json({ error: "غير مصرح لك بالاطلاع على هذا الطلب" }); return; }

  const name = await actorName(authUser.userId, "مدير");
  await db.transaction(async (tx) => {
    await tx.insert(orderEventsTable).values({
      orderId: id, status: "emergency_otp",
      description: `🚨 تم استخدام كود الطوارئ بواسطة: ${name} — الساعة ${new Date().toLocaleTimeString("ar-EG", { timeZone: "Africa/Cairo" })}`,
      actorId: authUser.userId,
      actorName: name,
      isEmergencyOtp: true,
    });
    // A manager stepping in clears any brute-force lock so the driver can finish the delivery.
    await tx.update(ordersTable).set({ otpAttempts: 0, otpLockedUntil: null }).where(eq(ordersTable.id, id));
  });

  await audit(req, "order.emergency_otp", { type: "order", id }, order.orderNumber);
  res.json({ otp: order.otp, orderId: id, generatedBy: name, generatedAt: new Date().toISOString() });
});

// Public tracking (no login). Rate-limited, and the customer name is shortened.
const trackLimiter = rateLimit({
  windowMs: 60_000,
  max: 30,
  key: (req) => `track:${req.ip}`,
  message: "طلبات تتبع كثيرة، برجاء المحاولة بعد دقيقة",
});

const round3 = (n: number) => Math.round(n * 1000) / 1000;

/**
 * "Uber-style" approach info for the customer. Privacy rules: the courier's position is only
 * revealed when they're within 2 stops of this order AND actively reporting, rounded to ~100 m,
 * and only the first name is shown.
 */
async function buildLiveInfo(order: any) {
  const closed = (FINAL_STATUSES as readonly string[]).includes(order.status) || order.status === "returned";
  const pinLat = order.customerLat !== null && order.customerLat !== undefined ? num(order.customerLat) : null;
  const pinLng = order.customerLng !== null && order.customerLng !== undefined ? num(order.customerLng) : null;
  const hasPin = pinLat !== null && pinLng !== null;
  const base = { canPin: !closed, hasPin, destLat: hasPin ? pinLat : null, destLng: hasPin ? pinLng : null };
  if (order.status !== "in_transit" || !order.driverId) return { ...base, tracking: false };

  const queue = await db.select({
    id: ordersTable.id, governorate: ordersTable.governorate, area: ordersTable.area,
    customerLat: ordersTable.customerLat, customerLng: ordersTable.customerLng,
  }).from(ordersTable)
    .where(and(eq(ordersTable.driverId, order.driverId), eq(ordersTable.status, "in_transit")))
    .orderBy(sql`${ordersTable.stopSequence} asc nulls last`, ordersTable.id);
  const idx = queue.findIndex((q) => q.id === order.id);
  if (idx === -1) return { ...base, tracking: false };

  const [driver] = await db.select({
    fullName: usersTable.fullName, lat: usersTable.currentLat, lng: usersTable.currentLng, at: usersTable.locationUpdatedAt,
  }).from(usersTable).where(eq(usersTable.id, order.driverId));
  const conn = connectionStatus(driver?.at ?? null);
  const driverPt = driver && driver.lat !== null && driver.lng !== null ? { lat: num(driver.lat), lng: num(driver.lng) } : null;

  const zones = await db.select({ governorate: zonesTable.governorate, area: zonesTable.area, lat: zonesTable.lat, lng: zonesTable.lng })
    .from(zonesTable).where(inArray(zonesTable.governorate, uniq(queue.slice(0, idx + 1).map((q) => q.governorate))));
  const zoneMap = new Map(zones.map((z) => [`${z.governorate}|${z.area}`, z]));
  const stops = queue.slice(0, idx + 1).map((q) => {
    if (q.customerLat !== null && q.customerLng !== null) return { lat: num(q.customerLat), lng: num(q.customerLng) };
    const z = zoneMap.get(`${q.governorate}|${q.area}`);
    return z && z.lat !== null && z.lng !== null ? { lat: num(z.lat), lng: num(z.lng) } : governorateCenter(q.governorate);
  });
  const etas = estimateStops(conn.status === "live" || conn.status === "stale" ? driverPt : null, stops, currentTrafficMultiplier());
  const showDriver = conn.status === "live" && idx <= 2 && driverPt !== null;

  return {
    ...base,
    tracking: true,
    stopsAhead: idx,
    etaMinutes: etas[idx]?.etaMinutes ?? null,
    etaPrecise: hasPin,
    driverFirstName: driver?.fullName?.trim().split(/\s+/)[0] ?? null,
    driverLat: showDriver ? round3(driverPt!.lat) : null,
    driverLng: showDriver ? round3(driverPt!.lng) : null,
    connection: conn.status,
    updatedAgoSeconds: conn.ageSeconds,
  };
}

function normalizeOrderNumber(raw: unknown): string | null {
  const orderNumber = String(raw ?? "").trim().toUpperCase().slice(0, 40);
  return /^[A-Z0-9\-]{3,40}$/.test(orderNumber) ? orderNumber : null;
}

router.get("/track/:orderNumber", trackLimiter, async (req, res): Promise<void> => {
  const orderNumber = normalizeOrderNumber(req.params.orderNumber);
  if (!orderNumber) { res.status(404).json({ error: "Order not found" }); return; }
  const [order] = await db.select().from(ordersTable).where(eq(ordersTable.orderNumber, orderNumber));
  if (!order) { res.status(404).json({ error: "Order not found" }); return; }
  const events = await db.select().from(orderEventsTable).where(eq(orderEventsTable.orderId, order.id)).orderBy(orderEventsTable.createdAt);
  res.json({
    orderNumber: order.orderNumber,
    status: order.status,
    customerName: order.customerName.trim().split(/\s+/)[0],
    otp: order.status === "in_transit" ? order.otp : null,
    timeline: events.map((e) => ({
      id: e.id, status: e.status, description: e.description,
      actorName: e.actorName,
      timestamp: iso(e.createdAt),
    })),
    estimatedDelivery: null,
    live: await buildLiveInfo(order),
  });
});

// New: the customer drops an exact pin on their delivery location. Fixes the biggest cause of
// failed / late deliveries (vague addresses) and gives dispatch a precise ETA.
// Verified with the last 4 digits of the phone number the order was placed with.
const pinLimiter = rateLimit({
  windowMs: 15 * 60_000,
  max: 10,
  key: (req) => `pin:${req.ip}:${String(req.params.orderNumber).toUpperCase()}`,
  message: "محاولات كثيرة، برجاء المحاولة بعد قليل",
});
const pinPerOrderLimiter = rateLimit({
  windowMs: 60 * 60_000,
  max: 20,
  key: (req) => `pino:${String(req.params.orderNumber).toUpperCase()}`,
  message: "محاولات كثيرة لهذا الطلب، برجاء المحاولة لاحقاً",
});

router.post("/track/:orderNumber/location", pinLimiter, pinPerOrderLimiter, async (req, res): Promise<void> => {
  const orderNumber = normalizeOrderNumber(req.params.orderNumber);
  const { phoneLast4, lat, lng } = req.body ?? {};
  if (!orderNumber) { res.status(404).json({ error: "Order not found" }); return; }
  // Rough bounding box of Egypt — rejects obviously bogus coordinates.
  if (typeof lat !== "number" || typeof lng !== "number" || !Number.isFinite(lat) || !Number.isFinite(lng) ||
      lat < 21.5 || lat > 32 || lng < 24.5 || lng > 37) {
    res.status(400).json({ error: "الموقع خارج نطاق الخدمة أو غير صحيح" });
    return;
  }
  const last4 = normalizeDigits(String(phoneLast4 ?? "")).replace(/\D/g, "");
  if (last4.length !== 4) { res.status(400).json({ error: "أدخل آخر 4 أرقام من رقم هاتفك" }); return; }

  const [order] = await db.select().from(ordersTable).where(eq(ordersTable.orderNumber, orderNumber));
  const matches = !!order && [order.customerPhone, order.customerPhone2]
    .filter((p): p is string => !!p)
    .some((p) => otpMatches(last4, normalizeDigits(p).replace(/\D/g, "").slice(-4)));
  if (!order || !matches) { res.status(403).json({ error: "بيانات التحقق غير صحيحة" }); return; }
  if (!["pending", "ready", "in_transit"].includes(order.status)) {
    res.status(409).json({ error: "لا يمكن تحديد الموقع لهذا الطلب في حالته الحالية" });
    return;
  }

  await db.transaction(async (tx) => {
    await tx.update(ordersTable).set({
      customerLat: String(Math.round(lat * 1e6) / 1e6),
      customerLng: String(Math.round(lng * 1e6) / 1e6),
      customerLocationAt: new Date(),
    }).where(eq(ordersTable.id, order.id));
    await tx.insert(orderEventsTable).values({
      orderId: order.id,
      status: order.status,
      description: "العميل حدّد موقع التسليم بدقة على الخريطة",
      actorName: "العميل",
    });
  });
  res.json({ success: true });
});

export default router;
