import { Router } from "express";
import { db } from "@workspace/db";
import { usersTable, ordersTable, zonesTable, driverLocationHistoryTable } from "@workspace/db";
import { eq, and, inArray, gte, lt, sql, asc } from "drizzle-orm";
import { requireAuth, requireRole, getAuth, requirePermission } from "../middlewares/auth";
import { rateLimit } from "../lib/rateLimit";
import { getShiftStates } from "../lib/shifts";
import { cairoHour, startOfCairoDay } from "../lib/time";
import { haversineKm as geoHaversine, bearing as geoBearing, currentTrafficMultiplier, estimateStops, governorateCenter, type Pt } from "../lib/geo";
import { parseId } from "../lib/validate";

const router = Router();

// ---------------------------------------------------------------------------
// Tunables
// ---------------------------------------------------------------------------
const PENDING_DELIVERY_STATUSES = ["in_transit"];
const MAX_ACCURACY_M = 200;          // fixes worse than this are ignored (indoor / cell-tower guesses)
const MAX_JUMP_SPEED_KMH = 180;      // faster than this between two fixes = GPS glitch
const MIN_JUMP_DISTANCE_M = 300;     // ...but only when it also moved this far (avoids dt≈0 noise)
const MIN_STORE_INTERVAL_MS = 10_000;
const STATIONARY_DISTANCE_M = 15;
const STATIONARY_STORE_MS = 60_000;  // a parked phone is stored at most once a minute
const MAX_BATCH_POINTS = 100;
const MAX_POINT_AGE_MS = 24 * 3_600_000;
const LIVE_SECONDS = 90;
const STALE_SECONDS = 10 * 60;
const TRAIL_MINUTES = 30;
const STOP_RADIUS_M = 50;
const STOP_MIN_MINUTES = 5;

export type DriverConnection = "live" | "stale" | "offline" | "no_signal";

export function connectionStatus(updatedAt: Date | null, now = Date.now()): { status: DriverConnection; ageSeconds: number | null } {
  if (!updatedAt) return { status: "no_signal", ageSeconds: null };
  const ageSeconds = Math.max(0, Math.round((now - updatedAt.getTime()) / 1000));
  if (ageSeconds <= LIVE_SECONDS) return { status: "live", ageSeconds };
  if (ageSeconds <= STALE_SECONDS) return { status: "stale", ageSeconds };
  return { status: "offline", ageSeconds };
}

// 4-arg convenience wrapper over the shared geo helpers.
const haversineKm = (lat1: number, lng1: number, lat2: number, lng2: number) =>
  geoHaversine({ lat: lat1, lng: lng1 }, { lat: lat2, lng: lng2 });
const getBearing = (from: Pt, to: Pt) => geoBearing(from, to);

const num = (v: unknown): number | null => {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

const toIso = (d: unknown): string | null => (d instanceof Date ? d.toISOString() : (d as string | null) ?? null);

// ---------------------------------------------------------------------------
// Driver → server: location reporting (single point or an offline batch)
// ---------------------------------------------------------------------------
// Batches count as one request, so this only stops a runaway/abusive client.
const locationLimiter = rateLimit({
  windowMs: 60_000,
  max: 60,
  key: (req) => `loc:${req.user?.userId ?? req.ip}`,
});

/** Drop location points older than `days` days (called daily from index.ts). */
export async function pruneLocationHistory(days = 30): Promise<void> {
  const cutoff = new Date(Date.now() - days * 86_400_000);
  await db.delete(driverLocationHistoryTable).where(lt(driverLocationHistoryTable.recordedAt, cutoff));
}

interface ParsedPoint {
  lat: number;
  lng: number;
  accuracy: number | null;
  speed: number | null;
  heading: number | null;
  at: Date;
}

function parsePoint(raw: any, now: number): ParsedPoint | null {
  const lat = typeof raw?.lat === "number" ? raw.lat : NaN;
  const lng = typeof raw?.lng === "number" ? raw.lng : NaN;
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) return null;
  // (0,0) is what many devices report when they have no fix at all.
  if (lat === 0 && lng === 0) return null;
  let at = new Date(now);
  if (raw.recordedAt !== undefined && raw.recordedAt !== null) {
    const parsed = new Date(raw.recordedAt);
    if (Number.isNaN(parsed.getTime())) return null;
    if (parsed.getTime() > now + 120_000 || parsed.getTime() < now - MAX_POINT_AGE_MS) return null;
    at = parsed;
  }
  const accuracy = num(raw.accuracy);
  const speed = num(raw.speed);
  const heading = num(raw.heading);
  return {
    lat, lng, at,
    accuracy: accuracy !== null && accuracy >= 0 && accuracy < 100_000 ? accuracy : null,
    speed: speed !== null && speed >= 0 && speed <= 100 ? speed : null,
    heading: heading !== null && heading >= 0 && heading <= 360 ? heading : null,
  };
}

router.post("/tracking/location", requireAuth, requireRole("driver"), locationLimiter, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const body = req.body ?? {};
  const rawPoints: any[] = Array.isArray(body.points) ? body.points : [body];
  if (rawPoints.length === 0 || rawPoints.length > MAX_BATCH_POINTS) {
    res.status(400).json({ error: "عدد نقاط الموقع غير صحيح" });
    return;
  }

  const now = Date.now();
  const parsed = rawPoints.map((p) => parsePoint(p, now));
  const points = parsed.filter((p): p is ParsedPoint => p !== null).sort((a, b) => a.at.getTime() - b.at.getTime());
  if (points.length === 0) {
    res.status(400).json({ error: "إحداثيات غير صحيحة" });
    return;
  }

  const outcome = await db.transaction(async (tx) => {
    const [me] = await tx.select({
      lat: usersTable.currentLat, lng: usersTable.currentLng, at: usersTable.locationUpdatedAt,
    }).from(usersTable).where(eq(usersTable.id, authUser.userId)).for("update");

    let prev: { lat: number; lng: number; at: number } | null =
      me && me.lat !== null && me.lng !== null && me.at
        ? { lat: Number(me.lat), lng: Number(me.lng), at: me.at.getTime() }
        : null;
    const currentAt = prev?.at ?? 0;

    const toStore: (typeof driverLocationHistoryTable.$inferInsert)[] = [];
    let latestAccepted: ParsedPoint | null = null;
    let accepted = 0;
    let rejected = 0;

    for (const p of points) {
      if (p.accuracy !== null && p.accuracy > MAX_ACCURACY_M) { rejected++; continue; }

      // Points older than what we already hold are only useful as breadcrumbs for the trail.
      const isBackfill = p.at.getTime() <= currentAt;
      let distM = Infinity;
      let dtMs = Infinity;
      if (!isBackfill && prev) {
        distM = haversineKm(prev.lat, prev.lng, p.lat, p.lng) * 1000;
        dtMs = p.at.getTime() - prev.at;
        const kmh = dtMs > 0 ? (distM / 1000) / (dtMs / 3_600_000) : 0;
        if (distM > MIN_JUMP_DISTANCE_M && kmh > MAX_JUMP_SPEED_KMH) { rejected++; continue; } // GPS glitch
      }
      accepted++;

      const store = isBackfill || !prev || !(dtMs < MIN_STORE_INTERVAL_MS || (distM < STATIONARY_DISTANCE_M && dtMs < STATIONARY_STORE_MS));
      if (store) {
        toStore.push({
          driverId: authUser.userId,
          lat: String(p.lat), lng: String(p.lng),
          accuracy: p.accuracy === null ? null : String(p.accuracy),
          speed: p.speed === null ? null : String(p.speed),
          heading: p.heading === null ? null : String(p.heading),
          recordedAt: p.at,
        });
      }
      if (!isBackfill) {
        prev = { lat: p.lat, lng: p.lng, at: p.at.getTime() };
        latestAccepted = p;
      }
    }

    if (toStore.length) await tx.insert(driverLocationHistoryTable).values(toStore);
    // The "current position" (heartbeat) is updated even when the history row was skipped as a duplicate.
    if (latestAccepted) {
      await tx.update(usersTable).set({
        currentLat: String(latestAccepted.lat),
        currentLng: String(latestAccepted.lng),
        locationUpdatedAt: latestAccepted.at,
        locationAccuracy: latestAccepted.accuracy === null ? null : String(latestAccepted.accuracy),
        locationSpeed: latestAccepted.speed === null ? null : String(latestAccepted.speed),
        locationHeading: latestAccepted.heading === null ? null : String(latestAccepted.heading),
      }).where(eq(usersTable.id, authUser.userId));
    }
    return { accepted, rejected: rejected + (parsed.length - points.length) };
  });

  res.json({ success: true, ...outcome, serverTime: new Date().toISOString() });
});

// ---------------------------------------------------------------------------
// Admin: live board
// ---------------------------------------------------------------------------
const TRACKING_ROLES = ["super_admin", "branch_manager", "operations"];

router.get("/tracking/drivers", requireAuth, requirePermission("tracking.view"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const driverConds: any[] = [eq(usersTable.role, "driver"), eq(usersTable.isActive, true)];
  // Branch staff only track their own branch's drivers.
  if (authUser.role !== "super_admin") {
    driverConds.push(authUser.branchId ? eq(usersTable.branchId, authUser.branchId) : sql`false`);
  }
  const drivers = await db.select().from(usersTable).where(and(...driverConds)).orderBy(usersTable.fullName);
  const driverIds = drivers.map((d) => d.id);
  const now = new Date();
  const shiftStates = await getShiftStates(driverIds);

  const [allZones, activeOrders, trailRows] = await Promise.all([
    db.select().from(zonesTable),
    driverIds.length
      ? db.select().from(ordersTable).where(and(
          inArray(ordersTable.driverId, driverIds),
          inArray(ordersTable.status, PENDING_DELIVERY_STATUSES as any),
        ))
      : Promise.resolve([] as (typeof ordersTable.$inferSelect)[]),
    // Short trail only: the full-day route is fetched on demand for the selected driver.
    driverIds.length
      ? db.select({
          driverId: driverLocationHistoryTable.driverId,
          lat: driverLocationHistoryTable.lat, lng: driverLocationHistoryTable.lng,
          recordedAt: driverLocationHistoryTable.recordedAt,
        }).from(driverLocationHistoryTable).where(and(
          inArray(driverLocationHistoryTable.driverId, driverIds),
          gte(driverLocationHistoryTable.recordedAt, new Date(now.getTime() - TRAIL_MINUTES * 60_000)),
        )).orderBy(asc(driverLocationHistoryTable.recordedAt))
      : Promise.resolve([]),
  ]);

  const zoneMap = new Map(allZones.map((z) => [`${z.governorate}|${z.area}`, z]));
  const hour = cairoHour(now);
  const trafficMultiplier = currentTrafficMultiplier(now);

  const ordersByDriver = new Map<number, typeof activeOrders>();
  for (const o of activeOrders) {
    const list = ordersByDriver.get(o.driverId as number) ?? [];
    list.push(o);
    ordersByDriver.set(o.driverId as number, list);
  }
  const trailByDriver = new Map<number, { lat: number; lng: number; recordedAt: string | null }[]>();
  for (const r of trailRows) {
    const list = trailByDriver.get(r.driverId) ?? [];
    list.push({ lat: Number(r.lat), lng: Number(r.lng), recordedAt: toIso(r.recordedAt) });
    trailByDriver.set(r.driverId, list);
  }

  const result = drivers.map((driver) => {
    const lat = num(driver.currentLat);
    const lng = num(driver.currentLng);
    const { status, ageSeconds } = connectionStatus(driver.locationUpdatedAt, now.getTime());
    const speedMs = num(driver.locationSpeed);

    // Optimised route order first (set by "ترتيب أمثل"), then creation order.
    const queue = (ordersByDriver.get(driver.id) ?? []).sort(
      (a, b) => (a.stopSequence ?? 1e9) - (b.stopSequence ?? 1e9) || a.id - b.id,
    );
    const path = trailByDriver.get(driver.id) ?? [];

    // Heading: prefer the device compass/course; otherwise derive it from the last two distinct points.
    let heading = num(driver.locationHeading);
    if (heading === null && path.length >= 2) {
      const last = path[path.length - 1];
      const earlier = [...path].reverse().find((p) => haversineKm(p.lat, p.lng, last.lat, last.lng) * 1000 > 10);
      if (earlier) heading = getBearing(earlier, last);
    }

    // Destination = the customer's own pin when they shared one, otherwise the zone centre.
    const stopPoints = queue.map((order) => {
      const pinLat = num(order.customerLat);
      const pinLng = num(order.customerLng);
      if (pinLat !== null && pinLng !== null) return { pt: { lat: pinLat, lng: pinLng }, precise: true };
      const zone = zoneMap.get(`${order.governorate}|${order.area}`);
      const zLat = num(zone?.lat);
      const zLng = num(zone?.lng);
      return { pt: zLat !== null && zLng !== null ? { lat: zLat, lng: zLng } : governorateCenter(order.governorate), precise: false };
    });
    const etas = estimateStops(
      lat !== null && lng !== null ? { lat, lng } : null,
      stopPoints.map((sp) => sp.pt),
      trafficMultiplier,
    );
    const ordersWithEta = queue.map((order, idx) => ({
      orderId: order.id,
      orderNumber: order.orderNumber,
      customerName: order.customerName,
      governorate: order.governorate,
      area: order.area,
      status: order.status,
      lat: stopPoints[idx].pt?.lat ?? null,
      lng: stopPoints[idx].pt?.lng ?? null,
      precise: stopPoints[idx].precise,
      queuePosition: idx + 1,
      etaMinutes: etas[idx].etaMinutes,
      distanceKm: etas[idx].distanceKm,
    }));

    return {
      driverId: driver.id,
      driverName: driver.fullName,
      phone: driver.phone,
      lat,
      lng,
      locationUpdatedAt: toIso(driver.locationUpdatedAt),
      status,
      shiftStatus: shiftStates.get(driver.id)?.status ?? "off",
      ageSeconds,
      accuracy: num(driver.locationAccuracy),
      speedKmh: speedMs === null ? null : Math.round(speedMs * 3.6),
      heading,
      path: path.slice(-120),
      activeOrderCount: queue.length,
      orders: ordersWithEta,
    };
  });

  const summary = {
    total: result.length,
    live: result.filter((d) => d.status === "live").length,
    stale: result.filter((d) => d.status === "stale").length,
    offline: result.filter((d) => d.status === "offline").length,
    noSignal: result.filter((d) => d.status === "no_signal").length,
    activeOrders: result.reduce((a, d) => a + d.activeOrderCount, 0),
    // Drivers carrying orders but not reporting a fresh position — the ones dispatch must chase.
    onShift: result.filter((d) => d.shiftStatus !== "off").length,
    needsAttention: result.filter((d) => d.activeOrderCount > 0 && d.status !== "live").length,
  };

  res.json({ drivers: result, trafficMultiplier, hour, summary, etaMethod: "heuristic", generatedAt: now.toISOString() });
});

// ---------------------------------------------------------------------------
// Admin: one driver's route for a day, with distance / stops statistics
// ---------------------------------------------------------------------------
function dayBounds(dateParam: unknown): { from: Date; to: Date } | null {
  if (dateParam === undefined) {
    const from = startOfCairoDay();
    return { from, to: startOfCairoDay(new Date(from.getTime() + 36 * 3_600_000)) };
  }
  if (typeof dateParam !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(dateParam)) return null;
  const from = startOfCairoDay(new Date(`${dateParam}T12:00:00+02:00`));
  if (Number.isNaN(from.getTime())) return null;
  return { from, to: startOfCairoDay(new Date(from.getTime() + 36 * 3_600_000)) };
}

router.get("/tracking/drivers/:id/history", requireAuth, requirePermission("tracking.view"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم المندوب غير صحيح" }); return; }
  const bounds = dayBounds(req.query.date);
  if (!bounds) { res.status(400).json({ error: "صيغة التاريخ غير صحيحة (YYYY-MM-DD)" }); return; }

  const [driver] = await db.select({ id: usersTable.id, role: usersTable.role, fullName: usersTable.fullName, branchId: usersTable.branchId })
    .from(usersTable).where(eq(usersTable.id, id));
  if (!driver || driver.role !== "driver") { res.status(404).json({ error: "المندوب غير موجود" }); return; }
  if (authUser.role !== "super_admin" && (!authUser.branchId || driver.branchId !== authUser.branchId)) {
    res.status(403).json({ error: "غير مصرح بتتبع مندوب من فرع آخر" });
    return;
  }

  const rows = await db.select().from(driverLocationHistoryTable).where(and(
    eq(driverLocationHistoryTable.driverId, id),
    gte(driverLocationHistoryTable.recordedAt, bounds.from),
    lt(driverLocationHistoryTable.recordedAt, bounds.to),
  )).orderBy(asc(driverLocationHistoryTable.recordedAt), asc(driverLocationHistoryTable.id)).limit(20_000);

  const pts = rows.map((r) => ({ lat: Number(r.lat), lng: Number(r.lng), t: r.recordedAt.getTime() }));

  let distanceKm = 0;
  let movingMs = 0;
  let maxSpeedKmh = 0;
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1], b = pts[i];
    const dtMs = b.t - a.t;
    if (dtMs <= 0) continue;
    const km = haversineKm(a.lat, a.lng, b.lat, b.lng);
    const kmh = km / (dtMs / 3_600_000);
    if (km * 1000 > MIN_JUMP_DISTANCE_M && kmh > MAX_JUMP_SPEED_KMH) continue; // glitch segment
    if (km * 1000 < 8) continue; // standing still / GPS drift
    distanceKm += km;
    if (dtMs <= 5 * 60_000) movingMs += dtMs;
    if (kmh <= MAX_JUMP_SPEED_KMH) maxSpeedKmh = Math.max(maxSpeedKmh, kmh);
  }

  // Stops: the driver stayed within STOP_RADIUS_M of the same spot for at least STOP_MIN_MINUTES.
  const stops: { lat: number; lng: number; from: string; to: string; minutes: number }[] = [];
  let i = 0;
  while (i < pts.length && stops.length < 30) {
    let j = i;
    // A data gap > 15 min (phone off / no signal) must not be counted as the driver standing still.
    while (j + 1 < pts.length && pts[j + 1].t - pts[j].t <= 15 * 60_000 &&
      haversineKm(pts[i].lat, pts[i].lng, pts[j + 1].lat, pts[j + 1].lng) * 1000 <= STOP_RADIUS_M) j++;
    const minutes = (pts[j].t - pts[i].t) / 60_000;
    if (j > i && minutes >= STOP_MIN_MINUTES) {
      const cluster = pts.slice(i, j + 1);
      stops.push({
        lat: cluster.reduce((a, p) => a + p.lat, 0) / cluster.length,
        lng: cluster.reduce((a, p) => a + p.lng, 0) / cluster.length,
        from: new Date(pts[i].t).toISOString(),
        to: new Date(pts[j].t).toISOString(),
        minutes: Math.round(minutes),
      });
      i = j + 1;
    } else {
      i++;
    }
  }

  const MAX_PATH_POINTS = 600;
  const stride = Math.max(1, Math.ceil(pts.length / MAX_PATH_POINTS));
  const path = pts
    .filter((_, idx) => idx % stride === 0 || idx === pts.length - 1)
    .map((p) => ({ lat: p.lat, lng: p.lng, recordedAt: new Date(p.t).toISOString() }));

  res.json({
    driverId: id,
    driverName: driver.fullName,
    from: bounds.from.toISOString(),
    to: bounds.to.toISOString(),
    pointCount: pts.length,
    path,
    stats: {
      distanceKm: Math.round(distanceKm * 10) / 10,
      movingMinutes: Math.round(movingMs / 60_000),
      maxSpeedKmh: Math.round(maxSpeedKmh),
      stops,
    },
  });
});

export default router;
