import { Router } from "express";
import { db, ordersTable, usersTable } from "@workspace/db";
import { and, eq, gte, sql, inArray, desc } from "drizzle-orm";
import { requireAuth, requireRole, getAuth, requirePermission, can } from "../middlewares/auth";
import { getRoleOrderConditions } from "../middlewares/orderScope";
import { startOfCairoDayAgo } from "../lib/time";
import { num } from "../lib/format";

const router = Router();

const SUCCESS = sql`('delivered', 'partial_delivery')`;
const FAILED = sql`('returned', 'final_return')`;

const pct = (part: number, whole: number) => (whole > 0 ? Math.round((part / whole) * 1000) / 10 : null);

// New: business intelligence — where deliveries succeed or fail, who performs best, when.
// Everything is scoped by the caller's role (a merchant only ever sees their own orders).
router.get("/analytics/overview", requireAuth, requirePermission("analytics.view"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const rawDays = Number(req.query.days);
  const days = [7, 30, 90].includes(rawDays) ? rawDays : 30;
  const since = startOfCairoDayAgo(days - 1);
  const isMerchant = authUser.role === "merchant";

  const scope = and(gte(ordersTable.createdAt, since), ...getRoleOrderConditions(authUser));
  const closedIn = sql`${ordersTable.status} in ('delivered', 'partial_delivery', 'returned', 'final_return')`;

  const [kpi] = await db.select({
    total: sql<number>`count(*)`,
    delivered: sql<number>`count(*) filter (where ${ordersTable.status} in ${SUCCESS})`,
    returned: sql<number>`count(*) filter (where ${ordersTable.status} in ${FAILED})`,
    open: sql<number>`count(*) filter (where ${ordersTable.status} in ('pending', 'ready', 'in_transit'))`,
    cod: sql<string>`coalesce(sum(${ordersTable.collectedAmount}) filter (where ${ordersTable.status} in ${SUCCESS}), 0)`,
    avgHours: sql<string | null>`avg(extract(epoch from (${ordersTable.deliveredAt} - ${ordersTable.createdAt})) / 3600) filter (where ${ordersTable.status} in ${SUCCESS} and ${ordersTable.deliveredAt} is not null)`,
    firstAttempt: sql<number>`count(*) filter (where ${ordersTable.status} in ${SUCCESS} and ${ordersTable.attemptCount} = 0)`,
  }).from(ordersTable).where(scope);

  const areaRows = await db.select({
    governorate: ordersTable.governorate,
    area: ordersTable.area,
    total: sql<number>`count(*)`,
    delivered: sql<number>`count(*) filter (where ${ordersTable.status} in ${SUCCESS})`,
    returned: sql<number>`count(*) filter (where ${ordersTable.status} in ${FAILED})`,
  }).from(ordersTable).where(scope)
    .groupBy(ordersTable.governorate, ordersTable.area)
    .orderBy(desc(sql`count(*)`)).limit(30);
  const areas = areaRows.map((r) => {
    const delivered = Number(r.delivered), returned = Number(r.returned);
    return { governorate: r.governorate, area: r.area, total: Number(r.total), delivered, returned, returnRate: pct(returned, delivered + returned) };
  });

  const hourRows = await db.select({
    hour: sql<number>`extract(hour from (${ordersTable.deliveredAt} at time zone 'UTC') at time zone 'Africa/Cairo')::int`,
    cnt: sql<number>`count(*)`,
  }).from(ordersTable)
    .where(and(scope, inArray(ordersTable.status, ["delivered", "partial_delivery"]), sql`${ordersTable.deliveredAt} is not null`))
    .groupBy(sql`1`);
  const hourMap = new Map(hourRows.map((r) => [Number(r.hour), Number(r.cnt)]));
  const hourly = Array.from({ length: 24 }, (_, h) => ({ hour: h, deliveries: hourMap.get(h) ?? 0 }));

  let drivers: any[] = [];
  let merchants: any[] = [];
  if (can(authUser, "analytics.team")) {
    const driverRows = await db.select({
      driverId: ordersTable.driverId,
      closed: sql<number>`count(*) filter (where ${closedIn})`,
      delivered: sql<number>`count(*) filter (where ${ordersTable.status} in ${SUCCESS})`,
      returned: sql<number>`count(*) filter (where ${ordersTable.status} in ${FAILED})`,
      avgHours: sql<string | null>`avg(extract(epoch from (${ordersTable.deliveredAt} - ${ordersTable.createdAt})) / 3600) filter (where ${ordersTable.status} in ${SUCCESS} and ${ordersTable.deliveredAt} is not null)`,
      cod: sql<string>`coalesce(sum(${ordersTable.collectedAmount}) filter (where ${ordersTable.status} in ${SUCCESS}), 0)`,
    }).from(ordersTable).where(and(scope, sql`${ordersTable.driverId} is not null`))
      .groupBy(ordersTable.driverId).orderBy(desc(sql`count(*) filter (where ${ordersTable.status} in ${SUCCESS})`)).limit(15);
    const driverIds = driverRows.map((r) => r.driverId as number);
    const names = driverIds.length ? await db.select({ id: usersTable.id, fullName: usersTable.fullName }).from(usersTable).where(inArray(usersTable.id, driverIds)) : [];
    const nameMap = new Map(names.map((n) => [n.id, n.fullName]));
    drivers = driverRows.map((r) => {
      const delivered = Number(r.delivered), returned = Number(r.returned);
      return {
        driverId: r.driverId, name: nameMap.get(r.driverId as number) ?? "—",
        closed: Number(r.closed), delivered, returned,
        successRate: pct(delivered, delivered + returned),
        avgHours: r.avgHours === null ? null : Math.round(num(r.avgHours) * 10) / 10,
        cod: num(r.cod),
      };
    });

    const merchantRows = await db.select({
      merchantId: ordersTable.merchantId,
      total: sql<number>`count(*)`,
      delivered: sql<number>`count(*) filter (where ${ordersTable.status} in ${SUCCESS})`,
      returned: sql<number>`count(*) filter (where ${ordersTable.status} in ${FAILED})`,
    }).from(ordersTable).where(scope).groupBy(ordersTable.merchantId).orderBy(desc(sql`count(*)`)).limit(15);
    const merchantIds = merchantRows.map((r) => r.merchantId);
    const mNames = merchantIds.length ? await db.select({ id: usersTable.id, fullName: usersTable.fullName }).from(usersTable).where(inArray(usersTable.id, merchantIds)) : [];
    const mNameMap = new Map(mNames.map((n) => [n.id, n.fullName]));
    merchants = merchantRows.map((r) => {
      const delivered = Number(r.delivered), returned = Number(r.returned);
      return { merchantId: r.merchantId, name: mNameMap.get(r.merchantId) ?? "—", total: Number(r.total), delivered, returned, returnRate: pct(returned, delivered + returned) };
    });
  }

  const delivered = Number(kpi?.delivered ?? 0), returned = Number(kpi?.returned ?? 0);
  res.json({
    days,
    kpis: {
      totalOrders: Number(kpi?.total ?? 0),
      delivered, returned,
      openOrders: Number(kpi?.open ?? 0),
      successRate: pct(delivered, delivered + returned),
      firstAttemptRate: pct(Number(kpi?.firstAttempt ?? 0), delivered),
      avgDeliveryHours: kpi?.avgHours == null ? null : Math.round(num(kpi.avgHours) * 10) / 10,
      codCollected: num(kpi?.cod),
    },
    areas,
    hourly,
    drivers,
    merchants,
  });
});

export default router;
