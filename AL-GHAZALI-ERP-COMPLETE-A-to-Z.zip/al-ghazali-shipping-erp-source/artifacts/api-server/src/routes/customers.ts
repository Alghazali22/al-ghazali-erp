import { Router } from "express";
import { db, ordersTable } from "@workspace/db";
import { and, eq, sql, desc } from "drizzle-orm";
import { requireAuth, requireRole, getAuth, requirePermission } from "../middlewares/auth";
import { getRoleOrderConditions } from "../middlewares/orderScope";
import { rateLimit } from "../lib/rateLimit";
import { parsePhone, phoneKey, parseId } from "../lib/validate";

const router = Router();

const lookupLimiter = rateLimit({
  windowMs: 60_000,
  max: 60,
  key: (req) => `rep:${req.user?.userId ?? req.ip}`,
  message: "عدد كبير من الاستعلامات، حاول بعد قليل",
});

export type RiskLevel = "new" | "good" | "warning" | "high";

/** Pure rule: returns the risk level from a customer's order outcomes. Exported for tests. */
export function assessRisk(delivered: number, returned: number): { level: RiskLevel; closed: number; returnRate: number } {
  const closed = delivered + returned;
  const returnRate = closed > 0 ? returned / closed : 0;
  if (closed < 2) return { level: "new", closed, returnRate };
  if (closed >= 3 && returnRate >= 0.5) return { level: "high", closed, returnRate };
  if (returnRate >= 0.3) return { level: "warning", closed, returnRate };
  return { level: "good", closed, returnRate };
}

const MESSAGES: Record<RiskLevel, string> = {
  new: "عميل جديد أو بلا تاريخ كافٍ في الشبكة",
  good: "عميل موثوق — تاريخ استلام جيد",
  warning: "انتبه: نسبة مرتجعات ملحوظة لهذا الرقم",
  high: "خطر مرتفع: أغلب طلبات هذا الرقم انتهت بمرتجع. يُنصح بالتأكيد هاتفياً قبل الشحن",
};

// New: shared "customer reputation" across every merchant on the platform. Only anonymous
// aggregate counts are returned — never names, addresses or which merchant an order belonged to.
router.get("/customers/reputation", requireAuth, requirePermission("customers.reputation"), lookupLimiter, async (req, res): Promise<void> => {
  const phone = parsePhone(req.query.phone);
  if (!phone) { res.status(400).json({ error: "رقم الهاتف غير صحيح" }); return; }
  const key = phoneKey(phone);

  const [row] = await db.select({
    total: sql<number>`count(*)`,
    delivered: sql<number>`count(*) filter (where ${ordersTable.status} in ('delivered', 'partial_delivery'))`,
    returned: sql<number>`count(*) filter (where ${ordersTable.status} in ('returned', 'final_return'))`,
    open: sql<number>`count(*) filter (where ${ordersTable.status} in ('pending', 'ready', 'in_transit'))`,
  }).from(ordersTable).where(and(eq(ordersTable.customerPhoneKey, key)));

  const delivered = Number(row?.delivered ?? 0);
  const returned = Number(row?.returned ?? 0);
  const risk = assessRisk(delivered, returned);
  res.json({
    level: risk.level,
    message: MESSAGES[risk.level],
    totalOrders: Number(row?.total ?? 0),
    delivered,
    returned,
    openOrders: Number(row?.open ?? 0),
    successRate: risk.closed > 0 ? Math.round((delivered / risk.closed) * 100) : null,
  });
});

// New: "address book". When a merchant types the phone of a returning customer, the form can
// pre-fill name / address / area from that merchant's OWN previous order. Never crosses merchants.
router.get("/customers/lookup", requireAuth, requirePermission("customers.lookup"), lookupLimiter, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const phone = parsePhone(req.query.phone);
  if (!phone) { res.status(400).json({ error: "رقم الهاتف غير صحيح" }); return; }
  const merchantId = authUser.role === "merchant" ? authUser.userId : parseId(req.query.merchantId);
  if (!merchantId) { res.status(400).json({ error: "رقم التاجر مطلوب" }); return; }

  const where = and(
    eq(ordersTable.customerPhoneKey, phoneKey(phone)),
    eq(ordersTable.merchantId, merchantId),
    ...getRoleOrderConditions(authUser),
  );
  const [[last], [total]] = await Promise.all([
    db.select({
      customerName: ordersTable.customerName, customerPhone2: ordersTable.customerPhone2,
      customerAddress: ordersTable.customerAddress, governorate: ordersTable.governorate, area: ordersTable.area,
    }).from(ordersTable).where(where).orderBy(desc(ordersTable.createdAt), desc(ordersTable.id)).limit(1),
    db.select({ cnt: sql<number>`count(*)` }).from(ordersTable).where(where),
  ]);
  if (!last) { res.json({ found: false }); return; }
  res.json({ found: true, ...last, orders: Number(total?.cnt ?? 0) });
});

export default router;
