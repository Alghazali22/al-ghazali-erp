import { Router } from "express";
import { db } from "@workspace/db";
import { zonesTable, merchantPricingTable, usersTable } from "@workspace/db";
import { eq, and, inArray } from "drizzle-orm";
import { requireAuth, requireRole, getAuth, requirePermission } from "../middlewares/auth";
import { num } from "../lib/format";
import { parseId, parseMoney, asTrimmedString } from "../lib/validate";

const router = Router();

const MAX_OVERRIDES = 1000;

function formatZone(z: any) {
  return {
    ...z,
    basePrice: num(z.basePrice),
    returnPrice: num(z.returnPrice),
    lat: z.lat !== null && z.lat !== undefined ? num(z.lat) : null,
    lng: z.lng !== null && z.lng !== undefined ? num(z.lng) : null,
  };
}

/** Optional coordinate: undefined = not provided, null = clear, number = value. Returns "invalid" on bad input. */
function parseCoord(value: unknown, min: number, max: number): number | null | undefined | "invalid" {
  if (value === undefined) return undefined;
  if (value === null || value === "") return null;
  const n = Number(value);
  return Number.isFinite(n) && n >= min && n <= max ? n : "invalid";
}

router.get("/zones", requireAuth, async (_req, res): Promise<void> => {
  const zones = await db.select().from(zonesTable).orderBy(zonesTable.governorate, zonesTable.area);
  res.json(zones.map(formatZone));
});

router.post("/zones", requireAuth, requirePermission("zones.manage"), async (req, res): Promise<void> => {
  const body = req.body ?? {};
  const governorate = asTrimmedString(body.governorate, 100);
  const area = asTrimmedString(body.area, 100);
  const basePrice = parseMoney(body.basePrice, { allowZero: true, max: 100_000 });
  const returnPrice = body.returnPrice === undefined || body.returnPrice === null ? 10 : parseMoney(body.returnPrice, { allowZero: true, max: 100_000 });
  const lat = parseCoord(body.lat, -90, 90);
  const lng = parseCoord(body.lng, -180, 180);

  if (!governorate || !area) { res.status(400).json({ error: "المحافظة والمنطقة مطلوبتان" }); return; }
  if (basePrice === null) { res.status(400).json({ error: "سعر الشحن غير صحيح" }); return; }
  if (returnPrice === null) { res.status(400).json({ error: "سعر المرتجع غير صحيح" }); return; }
  if (lat === "invalid" || lng === "invalid") { res.status(400).json({ error: "الإحداثيات غير صحيحة" }); return; }

  // Order creation picks the first matching zone, so duplicates would make pricing ambiguous.
  const [dup] = await db.select({ id: zonesTable.id }).from(zonesTable)
    .where(and(eq(zonesTable.governorate, governorate), eq(zonesTable.area, area)));
  if (dup) { res.status(409).json({ error: "هذه المنطقة موجودة بالفعل" }); return; }

  const [zone] = await db.insert(zonesTable).values({
    governorate, area,
    basePrice: String(basePrice),
    returnPrice: String(returnPrice),
    lat: lat === undefined || lat === null ? null : String(lat),
    lng: lng === undefined || lng === null ? null : String(lng),
  }).returning();
  res.status(201).json(formatZone(zone));
});

router.patch("/zones/:id", requireAuth, requirePermission("zones.manage"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم المنطقة غير صحيح" }); return; }
  const body = req.body ?? {};
  const updates: any = {};

  if (body.basePrice !== undefined) {
    const v = parseMoney(body.basePrice, { allowZero: true, max: 100_000 });
    if (v === null) { res.status(400).json({ error: "سعر الشحن غير صحيح" }); return; }
    updates.basePrice = String(v);
  }
  if (body.returnPrice !== undefined) {
    const v = parseMoney(body.returnPrice, { allowZero: true, max: 100_000 });
    if (v === null) { res.status(400).json({ error: "سعر المرتجع غير صحيح" }); return; }
    updates.returnPrice = String(v);
  }
  if (body.isActive !== undefined) {
    if (typeof body.isActive !== "boolean") { res.status(400).json({ error: "قيمة التفعيل غير صحيحة" }); return; }
    updates.isActive = body.isActive;
  }
  const lat = parseCoord(body.lat, -90, 90);
  const lng = parseCoord(body.lng, -180, 180);
  if (lat === "invalid" || lng === "invalid") { res.status(400).json({ error: "الإحداثيات غير صحيحة" }); return; }
  if (lat !== undefined) updates.lat = lat === null ? null : String(lat);
  if (lng !== undefined) updates.lng = lng === null ? null : String(lng);

  if (Object.keys(updates).length === 0) { res.status(400).json({ error: "لا توجد بيانات للتحديث" }); return; }
  const [zone] = await db.update(zonesTable).set(updates).where(eq(zonesTable.id, id)).returning();
  if (!zone) { res.status(404).json({ error: "Not found" }); return; }
  res.json(formatZone(zone));
});

async function loadPricing(merchantId: number) {
  const rows = await db.select({
    id: merchantPricingTable.id,
    merchantId: merchantPricingTable.merchantId,
    zoneId: merchantPricingTable.zoneId,
    customPrice: merchantPricingTable.customPrice,
    governorate: zonesTable.governorate,
    area: zonesTable.area,
  }).from(merchantPricingTable)
    .leftJoin(zonesTable, eq(merchantPricingTable.zoneId, zonesTable.id))
    .where(eq(merchantPricingTable.merchantId, merchantId));
  return rows.map((o) => ({ ...o, customPrice: num(o.customPrice) }));
}

router.get("/users/:id/pricing", requireAuth, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const merchantId = parseId(req.params.id);
  if (!merchantId) { res.status(400).json({ error: "رقم التاجر غير صحيح" }); return; }
  const [merchant] = await db.select({ id: usersTable.id, role: usersTable.role, branchId: usersTable.branchId })
    .from(usersTable).where(eq(usersTable.id, merchantId));
  if (!merchant || merchant.role !== "merchant") { res.status(404).json({ error: "Not found" }); return; }

  // Previously any logged-in user could read any merchant's negotiated prices.
  const allowed =
    authUser.userId === merchantId ||
    authUser.role === "super_admin" ||
    authUser.role === "accountant" ||
    ((authUser.role === "branch_manager" || authUser.role === "operations") && !!authUser.branchId && merchant.branchId === authUser.branchId);
  if (!allowed) { res.status(403).json({ error: "غير مصرح" }); return; }
  res.json(await loadPricing(merchantId));
});

router.put("/users/:id/pricing", requireAuth, requirePermission("pricing.manage"), async (req, res): Promise<void> => {
  const merchantId = parseId(req.params.id);
  if (!merchantId) { res.status(400).json({ error: "رقم التاجر غير صحيح" }); return; }
  const [merchant] = await db.select({ role: usersTable.role }).from(usersTable).where(eq(usersTable.id, merchantId));
  if (!merchant || merchant.role !== "merchant") { res.status(404).json({ error: "التاجر غير موجود" }); return; }

  const raw = req.body?.overrides ?? [];
  if (!Array.isArray(raw) || raw.length > MAX_OVERRIDES) { res.status(400).json({ error: "قائمة الأسعار غير صحيحة" }); return; }
  const overrides: { zoneId: number; customPrice: string }[] = [];
  const seen = new Set<number>();
  for (const o of raw) {
    const zoneId = parseId(o?.zoneId);
    const price = parseMoney(o?.customPrice, { allowZero: true, max: 100_000 });
    if (!zoneId || price === null) { res.status(400).json({ error: "بيانات التسعير غير صحيحة" }); return; }
    if (seen.has(zoneId)) { res.status(400).json({ error: "منطقة مكررة في قائمة الأسعار" }); return; }
    seen.add(zoneId);
    overrides.push({ zoneId, customPrice: String(price) });
  }
  if (overrides.length) {
    const found = await db.select({ id: zonesTable.id }).from(zonesTable).where(inArray(zonesTable.id, overrides.map((o) => o.zoneId)));
    if (found.length !== overrides.length) { res.status(400).json({ error: "إحدى المناطق غير موجودة" }); return; }
  }

  // Atomic replace: previously a failed insert after the delete wiped the merchant's pricing.
  await db.transaction(async (tx) => {
    await tx.delete(merchantPricingTable).where(eq(merchantPricingTable.merchantId, merchantId));
    if (overrides.length) {
      await tx.insert(merchantPricingTable).values(overrides.map((o) => ({ merchantId, ...o })));
    }
  });
  res.json(await loadPricing(merchantId));
});

router.delete("/zones/:id", requireAuth, requirePermission("zones.manage"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم المنطقة غير صحيح" }); return; }
  const found = await db.transaction(async (tx) => {
    const [zone] = await tx.select({ id: zonesTable.id }).from(zonesTable).where(eq(zonesTable.id, id));
    if (!zone) return false;
    await tx.delete(merchantPricingTable).where(eq(merchantPricingTable.zoneId, id));
    await tx.delete(zonesTable).where(eq(zonesTable.id, id));
    return true;
  });
  if (!found) { res.status(404).json({ error: "Not found" }); return; }
  res.status(204).send();
});

export default router;
