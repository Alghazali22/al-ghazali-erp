import { Router } from "express";
import { db, driverShiftsTable, usersTable, tripsTable, ordersTable, branchesTable } from "@workspace/db";
import { and, eq, inArray, isNull, gte, sql, desc, count } from "drizzle-orm";
import { requireAuth, requireRole, getAuth, type AuthPayload, requirePermission, requireSelfRoleOrPermission, can, type RequestUser } from "../middlewares/auth";
import { iso, num } from "../lib/format";
import { parseId, isUniqueViolation, isOneOf } from "../lib/validate";
import { startOfCairoDay } from "../lib/time";
import { getShiftStates, rotationPositions, rejoinQueue, shiftSummary, closeStaleShifts, type DriverShiftState } from "../lib/shifts";

export { closeStaleShifts };

const router = Router();
const DISPATCH_ROLES = ["super_admin", "branch_manager", "operations"];

type DriverRow = { id: number; fullName: string; role: string; isActive: boolean; branchId: number | null; phone: string | null; cashBalance: string };

async function loadDriver(id: number): Promise<DriverRow | undefined> {
  const [row] = await db.select({
    id: usersTable.id, fullName: usersTable.fullName, role: usersTable.role, isActive: usersTable.isActive,
    branchId: usersTable.branchId, phone: usersTable.phone, cashBalance: usersTable.cashBalance,
  }).from(usersTable).where(eq(usersTable.id, id));
  return row;
}

/** Couriers act on themselves; dispatch staff act on couriers of their own branch (super admin: any). */
function resolveTarget(authUser: RequestUser, bodyDriverId: unknown): { driverId: number | null; onBehalf: boolean; error?: string } {
  if (authUser.role === "driver") return { driverId: authUser.userId, onBehalf: false };
  if (!can(authUser, "dispatch.shifts")) return { driverId: null, onBehalf: false, error: "غير مصرح" };
  const id = parseId(bodyDriverId);
  return id ? { driverId: id, onBehalf: true } : { driverId: null, onBehalf: true, error: "رقم المندوب مطلوب" };
}

function canManage(authUser: AuthPayload, driver: DriverRow): boolean {
  if (authUser.role === "super_admin") return true;
  return !!authUser.branchId && driver.branchId === authUser.branchId;
}

const formatShift = (s: typeof driverShiftsTable.$inferSelect) => ({
  id: s.id, driverId: s.driverId, branchId: s.branchId,
  startedAt: iso(s.startedAt), endedAt: iso(s.endedAt), endReason: s.endReason,
  queuedAt: iso(s.queuedAt), onBreak: !!s.breakStartedAt, breakMinutes: s.breakMinutes,
  deliveredCount: s.deliveredCount, returnedCount: s.returnedCount,
  collectedAmount: s.collectedAmount === null ? null : num(s.collectedAmount),
});

/** Rotation position of one courier inside his branch. */
async function queueInfo(driver: DriverRow) {
  if (!driver.branchId) return null;
  const peers = await db.select({ id: usersTable.id }).from(usersTable)
    .where(and(eq(usersTable.role, "driver"), eq(usersTable.isActive, true), eq(usersTable.branchId, driver.branchId)));
  const states = await getShiftStates(peers.map((p) => p.id));
  const positions = rotationPositions([...states.values()]);
  return { position: positions.get(driver.id) ?? null, size: positions.size };
}

// ---------------------------------------------------------------------------
// Courier: my state
// ---------------------------------------------------------------------------
router.get("/shifts/me", requireAuth, requireRole("driver"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const driver = await loadDriver(authUser.userId);
  if (!driver) { res.status(404).json({ error: "Not found" }); return; }
  const state = (await getShiftStates([driver.id])).get(driver.id)!;

  const [shift] = state.shiftId
    ? await db.select().from(driverShiftsTable).where(eq(driverShiftsTable.id, state.shiftId))
    : [];
  const queue = state.status === "available" ? await queueInfo(driver) : null;

  // A trip being prepared for me at the loading station (waiting for my acknowledgement).
  const [pending] = await db.select().from(tripsTable)
    .where(and(eq(tripsTable.driverId, driver.id), eq(tripsTable.status, "draft")))
    .orderBy(desc(tripsTable.id)).limit(1);
  let pendingTrip: any = null;
  if (pending) {
    const [agg] = await db.select({
      total: count(),
      loaded: sql<number>`count(*) filter (where ${ordersTable.loadedAt} is not null)`,
      cod: sql<string>`coalesce(sum(${ordersTable.totalToCollect}), 0)`,
    }).from(ordersTable).where(and(eq(ordersTable.tripId, pending.id), sql`${ordersTable.status} not in ('delivered', 'partial_delivery', 'final_return')`));
    const total = Number(agg?.total ?? 0);
    if (total > 0) {
      const loaded = Number(agg?.loaded ?? 0);
      pendingTrip = {
        id: pending.id, orderCount: total, loadedCount: loaded, totalToCollect: num(agg?.cod),
        ready: loaded === total, acceptedAt: iso(pending.acceptedAt),
      };
    }
  }

  const since = shift?.startedAt ?? startOfCairoDay();
  const summary = await shiftSummary(driver.id, since);
  res.json({
    status: state.status,
    shift: shift ? formatShift(shift) : null,
    queue,
    activeTripId: state.activeTripId,
    pendingTrip,
    cashBalance: num(driver.cashBalance),
    today: summary,
  });
});

// ---------------------------------------------------------------------------
// Start / break / end
// ---------------------------------------------------------------------------
router.post("/shifts/start", requireAuth, requireSelfRoleOrPermission(["driver"], "dispatch.shifts"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const target = resolveTarget(authUser, req.body?.driverId);
  if (!target.driverId) { res.status(400).json({ error: target.error }); return; }
  const driver = await loadDriver(target.driverId);
  if (!driver || driver.role !== "driver" || !driver.isActive) { res.status(404).json({ error: "المندوب غير موجود أو غير مفعّل" }); return; }
  if (target.onBehalf && !canManage(authUser, driver)) { res.status(403).json({ error: "المندوب تابع لفرع آخر" }); return; }

  try {
    const [created] = await db.insert(driverShiftsTable).values({ driverId: driver.id, branchId: driver.branchId }).returning();
    res.status(201).json({ started: true, shift: formatShift(created) });
  } catch (err) {
    if (!isUniqueViolation(err)) throw err;
    // Double tap / second device: the shift already exists — return it instead of failing.
    const [existing] = await db.select().from(driverShiftsTable).where(and(eq(driverShiftsTable.driverId, driver.id), isNull(driverShiftsTable.endedAt)));
    res.json({ started: false, shift: existing ? formatShift(existing) : null });
  }
});

router.post("/shifts/break", requireAuth, requireSelfRoleOrPermission(["driver"], "dispatch.shifts"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const action = req.body?.action;
  if (!isOneOf(action, ["start", "end"] as const)) { res.status(400).json({ error: "الإجراء غير صحيح" }); return; }
  const target = resolveTarget(authUser, req.body?.driverId);
  if (!target.driverId) { res.status(400).json({ error: target.error }); return; }
  const driver = await loadDriver(target.driverId);
  if (!driver || driver.role !== "driver") { res.status(404).json({ error: "المندوب غير موجود" }); return; }
  if (target.onBehalf && !canManage(authUser, driver)) { res.status(403).json({ error: "المندوب تابع لفرع آخر" }); return; }

  const state = (await getShiftStates([driver.id])).get(driver.id)!;
  if (!state.shiftId) { res.status(409).json({ error: "المندوب لم يبدأ الشيفت" }); return; }
  if (state.status === "on_trip") { res.status(409).json({ error: "لا يمكن أخذ استراحة أثناء رحلة جارية" }); return; }

  if (action === "start") {
    if (state.breakStartedAt) { res.json({ ok: true, onBreak: true }); return; }
    await db.update(driverShiftsTable).set({ breakStartedAt: new Date() }).where(eq(driverShiftsTable.id, state.shiftId));
    res.json({ ok: true, onBreak: true });
    return;
  }
  if (!state.breakStartedAt) { res.json({ ok: true, onBreak: false }); return; }
  const minutes = Math.max(0, Math.round((Date.now() - state.breakStartedAt.getTime()) / 60_000));
  // Coming back from a break puts the courier at the BACK of the rotation (fair to those who kept working).
  await db.update(driverShiftsTable).set({
    breakStartedAt: null, breakMinutes: state.breakMinutes + minutes, queuedAt: new Date(),
  }).where(eq(driverShiftsTable.id, state.shiftId));
  res.json({ ok: true, onBreak: false, breakMinutes: minutes });
});

router.post("/shifts/end", requireAuth, requireSelfRoleOrPermission(["driver"], "dispatch.shifts"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const target = resolveTarget(authUser, req.body?.driverId);
  if (!target.driverId) { res.status(400).json({ error: target.error }); return; }
  const driver = await loadDriver(target.driverId);
  if (!driver || driver.role !== "driver") { res.status(404).json({ error: "المندوب غير موجود" }); return; }
  if (target.onBehalf && !canManage(authUser, driver)) { res.status(403).json({ error: "المندوب تابع لفرع آخر" }); return; }

  const state = (await getShiftStates([driver.id])).get(driver.id)!;
  if (!state.shiftId) { res.status(409).json({ error: "لا يوجد شيفت مفتوح" }); return; }

  // A shift can't close while parcels are still out with the courier or loaded but not dispatched.
  const [[transit], [loaded]] = await Promise.all([
    db.select({ cnt: count() }).from(ordersTable).where(and(eq(ordersTable.driverId, driver.id), eq(ordersTable.status, "in_transit"))),
    db.select({ cnt: count() }).from(ordersTable).where(and(
      eq(ordersTable.driverId, driver.id), sql`${ordersTable.loadedAt} is not null`,
      sql`${ordersTable.tripId} in (select id from trips where driver_id = ${driver.id} and status = 'draft')`,
    )),
  ]);
  if (state.activeTripId || Number(transit?.cnt ?? 0) > 0) {
    res.status(409).json({ error: `لا يمكن إنهاء الشيفت: معه ${Number(transit?.cnt ?? 0)} شحنة في الطريق. سلّمها أو أرجعها وأغلق الرحلة أولاً`, code: "OPEN_TRIP" });
    return;
  }
  if (Number(loaded?.cnt ?? 0) > 0) {
    res.status(409).json({ error: `لا يمكن إنهاء الشيفت: تم تحميل ${Number(loaded?.cnt ?? 0)} شحنة عليه ولم يخرج بها. أفرغها أو احذف الرحلة أولاً`, code: "LOADED_NOT_DISPATCHED" });
    return;
  }

  const [shift] = await db.select().from(driverShiftsTable).where(eq(driverShiftsTable.id, state.shiftId));
  const summary = await shiftSummary(driver.id, shift.startedAt);
  const breakMinutes = shift.breakStartedAt
    ? shift.breakMinutes + Math.round((Date.now() - shift.breakStartedAt.getTime()) / 60_000)
    : shift.breakMinutes;
  const [closed] = await db.update(driverShiftsTable).set({
    endedAt: new Date(), endedBy: target.onBehalf ? authUser.userId : null,
    endReason: target.onBehalf ? "manager" : "self",
    breakStartedAt: null, breakMinutes,
    deliveredCount: summary.deliveredCount, returnedCount: summary.returnedCount, collectedAmount: String(summary.collectedAmount),
  }).where(and(eq(driverShiftsTable.id, state.shiftId), isNull(driverShiftsTable.endedAt))).returning();

  res.json({
    ended: true,
    shift: closed ? formatShift(closed) : null,
    // The courier still owes the company this cash; the accountant settles it from the settlements screen.
    cashDue: num(driver.cashBalance),
  });
});

// ---------------------------------------------------------------------------
// Dispatch: the rotation board
// ---------------------------------------------------------------------------
router.get("/shifts/board", requireAuth, requirePermission("dispatch.shifts"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const conds: any[] = [eq(usersTable.role, "driver"), eq(usersTable.isActive, true)];
  if (authUser.role !== "super_admin") {
    conds.push(authUser.branchId ? eq(usersTable.branchId, authUser.branchId) : sql`false`);
  } else if (req.query.branchId !== undefined) {
    const bid = parseId(req.query.branchId);
    if (!bid) { res.status(400).json({ error: "رقم الفرع غير صحيح" }); return; }
    conds.push(eq(usersTable.branchId, bid));
  }
  const drivers = await db.select({
    id: usersTable.id, fullName: usersTable.fullName, phone: usersTable.phone, branchId: usersTable.branchId, cashBalance: usersTable.cashBalance,
  }).from(usersTable).where(and(...conds)).orderBy(usersTable.fullName);
  const ids = drivers.map((d) => d.id);

  const states = await getShiftStates(ids);
  // Rotation is per branch.
  const positions = new Map<number, number>();
  const branches = [...new Set(drivers.map((d) => d.branchId))];
  for (const b of branches) {
    const inBranch = drivers.filter((d) => d.branchId === b).map((d) => states.get(d.id)!);
    for (const [id, pos] of rotationPositions(inBranch)) positions.set(id, pos);
  }

  const today = startOfCairoDay();
  const [deliveredRows, openRows, tripRows] = ids.length ? await Promise.all([
    db.select({ driverId: ordersTable.driverId, cnt: count() }).from(ordersTable)
      .where(and(inArray(ordersTable.driverId, ids), inArray(ordersTable.status, ["delivered", "partial_delivery"]), gte(ordersTable.deliveredAt, today)))
      .groupBy(ordersTable.driverId),
    db.select({ driverId: ordersTable.driverId, cnt: count() }).from(ordersTable)
      .where(and(inArray(ordersTable.driverId, ids), eq(ordersTable.status, "in_transit"))).groupBy(ordersTable.driverId),
    db.select({ id: tripsTable.id, driverId: tripsTable.driverId, status: tripsTable.status }).from(tripsTable)
      .where(and(inArray(tripsTable.driverId, ids), inArray(tripsTable.status, ["draft", "confirmed", "in_progress"]))),
  ]) : [[], [], []] as any[];
  const deliveredMap = new Map(deliveredRows.map((r: any) => [r.driverId, Number(r.cnt)]));
  const openMap = new Map(openRows.map((r: any) => [r.driverId, Number(r.cnt)]));
  const tripMap = new Map<number, { id: number; status: string }>();
  for (const t of tripRows as any[]) {
    const prev = tripMap.get(t.driverId);
    if (!prev || t.status !== "draft") tripMap.set(t.driverId, { id: t.id, status: t.status }); // a running trip wins over a draft
  }

  const rank = { available: 0, on_trip: 1, break: 2, off: 3 } as const;
  const rows = drivers.map((d) => {
    const s = states.get(d.id) as DriverShiftState;
    return {
      driverId: d.id, driverName: d.fullName, phone: d.phone, branchId: d.branchId,
      status: s.status,
      queuePosition: positions.get(d.id) ?? null,
      shiftStartedAt: iso(s.startedAt),
      waitingSince: s.status === "available" ? iso(s.queuedAt) : null,
      breakStartedAt: iso(s.breakStartedAt),
      breakMinutes: s.breakMinutes,
      deliveredToday: deliveredMap.get(d.id) ?? 0,
      parcelsOut: openMap.get(d.id) ?? 0,
      trip: tripMap.get(d.id) ?? null,
      cashBalance: num(d.cashBalance),
    };
  }).sort((a, b) => rank[a.status] - rank[b.status] || (a.queuePosition ?? 99) - (b.queuePosition ?? 99) || a.driverName.localeCompare(b.driverName, "ar"));

  res.json({
    drivers: rows,
    summary: {
      available: rows.filter((r) => r.status === "available").length,
      onTrip: rows.filter((r) => r.status === "on_trip").length,
      onBreak: rows.filter((r) => r.status === "break").length,
      off: rows.filter((r) => r.status === "off").length,
    },
    generatedAt: new Date().toISOString(),
  });
});

// Manager override of the rotation: send someone to the front (urgent route) or the back.
router.post("/shifts/queue/:driverId", requireAuth, requirePermission("dispatch.shifts"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const driverId = parseId(req.params.driverId);
  const position = req.body?.position;
  if (!driverId || !isOneOf(position, ["front", "back"] as const)) { res.status(400).json({ error: "بيانات غير صحيحة" }); return; }
  const driver = await loadDriver(driverId);
  if (!driver || driver.role !== "driver") { res.status(404).json({ error: "المندوب غير موجود" }); return; }
  if (!canManage(authUser, driver)) { res.status(403).json({ error: "المندوب تابع لفرع آخر" }); return; }

  const state = (await getShiftStates([driverId])).get(driverId)!;
  if (state.status !== "available" || !state.shiftId) { res.status(409).json({ error: "المندوب ليس في الانتظار حالياً" }); return; }

  let queuedAt = new Date();
  if (position === "front" && driver.branchId) {
    const peers = await db.select({ id: usersTable.id }).from(usersTable)
      .where(and(eq(usersTable.role, "driver"), eq(usersTable.isActive, true), eq(usersTable.branchId, driver.branchId)));
    const peerStates = [...(await getShiftStates(peers.map((p) => p.id))).values()].filter((s) => s.status === "available" && s.queuedAt);
    const earliest = Math.min(...peerStates.map((s) => s.queuedAt!.getTime()));
    queuedAt = new Date(Math.min(earliest, Date.now()) - 1000);
  }
  await db.update(driverShiftsTable).set({ queuedAt }).where(eq(driverShiftsTable.id, state.shiftId));
  res.json({ ok: true });
});

// Shift history (attendance + output per shift) — the base for payroll / performance review.
router.get("/shifts/history", requireAuth, requirePermission("dispatch.shifts"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const rawDays = Number(req.query.days);
  const days = Number.isInteger(rawDays) && rawDays >= 1 ? Math.min(rawDays, 90) : 7;
  const conds: any[] = [gte(driverShiftsTable.startedAt, new Date(Date.now() - days * 86_400_000))];
  if (authUser.role !== "super_admin") conds.push(authUser.branchId ? eq(driverShiftsTable.branchId, authUser.branchId) : sql`false`);
  if (req.query.driverId !== undefined) {
    const id = parseId(req.query.driverId);
    if (!id) { res.status(400).json({ error: "رقم المندوب غير صحيح" }); return; }
    conds.push(eq(driverShiftsTable.driverId, id));
  }
  const rows = await db.select({
    shift: driverShiftsTable, driverName: usersTable.fullName,
  }).from(driverShiftsTable).innerJoin(usersTable, eq(driverShiftsTable.driverId, usersTable.id))
    .where(and(...conds)).orderBy(desc(driverShiftsTable.startedAt)).limit(300);
  res.json(rows.map((r) => ({ ...formatShift(r.shift), driverName: r.driverName })));
});

export default router;
