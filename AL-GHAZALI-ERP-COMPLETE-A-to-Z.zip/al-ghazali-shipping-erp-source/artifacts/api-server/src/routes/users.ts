import { audit } from "../lib/audit";
import { Router } from "express";
import { db, usersTable, branchesTable } from "@workspace/db";
import { eq, and, ilike, inArray } from "drizzle-orm";
import { requireAuth, requireRole, getAuth, hashPassword, MIN_PASSWORD_LENGTH, requirePermission } from "../middlewares/auth";
import { getRoleUserBranchCondition, canManageUserRecord } from "../middlewares/orderScope";
import { formatUser } from "../lib/format";
import {
  parseId, escapeLike, asTrimmedString, optionalString, isOneOf, isUniqueViolation, USER_ROLES,
} from "../lib/validate";

const router = Router();

// Roles a branch manager may create (never other managers / accountants / admins).
const BRANCH_MANAGER_CREATABLE = ["driver", "merchant", "cs", "operations"] as const;
const USERNAME_RE = /^[A-Za-z0-9_.\-@]{3,40}$/;

/** Attach branchName to many users with a single query (was one query per user). */
async function withBranchNames(users: any[]) {
  const ids = [...new Set(users.map((u) => u.branchId).filter((v): v is number => !!v))];
  const map = new Map<number, string>();
  if (ids.length) {
    const rows = await db.select({ id: branchesTable.id, name: branchesTable.name })
      .from(branchesTable).where(inArray(branchesTable.id, ids));
    rows.forEach((r) => map.set(r.id, r.name));
  }
  return users.map((u) => ({ ...u, branchName: u.branchId ? map.get(u.branchId) ?? null : null }));
}

router.get("/users", requireAuth, async (req, res): Promise<void> => {
  const { role, branchId, search } = req.query;
  const authUser = getAuth(req);
  const conditions: any[] = [];

  if (role !== undefined) {
    if (!isOneOf(role, USER_ROLES)) { res.status(400).json({ error: "دور غير صحيح" }); return; }
    conditions.push(eq(usersTable.role, role));
  }

  if (authUser.role === "merchant" || authUser.role === "driver") {
    // Merchants/drivers may only ever see their own record (previously they could list everyone,
    // including balances and ID documents). The order form still works: it lists just "me".
    conditions.push(eq(usersTable.id, authUser.userId));
  } else if (authUser.role === "super_admin" || authUser.role === "accountant") {
    if (branchId !== undefined) {
      const bid = parseId(branchId);
      if (!bid) { res.status(400).json({ error: "رقم الفرع غير صحيح" }); return; }
      conditions.push(eq(usersTable.branchId, bid));
    }
  } else {
    // Branch-scoped staff are locked to their own branch regardless of query params.
    conditions.push(...getRoleUserBranchCondition(authUser));
  }

  if (typeof search === "string" && search.trim()) {
    conditions.push(ilike(usersTable.fullName, `%${escapeLike(search.trim().slice(0, 100))}%`));
  }

  let query = db.select().from(usersTable).$dynamic();
  if (conditions.length) query = query.where(and(...conditions));
  const users = await query.orderBy(usersTable.id);
  res.json(await withBranchNames(users.map(formatUser)));
});

router.post("/users", requireAuth, requirePermission("users.create"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const body = req.body ?? {};
  const username = asTrimmedString(body.username, 40);
  const fullName = asTrimmedString(body.fullName, 120);
  const password = body.password;

  if (!username || !USERNAME_RE.test(username)) {
    res.status(400).json({ error: "اسم المستخدم غير صحيح (3-40 حرفاً إنجليزياً أو أرقاماً)" });
    return;
  }
  if (!fullName) { res.status(400).json({ error: "الاسم الكامل مطلوب" }); return; }
  if (typeof password !== "string" || password.length < MIN_PASSWORD_LENGTH || password.length > 128) {
    res.status(400).json({ error: `كلمة المرور مطلوبة ويجب ألا تقل عن ${MIN_PASSWORD_LENGTH} أحرف` });
    return;
  }
  if (!isOneOf(body.role, USER_ROLES)) { res.status(400).json({ error: "الدور غير صحيح" }); return; }
  const role = body.role;

  let branchId: number | null = body.branchId === undefined || body.branchId === null ? null : parseId(body.branchId);
  if (body.branchId !== undefined && body.branchId !== null && !branchId) {
    res.status(400).json({ error: "رقم الفرع غير صحيح" });
    return;
  }

  if (authUser.role === "branch_manager") {
    // Privilege-escalation fix: a branch manager could previously create super_admin accounts.
    if (!isOneOf(role, BRANCH_MANAGER_CREATABLE)) {
      res.status(403).json({ error: "لا تملك صلاحية إنشاء هذا النوع من الحسابات" });
      return;
    }
    if (!authUser.branchId) { res.status(403).json({ error: "حسابك غير مرتبط بفرع" }); return; }
    branchId = authUser.branchId; // always their own branch
  }

  if (branchId) {
    const [b] = await db.select({ id: branchesTable.id }).from(branchesTable).where(eq(branchesTable.id, branchId));
    if (!b) { res.status(400).json({ error: "الفرع غير موجود" }); return; }
  }

  try {
    const [user] = await db.insert(usersTable).values({
      username,
      passwordHash: hashPassword(password),
      fullName,
      role,
      phone: optionalString(body.phone, 30) ?? null,
      email: optionalString(body.email, 200) ?? null,
      branchId,
      nationalIdFront: optionalString(body.nationalIdFront, 2000) ?? null,
      nationalIdBack: optionalString(body.nationalIdBack, 2000) ?? null,
      drivingLicense: optionalString(body.drivingLicense, 2000) ?? null,
      vehicleLicense: optionalString(body.vehicleLicense, 2000) ?? null,
      profilePhoto: optionalString(body.profilePhoto, 2000) ?? null,
      merchantLogo: optionalString(body.merchantLogo, 2000) ?? null,
    }).returning();
    await audit(req, "user.create", { type: "user", id: user.id }, `${user.username} (${user.role})`);
    res.status(201).json((await withBranchNames([formatUser(user)]))[0]);
  } catch (err) {
    if (isUniqueViolation(err)) { res.status(409).json({ error: "اسم المستخدم مستخدم بالفعل" }); return; }
    throw err;
  }
});

async function loadTarget(idParam: unknown) {
  const id = parseId(idParam);
  if (!id) return { id: null as null, user: undefined };
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, id));
  return { id, user };
}

router.get("/users/:id", requireAuth, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const { id, user } = await loadTarget(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم غير صحيح" }); return; }
  if (!user) { res.status(404).json({ error: "Not found" }); return; }
  // IDOR fix: previously any logged-in user could read any user (balances, ID documents, ...).
  if (!canManageUserRecord(authUser, user)) {
    res.status(403).json({ error: "غير مصرح" });
    return;
  }
  res.json((await withBranchNames([formatUser(user)]))[0]);
});

router.patch("/users/:id", requireAuth, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const { id, user: target } = await loadTarget(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم غير صحيح" }); return; }
  if (!target) { res.status(404).json({ error: "Not found" }); return; }
  if (!canManageUserRecord(authUser, target)) { res.status(403).json({ error: "غير مصرح بتعديل هذا المستخدم" }); return; }

  const body = req.body ?? {};
  const updates: any = {};
  const set = (key: string, maxLen: number) => {
    const v = optionalString(body[key], maxLen);
    if (body[key] !== undefined && v !== undefined) updates[key] = v;
  };
  const isSelf = authUser.userId === target.id;
  const isAdmin = authUser.role === "super_admin";

  if (body.fullName !== undefined) {
    const fn = asTrimmedString(body.fullName, 120);
    if (!fn) { res.status(400).json({ error: "الاسم غير صحيح" }); return; }
    updates.fullName = fn;
  }
  set("phone", 30);
  set("email", 200);
  set("profilePhoto", 2000);
  set("merchantLogo", 2000);

  // Sensitive documents: staff who manage the account only (not the account holder).
  if (!isSelf || isAdmin) {
    set("nationalIdFront", 2000);
    set("nationalIdBack", 2000);
    set("drivingLicense", 2000);
    set("vehicleLicense", 2000);
  }

  // Moving a user between branches is an admin-only action (it changes their data scope).
  if (body.branchId !== undefined) {
    if (!isAdmin) { res.status(403).json({ error: "تغيير الفرع متاح للمدير العام فقط" }); return; }
    if (body.branchId === null) {
      updates.branchId = null;
    } else {
      const bid = parseId(body.branchId);
      if (!bid) { res.status(400).json({ error: "رقم الفرع غير صحيح" }); return; }
      const [b] = await db.select({ id: branchesTable.id }).from(branchesTable).where(eq(branchesTable.id, bid));
      if (!b) { res.status(400).json({ error: "الفرع غير موجود" }); return; }
      updates.branchId = bid;
    }
  }

  if (Object.keys(updates).length === 0) { res.status(400).json({ error: "لا توجد بيانات للتحديث" }); return; }
  const [user] = await db.update(usersTable).set(updates).where(eq(usersTable.id, id)).returning();
  res.json((await withBranchNames([formatUser(user)]))[0]);
});

// New: administrators had no way to reset a forgotten password.
router.post("/users/:id/reset-password", requireAuth, requirePermission("users.reset_password"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const { id, user: target } = await loadTarget(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم غير صحيح" }); return; }
  if (!target) { res.status(404).json({ error: "Not found" }); return; }
  if (target.id === authUser.userId) { res.status(400).json({ error: "استخدم تغيير كلمة المرور لحسابك" }); return; }
  if (!canManageUserRecord(authUser, target)) { res.status(403).json({ error: "غير مصرح" }); return; }
  const { newPassword } = req.body ?? {};
  if (typeof newPassword !== "string" || newPassword.length < MIN_PASSWORD_LENGTH || newPassword.length > 128) {
    res.status(400).json({ error: `كلمة المرور يجب ألا تقل عن ${MIN_PASSWORD_LENGTH} أحرف` });
    return;
  }
  await db.update(usersTable).set({ passwordHash: hashPassword(newPassword) }).where(eq(usersTable.id, id));
  await audit(req, "user.reset_password", { type: "user", id }, target.username);
  res.json({ ok: true });
});

router.delete("/users/:id", requireAuth, requirePermission("users.delete"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم غير صحيح" }); return; }
  if (id === authUser.userId) { res.status(400).json({ error: "لا يمكنك حذف حسابك الشخصي" }); return; }
  await db.delete(usersTable).where(eq(usersTable.id, id));
  await audit(req, "user.delete", { type: "user", id });
  res.status(204).send();
});

router.post("/users/:id/toggle-status", requireAuth, requirePermission("users.toggle"), async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const { id, user: target } = await loadTarget(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم غير صحيح" }); return; }
  if (!target) { res.status(404).json({ error: "Not found" }); return; }
  if (target.id === authUser.userId) { res.status(400).json({ error: "لا يمكنك تعطيل حسابك الشخصي" }); return; }
  // Previously a branch manager could disable any account, including super admins and other branches.
  if (!canManageUserRecord(authUser, target)) { res.status(403).json({ error: "غير مصرح" }); return; }
  const [user] = await db.update(usersTable).set({ isActive: !target.isActive }).where(eq(usersTable.id, id)).returning();
  await audit(req, user.isActive ? "user.enable" : "user.disable", { type: "user", id }, target.username);
  res.json((await withBranchNames([formatUser(user)]))[0]);
});

export { formatUser };
export default router;
