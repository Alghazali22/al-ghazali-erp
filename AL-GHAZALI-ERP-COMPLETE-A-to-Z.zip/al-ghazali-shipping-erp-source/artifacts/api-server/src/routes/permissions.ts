import { Router } from "express";
import { db, usersTable, auditLogTable, branchesTable } from "@workspace/db";
import { and, eq, desc, inArray, like, sql } from "drizzle-orm";
import { requireAuth, requirePermission } from "../middlewares/auth";
import { audit } from "../lib/audit";
import { iso } from "../lib/format";
import { parseId, parsePagination } from "../lib/validate";
import {
  PERMISSION_GROUPS, roleDefaults, effectivePermissions, isGrantable, isValidPermission, canHaveGrants, type Role,
} from "../lib/permissions";

const router = Router();

const ROLES: Role[] = ["super_admin", "branch_manager", "accountant", "operations", "cs", "driver", "merchant"];
const ROLE_LABELS: Record<Role, string> = {
  super_admin: "المدير العام", branch_manager: "مدير فرع", accountant: "محاسب", operations: "عمليات",
  cs: "خدمة عملاء", driver: "مندوب", merchant: "تاجر",
};

// The full catalog + what each role gets by default — the "who can do what" matrix.
router.get("/permissions/catalog", requireAuth, requirePermission("permissions.manage"), async (_req, res): Promise<void> => {
  res.json({
    groups: PERMISSION_GROUPS.map((g) => ({
      key: g.key, label: g.label,
      permissions: g.permissions.map((p) => ({ key: p.key, label: p.label, locked: !!p.locked })),
    })),
    roles: ROLES.map((r) => ({ key: r, label: ROLE_LABELS[r], canHaveGrants: canHaveGrants(r), defaults: [...roleDefaults(r)] })),
  });
});

// Employees whose permissions can be customised (internal staff other than the owner).
router.get("/permissions/users", requireAuth, requirePermission("permissions.manage"), async (_req, res): Promise<void> => {
  const staff = await db.select({
    id: usersTable.id, fullName: usersTable.fullName, role: usersTable.role, branchId: usersTable.branchId,
    isActive: usersTable.isActive, grant: usersTable.permissionsGrant, revoke: usersTable.permissionsRevoke,
  }).from(usersTable).where(inArray(usersTable.role, ["branch_manager", "accountant", "operations", "cs"])).orderBy(usersTable.role, usersTable.fullName);
  const branchIds = [...new Set(staff.map((u) => u.branchId).filter((v): v is number => !!v))];
  const branches = branchIds.length ? await db.select({ id: branchesTable.id, name: branchesTable.name }).from(branchesTable).where(inArray(branchesTable.id, branchIds)) : [];
  const branchName = new Map(branches.map((b) => [b.id, b.name]));
  res.json(staff.map((u) => ({
    id: u.id, fullName: u.fullName, role: u.role, roleLabel: ROLE_LABELS[u.role as Role] ?? u.role, isActive: u.isActive,
    branchName: u.branchId ? branchName.get(u.branchId) ?? null : null,
    grants: u.grant ?? [], revokes: u.revoke ?? [],
    effective: [...effectivePermissions(u.role, u.grant ?? [], u.revoke ?? [])],
  })));
});

const asKeyList = (value: unknown): string[] | null => {
  if (!Array.isArray(value) || value.length > 100 || value.some((v) => typeof v !== "string")) return null;
  return [...new Set(value as string[])];
};

router.put("/permissions/users/:id", requireAuth, requirePermission("permissions.manage"), async (req, res): Promise<void> => {
  const id = parseId(req.params.id);
  if (!id) { res.status(400).json({ error: "رقم المستخدم غير صحيح" }); return; }
  const grants = asKeyList(req.body?.grants ?? []);
  const revokes = asKeyList(req.body?.revokes ?? []);
  if (!grants || !revokes) { res.status(400).json({ error: "قوائم الصلاحيات غير صحيحة" }); return; }
  if (grants.some((g) => !isGrantable(g))) { res.status(400).json({ error: "تحتوي القائمة صلاحية غير موجودة أو لا يمكن منحها" }); return; }
  if (revokes.some((r) => !isValidPermission(r))) { res.status(400).json({ error: "تحتوي القائمة صلاحية غير موجودة" }); return; }
  if (grants.some((g) => revokes.includes(g))) { res.status(400).json({ error: "لا يمكن منح وسحب نفس الصلاحية معاً" }); return; }

  const [target] = await db.select().from(usersTable).where(eq(usersTable.id, id));
  if (!target) { res.status(404).json({ error: "المستخدم غير موجود" }); return; }
  if (!canHaveGrants(target.role)) { res.status(400).json({ error: "لا يمكن تخصيص صلاحيات هذا النوع من الحسابات" }); return; }

  // Store only real exceptions: a "grant" that the role already has by default is just noise.
  const defaults = roleDefaults(target.role);
  const cleanGrants = grants.filter((g) => !defaults.has(g));
  const cleanRevokes = revokes.filter((r) => defaults.has(r));

  await db.update(usersTable).set({ permissionsGrant: cleanGrants, permissionsRevoke: cleanRevokes }).where(eq(usersTable.id, id));
  const added = cleanGrants.filter((g) => !(target.permissionsGrant ?? []).includes(g));
  const removed = cleanRevokes.filter((r) => !(target.permissionsRevoke ?? []).includes(r));
  await audit(req, "permissions.update", { type: "user", id }, `${target.fullName}: منح [${cleanGrants.join(", ") || "—"}] · سحب [${cleanRevokes.join(", ") || "—"}]${added.length || removed.length ? "" : " (بدون تغيير)"}`);
  res.json({
    id, grants: cleanGrants, revokes: cleanRevokes,
    effective: [...effectivePermissions(target.role, cleanGrants, cleanRevokes)],
  });
});

// Audit trail of sensitive actions.
router.get("/audit", requireAuth, requirePermission("audit.view"), async (req, res): Promise<void> => {
  const conds: any[] = [];
  if (typeof req.query.action === "string" && /^[a-z_.]{1,40}$/.test(req.query.action)) conds.push(like(auditLogTable.action, `${req.query.action}%`));
  if (req.query.actorId !== undefined) {
    const actorId = parseId(req.query.actorId);
    if (!actorId) { res.status(400).json({ error: "رقم غير صحيح" }); return; }
    conds.push(eq(auditLogTable.actorId, actorId));
  }
  const { limit, offset } = parsePagination(req.query, { defaultLimit: 50, maxLimit: 200 });
  const rows = await db.select().from(auditLogTable).where(conds.length ? and(...conds) : undefined)
    .orderBy(desc(auditLogTable.createdAt), desc(auditLogTable.id)).limit(limit).offset(offset);
  res.json(rows.map((r) => ({ ...r, createdAt: iso(r.createdAt) })));
});

export default router;
