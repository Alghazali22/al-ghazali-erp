import { Router } from "express";
import { db } from "@workspace/db";
import { announcementsTable, systemSettingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAuth, requireRole, invalidateSystemState, requirePermission } from "../middlewares/auth";
import { audit } from "../lib/audit";
import { iso } from "../lib/format";
import { optionalString } from "../lib/validate";

const router = Router();

async function getOrCreateAnnouncement() {
  const [existing] = await db.select().from(announcementsTable).limit(1);
  if (existing) return existing;
  const [created] = await db.insert(announcementsTable).values({ message: null, isActive: false }).returning();
  return created;
}

async function getOrCreateSystemSettings() {
  const [existing] = await db.select().from(systemSettingsTable).limit(1);
  if (existing) return existing;
  const [created] = await db.insert(systemSettingsTable).values({ isShutdown: false }).returning();
  return created;
}

const formatAnnouncement = (a: any) => ({ ...a, updatedAt: iso(a.updatedAt) });
const formatStatus = (s: any) => ({ isShutdown: s.isShutdown, shutdownMessage: s.shutdownMessage, updatedAt: iso(s.updatedAt) });

router.get("/system/announcement", requireAuth, async (_req, res): Promise<void> => {
  res.json(formatAnnouncement(await getOrCreateAnnouncement()));
});

router.put("/system/announcement", requireAuth, requirePermission("system.announcement"), async (req, res): Promise<void> => {
  const { message, isActive } = req.body ?? {};
  const text = optionalString(message, 500);
  if (message !== undefined && text === undefined) { res.status(400).json({ error: "نص الإعلان غير صحيح" }); return; }
  if (isActive !== undefined && typeof isActive !== "boolean") { res.status(400).json({ error: "حالة الإعلان غير صحيحة" }); return; }
  const a = await getOrCreateAnnouncement();
  const updates: any = { updatedAt: new Date() };
  if (text !== undefined) updates.message = text;
  if (isActive !== undefined) updates.isActive = isActive;
  const [updated] = await db.update(announcementsTable).set(updates).where(eq(announcementsTable.id, a.id)).returning();
  res.json(formatAnnouncement(updated));
});

// Public on purpose: the login screen needs to know whether the system is shut down.
router.get("/system/status", async (_req, res): Promise<void> => {
  res.json(formatStatus(await getOrCreateSystemSettings()));
});

router.post("/system/shutdown", requireAuth, requirePermission("system.shutdown"), async (req, res): Promise<void> => {
  const { isShutdown, message } = req.body ?? {};
  if (typeof isShutdown !== "boolean") { res.status(400).json({ error: "حالة الإغلاق مطلوبة" }); return; }
  const text = optionalString(message, 300);
  const s = await getOrCreateSystemSettings();
  const updates: any = { isShutdown, updatedAt: new Date() };
  if (text) updates.shutdownMessage = text;
  const [updated] = await db.update(systemSettingsTable).set(updates).where(eq(systemSettingsTable.id, s.id)).returning();
  invalidateSystemState(); // take effect immediately on this instance
  await audit(req, isShutdown ? "system.shutdown" : "system.restore", null, text ?? undefined);
  res.json(formatStatus(updated));
});

export default router;
