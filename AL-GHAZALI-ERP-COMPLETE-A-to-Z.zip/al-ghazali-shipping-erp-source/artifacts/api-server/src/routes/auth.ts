import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  signToken, requireAuth, getAuth, hashPassword, verifyPassword,
  getDummyHash, MIN_PASSWORD_LENGTH,
} from "../middlewares/auth";
import { rateLimit } from "../lib/rateLimit";
import { formatUser } from "../lib/format";
import { effectivePermissions } from "../lib/permissions";

const router = Router();

// Brute-force protection: strict per (ip + username), generous per ip.
const loginPerIp = rateLimit({
  windowMs: 15 * 60_000,
  max: 100,
  key: (req) => `ip:${req.ip}`,
  message: "محاولات تسجيل دخول كثيرة، برجاء المحاولة بعد قليل",
});
const loginPerAccount = rateLimit({
  windowMs: 15 * 60_000,
  max: 10,
  key: (req) => `acct:${req.ip}:${String(req.body?.username ?? "").toLowerCase().slice(0, 64)}`,
  message: "محاولات تسجيل دخول كثيرة لهذا الحساب، برجاء المحاولة بعد 15 دقيقة",
});

router.post("/auth/login", loginPerIp, loginPerAccount, async (req, res): Promise<void> => {
  const { username, password } = req.body ?? {};
  if (typeof username !== "string" || typeof password !== "string" || !username || !password) {
    res.status(400).json({ error: "Username and password required" });
    return;
  }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.username, username.trim()));
  // Always run one scrypt verification so response time doesn't reveal whether the username exists.
  const valid = verifyPassword(password, user?.passwordHash ?? getDummyHash());
  if (!user || !valid) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }
  if (!user.isActive) {
    res.status(401).json({ error: "Account is disabled" });
    return;
  }
  const token = signToken({ userId: user.id, role: user.role, branchId: user.branchId });
  const permissions = [...effectivePermissions(user.role, user.permissionsGrant ?? [], user.permissionsRevoke ?? [])];
  res.json({ user: { ...formatUser(user), permissions }, token });
});

router.post("/auth/logout", (_req, res): void => {
  // Tokens are stateless; the client discards its copy.
  res.json({ ok: true });
});

router.get("/auth/me", requireAuth, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, authUser.userId));
  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }
  res.json({ ...formatUser(user), permissions: [...authUser.permissions] });
});

// New: users had no way to change their own password.
const changePasswordLimiter = rateLimit({
  windowMs: 15 * 60_000,
  max: 10,
  key: (req) => `chpw:${req.ip}`,
});

router.post("/auth/change-password", requireAuth, changePasswordLimiter, async (req, res): Promise<void> => {
  const authUser = getAuth(req);
  const { currentPassword, newPassword } = req.body ?? {};
  if (typeof currentPassword !== "string" || typeof newPassword !== "string") {
    res.status(400).json({ error: "كلمة المرور الحالية والجديدة مطلوبتان" });
    return;
  }
  if (newPassword.length < MIN_PASSWORD_LENGTH || newPassword.length > 128) {
    res.status(400).json({ error: `كلمة المرور الجديدة يجب أن تكون ${MIN_PASSWORD_LENGTH} أحرف على الأقل` });
    return;
  }
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, authUser.userId));
  if (!user || !verifyPassword(currentPassword, user.passwordHash)) {
    res.status(400).json({ error: "كلمة المرور الحالية غير صحيحة" });
    return;
  }
  if (currentPassword === newPassword) {
    res.status(400).json({ error: "كلمة المرور الجديدة يجب أن تختلف عن الحالية" });
    return;
  }
  await db.update(usersTable).set({ passwordHash: hashPassword(newPassword) }).where(eq(usersTable.id, user.id));
  res.json({ ok: true });
});

export { formatUser };
export default router;
