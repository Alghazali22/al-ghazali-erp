import express, { type Express, type Request, type Response, type NextFunction } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

app.disable("x-powered-by");
// Number of reverse-proxy hops in front of the app (Replit = 1). Needed so req.ip
// (used by the rate limiters) is the real client address.
app.set("trust proxy", Number(process.env.TRUST_PROXY_HOPS ?? 1));

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);

// Basic hardening headers. (No X-Frame-Options so the Replit preview iframe keeps working.)
app.use((_req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("Cache-Control", "no-store");
  next();
});

// CORS: the web app and API share an origin behind the proxy, so cross-origin access
// is only needed for other clients. Set CORS_ORIGINS="https://a.com,https://b.com" to restrict;
// when unset, behaviour is unchanged (open) to avoid breaking existing deployments.
const corsOrigins = (process.env.CORS_ORIGINS ?? "")
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);
app.use(corsOrigins.length ? cors({ origin: corsOrigins }) : cors());

app.use(express.json({ limit: "256kb" }));
app.use(express.urlencoded({ extended: true, limit: "256kb" }));

app.use("/api", router);

app.use("/api", (_req: Request, res: Response) => {
  res.status(404).json({ error: "Not found" });
});

// Central error handler: never leak stack traces / SQL to clients.
// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  if (res.headersSent) {
    next(err);
    return;
  }
  if (err?.type === "entity.too.large") {
    res.status(413).json({ error: "حجم الطلب كبير جداً" });
    return;
  }
  if (err?.type === "entity.parse.failed" || (err instanceof SyntaxError && "body" in err)) {
    res.status(400).json({ error: "صيغة البيانات المرسلة غير صحيحة" });
    return;
  }
  logger.error({ err, method: req.method, url: req.url?.split("?")[0] }, "Unhandled request error");
  res.status(500).json({ error: "حدث خطأ غير متوقع، حاول مرة أخرى" });
});

export default app;
