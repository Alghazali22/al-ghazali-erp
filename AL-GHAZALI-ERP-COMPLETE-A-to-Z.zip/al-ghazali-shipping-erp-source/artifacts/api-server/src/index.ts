// All "today" / date math in the codebase assumes the process clock is UTC
// (business-day logic converts to Africa/Cairo explicitly — see lib/time.ts).
process.env.TZ = "UTC";

import app from "./app";
import { logger } from "./lib/logger";
import { pool, db } from "@workspace/db";
import { sql } from "drizzle-orm";
import { pruneLocationHistory } from "./routes/tracking";
import { closeStaleShifts } from "./routes/shifts";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const server = app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
});

// One-off, idempotent backfill of the customer-reputation key for orders created before it existed.
db.execute(sql`UPDATE orders SET customer_phone_key = right(regexp_replace(customer_phone, '[^0-9]', '', 'g'), 10) WHERE customer_phone_key IS NULL`)
  .catch((err) => logger.error({ err }, "customer_phone_key backfill failed (run db push first?)"));

// Keep the GPS history table from growing forever (30 days retained).
const pruneTimer = setInterval(() => {
  pruneLocationHistory(30).catch((err) => logger.error({ err }, "Failed to prune location history"));
}, 24 * 60 * 60 * 1000);
pruneTimer.unref();

// Close shifts that were never ended (phone died, courier just left) so they don't block the rotation.
const shiftTimer = setInterval(() => {
  closeStaleShifts(20).then((n) => { if (n) logger.info({ closed: n }, "Closed stale shifts"); })
    .catch((err) => logger.error({ err }, "Failed to close stale shifts"));
}, 60 * 60 * 1000);
shiftTimer.unref();

process.on("unhandledRejection", (reason) => {
  logger.error({ err: reason }, "Unhandled promise rejection");
});

let shuttingDown = false;
function shutdown(signal: string) {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.info({ signal }, "Shutting down gracefully");
  server.close(() => {
    pool.end().finally(() => process.exit(0));
  });
  // Force-exit if connections hang.
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
