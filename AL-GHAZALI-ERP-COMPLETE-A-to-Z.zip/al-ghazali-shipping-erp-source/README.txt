Al-Ghazali Shipping ERP — Full Source Export

Contains the first-party ERP web app and API source, database schemas, generated API client and validators, OpenAPI specification, workspace manifests/configuration, scripts, and required logo asset.

Not included: third-party node_modules, compiled build output, local Replit metadata, environment files, or secrets. The mockup sandbox is a separate design tool and is not part of this ERP source export.

Runtime configuration must be supplied separately through secure environment variables, including DATABASE_URL and SESSION_SECRET. In this export, insecure hardcoded defaults were removed from auth/user-creation code: SESSION_SECRET must be configured and a password must be provided when creating users.

Install dependencies from the workspace root with pnpm install. See package manifests and artifact manifests for run/build commands.
