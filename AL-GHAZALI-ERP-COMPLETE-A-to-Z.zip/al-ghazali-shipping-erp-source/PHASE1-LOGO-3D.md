# المرحلة 1 — اللوجو + خلفية 3D (جاهزة)

## ما تم تنفيذه
1. استبدال لوجو النظام باللوجو الرسمي الجديد (الغزال + الطرد) في:
   - شاشة تسجيل الدخول
   - الشريط الجانبي (AppLayout)
   - صفحة التتبع العامة للعميل
2. إعادة تصميم شاشة الدخول بخلفية 3D احترافية:
   - منظور (perspective) + ميلان اللوجو مع حركة الماوس
   - حلقات مدارية ثلاثية الأبعاد
   - أرضية شبكة منظور
   - جزيئات ضوء متحركة
   - توهج ذهبي متوافق مع هوية العلامة
   - شعار: Fast. Reliable. Al-Ghazali. / سريع. موثوق. الغزالي.

## الملفات المعدّلة
- `attached_assets/al-ghazali-logo.png` (جديد)
- `attached_assets/file_00000000ddd461f4ac9c307524f331ba_1780749296729.png` (تم الاستبدال)
- `artifacts/al-ghazali/src/pages/login.tsx`
- `artifacts/al-ghazali/src/components/layout/AppLayout.tsx`
- `artifacts/al-ghazali/src/pages/track.tsx`

## التشغيل على Replit
1. ارفع محتويات المجلد `al-ghazali-shipping-erp-source` إلى مشروع Replit (أو استبدل المشروع الحالي).
2. Secrets المطلوبة على الأقل:
   - `DATABASE_URL`
   - `SESSION_SECRET` (32+ حرف عشوائي)
3. `pnpm install`
4. `pnpm --filter @workspace/db push`
5. شغّل المشروع كالمعتاد من إعدادات Replit / أوامر الـ artifacts.

## المراحل التالية (حسب طلبك)
- المرحلة 2: إثبات التسليم (صورة / توقيع) + تحسين OTP
- المرحلة 3: SMS / WhatsApp حقيقي + إشعارات
- المرحلة 4: تحسين غرفة العمليات والشيفتات وتجربة المندوب

كل مرحلة تُسلَّم كملف مصدر جاهز بدون الاعتماد على توليد Replit.
