import { pgTable, serial, text, boolean, integer, numeric, timestamp, pgEnum, index } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const roleEnum = pgEnum("user_role", [
  "super_admin", "branch_manager", "accountant", "operations", "cs", "driver", "merchant"
]);

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  fullName: text("full_name").notNull(),
  role: roleEnum("role").notNull(),
  phone: text("phone"),
  email: text("email"),
  branchId: integer("branch_id"),
  isActive: boolean("is_active").notNull().default(true),
  // Per-employee exceptions to the role's default permissions (see api-server/src/lib/permissions.ts).
  permissionsGrant: text("permissions_grant").array().notNull().default(sql`'{}'::text[]`),
  permissionsRevoke: text("permissions_revoke").array().notNull().default(sql`'{}'::text[]`),
  nationalIdFront: text("national_id_front"),
  nationalIdBack: text("national_id_back"),
  drivingLicense: text("driving_license"),
  vehicleLicense: text("vehicle_license"),
  profilePhoto: text("profile_photo"),
  merchantLogo: text("merchant_logo"),
  cashBalance: numeric("cash_balance", { precision: 12, scale: 2 }).notNull().default("0"),
  // Cash a driver has handed in that has not yet been matched to delivered orders (see settle-driver).
  settlementCredit: numeric("settlement_credit", { precision: 12, scale: 2 }).notNull().default("0"),
  walletBalance: numeric("wallet_balance", { precision: 12, scale: 2 }).notNull().default("0"),
  pendingBalance: numeric("pending_balance", { precision: 12, scale: 2 }).notNull().default("0"),
  totalWithdrawn: numeric("total_withdrawn", { precision: 12, scale: 2 }).notNull().default("0"),
  currentLat: numeric("current_lat", { precision: 10, scale: 6 }),
  currentLng: numeric("current_lng", { precision: 10, scale: 6 }),
  locationUpdatedAt: timestamp("location_updated_at"),
  locationAccuracy: numeric("location_accuracy", { precision: 8, scale: 1 }), // metres
  locationSpeed: numeric("location_speed", { precision: 6, scale: 2 }),       // m/s
  locationHeading: numeric("location_heading", { precision: 5, scale: 1 }),   // degrees
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [
  index("users_role_idx").on(t.role),
  index("users_branch_idx").on(t.branchId),
]);

export const driverLocationHistoryTable = pgTable("driver_location_history", {
  id: serial("id").primaryKey(),
  driverId: integer("driver_id").notNull(),
  lat: numeric("lat", { precision: 10, scale: 6 }).notNull(),
  lng: numeric("lng", { precision: 10, scale: 6 }).notNull(),
  accuracy: numeric("accuracy", { precision: 8, scale: 1 }),
  speed: numeric("speed", { precision: 6, scale: 2 }),
  heading: numeric("heading", { precision: 5, scale: 1 }),
  recordedAt: timestamp("recorded_at").notNull().defaultNow(),
}, (t) => [
  index("driver_location_driver_time_idx").on(t.driverId, t.recordedAt),
]);

export const insertUserSchema = createInsertSchema(usersTable).omit({ id: true, createdAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
export type DriverLocationHistory = typeof driverLocationHistoryTable.$inferSelect;
