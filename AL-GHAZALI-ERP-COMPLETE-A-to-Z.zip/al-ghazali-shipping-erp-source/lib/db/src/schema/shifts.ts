import { pgTable, serial, text, integer, numeric, timestamp, index, uniqueIndex } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

// A courier's working shift. While a shift is open the courier is "on duty": they appear in the dispatch
// rotation (ordered by queued_at — whoever has waited longest is next), can be assigned trips, and report GPS.
export const driverShiftsTable = pgTable("driver_shifts", {
  id: serial("id").primaryKey(),
  driverId: integer("driver_id").notNull(),
  branchId: integer("branch_id"),
  startedAt: timestamp("started_at").notNull().defaultNow(),
  endedAt: timestamp("ended_at"),
  endedBy: integer("ended_by"),            // null = the courier themself (or the automatic cleanup)
  endReason: text("end_reason"),           // self | manager | auto
  // Position in the rotation: set at shift start, and again every time the courier finishes a trip.
  queuedAt: timestamp("queued_at").notNull().defaultNow(),
  breakStartedAt: timestamp("break_started_at"),
  breakMinutes: integer("break_minutes").notNull().default(0),
  // Snapshot taken when the shift closes.
  deliveredCount: integer("delivered_count"),
  returnedCount: integer("returned_count"),
  collectedAmount: numeric("collected_amount", { precision: 12, scale: 2 }),
}, (t) => [
  index("driver_shifts_driver_idx").on(t.driverId, t.endedAt),
  index("driver_shifts_branch_idx").on(t.branchId),
  // At most ONE open shift per courier, enforced by the database (guards double taps / two devices).
  uniqueIndex("driver_shifts_one_open_idx").on(t.driverId).where(sql`ended_at is null`),
]);

export type DriverShift = typeof driverShiftsTable.$inferSelect;
