import { pgTable, serial, text, integer, timestamp, index } from "drizzle-orm/pg-core";

// API keys let a merchant's online store push orders straight into the system.
// Only a SHA-256 hash of the key is stored; the plaintext is shown once at creation.
export const apiKeysTable = pgTable("api_keys", {
  id: serial("id").primaryKey(),
  merchantId: integer("merchant_id").notNull(),
  name: text("name").notNull(),
  keyPrefix: text("key_prefix").notNull(),
  keyHash: text("key_hash").notNull().unique(),
  lastUsedAt: timestamp("last_used_at"),
  revokedAt: timestamp("revoked_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [
  index("api_keys_merchant_idx").on(t.merchantId),
]);

export type ApiKey = typeof apiKeysTable.$inferSelect;
