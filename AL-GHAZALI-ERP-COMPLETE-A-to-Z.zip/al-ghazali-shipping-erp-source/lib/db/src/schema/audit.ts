import { pgTable, serial, text, integer, timestamp, index } from "drizzle-orm/pg-core";

// Who did what, to what, and when — for the sensitive actions (money, permissions, deletions, overrides).
export const auditLogTable = pgTable("audit_log", {
  id: serial("id").primaryKey(),
  actorId: integer("actor_id"),
  actorName: text("actor_name").notNull(),
  actorRole: text("actor_role").notNull(),
  action: text("action").notNull(),            // e.g. order.delete, trip.override, permissions.update
  targetType: text("target_type"),             // order | trip | user | withdrawal | ...
  targetId: text("target_id"),
  details: text("details"),                    // short human-readable summary (Arabic)
  branchId: integer("branch_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [
  index("audit_log_created_idx").on(t.createdAt),
  index("audit_log_actor_idx").on(t.actorId),
  index("audit_log_action_idx").on(t.action),
]);

export type AuditEntry = typeof auditLogTable.$inferSelect;
