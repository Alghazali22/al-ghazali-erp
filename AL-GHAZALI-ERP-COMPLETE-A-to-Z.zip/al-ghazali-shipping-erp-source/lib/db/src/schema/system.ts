import { pgTable, serial, text, boolean, timestamp } from "drizzle-orm/pg-core";

export const announcementsTable = pgTable("announcements", {
  id: serial("id").primaryKey(),
  message: text("message"),
  isActive: boolean("is_active").notNull().default(false),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const systemSettingsTable = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  isShutdown: boolean("is_shutdown").notNull().default(false),
  shutdownMessage: text("shutdown_message").notNull().default("النظام مغلق مؤقتاً بواسطة الإدارة العليا لتحديث العمليات أو الجرد"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type Announcement = typeof announcementsTable.$inferSelect;
export type SystemSettings = typeof systemSettingsTable.$inferSelect;
