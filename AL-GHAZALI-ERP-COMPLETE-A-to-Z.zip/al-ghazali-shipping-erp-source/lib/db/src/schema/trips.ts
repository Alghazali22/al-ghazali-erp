import { pgTable, serial, text, integer, numeric, timestamp, pgEnum, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const tripStatusEnum = pgEnum("trip_status", ["draft", "confirmed", "in_progress", "completed"]);

export const tripsTable = pgTable("trips", {
  id: serial("id").primaryKey(),
  status: tripStatusEnum("status").notNull().default("draft"),
  driverId: integer("driver_id").notNull(),
  branchId: integer("branch_id").notNull(),
  confirmedAt: timestamp("confirmed_at"),
  // Handover: the courier confirms in their app that they received the parcels listed on the trip.
  acceptedAt: timestamp("accepted_at"),
  acceptedById: integer("accepted_by_id"),
  // The moment the courier left the branch (all parcels loaded + accepted, or a manager override).
  departedAt: timestamp("departed_at"),
  overrideReason: text("override_reason"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [
  index("trips_driver_idx").on(t.driverId),
  index("trips_branch_idx").on(t.branchId),
]);

export const insertTripSchema = createInsertSchema(tripsTable).omit({ id: true, createdAt: true });
export type InsertTrip = z.infer<typeof insertTripSchema>;
export type Trip = typeof tripsTable.$inferSelect;
