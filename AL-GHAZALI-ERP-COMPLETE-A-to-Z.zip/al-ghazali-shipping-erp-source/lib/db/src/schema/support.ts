import { pgTable, serial, text, integer, timestamp, index } from "drizzle-orm/pg-core";

// Customer-care tickets (complaint, delay, address change, reschedule…). Optionally tied to an order.
export const ticketsTable = pgTable("tickets", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id"),
  type: text("type").notNull().default("other"),          // complaint | delay | address_change | reschedule | damaged | cod_dispute | other
  priority: text("priority").notNull().default("normal"), // low | normal | high | urgent
  status: text("status").notNull().default("open"),       // open | in_progress | waiting | resolved | closed
  subject: text("subject").notNull(),
  createdById: integer("created_by_id").notNull(),
  assigneeId: integer("assignee_id"),
  branchId: integer("branch_id"),
  dueAt: timestamp("due_at").notNull(),                    // SLA deadline, from priority
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
}, (t) => [
  index("tickets_status_idx").on(t.status),
  index("tickets_order_idx").on(t.orderId),
  index("tickets_assignee_idx").on(t.assigneeId),
  index("tickets_branch_idx").on(t.branchId),
]);

// Internal thread on a ticket (never shown to the end customer).
export const ticketNotesTable = pgTable("ticket_notes", {
  id: serial("id").primaryKey(),
  ticketId: integer("ticket_id").notNull(),
  authorId: integer("author_id").notNull(),
  authorName: text("author_name").notNull(),
  kind: text("kind").notNull().default("note"),           // note | call | whatsapp | status
  body: text("body").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [index("ticket_notes_ticket_idx").on(t.ticketId)]);

// Contact log on an order: every call / message the care team made. Internal only — the public
// tracking timeline (order_events) is a different table on purpose.
export const orderNotesTable = pgTable("order_notes", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  authorId: integer("author_id").notNull(),
  authorName: text("author_name").notNull(),
  kind: text("kind").notNull().default("note"),           // note | call_answered | call_no_answer | whatsapp | reschedule
  body: text("body").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [index("order_notes_order_idx").on(t.orderId, t.createdAt)]);

export type Ticket = typeof ticketsTable.$inferSelect;
