import { pgTable, serial, text, boolean, numeric, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const zonesTable = pgTable("zones", {
  id: serial("id").primaryKey(),
  governorate: text("governorate").notNull(),
  area: text("area").notNull(),
  basePrice: numeric("base_price", { precision: 10, scale: 2 }).notNull(),
  returnPrice: numeric("return_price", { precision: 10, scale: 2 }).notNull().default("10"),
  isActive: boolean("is_active").notNull().default(true),
  lat: numeric("lat", { precision: 10, scale: 6 }),
  lng: numeric("lng", { precision: 10, scale: 6 }),
});

export const merchantPricingTable = pgTable("merchant_pricing", {
  id: serial("id").primaryKey(),
  merchantId: integer("merchant_id").notNull(),
  zoneId: integer("zone_id").notNull(),
  customPrice: numeric("custom_price", { precision: 10, scale: 2 }).notNull(),
});

export const insertZoneSchema = createInsertSchema(zonesTable).omit({ id: true });
export type InsertZone = z.infer<typeof insertZoneSchema>;
export type Zone = typeof zonesTable.$inferSelect;
export type MerchantPricing = typeof merchantPricingTable.$inferSelect;
