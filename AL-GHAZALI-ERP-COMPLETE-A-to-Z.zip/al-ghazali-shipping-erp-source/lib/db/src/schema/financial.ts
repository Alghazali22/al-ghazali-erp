import { pgTable, serial, text, integer, numeric, timestamp, boolean, pgEnum, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const transactionTypeEnum = pgEnum("transaction_type", [
  "driver_settlement", "merchant_withdrawal", "shipping_fee", "return_fee", "adjustment"
]);

export const withdrawalStatusEnum = pgEnum("withdrawal_status", ["pending", "approved", "rejected"]);

export const settlementsTable = pgTable("settlements", {
  id: serial("id").primaryKey(),
  driverId: integer("driver_id").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  settledById: integer("settled_by_id").notNull(),
  settledByName: text("settled_by_name").notNull(),
  branchId: integer("branch_id").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const withdrawalRequestsTable = pgTable("withdrawal_requests", {
  id: serial("id").primaryKey(),
  merchantId: integer("merchant_id").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  status: withdrawalStatusEnum("status").notNull().default("pending"),
  notes: text("notes"),
  processedById: integer("processed_by_id"),
  processedByName: text("processed_by_name"),
  receiptNumber: text("receipt_number").unique(),
  processedAt: timestamp("processed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [
  index("withdrawals_merchant_idx").on(t.merchantId),
  index("withdrawals_status_idx").on(t.status),
]);

export const treasuryTable = pgTable("treasury", {
  id: serial("id").primaryKey(),
  branchId: integer("branch_id").notNull().unique(),
  balance: numeric("balance", { precision: 14, scale: 2 }).notNull().default("0"),
  totalIn: numeric("total_in", { precision: 14, scale: 2 }).notNull().default("0"),
  totalOut: numeric("total_out", { precision: 14, scale: 2 }).notNull().default("0"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const transactionsTable = pgTable("transactions", {
  id: serial("id").primaryKey(),
  type: transactionTypeEnum("type").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  description: text("description").notNull(),
  reference: text("reference"),
  branchId: integer("branch_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [
  index("transactions_branch_idx").on(t.branchId),
  index("transactions_reference_idx").on(t.reference),
  index("transactions_created_at_idx").on(t.createdAt),
]);

export type Settlement = typeof settlementsTable.$inferSelect;
export type WithdrawalRequest = typeof withdrawalRequestsTable.$inferSelect;
export type Treasury = typeof treasuryTable.$inferSelect;
export type Transaction = typeof transactionsTable.$inferSelect;
