import { pgTable, serial, text, boolean, integer, numeric, timestamp, pgEnum, index, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const orderStatusEnum = pgEnum("order_status", [
  "pending", "ready", "in_transit", "delivered", "partial_delivery", "returned", "final_return"
]);

export const inventoryStatusEnum = pgEnum("inventory_status", [
  "awaiting_merchant_receipt", "in_warehouse", "transfer_out",
]);

export const transferStatusEnum = pgEnum("transfer_status", [
  "in_transit", "received",
]);

export const ordersTable = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  status: orderStatusEnum("status").notNull().default("pending"),
  inventoryStatus: inventoryStatusEnum("inventory_status").notNull().default("in_warehouse"),
  customerName: text("customer_name").notNull(),
  customerPhone: text("customer_phone").notNull(),
  customerPhone2: text("customer_phone2"),
  // Last 10 digits of the phone (digits only) — indexed key for the shared customer-reputation lookup.
  customerPhoneKey: text("customer_phone_key"),
  // Exact delivery pin shared by the customer through the tracking link.
  customerLat: numeric("customer_lat", { precision: 10, scale: 6 }),
  customerLng: numeric("customer_lng", { precision: 10, scale: 6 }),
  customerLocationAt: timestamp("customer_location_at"),
  // Position of this order inside its trip's optimised route (1 = first stop).
  stopSequence: integer("stop_sequence"),
  // Scanned into the courier's bag at the loading station (cleared when the trip is changed).
  loadedAt: timestamp("loaded_at"),
  // A returned parcel physically scanned back into the branch warehouse.
  returnedToBranchAt: timestamp("returned_to_branch_at"),
  // Where the order came from and, for API orders, the merchant's own reference (idempotency key).
  source: text("source").notNull().default("manual"),
  externalRef: text("external_ref"),
  customerAddress: text("customer_address").notNull(),
  governorate: text("governorate").notNull(),
  area: text("area").notNull(),
  packageValue: numeric("package_value", { precision: 12, scale: 2 }).notNull(),
  shippingFee: numeric("shipping_fee", { precision: 10, scale: 2 }).notNull(),
  totalToCollect: numeric("total_to_collect", { precision: 12, scale: 2 }).notNull(),
  notes: text("notes"),
  merchantId: integer("merchant_id").notNull(),
  branchId: integer("branch_id").notNull(),
  driverId: integer("driver_id"),
  tripId: integer("trip_id"),
  attemptCount: integer("attempt_count").notNull().default(0),
  collectedAmount: numeric("collected_amount", { precision: 12, scale: 2 }),
  otp: text("otp"),
  // true once the driver has handed the order's collected cash to the company; releases the merchant's money.
  cashSettled: boolean("cash_settled").notNull().default(false),
  otpAttempts: integer("otp_attempts").notNull().default(0),
  otpLockedUntil: timestamp("otp_locked_until"),
  deliveredAt: timestamp("delivered_at"),
  // Proof of Delivery (POD)
  podPhotoUrl: text("pod_photo_url"),
  podSignature: text("pod_signature"),
  podCapturedAt: timestamp("pod_captured_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [
  index("orders_status_idx").on(t.status),
  index("orders_merchant_idx").on(t.merchantId),
  index("orders_branch_idx").on(t.branchId),
  index("orders_driver_idx").on(t.driverId),
  index("orders_trip_idx").on(t.tripId),
  index("orders_created_at_idx").on(t.createdAt),
  index("orders_phone_key_idx").on(t.customerPhoneKey),
  uniqueIndex("orders_merchant_external_ref_idx").on(t.merchantId, t.externalRef),
]);

export const orderTransfersTable = pgTable("order_transfers", {
  id: serial("id").primaryKey(),
  transferNumber: text("transfer_number").notNull().unique(),
  orderId: integer("order_id").notNull(),
  fromBranchId: integer("from_branch_id").notNull(),
  toBranchId: integer("to_branch_id").notNull(),
  status: transferStatusEnum("status").notNull().default("in_transit"),
  createdById: integer("created_by_id").notNull(),
  createdByName: text("created_by_name"),
  receivedById: integer("received_by_id"),
  receivedByName: text("received_by_name"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  receivedAt: timestamp("received_at"),
}, (t) => [
  index("order_transfers_order_idx").on(t.orderId),
  index("order_transfers_to_branch_idx").on(t.toBranchId),
  index("order_transfers_from_branch_idx").on(t.fromBranchId),
]);

export const orderEventsTable = pgTable("order_events", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  status: text("status").notNull(),
  description: text("description").notNull(),
  actorId: integer("actor_id"),
  actorName: text("actor_name"),
  isEmergencyOtp: boolean("is_emergency_otp").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (t) => [
  index("order_events_order_idx").on(t.orderId),
]);

export const insertOrderSchema = createInsertSchema(ordersTable).omit({ id: true, createdAt: true, orderNumber: true, otp: true, otpAttempts: true, otpLockedUntil: true, cashSettled: true, customerPhoneKey: true, customerLat: true, customerLng: true, customerLocationAt: true, stopSequence: true, loadedAt: true, returnedToBranchAt: true, source: true, externalRef: true });
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof ordersTable.$inferSelect;
export type OrderTransfer = typeof orderTransfersTable.$inferSelect;
export type OrderEvent = typeof orderEventsTable.$inferSelect;
